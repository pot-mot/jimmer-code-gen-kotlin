package top.potmot.service.model.entities.properties

import cn.dev33.satoken.annotation.SaCheckPermission
import jakarta.validation.Valid
import org.babyfish.jimmer.Page
import org.babyfish.jimmer.sql.ast.mutation.AssociatedSaveMode
import org.babyfish.jimmer.sql.ast.mutation.SaveMode
import org.babyfish.jimmer.sql.kt.KSqlClient
import org.babyfish.jimmer.sql.kt.ast.expression.asc
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import top.potmot.entity.dto.query.PageQuery
import top.potmot.entity.model.entities.properties.GenEnumColumnProperty
import top.potmot.entity.model.entities.properties.dto.GenEnumColumnPropertyDetailView
import top.potmot.entity.model.entities.properties.dto.GenEnumColumnPropertyExistByPropertySpec
import top.potmot.entity.model.entities.properties.dto.GenEnumColumnPropertyInsertInput
import top.potmot.entity.model.entities.properties.dto.GenEnumColumnPropertyListView
import top.potmot.entity.model.entities.properties.dto.GenEnumColumnPropertyOptionView
import top.potmot.entity.model.entities.properties.dto.GenEnumColumnPropertySpec
import top.potmot.entity.model.entities.properties.dto.GenEnumColumnPropertyUpdateFillView
import top.potmot.entity.model.entities.properties.dto.GenEnumColumnPropertyUpdateInput
import top.potmot.entity.model.entities.properties.id
import top.potmot.exception.AuthorizeException

@RestController
@RequestMapping("/genEnumColumnProperty")
class GenEnumColumnPropertyService(
    private val sqlClient: KSqlClient
) {
    /**
     * 根据ID获取枚举列属性。
     *
     * @param id 枚举列属性的ID。
     * @return 枚举列属性的详细信息。
     */
    @GetMapping("/{id}")
    @SaCheckPermission("model:entities:properties:genEnumColumnProperty:get")
    @Throws(AuthorizeException::class)
    fun get(@PathVariable id: Int): GenEnumColumnPropertyDetailView? =
        sqlClient.findById(GenEnumColumnPropertyDetailView::class, id)

    /**
     * 根据提供的查询参数列出枚举列属性。
     *
     * @param spec 查询参数。
     * @return 枚举列属性列表数据。
     */
    @PostMapping("/list")
    @SaCheckPermission("model:entities:properties:genEnumColumnProperty:list")
    @Throws(AuthorizeException::class)
    fun list(@RequestBody spec: GenEnumColumnPropertySpec): List<GenEnumColumnPropertyListView> =
        sqlClient.executeQuery(GenEnumColumnProperty::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenEnumColumnPropertyListView::class))
        }

    /**
     * 根据提供的查询参数分页查询枚举列属性。
     *
     * @param query 分页查询参数。
     * @return 枚举列属性分页数据。
     */
    @PostMapping("/page")
    @SaCheckPermission("model:entities:properties:genEnumColumnProperty:list")
    @Throws(AuthorizeException::class)
    fun page(@RequestBody query: PageQuery<GenEnumColumnPropertySpec>): Page<GenEnumColumnPropertyListView> =
        sqlClient.createQuery(GenEnumColumnProperty::class) {
            where(query.spec)
            orderBy(table.id.asc())
            select(table.fetch(GenEnumColumnPropertyListView::class))
        }.fetchPage(query.pageIndex, query.pageSize)

    /**
     * 根据提供的查询参数列出枚举列属性选项。
     *
     * @param spec 查询参数。
     * @return 枚举列属性列表数据。
     */
    @PostMapping("/list/options")
    @SaCheckPermission("model:entities:properties:genEnumColumnProperty:select")
    @Throws(AuthorizeException::class)
    fun listOptions(@RequestBody spec: GenEnumColumnPropertySpec): List<GenEnumColumnPropertyOptionView> =
        sqlClient.executeQuery(GenEnumColumnProperty::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenEnumColumnPropertyOptionView::class))
        }

    /**
     * 插入新的枚举列属性。
     *
     * @param input 枚举列属性插入输入对象。
     * @return 插入的枚举列属性的ID。
     */
    @PostMapping
    @SaCheckPermission("model:entities:properties:genEnumColumnProperty:insert")
    @Throws(AuthorizeException::class)
    @Transactional
    fun insert(@RequestBody @Valid input: GenEnumColumnPropertyInsertInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.INSERT_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 根据ID获取枚举列属性的更新回填信息。
     *
     * @param id 枚举列属性的ID。
     * @return 枚举列属性的更新回填信息。
     */
    @GetMapping("/{id}/forUpdate")
    @SaCheckPermission("model:entities:properties:genEnumColumnProperty:update")
    @Throws(AuthorizeException::class)
    fun getForUpdate(@PathVariable id: Int): GenEnumColumnPropertyUpdateFillView? =
        sqlClient.findById(GenEnumColumnPropertyUpdateFillView::class, id)

    /**
     * 更新枚举列属性。
     *
     * @param input 枚举列属性更新输入对象。
     * @return 更新的枚举列属性的ID。
     */
    @PutMapping
    @SaCheckPermission("model:entities:properties:genEnumColumnProperty:update")
    @Throws(AuthorizeException::class)
    @Transactional
    fun update(@RequestBody @Valid input: GenEnumColumnPropertyUpdateInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.UPDATE_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 删除指定ID的枚举列属性。
     *
     * @param ids 要删除的枚举列属性ID列表。
     * @return 删除的枚举列属性的行数。
     */
    @DeleteMapping
    @SaCheckPermission("model:entities:properties:genEnumColumnProperty:delete")
    @Throws(AuthorizeException::class)
    @Transactional
    fun delete(@RequestParam ids: List<Int>): Int =
        sqlClient.deleteByIds(GenEnumColumnProperty::class, ids).affectedRowCount(GenEnumColumnProperty::class)

    /**
     * 根据 属性 校验枚举列属性是否存在。
     *
     * @param spec 枚举列属性校验规格对象。
     * @return 枚举列属性是否存在。
     */
    @PostMapping("/existByProperty")
    @SaCheckPermission("model:entities:properties:genEnumColumnProperty:list")
    @Throws(AuthorizeException::class)
    fun existByProperty(@RequestBody spec: GenEnumColumnPropertyExistByPropertySpec): Boolean =
        sqlClient.createQuery(GenEnumColumnProperty::class) {
            where(spec)
            select(table)
        }.exists()
}