package top.potmot.service.model.entities.properties

import cn.dev33.satoken.annotation.SaCheckPermission
import jakarta.validation.Valid
import org.babyfish.jimmer.Page
import org.babyfish.jimmer.sql.ast.mutation.AssociatedSaveMode
import org.babyfish.jimmer.sql.ast.mutation.SaveMode
import org.babyfish.jimmer.sql.kt.KSqlClient
import org.babyfish.jimmer.sql.kt.ast.expression.asc
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import top.potmot.entity.dto.query.PageQuery
import top.potmot.entity.model.entities.properties.GenManyToOneSourceProperty
import top.potmot.entity.model.entities.properties.dto.GenManyToOneSourcePropertyDetailView
import top.potmot.entity.model.entities.properties.dto.GenManyToOneSourcePropertyExistByPropertySpec
import top.potmot.entity.model.entities.properties.dto.GenManyToOneSourcePropertyInsertInput
import top.potmot.entity.model.entities.properties.dto.GenManyToOneSourcePropertyListView
import top.potmot.entity.model.entities.properties.dto.GenManyToOneSourcePropertyOptionView
import top.potmot.entity.model.entities.properties.dto.GenManyToOneSourcePropertySpec
import top.potmot.entity.model.entities.properties.dto.GenManyToOneSourcePropertyUpdateFillView
import top.potmot.entity.model.entities.properties.dto.GenManyToOneSourcePropertyUpdateInput
import top.potmot.entity.model.entities.properties.id
import top.potmot.exception.AuthorizeException

@RestController
@RequestMapping("/genManyToOneSourceProperty")
class GenManyToOneSourcePropertyService(
    private val sqlClient: KSqlClient
) {
    /**
     * 根据ID获取多对一源属性（对单）。
     *
     * @param id 多对一源属性（对单）的ID。
     * @return 多对一源属性（对单）的详细信息。
     */
    @GetMapping("/{id}")
    @SaCheckPermission("model:entities:properties:genManyToOneSourceProperty:get")
    @Throws(AuthorizeException::class)
    fun get(@PathVariable id: Int): GenManyToOneSourcePropertyDetailView? =
        sqlClient.findById(GenManyToOneSourcePropertyDetailView::class, id)

    /**
     * 根据提供的查询参数列出多对一源属性（对单）。
     *
     * @param spec 查询参数。
     * @return 多对一源属性（对单）列表数据。
     */
    @PostMapping("/list")
    @SaCheckPermission("model:entities:properties:genManyToOneSourceProperty:list")
    @Throws(AuthorizeException::class)
    fun list(@RequestBody spec: GenManyToOneSourcePropertySpec): List<GenManyToOneSourcePropertyListView> =
        sqlClient.executeQuery(GenManyToOneSourceProperty::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenManyToOneSourcePropertyListView::class))
        }

    /**
     * 根据提供的查询参数分页查询多对一源属性（对单）。
     *
     * @param query 分页查询参数。
     * @return 多对一源属性（对单）分页数据。
     */
    @PostMapping("/page")
    @SaCheckPermission("model:entities:properties:genManyToOneSourceProperty:list")
    @Throws(AuthorizeException::class)
    fun page(@RequestBody query: PageQuery<GenManyToOneSourcePropertySpec>): Page<GenManyToOneSourcePropertyListView> =
        sqlClient.createQuery(GenManyToOneSourceProperty::class) {
            where(query.spec)
            orderBy(table.id.asc())
            select(table.fetch(GenManyToOneSourcePropertyListView::class))
        }.fetchPage(query.pageIndex, query.pageSize)

    /**
     * 根据提供的查询参数列出多对一源属性（对单）选项。
     *
     * @param spec 查询参数。
     * @return 多对一源属性（对单）列表数据。
     */
    @PostMapping("/list/options")
    @SaCheckPermission("model:entities:properties:genManyToOneSourceProperty:select")
    @Throws(AuthorizeException::class)
    fun listOptions(@RequestBody spec: GenManyToOneSourcePropertySpec): List<GenManyToOneSourcePropertyOptionView> =
        sqlClient.executeQuery(GenManyToOneSourceProperty::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenManyToOneSourcePropertyOptionView::class))
        }

    /**
     * 插入新的多对一源属性（对单）。
     *
     * @param input 多对一源属性（对单）插入输入对象。
     * @return 插入的多对一源属性（对单）的ID。
     */
    @PostMapping
    @SaCheckPermission("model:entities:properties:genManyToOneSourceProperty:insert")
    @Throws(AuthorizeException::class)
    @Transactional
    fun insert(@RequestBody @Valid input: GenManyToOneSourcePropertyInsertInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.INSERT_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 根据ID获取多对一源属性（对单）的更新回填信息。
     *
     * @param id 多对一源属性（对单）的ID。
     * @return 多对一源属性（对单）的更新回填信息。
     */
    @GetMapping("/{id}/forUpdate")
    @SaCheckPermission("model:entities:properties:genManyToOneSourceProperty:update")
    @Throws(AuthorizeException::class)
    fun getForUpdate(@PathVariable id: Int): GenManyToOneSourcePropertyUpdateFillView? =
        sqlClient.findById(GenManyToOneSourcePropertyUpdateFillView::class, id)

    /**
     * 更新多对一源属性（对单）。
     *
     * @param input 多对一源属性（对单）更新输入对象。
     * @return 更新的多对一源属性（对单）的ID。
     */
    @PutMapping
    @SaCheckPermission("model:entities:properties:genManyToOneSourceProperty:update")
    @Throws(AuthorizeException::class)
    @Transactional
    fun update(@RequestBody @Valid input: GenManyToOneSourcePropertyUpdateInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.UPDATE_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 删除指定ID的多对一源属性（对单）。
     *
     * @param ids 要删除的多对一源属性（对单）ID列表。
     * @return 删除的多对一源属性（对单）的行数。
     */
    @DeleteMapping
    @SaCheckPermission("model:entities:properties:genManyToOneSourceProperty:delete")
    @Throws(AuthorizeException::class)
    @Transactional
    fun delete(@RequestParam ids: List<Int>): Int =
        sqlClient.deleteByIds(GenManyToOneSourceProperty::class, ids).affectedRowCount(GenManyToOneSourceProperty::class)

    /**
     * 根据 属性 校验多对一源属性（对单）是否存在。
     *
     * @param spec 多对一源属性（对单）校验规格对象。
     * @return 多对一源属性（对单）是否存在。
     */
    @PostMapping("/existByProperty")
    @SaCheckPermission("model:entities:properties:genManyToOneSourceProperty:list")
    @Throws(AuthorizeException::class)
    fun existByProperty(@RequestBody spec: GenManyToOneSourcePropertyExistByPropertySpec): Boolean =
        sqlClient.createQuery(GenManyToOneSourceProperty::class) {
            where(spec)
            select(table)
        }.exists()
}