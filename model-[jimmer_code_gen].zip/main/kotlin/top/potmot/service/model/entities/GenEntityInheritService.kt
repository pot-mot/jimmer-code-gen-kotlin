package top.potmot.service.model.entities

import cn.dev33.satoken.annotation.SaCheckPermission
import jakarta.validation.Valid
import org.babyfish.jimmer.Page
import org.babyfish.jimmer.sql.ast.mutation.AssociatedSaveMode
import org.babyfish.jimmer.sql.ast.mutation.SaveMode
import org.babyfish.jimmer.sql.kt.KSqlClient
import org.babyfish.jimmer.sql.kt.ast.expression.asc
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import top.potmot.entity.dto.query.PageQuery
import top.potmot.entity.model.entities.GenEntityInherit
import top.potmot.entity.model.entities.dto.GenEntityInheritDetailView
import top.potmot.entity.model.entities.dto.GenEntityInheritExistByParentAndChildSpec
import top.potmot.entity.model.entities.dto.GenEntityInheritInsertInput
import top.potmot.entity.model.entities.dto.GenEntityInheritListView
import top.potmot.entity.model.entities.dto.GenEntityInheritOptionView
import top.potmot.entity.model.entities.dto.GenEntityInheritSpec
import top.potmot.entity.model.entities.dto.GenEntityInheritUpdateFillView
import top.potmot.entity.model.entities.dto.GenEntityInheritUpdateInput
import top.potmot.entity.model.entities.id
import top.potmot.exception.AuthorizeException

@RestController
@RequestMapping("/genEntityInherit")
class GenEntityInheritService(
    private val sqlClient: KSqlClient
) {
    /**
     * 根据ID获取实体继承。
     *
     * @param id 实体继承的ID。
     * @return 实体继承的详细信息。
     */
    @GetMapping("/{id}")
    @SaCheckPermission("model:entities:genEntityInherit:get")
    @Throws(AuthorizeException::class)
    fun get(@PathVariable id: Int): GenEntityInheritDetailView? =
        sqlClient.findById(GenEntityInheritDetailView::class, id)

    /**
     * 根据提供的查询参数列出实体继承。
     *
     * @param spec 查询参数。
     * @return 实体继承列表数据。
     */
    @PostMapping("/list")
    @SaCheckPermission("model:entities:genEntityInherit:list")
    @Throws(AuthorizeException::class)
    fun list(@RequestBody spec: GenEntityInheritSpec): List<GenEntityInheritListView> =
        sqlClient.executeQuery(GenEntityInherit::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenEntityInheritListView::class))
        }

    /**
     * 根据提供的查询参数分页查询实体继承。
     *
     * @param query 分页查询参数。
     * @return 实体继承分页数据。
     */
    @PostMapping("/page")
    @SaCheckPermission("model:entities:genEntityInherit:list")
    @Throws(AuthorizeException::class)
    fun page(@RequestBody query: PageQuery<GenEntityInheritSpec>): Page<GenEntityInheritListView> =
        sqlClient.createQuery(GenEntityInherit::class) {
            where(query.spec)
            orderBy(table.id.asc())
            select(table.fetch(GenEntityInheritListView::class))
        }.fetchPage(query.pageIndex, query.pageSize)

    /**
     * 根据提供的查询参数列出实体继承选项。
     *
     * @param spec 查询参数。
     * @return 实体继承列表数据。
     */
    @PostMapping("/list/options")
    @SaCheckPermission("model:entities:genEntityInherit:select")
    @Throws(AuthorizeException::class)
    fun listOptions(@RequestBody spec: GenEntityInheritSpec): List<GenEntityInheritOptionView> =
        sqlClient.executeQuery(GenEntityInherit::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenEntityInheritOptionView::class))
        }

    /**
     * 插入新的实体继承。
     *
     * @param input 实体继承插入输入对象。
     * @return 插入的实体继承的ID。
     */
    @PostMapping
    @SaCheckPermission("model:entities:genEntityInherit:insert")
    @Throws(AuthorizeException::class)
    @Transactional
    fun insert(@RequestBody @Valid input: GenEntityInheritInsertInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.INSERT_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 根据ID获取实体继承的更新回填信息。
     *
     * @param id 实体继承的ID。
     * @return 实体继承的更新回填信息。
     */
    @GetMapping("/{id}/forUpdate")
    @SaCheckPermission("model:entities:genEntityInherit:update")
    @Throws(AuthorizeException::class)
    fun getForUpdate(@PathVariable id: Int): GenEntityInheritUpdateFillView? =
        sqlClient.findById(GenEntityInheritUpdateFillView::class, id)

    /**
     * 更新实体继承。
     *
     * @param input 实体继承更新输入对象。
     * @return 更新的实体继承的ID。
     */
    @PutMapping
    @SaCheckPermission("model:entities:genEntityInherit:update")
    @Throws(AuthorizeException::class)
    @Transactional
    fun update(@RequestBody @Valid input: GenEntityInheritUpdateInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.UPDATE_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 删除指定ID的实体继承。
     *
     * @param ids 要删除的实体继承ID列表。
     * @return 删除的实体继承的行数。
     */
    @DeleteMapping
    @SaCheckPermission("model:entities:genEntityInherit:delete")
    @Throws(AuthorizeException::class)
    @Transactional
    fun delete(@RequestParam ids: List<Int>): Int =
        sqlClient.deleteByIds(GenEntityInherit::class, ids).affectedRowCount(GenEntityInherit::class)

    /**
     * 根据 父级 和 子级 校验实体继承是否存在。
     *
     * @param spec 实体继承校验规格对象。
     * @return 实体继承是否存在。
     */
    @PostMapping("/existByParentAndChild")
    @SaCheckPermission("model:entities:genEntityInherit:list")
    @Throws(AuthorizeException::class)
    fun existByParentAndChild(@RequestBody spec: GenEntityInheritExistByParentAndChildSpec): Boolean =
        sqlClient.createQuery(GenEntityInherit::class) {
            where(spec)
            select(table)
        }.exists()
}