package top.potmot.service.model.entities.properties

import cn.dev33.satoken.annotation.SaCheckPermission
import jakarta.validation.Valid
import org.babyfish.jimmer.Page
import org.babyfish.jimmer.sql.ast.mutation.AssociatedSaveMode
import org.babyfish.jimmer.sql.ast.mutation.SaveMode
import org.babyfish.jimmer.sql.kt.KSqlClient
import org.babyfish.jimmer.sql.kt.ast.expression.asc
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import top.potmot.entity.dto.query.PageQuery
import top.potmot.entity.model.entities.properties.GenLogicalDeleteProperty
import top.potmot.entity.model.entities.properties.dto.GenLogicalDeletePropertyDetailView
import top.potmot.entity.model.entities.properties.dto.GenLogicalDeletePropertyExistByPropertySpec
import top.potmot.entity.model.entities.properties.dto.GenLogicalDeletePropertyInsertInput
import top.potmot.entity.model.entities.properties.dto.GenLogicalDeletePropertyListView
import top.potmot.entity.model.entities.properties.dto.GenLogicalDeletePropertyOptionView
import top.potmot.entity.model.entities.properties.dto.GenLogicalDeletePropertySpec
import top.potmot.entity.model.entities.properties.dto.GenLogicalDeletePropertyUpdateFillView
import top.potmot.entity.model.entities.properties.dto.GenLogicalDeletePropertyUpdateInput
import top.potmot.entity.model.entities.properties.id
import top.potmot.exception.AuthorizeException

@RestController
@RequestMapping("/genLogicalDeleteProperty")
class GenLogicalDeletePropertyService(
    private val sqlClient: KSqlClient
) {
    /**
     * 根据ID获取逻辑删除属性。
     *
     * @param id 逻辑删除属性的ID。
     * @return 逻辑删除属性的详细信息。
     */
    @GetMapping("/{id}")
    @SaCheckPermission("model:entities:properties:genLogicalDeleteProperty:get")
    @Throws(AuthorizeException::class)
    fun get(@PathVariable id: Int): GenLogicalDeletePropertyDetailView? =
        sqlClient.findById(GenLogicalDeletePropertyDetailView::class, id)

    /**
     * 根据提供的查询参数列出逻辑删除属性。
     *
     * @param spec 查询参数。
     * @return 逻辑删除属性列表数据。
     */
    @PostMapping("/list")
    @SaCheckPermission("model:entities:properties:genLogicalDeleteProperty:list")
    @Throws(AuthorizeException::class)
    fun list(@RequestBody spec: GenLogicalDeletePropertySpec): List<GenLogicalDeletePropertyListView> =
        sqlClient.executeQuery(GenLogicalDeleteProperty::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenLogicalDeletePropertyListView::class))
        }

    /**
     * 根据提供的查询参数分页查询逻辑删除属性。
     *
     * @param query 分页查询参数。
     * @return 逻辑删除属性分页数据。
     */
    @PostMapping("/page")
    @SaCheckPermission("model:entities:properties:genLogicalDeleteProperty:list")
    @Throws(AuthorizeException::class)
    fun page(@RequestBody query: PageQuery<GenLogicalDeletePropertySpec>): Page<GenLogicalDeletePropertyListView> =
        sqlClient.createQuery(GenLogicalDeleteProperty::class) {
            where(query.spec)
            orderBy(table.id.asc())
            select(table.fetch(GenLogicalDeletePropertyListView::class))
        }.fetchPage(query.pageIndex, query.pageSize)

    /**
     * 根据提供的查询参数列出逻辑删除属性选项。
     *
     * @param spec 查询参数。
     * @return 逻辑删除属性列表数据。
     */
    @PostMapping("/list/options")
    @SaCheckPermission("model:entities:properties:genLogicalDeleteProperty:select")
    @Throws(AuthorizeException::class)
    fun listOptions(@RequestBody spec: GenLogicalDeletePropertySpec): List<GenLogicalDeletePropertyOptionView> =
        sqlClient.executeQuery(GenLogicalDeleteProperty::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenLogicalDeletePropertyOptionView::class))
        }

    /**
     * 插入新的逻辑删除属性。
     *
     * @param input 逻辑删除属性插入输入对象。
     * @return 插入的逻辑删除属性的ID。
     */
    @PostMapping
    @SaCheckPermission("model:entities:properties:genLogicalDeleteProperty:insert")
    @Throws(AuthorizeException::class)
    @Transactional
    fun insert(@RequestBody @Valid input: GenLogicalDeletePropertyInsertInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.INSERT_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 根据ID获取逻辑删除属性的更新回填信息。
     *
     * @param id 逻辑删除属性的ID。
     * @return 逻辑删除属性的更新回填信息。
     */
    @GetMapping("/{id}/forUpdate")
    @SaCheckPermission("model:entities:properties:genLogicalDeleteProperty:update")
    @Throws(AuthorizeException::class)
    fun getForUpdate(@PathVariable id: Int): GenLogicalDeletePropertyUpdateFillView? =
        sqlClient.findById(GenLogicalDeletePropertyUpdateFillView::class, id)

    /**
     * 更新逻辑删除属性。
     *
     * @param input 逻辑删除属性更新输入对象。
     * @return 更新的逻辑删除属性的ID。
     */
    @PutMapping
    @SaCheckPermission("model:entities:properties:genLogicalDeleteProperty:update")
    @Throws(AuthorizeException::class)
    @Transactional
    fun update(@RequestBody @Valid input: GenLogicalDeletePropertyUpdateInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.UPDATE_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 删除指定ID的逻辑删除属性。
     *
     * @param ids 要删除的逻辑删除属性ID列表。
     * @return 删除的逻辑删除属性的行数。
     */
    @DeleteMapping
    @SaCheckPermission("model:entities:properties:genLogicalDeleteProperty:delete")
    @Throws(AuthorizeException::class)
    @Transactional
    fun delete(@RequestParam ids: List<Int>): Int =
        sqlClient.deleteByIds(GenLogicalDeleteProperty::class, ids).affectedRowCount(GenLogicalDeleteProperty::class)

    /**
     * 根据 属性 校验逻辑删除属性是否存在。
     *
     * @param spec 逻辑删除属性校验规格对象。
     * @return 逻辑删除属性是否存在。
     */
    @PostMapping("/existByProperty")
    @SaCheckPermission("model:entities:properties:genLogicalDeleteProperty:list")
    @Throws(AuthorizeException::class)
    fun existByProperty(@RequestBody spec: GenLogicalDeletePropertyExistByPropertySpec): Boolean =
        sqlClient.createQuery(GenLogicalDeleteProperty::class) {
            where(spec)
            select(table)
        }.exists()
}