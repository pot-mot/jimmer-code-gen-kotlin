package top.potmot.service.model.entities.properties

import cn.dev33.satoken.annotation.SaCheckPermission
import jakarta.validation.Valid
import org.babyfish.jimmer.Page
import org.babyfish.jimmer.sql.ast.mutation.AssociatedSaveMode
import org.babyfish.jimmer.sql.ast.mutation.SaveMode
import org.babyfish.jimmer.sql.kt.KSqlClient
import org.babyfish.jimmer.sql.kt.ast.expression.asc
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import top.potmot.entity.dto.query.PageQuery
import top.potmot.entity.model.entities.properties.GenEmbeddableProperty
import top.potmot.entity.model.entities.properties.dto.GenEmbeddablePropertyDetailView
import top.potmot.entity.model.entities.properties.dto.GenEmbeddablePropertyExistByPropertySpec
import top.potmot.entity.model.entities.properties.dto.GenEmbeddablePropertyInsertInput
import top.potmot.entity.model.entities.properties.dto.GenEmbeddablePropertyListView
import top.potmot.entity.model.entities.properties.dto.GenEmbeddablePropertyOptionView
import top.potmot.entity.model.entities.properties.dto.GenEmbeddablePropertySpec
import top.potmot.entity.model.entities.properties.dto.GenEmbeddablePropertyUpdateFillView
import top.potmot.entity.model.entities.properties.dto.GenEmbeddablePropertyUpdateInput
import top.potmot.entity.model.entities.properties.id
import top.potmot.exception.AuthorizeException

@RestController
@RequestMapping("/genEmbeddableProperty")
class GenEmbeddablePropertyService(
    private val sqlClient: KSqlClient
) {
    /**
     * 根据ID获取复合属性。
     *
     * @param id 复合属性的ID。
     * @return 复合属性的详细信息。
     */
    @GetMapping("/{id}")
    @SaCheckPermission("model:entities:properties:genEmbeddableProperty:get")
    @Throws(AuthorizeException::class)
    fun get(@PathVariable id: Int): GenEmbeddablePropertyDetailView? =
        sqlClient.findById(GenEmbeddablePropertyDetailView::class, id)

    /**
     * 根据提供的查询参数列出复合属性。
     *
     * @param spec 查询参数。
     * @return 复合属性列表数据。
     */
    @PostMapping("/list")
    @SaCheckPermission("model:entities:properties:genEmbeddableProperty:list")
    @Throws(AuthorizeException::class)
    fun list(@RequestBody spec: GenEmbeddablePropertySpec): List<GenEmbeddablePropertyListView> =
        sqlClient.executeQuery(GenEmbeddableProperty::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenEmbeddablePropertyListView::class))
        }

    /**
     * 根据提供的查询参数分页查询复合属性。
     *
     * @param query 分页查询参数。
     * @return 复合属性分页数据。
     */
    @PostMapping("/page")
    @SaCheckPermission("model:entities:properties:genEmbeddableProperty:list")
    @Throws(AuthorizeException::class)
    fun page(@RequestBody query: PageQuery<GenEmbeddablePropertySpec>): Page<GenEmbeddablePropertyListView> =
        sqlClient.createQuery(GenEmbeddableProperty::class) {
            where(query.spec)
            orderBy(table.id.asc())
            select(table.fetch(GenEmbeddablePropertyListView::class))
        }.fetchPage(query.pageIndex, query.pageSize)

    /**
     * 根据提供的查询参数列出复合属性选项。
     *
     * @param spec 查询参数。
     * @return 复合属性列表数据。
     */
    @PostMapping("/list/options")
    @SaCheckPermission("model:entities:properties:genEmbeddableProperty:select")
    @Throws(AuthorizeException::class)
    fun listOptions(@RequestBody spec: GenEmbeddablePropertySpec): List<GenEmbeddablePropertyOptionView> =
        sqlClient.executeQuery(GenEmbeddableProperty::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenEmbeddablePropertyOptionView::class))
        }

    /**
     * 插入新的复合属性。
     *
     * @param input 复合属性插入输入对象。
     * @return 插入的复合属性的ID。
     */
    @PostMapping
    @SaCheckPermission("model:entities:properties:genEmbeddableProperty:insert")
    @Throws(AuthorizeException::class)
    @Transactional
    fun insert(@RequestBody @Valid input: GenEmbeddablePropertyInsertInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.INSERT_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 根据ID获取复合属性的更新回填信息。
     *
     * @param id 复合属性的ID。
     * @return 复合属性的更新回填信息。
     */
    @GetMapping("/{id}/forUpdate")
    @SaCheckPermission("model:entities:properties:genEmbeddableProperty:update")
    @Throws(AuthorizeException::class)
    fun getForUpdate(@PathVariable id: Int): GenEmbeddablePropertyUpdateFillView? =
        sqlClient.findById(GenEmbeddablePropertyUpdateFillView::class, id)

    /**
     * 更新复合属性。
     *
     * @param input 复合属性更新输入对象。
     * @return 更新的复合属性的ID。
     */
    @PutMapping
    @SaCheckPermission("model:entities:properties:genEmbeddableProperty:update")
    @Throws(AuthorizeException::class)
    @Transactional
    fun update(@RequestBody @Valid input: GenEmbeddablePropertyUpdateInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.UPDATE_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 删除指定ID的复合属性。
     *
     * @param ids 要删除的复合属性ID列表。
     * @return 删除的复合属性的行数。
     */
    @DeleteMapping
    @SaCheckPermission("model:entities:properties:genEmbeddableProperty:delete")
    @Throws(AuthorizeException::class)
    @Transactional
    fun delete(@RequestParam ids: List<Int>): Int =
        sqlClient.deleteByIds(GenEmbeddableProperty::class, ids).affectedRowCount(GenEmbeddableProperty::class)

    /**
     * 根据 属性 校验复合属性是否存在。
     *
     * @param spec 复合属性校验规格对象。
     * @return 复合属性是否存在。
     */
    @PostMapping("/existByProperty")
    @SaCheckPermission("model:entities:properties:genEmbeddableProperty:list")
    @Throws(AuthorizeException::class)
    fun existByProperty(@RequestBody spec: GenEmbeddablePropertyExistByPropertySpec): Boolean =
        sqlClient.createQuery(GenEmbeddableProperty::class) {
            where(spec)
            select(table)
        }.exists()
}