package top.potmot.service.model.entities

import cn.dev33.satoken.annotation.SaCheckPermission
import jakarta.validation.Valid
import org.babyfish.jimmer.Page
import org.babyfish.jimmer.sql.ast.mutation.AssociatedSaveMode
import org.babyfish.jimmer.sql.ast.mutation.SaveMode
import org.babyfish.jimmer.sql.kt.KSqlClient
import org.babyfish.jimmer.sql.kt.ast.expression.asc
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import top.potmot.entity.dto.query.PageQuery
import top.potmot.entity.model.entities.GenEntity
import top.potmot.entity.model.entities.dto.GenEntityDetailView
import top.potmot.entity.model.entities.dto.GenEntityExistByGroupAndInterfaceNameSpec
import top.potmot.entity.model.entities.dto.GenEntityInsertInput
import top.potmot.entity.model.entities.dto.GenEntityListView
import top.potmot.entity.model.entities.dto.GenEntityOptionView
import top.potmot.entity.model.entities.dto.GenEntitySpec
import top.potmot.entity.model.entities.dto.GenEntityUpdateFillView
import top.potmot.entity.model.entities.dto.GenEntityUpdateInput
import top.potmot.entity.model.entities.id
import top.potmot.exception.AuthorizeException

@RestController
@RequestMapping("/genEntity")
class GenEntityService(
    private val sqlClient: KSqlClient
) {
    /**
     * 根据ID获取实体。
     *
     * @param id 实体的ID。
     * @return 实体的详细信息。
     */
    @GetMapping("/{id}")
    @SaCheckPermission("model:entities:genEntity:get")
    @Throws(AuthorizeException::class)
    fun get(@PathVariable id: Int): GenEntityDetailView? =
        sqlClient.findById(GenEntityDetailView::class, id)

    /**
     * 根据提供的查询参数列出实体。
     *
     * @param spec 查询参数。
     * @return 实体列表数据。
     */
    @PostMapping("/list")
    @SaCheckPermission("model:entities:genEntity:list")
    @Throws(AuthorizeException::class)
    fun list(@RequestBody spec: GenEntitySpec): List<GenEntityListView> =
        sqlClient.executeQuery(GenEntity::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenEntityListView::class))
        }

    /**
     * 根据提供的查询参数分页查询实体。
     *
     * @param query 分页查询参数。
     * @return 实体分页数据。
     */
    @PostMapping("/page")
    @SaCheckPermission("model:entities:genEntity:list")
    @Throws(AuthorizeException::class)
    fun page(@RequestBody query: PageQuery<GenEntitySpec>): Page<GenEntityListView> =
        sqlClient.createQuery(GenEntity::class) {
            where(query.spec)
            orderBy(table.id.asc())
            select(table.fetch(GenEntityListView::class))
        }.fetchPage(query.pageIndex, query.pageSize)

    /**
     * 根据提供的查询参数列出实体选项。
     *
     * @param spec 查询参数。
     * @return 实体列表数据。
     */
    @PostMapping("/list/options")
    @SaCheckPermission("model:entities:genEntity:select")
    @Throws(AuthorizeException::class)
    fun listOptions(@RequestBody spec: GenEntitySpec): List<GenEntityOptionView> =
        sqlClient.executeQuery(GenEntity::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenEntityOptionView::class))
        }

    /**
     * 插入新的实体。
     *
     * @param input 实体插入输入对象。
     * @return 插入的实体的ID。
     */
    @PostMapping
    @SaCheckPermission("model:entities:genEntity:insert")
    @Throws(AuthorizeException::class)
    @Transactional
    fun insert(@RequestBody @Valid input: GenEntityInsertInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.INSERT_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 根据ID获取实体的更新回填信息。
     *
     * @param id 实体的ID。
     * @return 实体的更新回填信息。
     */
    @GetMapping("/{id}/forUpdate")
    @SaCheckPermission("model:entities:genEntity:update")
    @Throws(AuthorizeException::class)
    fun getForUpdate(@PathVariable id: Int): GenEntityUpdateFillView? =
        sqlClient.findById(GenEntityUpdateFillView::class, id)

    /**
     * 更新实体。
     *
     * @param input 实体更新输入对象。
     * @return 更新的实体的ID。
     */
    @PutMapping
    @SaCheckPermission("model:entities:genEntity:update")
    @Throws(AuthorizeException::class)
    @Transactional
    fun update(@RequestBody @Valid input: GenEntityUpdateInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.UPDATE_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 删除指定ID的实体。
     *
     * @param ids 要删除的实体ID列表。
     * @return 删除的实体的行数。
     */
    @DeleteMapping
    @SaCheckPermission("model:entities:genEntity:delete")
    @Throws(AuthorizeException::class)
    @Transactional
    fun delete(@RequestParam ids: List<Int>): Int =
        sqlClient.deleteByIds(GenEntity::class, ids).affectedRowCount(GenEntity::class)

    /**
     * 根据 分组 和 接口名称 校验实体是否存在。
     *
     * @param spec 实体校验规格对象。
     * @return 实体是否存在。
     */
    @PostMapping("/existByGroupAndInterfaceName")
    @SaCheckPermission("model:entities:genEntity:list")
    @Throws(AuthorizeException::class)
    fun existByGroupAndInterfaceName(@RequestBody spec: GenEntityExistByGroupAndInterfaceNameSpec): Boolean =
        sqlClient.createQuery(GenEntity::class) {
            where(spec)
            select(table)
        }.exists()
}