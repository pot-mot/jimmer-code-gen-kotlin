package top.potmot.service.model.entities.properties

import cn.dev33.satoken.annotation.SaCheckPermission
import jakarta.validation.Valid
import org.babyfish.jimmer.Page
import org.babyfish.jimmer.sql.ast.mutation.AssociatedSaveMode
import org.babyfish.jimmer.sql.ast.mutation.SaveMode
import org.babyfish.jimmer.sql.kt.KSqlClient
import org.babyfish.jimmer.sql.kt.ast.expression.asc
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import top.potmot.entity.dto.query.PageQuery
import top.potmot.entity.model.entities.properties.GenManyToManyMappedProperty
import top.potmot.entity.model.entities.properties.dto.GenManyToManyMappedPropertyDetailView
import top.potmot.entity.model.entities.properties.dto.GenManyToManyMappedPropertyExistByMappedBySpec
import top.potmot.entity.model.entities.properties.dto.GenManyToManyMappedPropertyExistByPropertySpec
import top.potmot.entity.model.entities.properties.dto.GenManyToManyMappedPropertyInsertInput
import top.potmot.entity.model.entities.properties.dto.GenManyToManyMappedPropertyListView
import top.potmot.entity.model.entities.properties.dto.GenManyToManyMappedPropertyOptionView
import top.potmot.entity.model.entities.properties.dto.GenManyToManyMappedPropertySpec
import top.potmot.entity.model.entities.properties.dto.GenManyToManyMappedPropertyUpdateFillView
import top.potmot.entity.model.entities.properties.dto.GenManyToManyMappedPropertyUpdateInput
import top.potmot.entity.model.entities.properties.id
import top.potmot.exception.AuthorizeException

@RestController
@RequestMapping("/genManyToManyMappedProperty")
class GenManyToManyMappedPropertyService(
    private val sqlClient: KSqlClient
) {
    /**
     * 根据ID获取多对多映射属性。
     *
     * @param id 多对多映射属性的ID。
     * @return 多对多映射属性的详细信息。
     */
    @GetMapping("/{id}")
    @SaCheckPermission("model:entities:properties:genManyToManyMappedProperty:get")
    @Throws(AuthorizeException::class)
    fun get(@PathVariable id: Int): GenManyToManyMappedPropertyDetailView? =
        sqlClient.findById(GenManyToManyMappedPropertyDetailView::class, id)

    /**
     * 根据提供的查询参数列出多对多映射属性。
     *
     * @param spec 查询参数。
     * @return 多对多映射属性列表数据。
     */
    @PostMapping("/list")
    @SaCheckPermission("model:entities:properties:genManyToManyMappedProperty:list")
    @Throws(AuthorizeException::class)
    fun list(@RequestBody spec: GenManyToManyMappedPropertySpec): List<GenManyToManyMappedPropertyListView> =
        sqlClient.executeQuery(GenManyToManyMappedProperty::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenManyToManyMappedPropertyListView::class))
        }

    /**
     * 根据提供的查询参数分页查询多对多映射属性。
     *
     * @param query 分页查询参数。
     * @return 多对多映射属性分页数据。
     */
    @PostMapping("/page")
    @SaCheckPermission("model:entities:properties:genManyToManyMappedProperty:list")
    @Throws(AuthorizeException::class)
    fun page(@RequestBody query: PageQuery<GenManyToManyMappedPropertySpec>): Page<GenManyToManyMappedPropertyListView> =
        sqlClient.createQuery(GenManyToManyMappedProperty::class) {
            where(query.spec)
            orderBy(table.id.asc())
            select(table.fetch(GenManyToManyMappedPropertyListView::class))
        }.fetchPage(query.pageIndex, query.pageSize)

    /**
     * 根据提供的查询参数列出多对多映射属性选项。
     *
     * @param spec 查询参数。
     * @return 多对多映射属性列表数据。
     */
    @PostMapping("/list/options")
    @SaCheckPermission("model:entities:properties:genManyToManyMappedProperty:select")
    @Throws(AuthorizeException::class)
    fun listOptions(@RequestBody spec: GenManyToManyMappedPropertySpec): List<GenManyToManyMappedPropertyOptionView> =
        sqlClient.executeQuery(GenManyToManyMappedProperty::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenManyToManyMappedPropertyOptionView::class))
        }

    /**
     * 插入新的多对多映射属性。
     *
     * @param input 多对多映射属性插入输入对象。
     * @return 插入的多对多映射属性的ID。
     */
    @PostMapping
    @SaCheckPermission("model:entities:properties:genManyToManyMappedProperty:insert")
    @Throws(AuthorizeException::class)
    @Transactional
    fun insert(@RequestBody @Valid input: GenManyToManyMappedPropertyInsertInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.INSERT_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 根据ID获取多对多映射属性的更新回填信息。
     *
     * @param id 多对多映射属性的ID。
     * @return 多对多映射属性的更新回填信息。
     */
    @GetMapping("/{id}/forUpdate")
    @SaCheckPermission("model:entities:properties:genManyToManyMappedProperty:update")
    @Throws(AuthorizeException::class)
    fun getForUpdate(@PathVariable id: Int): GenManyToManyMappedPropertyUpdateFillView? =
        sqlClient.findById(GenManyToManyMappedPropertyUpdateFillView::class, id)

    /**
     * 更新多对多映射属性。
     *
     * @param input 多对多映射属性更新输入对象。
     * @return 更新的多对多映射属性的ID。
     */
    @PutMapping
    @SaCheckPermission("model:entities:properties:genManyToManyMappedProperty:update")
    @Throws(AuthorizeException::class)
    @Transactional
    fun update(@RequestBody @Valid input: GenManyToManyMappedPropertyUpdateInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.UPDATE_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 删除指定ID的多对多映射属性。
     *
     * @param ids 要删除的多对多映射属性ID列表。
     * @return 删除的多对多映射属性的行数。
     */
    @DeleteMapping
    @SaCheckPermission("model:entities:properties:genManyToManyMappedProperty:delete")
    @Throws(AuthorizeException::class)
    @Transactional
    fun delete(@RequestParam ids: List<Int>): Int =
        sqlClient.deleteByIds(GenManyToManyMappedProperty::class, ids).affectedRowCount(GenManyToManyMappedProperty::class)

    /**
     * 根据 属性 校验多对多映射属性是否存在。
     *
     * @param spec 多对多映射属性校验规格对象。
     * @return 多对多映射属性是否存在。
     */
    @PostMapping("/existByProperty")
    @SaCheckPermission("model:entities:properties:genManyToManyMappedProperty:list")
    @Throws(AuthorizeException::class)
    fun existByProperty(@RequestBody spec: GenManyToManyMappedPropertyExistByPropertySpec): Boolean =
        sqlClient.createQuery(GenManyToManyMappedProperty::class) {
            where(spec)
            select(table)
        }.exists()

    /**
     * 根据 对应源属性 校验多对多映射属性是否存在。
     *
     * @param spec 多对多映射属性校验规格对象。
     * @return 多对多映射属性是否存在。
     */
    @PostMapping("/existByMappedBy")
    @SaCheckPermission("model:entities:properties:genManyToManyMappedProperty:list")
    @Throws(AuthorizeException::class)
    fun existByMappedBy(@RequestBody spec: GenManyToManyMappedPropertyExistByMappedBySpec): Boolean =
        sqlClient.createQuery(GenManyToManyMappedProperty::class) {
            where(spec)
            select(table)
        }.exists()
}