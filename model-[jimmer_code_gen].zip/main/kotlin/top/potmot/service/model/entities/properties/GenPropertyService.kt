package top.potmot.service.model.entities.properties

import cn.dev33.satoken.annotation.SaCheckPermission
import jakarta.validation.Valid
import org.babyfish.jimmer.Page
import org.babyfish.jimmer.sql.ast.mutation.AssociatedSaveMode
import org.babyfish.jimmer.sql.ast.mutation.SaveMode
import org.babyfish.jimmer.sql.kt.KSqlClient
import org.babyfish.jimmer.sql.kt.ast.expression.asc
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import top.potmot.entity.dto.query.PageQuery
import top.potmot.entity.model.entities.properties.GenProperty
import top.potmot.entity.model.entities.properties.dto.GenPropertyDetailView
import top.potmot.entity.model.entities.properties.dto.GenPropertyInsertInput
import top.potmot.entity.model.entities.properties.dto.GenPropertyListView
import top.potmot.entity.model.entities.properties.dto.GenPropertyOptionView
import top.potmot.entity.model.entities.properties.dto.GenPropertySpec
import top.potmot.entity.model.entities.properties.dto.GenPropertyUpdateFillView
import top.potmot.entity.model.entities.properties.dto.GenPropertyUpdateInput
import top.potmot.entity.model.entities.properties.id
import top.potmot.exception.AuthorizeException

@RestController
@RequestMapping("/genProperty")
class GenPropertyService(
    private val sqlClient: KSqlClient
) {
    /**
     * 根据ID获取属性。
     *
     * @param id 属性的ID。
     * @return 属性的详细信息。
     */
    @GetMapping("/{id}")
    @SaCheckPermission("model:entities:properties:genProperty:get")
    @Throws(AuthorizeException::class)
    fun get(@PathVariable id: Int): GenPropertyDetailView? =
        sqlClient.findById(GenPropertyDetailView::class, id)

    /**
     * 根据提供的查询参数列出属性。
     *
     * @param spec 查询参数。
     * @return 属性列表数据。
     */
    @PostMapping("/list")
    @SaCheckPermission("model:entities:properties:genProperty:list")
    @Throws(AuthorizeException::class)
    fun list(@RequestBody spec: GenPropertySpec): List<GenPropertyListView> =
        sqlClient.executeQuery(GenProperty::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenPropertyListView::class))
        }

    /**
     * 根据提供的查询参数分页查询属性。
     *
     * @param query 分页查询参数。
     * @return 属性分页数据。
     */
    @PostMapping("/page")
    @SaCheckPermission("model:entities:properties:genProperty:list")
    @Throws(AuthorizeException::class)
    fun page(@RequestBody query: PageQuery<GenPropertySpec>): Page<GenPropertyListView> =
        sqlClient.createQuery(GenProperty::class) {
            where(query.spec)
            orderBy(table.id.asc())
            select(table.fetch(GenPropertyListView::class))
        }.fetchPage(query.pageIndex, query.pageSize)

    /**
     * 根据提供的查询参数列出属性选项。
     *
     * @param spec 查询参数。
     * @return 属性列表数据。
     */
    @PostMapping("/list/options")
    @SaCheckPermission("model:entities:properties:genProperty:select")
    @Throws(AuthorizeException::class)
    fun listOptions(@RequestBody spec: GenPropertySpec): List<GenPropertyOptionView> =
        sqlClient.executeQuery(GenProperty::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenPropertyOptionView::class))
        }

    /**
     * 插入新的属性。
     *
     * @param input 属性插入输入对象。
     * @return 插入的属性的ID。
     */
    @PostMapping
    @SaCheckPermission("model:entities:properties:genProperty:insert")
    @Throws(AuthorizeException::class)
    @Transactional
    fun insert(@RequestBody @Valid input: GenPropertyInsertInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.INSERT_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 根据ID获取属性的更新回填信息。
     *
     * @param id 属性的ID。
     * @return 属性的更新回填信息。
     */
    @GetMapping("/{id}/forUpdate")
    @SaCheckPermission("model:entities:properties:genProperty:update")
    @Throws(AuthorizeException::class)
    fun getForUpdate(@PathVariable id: Int): GenPropertyUpdateFillView? =
        sqlClient.findById(GenPropertyUpdateFillView::class, id)

    /**
     * 更新属性。
     *
     * @param input 属性更新输入对象。
     * @return 更新的属性的ID。
     */
    @PutMapping
    @SaCheckPermission("model:entities:properties:genProperty:update")
    @Throws(AuthorizeException::class)
    @Transactional
    fun update(@RequestBody @Valid input: GenPropertyUpdateInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.UPDATE_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 删除指定ID的属性。
     *
     * @param ids 要删除的属性ID列表。
     * @return 删除的属性的行数。
     */
    @DeleteMapping
    @SaCheckPermission("model:entities:properties:genProperty:delete")
    @Throws(AuthorizeException::class)
    @Transactional
    fun delete(@RequestParam ids: List<Int>): Int =
        sqlClient.deleteByIds(GenProperty::class, ids).affectedRowCount(GenProperty::class)
}