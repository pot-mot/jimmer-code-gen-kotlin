package top.potmot.service.model.entities.properties

import cn.dev33.satoken.annotation.SaCheckPermission
import jakarta.validation.Valid
import org.babyfish.jimmer.Page
import org.babyfish.jimmer.sql.ast.mutation.AssociatedSaveMode
import org.babyfish.jimmer.sql.ast.mutation.SaveMode
import org.babyfish.jimmer.sql.kt.KSqlClient
import org.babyfish.jimmer.sql.kt.ast.expression.asc
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import top.potmot.entity.dto.query.PageQuery
import top.potmot.entity.model.entities.properties.GenExtraProperty
import top.potmot.entity.model.entities.properties.dto.GenExtraPropertyDetailView
import top.potmot.entity.model.entities.properties.dto.GenExtraPropertyExistByPropertySpec
import top.potmot.entity.model.entities.properties.dto.GenExtraPropertyInsertInput
import top.potmot.entity.model.entities.properties.dto.GenExtraPropertyListView
import top.potmot.entity.model.entities.properties.dto.GenExtraPropertyOptionView
import top.potmot.entity.model.entities.properties.dto.GenExtraPropertySpec
import top.potmot.entity.model.entities.properties.dto.GenExtraPropertyUpdateFillView
import top.potmot.entity.model.entities.properties.dto.GenExtraPropertyUpdateInput
import top.potmot.entity.model.entities.properties.id
import top.potmot.exception.AuthorizeException

@RestController
@RequestMapping("/genExtraProperty")
class GenExtraPropertyService(
    private val sqlClient: KSqlClient
) {
    /**
     * 根据ID获取额外属性。
     *
     * @param id 额外属性的ID。
     * @return 额外属性的详细信息。
     */
    @GetMapping("/{id}")
    @SaCheckPermission("model:entities:properties:genExtraProperty:get")
    @Throws(AuthorizeException::class)
    fun get(@PathVariable id: Int): GenExtraPropertyDetailView? =
        sqlClient.findById(GenExtraPropertyDetailView::class, id)

    /**
     * 根据提供的查询参数列出额外属性。
     *
     * @param spec 查询参数。
     * @return 额外属性列表数据。
     */
    @PostMapping("/list")
    @SaCheckPermission("model:entities:properties:genExtraProperty:list")
    @Throws(AuthorizeException::class)
    fun list(@RequestBody spec: GenExtraPropertySpec): List<GenExtraPropertyListView> =
        sqlClient.executeQuery(GenExtraProperty::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenExtraPropertyListView::class))
        }

    /**
     * 根据提供的查询参数分页查询额外属性。
     *
     * @param query 分页查询参数。
     * @return 额外属性分页数据。
     */
    @PostMapping("/page")
    @SaCheckPermission("model:entities:properties:genExtraProperty:list")
    @Throws(AuthorizeException::class)
    fun page(@RequestBody query: PageQuery<GenExtraPropertySpec>): Page<GenExtraPropertyListView> =
        sqlClient.createQuery(GenExtraProperty::class) {
            where(query.spec)
            orderBy(table.id.asc())
            select(table.fetch(GenExtraPropertyListView::class))
        }.fetchPage(query.pageIndex, query.pageSize)

    /**
     * 根据提供的查询参数列出额外属性选项。
     *
     * @param spec 查询参数。
     * @return 额外属性列表数据。
     */
    @PostMapping("/list/options")
    @SaCheckPermission("model:entities:properties:genExtraProperty:select")
    @Throws(AuthorizeException::class)
    fun listOptions(@RequestBody spec: GenExtraPropertySpec): List<GenExtraPropertyOptionView> =
        sqlClient.executeQuery(GenExtraProperty::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenExtraPropertyOptionView::class))
        }

    /**
     * 插入新的额外属性。
     *
     * @param input 额外属性插入输入对象。
     * @return 插入的额外属性的ID。
     */
    @PostMapping
    @SaCheckPermission("model:entities:properties:genExtraProperty:insert")
    @Throws(AuthorizeException::class)
    @Transactional
    fun insert(@RequestBody @Valid input: GenExtraPropertyInsertInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.INSERT_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 根据ID获取额外属性的更新回填信息。
     *
     * @param id 额外属性的ID。
     * @return 额外属性的更新回填信息。
     */
    @GetMapping("/{id}/forUpdate")
    @SaCheckPermission("model:entities:properties:genExtraProperty:update")
    @Throws(AuthorizeException::class)
    fun getForUpdate(@PathVariable id: Int): GenExtraPropertyUpdateFillView? =
        sqlClient.findById(GenExtraPropertyUpdateFillView::class, id)

    /**
     * 更新额外属性。
     *
     * @param input 额外属性更新输入对象。
     * @return 更新的额外属性的ID。
     */
    @PutMapping
    @SaCheckPermission("model:entities:properties:genExtraProperty:update")
    @Throws(AuthorizeException::class)
    @Transactional
    fun update(@RequestBody @Valid input: GenExtraPropertyUpdateInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.UPDATE_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 删除指定ID的额外属性。
     *
     * @param ids 要删除的额外属性ID列表。
     * @return 删除的额外属性的行数。
     */
    @DeleteMapping
    @SaCheckPermission("model:entities:properties:genExtraProperty:delete")
    @Throws(AuthorizeException::class)
    @Transactional
    fun delete(@RequestParam ids: List<Int>): Int =
        sqlClient.deleteByIds(GenExtraProperty::class, ids).affectedRowCount(GenExtraProperty::class)

    /**
     * 根据 属性 校验额外属性是否存在。
     *
     * @param spec 额外属性校验规格对象。
     * @return 额外属性是否存在。
     */
    @PostMapping("/existByProperty")
    @SaCheckPermission("model:entities:properties:genExtraProperty:list")
    @Throws(AuthorizeException::class)
    fun existByProperty(@RequestBody spec: GenExtraPropertyExistByPropertySpec): Boolean =
        sqlClient.createQuery(GenExtraProperty::class) {
            where(spec)
            select(table)
        }.exists()
}