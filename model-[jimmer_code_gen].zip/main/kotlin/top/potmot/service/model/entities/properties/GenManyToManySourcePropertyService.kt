package top.potmot.service.model.entities.properties

import cn.dev33.satoken.annotation.SaCheckPermission
import jakarta.validation.Valid
import org.babyfish.jimmer.Page
import org.babyfish.jimmer.sql.ast.mutation.AssociatedSaveMode
import org.babyfish.jimmer.sql.ast.mutation.SaveMode
import org.babyfish.jimmer.sql.kt.KSqlClient
import org.babyfish.jimmer.sql.kt.ast.expression.asc
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import top.potmot.entity.dto.query.PageQuery
import top.potmot.entity.model.entities.properties.GenManyToManySourceProperty
import top.potmot.entity.model.entities.properties.dto.GenManyToManySourcePropertyDetailView
import top.potmot.entity.model.entities.properties.dto.GenManyToManySourcePropertyExistByPropertySpec
import top.potmot.entity.model.entities.properties.dto.GenManyToManySourcePropertyInsertInput
import top.potmot.entity.model.entities.properties.dto.GenManyToManySourcePropertyListView
import top.potmot.entity.model.entities.properties.dto.GenManyToManySourcePropertyOptionView
import top.potmot.entity.model.entities.properties.dto.GenManyToManySourcePropertySpec
import top.potmot.entity.model.entities.properties.dto.GenManyToManySourcePropertyUpdateFillView
import top.potmot.entity.model.entities.properties.dto.GenManyToManySourcePropertyUpdateInput
import top.potmot.entity.model.entities.properties.id
import top.potmot.exception.AuthorizeException

@RestController
@RequestMapping("/genManyToManySourceProperty")
class GenManyToManySourcePropertyService(
    private val sqlClient: KSqlClient
) {
    /**
     * 根据ID获取多对多源属性。
     *
     * @param id 多对多源属性的ID。
     * @return 多对多源属性的详细信息。
     */
    @GetMapping("/{id}")
    @SaCheckPermission("model:entities:properties:genManyToManySourceProperty:get")
    @Throws(AuthorizeException::class)
    fun get(@PathVariable id: Int): GenManyToManySourcePropertyDetailView? =
        sqlClient.findById(GenManyToManySourcePropertyDetailView::class, id)

    /**
     * 根据提供的查询参数列出多对多源属性。
     *
     * @param spec 查询参数。
     * @return 多对多源属性列表数据。
     */
    @PostMapping("/list")
    @SaCheckPermission("model:entities:properties:genManyToManySourceProperty:list")
    @Throws(AuthorizeException::class)
    fun list(@RequestBody spec: GenManyToManySourcePropertySpec): List<GenManyToManySourcePropertyListView> =
        sqlClient.executeQuery(GenManyToManySourceProperty::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenManyToManySourcePropertyListView::class))
        }

    /**
     * 根据提供的查询参数分页查询多对多源属性。
     *
     * @param query 分页查询参数。
     * @return 多对多源属性分页数据。
     */
    @PostMapping("/page")
    @SaCheckPermission("model:entities:properties:genManyToManySourceProperty:list")
    @Throws(AuthorizeException::class)
    fun page(@RequestBody query: PageQuery<GenManyToManySourcePropertySpec>): Page<GenManyToManySourcePropertyListView> =
        sqlClient.createQuery(GenManyToManySourceProperty::class) {
            where(query.spec)
            orderBy(table.id.asc())
            select(table.fetch(GenManyToManySourcePropertyListView::class))
        }.fetchPage(query.pageIndex, query.pageSize)

    /**
     * 根据提供的查询参数列出多对多源属性选项。
     *
     * @param spec 查询参数。
     * @return 多对多源属性列表数据。
     */
    @PostMapping("/list/options")
    @SaCheckPermission("model:entities:properties:genManyToManySourceProperty:select")
    @Throws(AuthorizeException::class)
    fun listOptions(@RequestBody spec: GenManyToManySourcePropertySpec): List<GenManyToManySourcePropertyOptionView> =
        sqlClient.executeQuery(GenManyToManySourceProperty::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenManyToManySourcePropertyOptionView::class))
        }

    /**
     * 插入新的多对多源属性。
     *
     * @param input 多对多源属性插入输入对象。
     * @return 插入的多对多源属性的ID。
     */
    @PostMapping
    @SaCheckPermission("model:entities:properties:genManyToManySourceProperty:insert")
    @Throws(AuthorizeException::class)
    @Transactional
    fun insert(@RequestBody @Valid input: GenManyToManySourcePropertyInsertInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.INSERT_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 根据ID获取多对多源属性的更新回填信息。
     *
     * @param id 多对多源属性的ID。
     * @return 多对多源属性的更新回填信息。
     */
    @GetMapping("/{id}/forUpdate")
    @SaCheckPermission("model:entities:properties:genManyToManySourceProperty:update")
    @Throws(AuthorizeException::class)
    fun getForUpdate(@PathVariable id: Int): GenManyToManySourcePropertyUpdateFillView? =
        sqlClient.findById(GenManyToManySourcePropertyUpdateFillView::class, id)

    /**
     * 更新多对多源属性。
     *
     * @param input 多对多源属性更新输入对象。
     * @return 更新的多对多源属性的ID。
     */
    @PutMapping
    @SaCheckPermission("model:entities:properties:genManyToManySourceProperty:update")
    @Throws(AuthorizeException::class)
    @Transactional
    fun update(@RequestBody @Valid input: GenManyToManySourcePropertyUpdateInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.UPDATE_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 删除指定ID的多对多源属性。
     *
     * @param ids 要删除的多对多源属性ID列表。
     * @return 删除的多对多源属性的行数。
     */
    @DeleteMapping
    @SaCheckPermission("model:entities:properties:genManyToManySourceProperty:delete")
    @Throws(AuthorizeException::class)
    @Transactional
    fun delete(@RequestParam ids: List<Int>): Int =
        sqlClient.deleteByIds(GenManyToManySourceProperty::class, ids).affectedRowCount(GenManyToManySourceProperty::class)

    /**
     * 根据 属性 校验多对多源属性是否存在。
     *
     * @param spec 多对多源属性校验规格对象。
     * @return 多对多源属性是否存在。
     */
    @PostMapping("/existByProperty")
    @SaCheckPermission("model:entities:properties:genManyToManySourceProperty:list")
    @Throws(AuthorizeException::class)
    fun existByProperty(@RequestBody spec: GenManyToManySourcePropertyExistByPropertySpec): Boolean =
        sqlClient.createQuery(GenManyToManySourceProperty::class) {
            where(spec)
            select(table)
        }.exists()
}