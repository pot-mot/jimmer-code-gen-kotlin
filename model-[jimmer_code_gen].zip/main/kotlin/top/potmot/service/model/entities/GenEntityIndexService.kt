package top.potmot.service.model.entities

import cn.dev33.satoken.annotation.SaCheckPermission
import jakarta.validation.Valid
import org.babyfish.jimmer.Page
import org.babyfish.jimmer.sql.ast.mutation.AssociatedSaveMode
import org.babyfish.jimmer.sql.ast.mutation.SaveMode
import org.babyfish.jimmer.sql.kt.KSqlClient
import org.babyfish.jimmer.sql.kt.ast.expression.asc
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import top.potmot.entity.dto.query.PageQuery
import top.potmot.entity.model.entities.GenEntityIndex
import top.potmot.entity.model.entities.dto.GenEntityIndexDetailView
import top.potmot.entity.model.entities.dto.GenEntityIndexExistByEntityAndNameSpec
import top.potmot.entity.model.entities.dto.GenEntityIndexInsertInput
import top.potmot.entity.model.entities.dto.GenEntityIndexListView
import top.potmot.entity.model.entities.dto.GenEntityIndexOptionView
import top.potmot.entity.model.entities.dto.GenEntityIndexSpec
import top.potmot.entity.model.entities.dto.GenEntityIndexUpdateFillView
import top.potmot.entity.model.entities.dto.GenEntityIndexUpdateInput
import top.potmot.entity.model.entities.id
import top.potmot.exception.AuthorizeException

@RestController
@RequestMapping("/genEntityIndex")
class GenEntityIndexService(
    private val sqlClient: KSqlClient
) {
    /**
     * 根据ID获取实体索引。
     *
     * @param id 实体索引的ID。
     * @return 实体索引的详细信息。
     */
    @GetMapping("/{id}")
    @SaCheckPermission("model:entities:genEntityIndex:get")
    @Throws(AuthorizeException::class)
    fun get(@PathVariable id: Int): GenEntityIndexDetailView? =
        sqlClient.findById(GenEntityIndexDetailView::class, id)

    /**
     * 根据提供的查询参数列出实体索引。
     *
     * @param spec 查询参数。
     * @return 实体索引列表数据。
     */
    @PostMapping("/list")
    @SaCheckPermission("model:entities:genEntityIndex:list")
    @Throws(AuthorizeException::class)
    fun list(@RequestBody spec: GenEntityIndexSpec): List<GenEntityIndexListView> =
        sqlClient.executeQuery(GenEntityIndex::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenEntityIndexListView::class))
        }

    /**
     * 根据提供的查询参数分页查询实体索引。
     *
     * @param query 分页查询参数。
     * @return 实体索引分页数据。
     */
    @PostMapping("/page")
    @SaCheckPermission("model:entities:genEntityIndex:list")
    @Throws(AuthorizeException::class)
    fun page(@RequestBody query: PageQuery<GenEntityIndexSpec>): Page<GenEntityIndexListView> =
        sqlClient.createQuery(GenEntityIndex::class) {
            where(query.spec)
            orderBy(table.id.asc())
            select(table.fetch(GenEntityIndexListView::class))
        }.fetchPage(query.pageIndex, query.pageSize)

    /**
     * 根据提供的查询参数列出实体索引选项。
     *
     * @param spec 查询参数。
     * @return 实体索引列表数据。
     */
    @PostMapping("/list/options")
    @SaCheckPermission("model:entities:genEntityIndex:select")
    @Throws(AuthorizeException::class)
    fun listOptions(@RequestBody spec: GenEntityIndexSpec): List<GenEntityIndexOptionView> =
        sqlClient.executeQuery(GenEntityIndex::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenEntityIndexOptionView::class))
        }

    /**
     * 插入新的实体索引。
     *
     * @param input 实体索引插入输入对象。
     * @return 插入的实体索引的ID。
     */
    @PostMapping
    @SaCheckPermission("model:entities:genEntityIndex:insert")
    @Throws(AuthorizeException::class)
    @Transactional
    fun insert(@RequestBody @Valid input: GenEntityIndexInsertInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.INSERT_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 根据ID获取实体索引的更新回填信息。
     *
     * @param id 实体索引的ID。
     * @return 实体索引的更新回填信息。
     */
    @GetMapping("/{id}/forUpdate")
    @SaCheckPermission("model:entities:genEntityIndex:update")
    @Throws(AuthorizeException::class)
    fun getForUpdate(@PathVariable id: Int): GenEntityIndexUpdateFillView? =
        sqlClient.findById(GenEntityIndexUpdateFillView::class, id)

    /**
     * 更新实体索引。
     *
     * @param input 实体索引更新输入对象。
     * @return 更新的实体索引的ID。
     */
    @PutMapping
    @SaCheckPermission("model:entities:genEntityIndex:update")
    @Throws(AuthorizeException::class)
    @Transactional
    fun update(@RequestBody @Valid input: GenEntityIndexUpdateInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.UPDATE_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 删除指定ID的实体索引。
     *
     * @param ids 要删除的实体索引ID列表。
     * @return 删除的实体索引的行数。
     */
    @DeleteMapping
    @SaCheckPermission("model:entities:genEntityIndex:delete")
    @Throws(AuthorizeException::class)
    @Transactional
    fun delete(@RequestParam ids: List<Int>): Int =
        sqlClient.deleteByIds(GenEntityIndex::class, ids).affectedRowCount(GenEntityIndex::class)

    /**
     * 根据 归属表 和 名称 校验实体索引是否存在。
     *
     * @param spec 实体索引校验规格对象。
     * @return 实体索引是否存在。
     */
    @PostMapping("/existByEntityAndName")
    @SaCheckPermission("model:entities:genEntityIndex:list")
    @Throws(AuthorizeException::class)
    fun existByEntityAndName(@RequestBody spec: GenEntityIndexExistByEntityAndNameSpec): Boolean =
        sqlClient.createQuery(GenEntityIndex::class) {
            where(spec)
            select(table)
        }.exists()
}