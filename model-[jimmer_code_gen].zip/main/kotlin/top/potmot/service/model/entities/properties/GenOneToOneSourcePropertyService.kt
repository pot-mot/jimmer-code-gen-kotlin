package top.potmot.service.model.entities.properties

import cn.dev33.satoken.annotation.SaCheckPermission
import jakarta.validation.Valid
import org.babyfish.jimmer.Page
import org.babyfish.jimmer.sql.ast.mutation.AssociatedSaveMode
import org.babyfish.jimmer.sql.ast.mutation.SaveMode
import org.babyfish.jimmer.sql.kt.KSqlClient
import org.babyfish.jimmer.sql.kt.ast.expression.asc
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import top.potmot.entity.dto.query.PageQuery
import top.potmot.entity.model.entities.properties.GenOneToOneSourceProperty
import top.potmot.entity.model.entities.properties.dto.GenOneToOneSourcePropertyDetailView
import top.potmot.entity.model.entities.properties.dto.GenOneToOneSourcePropertyExistByPropertySpec
import top.potmot.entity.model.entities.properties.dto.GenOneToOneSourcePropertyInsertInput
import top.potmot.entity.model.entities.properties.dto.GenOneToOneSourcePropertyListView
import top.potmot.entity.model.entities.properties.dto.GenOneToOneSourcePropertyOptionView
import top.potmot.entity.model.entities.properties.dto.GenOneToOneSourcePropertySpec
import top.potmot.entity.model.entities.properties.dto.GenOneToOneSourcePropertyUpdateFillView
import top.potmot.entity.model.entities.properties.dto.GenOneToOneSourcePropertyUpdateInput
import top.potmot.entity.model.entities.properties.id
import top.potmot.exception.AuthorizeException

@RestController
@RequestMapping("/genOneToOneSourceProperty")
class GenOneToOneSourcePropertyService(
    private val sqlClient: KSqlClient
) {
    /**
     * 根据ID获取一对一源属性。
     *
     * @param id 一对一源属性的ID。
     * @return 一对一源属性的详细信息。
     */
    @GetMapping("/{id}")
    @SaCheckPermission("model:entities:properties:genOneToOneSourceProperty:get")
    @Throws(AuthorizeException::class)
    fun get(@PathVariable id: Int): GenOneToOneSourcePropertyDetailView? =
        sqlClient.findById(GenOneToOneSourcePropertyDetailView::class, id)

    /**
     * 根据提供的查询参数列出一对一源属性。
     *
     * @param spec 查询参数。
     * @return 一对一源属性列表数据。
     */
    @PostMapping("/list")
    @SaCheckPermission("model:entities:properties:genOneToOneSourceProperty:list")
    @Throws(AuthorizeException::class)
    fun list(@RequestBody spec: GenOneToOneSourcePropertySpec): List<GenOneToOneSourcePropertyListView> =
        sqlClient.executeQuery(GenOneToOneSourceProperty::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenOneToOneSourcePropertyListView::class))
        }

    /**
     * 根据提供的查询参数分页查询一对一源属性。
     *
     * @param query 分页查询参数。
     * @return 一对一源属性分页数据。
     */
    @PostMapping("/page")
    @SaCheckPermission("model:entities:properties:genOneToOneSourceProperty:list")
    @Throws(AuthorizeException::class)
    fun page(@RequestBody query: PageQuery<GenOneToOneSourcePropertySpec>): Page<GenOneToOneSourcePropertyListView> =
        sqlClient.createQuery(GenOneToOneSourceProperty::class) {
            where(query.spec)
            orderBy(table.id.asc())
            select(table.fetch(GenOneToOneSourcePropertyListView::class))
        }.fetchPage(query.pageIndex, query.pageSize)

    /**
     * 根据提供的查询参数列出一对一源属性选项。
     *
     * @param spec 查询参数。
     * @return 一对一源属性列表数据。
     */
    @PostMapping("/list/options")
    @SaCheckPermission("model:entities:properties:genOneToOneSourceProperty:select")
    @Throws(AuthorizeException::class)
    fun listOptions(@RequestBody spec: GenOneToOneSourcePropertySpec): List<GenOneToOneSourcePropertyOptionView> =
        sqlClient.executeQuery(GenOneToOneSourceProperty::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenOneToOneSourcePropertyOptionView::class))
        }

    /**
     * 插入新的一对一源属性。
     *
     * @param input 一对一源属性插入输入对象。
     * @return 插入的一对一源属性的ID。
     */
    @PostMapping
    @SaCheckPermission("model:entities:properties:genOneToOneSourceProperty:insert")
    @Throws(AuthorizeException::class)
    @Transactional
    fun insert(@RequestBody @Valid input: GenOneToOneSourcePropertyInsertInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.INSERT_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 根据ID获取一对一源属性的更新回填信息。
     *
     * @param id 一对一源属性的ID。
     * @return 一对一源属性的更新回填信息。
     */
    @GetMapping("/{id}/forUpdate")
    @SaCheckPermission("model:entities:properties:genOneToOneSourceProperty:update")
    @Throws(AuthorizeException::class)
    fun getForUpdate(@PathVariable id: Int): GenOneToOneSourcePropertyUpdateFillView? =
        sqlClient.findById(GenOneToOneSourcePropertyUpdateFillView::class, id)

    /**
     * 更新一对一源属性。
     *
     * @param input 一对一源属性更新输入对象。
     * @return 更新的一对一源属性的ID。
     */
    @PutMapping
    @SaCheckPermission("model:entities:properties:genOneToOneSourceProperty:update")
    @Throws(AuthorizeException::class)
    @Transactional
    fun update(@RequestBody @Valid input: GenOneToOneSourcePropertyUpdateInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.UPDATE_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 删除指定ID的一对一源属性。
     *
     * @param ids 要删除的一对一源属性ID列表。
     * @return 删除的一对一源属性的行数。
     */
    @DeleteMapping
    @SaCheckPermission("model:entities:properties:genOneToOneSourceProperty:delete")
    @Throws(AuthorizeException::class)
    @Transactional
    fun delete(@RequestParam ids: List<Int>): Int =
        sqlClient.deleteByIds(GenOneToOneSourceProperty::class, ids).affectedRowCount(GenOneToOneSourceProperty::class)

    /**
     * 根据 属性 校验一对一源属性是否存在。
     *
     * @param spec 一对一源属性校验规格对象。
     * @return 一对一源属性是否存在。
     */
    @PostMapping("/existByProperty")
    @SaCheckPermission("model:entities:properties:genOneToOneSourceProperty:list")
    @Throws(AuthorizeException::class)
    fun existByProperty(@RequestBody spec: GenOneToOneSourcePropertyExistByPropertySpec): Boolean =
        sqlClient.createQuery(GenOneToOneSourceProperty::class) {
            where(spec)
            select(table)
        }.exists()
}