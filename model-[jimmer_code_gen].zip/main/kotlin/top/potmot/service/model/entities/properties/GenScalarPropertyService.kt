package top.potmot.service.model.entities.properties

import cn.dev33.satoken.annotation.SaCheckPermission
import jakarta.validation.Valid
import org.babyfish.jimmer.Page
import org.babyfish.jimmer.sql.ast.mutation.AssociatedSaveMode
import org.babyfish.jimmer.sql.ast.mutation.SaveMode
import org.babyfish.jimmer.sql.kt.KSqlClient
import org.babyfish.jimmer.sql.kt.ast.expression.asc
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import top.potmot.entity.dto.query.PageQuery
import top.potmot.entity.model.entities.properties.GenScalarProperty
import top.potmot.entity.model.entities.properties.dto.GenScalarPropertyDetailView
import top.potmot.entity.model.entities.properties.dto.GenScalarPropertyExistByPropertySpec
import top.potmot.entity.model.entities.properties.dto.GenScalarPropertyInsertInput
import top.potmot.entity.model.entities.properties.dto.GenScalarPropertyListView
import top.potmot.entity.model.entities.properties.dto.GenScalarPropertyOptionView
import top.potmot.entity.model.entities.properties.dto.GenScalarPropertySpec
import top.potmot.entity.model.entities.properties.dto.GenScalarPropertyUpdateFillView
import top.potmot.entity.model.entities.properties.dto.GenScalarPropertyUpdateInput
import top.potmot.entity.model.entities.properties.id
import top.potmot.exception.AuthorizeException

@RestController
@RequestMapping("/genScalarProperty")
class GenScalarPropertyService(
    private val sqlClient: KSqlClient
) {
    /**
     * 根据ID获取标量属性。
     *
     * @param id 标量属性的ID。
     * @return 标量属性的详细信息。
     */
    @GetMapping("/{id}")
    @SaCheckPermission("model:entities:properties:genScalarProperty:get")
    @Throws(AuthorizeException::class)
    fun get(@PathVariable id: Int): GenScalarPropertyDetailView? =
        sqlClient.findById(GenScalarPropertyDetailView::class, id)

    /**
     * 根据提供的查询参数列出标量属性。
     *
     * @param spec 查询参数。
     * @return 标量属性列表数据。
     */
    @PostMapping("/list")
    @SaCheckPermission("model:entities:properties:genScalarProperty:list")
    @Throws(AuthorizeException::class)
    fun list(@RequestBody spec: GenScalarPropertySpec): List<GenScalarPropertyListView> =
        sqlClient.executeQuery(GenScalarProperty::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenScalarPropertyListView::class))
        }

    /**
     * 根据提供的查询参数分页查询标量属性。
     *
     * @param query 分页查询参数。
     * @return 标量属性分页数据。
     */
    @PostMapping("/page")
    @SaCheckPermission("model:entities:properties:genScalarProperty:list")
    @Throws(AuthorizeException::class)
    fun page(@RequestBody query: PageQuery<GenScalarPropertySpec>): Page<GenScalarPropertyListView> =
        sqlClient.createQuery(GenScalarProperty::class) {
            where(query.spec)
            orderBy(table.id.asc())
            select(table.fetch(GenScalarPropertyListView::class))
        }.fetchPage(query.pageIndex, query.pageSize)

    /**
     * 根据提供的查询参数列出标量属性选项。
     *
     * @param spec 查询参数。
     * @return 标量属性列表数据。
     */
    @PostMapping("/list/options")
    @SaCheckPermission("model:entities:properties:genScalarProperty:select")
    @Throws(AuthorizeException::class)
    fun listOptions(@RequestBody spec: GenScalarPropertySpec): List<GenScalarPropertyOptionView> =
        sqlClient.executeQuery(GenScalarProperty::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenScalarPropertyOptionView::class))
        }

    /**
     * 插入新的标量属性。
     *
     * @param input 标量属性插入输入对象。
     * @return 插入的标量属性的ID。
     */
    @PostMapping
    @SaCheckPermission("model:entities:properties:genScalarProperty:insert")
    @Throws(AuthorizeException::class)
    @Transactional
    fun insert(@RequestBody @Valid input: GenScalarPropertyInsertInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.INSERT_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 根据ID获取标量属性的更新回填信息。
     *
     * @param id 标量属性的ID。
     * @return 标量属性的更新回填信息。
     */
    @GetMapping("/{id}/forUpdate")
    @SaCheckPermission("model:entities:properties:genScalarProperty:update")
    @Throws(AuthorizeException::class)
    fun getForUpdate(@PathVariable id: Int): GenScalarPropertyUpdateFillView? =
        sqlClient.findById(GenScalarPropertyUpdateFillView::class, id)

    /**
     * 更新标量属性。
     *
     * @param input 标量属性更新输入对象。
     * @return 更新的标量属性的ID。
     */
    @PutMapping
    @SaCheckPermission("model:entities:properties:genScalarProperty:update")
    @Throws(AuthorizeException::class)
    @Transactional
    fun update(@RequestBody @Valid input: GenScalarPropertyUpdateInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.UPDATE_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 删除指定ID的标量属性。
     *
     * @param ids 要删除的标量属性ID列表。
     * @return 删除的标量属性的行数。
     */
    @DeleteMapping
    @SaCheckPermission("model:entities:properties:genScalarProperty:delete")
    @Throws(AuthorizeException::class)
    @Transactional
    fun delete(@RequestParam ids: List<Int>): Int =
        sqlClient.deleteByIds(GenScalarProperty::class, ids).affectedRowCount(GenScalarProperty::class)

    /**
     * 根据 属性 校验标量属性是否存在。
     *
     * @param spec 标量属性校验规格对象。
     * @return 标量属性是否存在。
     */
    @PostMapping("/existByProperty")
    @SaCheckPermission("model:entities:properties:genScalarProperty:list")
    @Throws(AuthorizeException::class)
    fun existByProperty(@RequestBody spec: GenScalarPropertyExistByPropertySpec): Boolean =
        sqlClient.createQuery(GenScalarProperty::class) {
            where(spec)
            select(table)
        }.exists()
}