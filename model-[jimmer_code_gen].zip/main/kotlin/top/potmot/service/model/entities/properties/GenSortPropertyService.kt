package top.potmot.service.model.entities.properties

import cn.dev33.satoken.annotation.SaCheckPermission
import jakarta.validation.Valid
import org.babyfish.jimmer.Page
import org.babyfish.jimmer.sql.ast.mutation.AssociatedSaveMode
import org.babyfish.jimmer.sql.ast.mutation.SaveMode
import org.babyfish.jimmer.sql.kt.KSqlClient
import org.babyfish.jimmer.sql.kt.ast.expression.asc
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import top.potmot.entity.dto.query.PageQuery
import top.potmot.entity.model.entities.properties.GenSortProperty
import top.potmot.entity.model.entities.properties.dto.GenSortPropertyDetailView
import top.potmot.entity.model.entities.properties.dto.GenSortPropertyExistByPropertySpec
import top.potmot.entity.model.entities.properties.dto.GenSortPropertyInsertInput
import top.potmot.entity.model.entities.properties.dto.GenSortPropertyListView
import top.potmot.entity.model.entities.properties.dto.GenSortPropertyOptionView
import top.potmot.entity.model.entities.properties.dto.GenSortPropertySpec
import top.potmot.entity.model.entities.properties.dto.GenSortPropertyUpdateFillView
import top.potmot.entity.model.entities.properties.dto.GenSortPropertyUpdateInput
import top.potmot.entity.model.entities.properties.id
import top.potmot.exception.AuthorizeException

@RestController
@RequestMapping("/genSortProperty")
class GenSortPropertyService(
    private val sqlClient: KSqlClient
) {
    /**
     * 根据ID获取排序属性。
     *
     * @param id 排序属性的ID。
     * @return 排序属性的详细信息。
     */
    @GetMapping("/{id}")
    @SaCheckPermission("model:entities:properties:genSortProperty:get")
    @Throws(AuthorizeException::class)
    fun get(@PathVariable id: Int): GenSortPropertyDetailView? =
        sqlClient.findById(GenSortPropertyDetailView::class, id)

    /**
     * 根据提供的查询参数列出排序属性。
     *
     * @param spec 查询参数。
     * @return 排序属性列表数据。
     */
    @PostMapping("/list")
    @SaCheckPermission("model:entities:properties:genSortProperty:list")
    @Throws(AuthorizeException::class)
    fun list(@RequestBody spec: GenSortPropertySpec): List<GenSortPropertyListView> =
        sqlClient.executeQuery(GenSortProperty::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenSortPropertyListView::class))
        }

    /**
     * 根据提供的查询参数分页查询排序属性。
     *
     * @param query 分页查询参数。
     * @return 排序属性分页数据。
     */
    @PostMapping("/page")
    @SaCheckPermission("model:entities:properties:genSortProperty:list")
    @Throws(AuthorizeException::class)
    fun page(@RequestBody query: PageQuery<GenSortPropertySpec>): Page<GenSortPropertyListView> =
        sqlClient.createQuery(GenSortProperty::class) {
            where(query.spec)
            orderBy(table.id.asc())
            select(table.fetch(GenSortPropertyListView::class))
        }.fetchPage(query.pageIndex, query.pageSize)

    /**
     * 根据提供的查询参数列出排序属性选项。
     *
     * @param spec 查询参数。
     * @return 排序属性列表数据。
     */
    @PostMapping("/list/options")
    @SaCheckPermission("model:entities:properties:genSortProperty:select")
    @Throws(AuthorizeException::class)
    fun listOptions(@RequestBody spec: GenSortPropertySpec): List<GenSortPropertyOptionView> =
        sqlClient.executeQuery(GenSortProperty::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenSortPropertyOptionView::class))
        }

    /**
     * 插入新的排序属性。
     *
     * @param input 排序属性插入输入对象。
     * @return 插入的排序属性的ID。
     */
    @PostMapping
    @SaCheckPermission("model:entities:properties:genSortProperty:insert")
    @Throws(AuthorizeException::class)
    @Transactional
    fun insert(@RequestBody @Valid input: GenSortPropertyInsertInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.INSERT_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 根据ID获取排序属性的更新回填信息。
     *
     * @param id 排序属性的ID。
     * @return 排序属性的更新回填信息。
     */
    @GetMapping("/{id}/forUpdate")
    @SaCheckPermission("model:entities:properties:genSortProperty:update")
    @Throws(AuthorizeException::class)
    fun getForUpdate(@PathVariable id: Int): GenSortPropertyUpdateFillView? =
        sqlClient.findById(GenSortPropertyUpdateFillView::class, id)

    /**
     * 更新排序属性。
     *
     * @param input 排序属性更新输入对象。
     * @return 更新的排序属性的ID。
     */
    @PutMapping
    @SaCheckPermission("model:entities:properties:genSortProperty:update")
    @Throws(AuthorizeException::class)
    @Transactional
    fun update(@RequestBody @Valid input: GenSortPropertyUpdateInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.UPDATE_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 删除指定ID的排序属性。
     *
     * @param ids 要删除的排序属性ID列表。
     * @return 删除的排序属性的行数。
     */
    @DeleteMapping
    @SaCheckPermission("model:entities:properties:genSortProperty:delete")
    @Throws(AuthorizeException::class)
    @Transactional
    fun delete(@RequestParam ids: List<Int>): Int =
        sqlClient.deleteByIds(GenSortProperty::class, ids).affectedRowCount(GenSortProperty::class)

    /**
     * 根据 属性 校验排序属性是否存在。
     *
     * @param spec 排序属性校验规格对象。
     * @return 排序属性是否存在。
     */
    @PostMapping("/existByProperty")
    @SaCheckPermission("model:entities:properties:genSortProperty:list")
    @Throws(AuthorizeException::class)
    fun existByProperty(@RequestBody spec: GenSortPropertyExistByPropertySpec): Boolean =
        sqlClient.createQuery(GenSortProperty::class) {
            where(spec)
            select(table)
        }.exists()
}