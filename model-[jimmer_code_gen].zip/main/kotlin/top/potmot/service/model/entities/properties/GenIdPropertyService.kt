package top.potmot.service.model.entities.properties

import cn.dev33.satoken.annotation.SaCheckPermission
import jakarta.validation.Valid
import org.babyfish.jimmer.Page
import org.babyfish.jimmer.sql.ast.mutation.AssociatedSaveMode
import org.babyfish.jimmer.sql.ast.mutation.SaveMode
import org.babyfish.jimmer.sql.kt.KSqlClient
import org.babyfish.jimmer.sql.kt.ast.expression.asc
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import top.potmot.entity.dto.query.PageQuery
import top.potmot.entity.model.entities.properties.GenIdProperty
import top.potmot.entity.model.entities.properties.dto.GenIdPropertyDetailView
import top.potmot.entity.model.entities.properties.dto.GenIdPropertyExistByPropertySpec
import top.potmot.entity.model.entities.properties.dto.GenIdPropertyInsertInput
import top.potmot.entity.model.entities.properties.dto.GenIdPropertyListView
import top.potmot.entity.model.entities.properties.dto.GenIdPropertyOptionView
import top.potmot.entity.model.entities.properties.dto.GenIdPropertySpec
import top.potmot.entity.model.entities.properties.dto.GenIdPropertyUpdateFillView
import top.potmot.entity.model.entities.properties.dto.GenIdPropertyUpdateInput
import top.potmot.entity.model.entities.properties.id
import top.potmot.exception.AuthorizeException

@RestController
@RequestMapping("/genIdProperty")
class GenIdPropertyService(
    private val sqlClient: KSqlClient
) {
    /**
     * 根据ID获取ID属性。
     *
     * @param id ID属性的ID。
     * @return ID属性的详细信息。
     */
    @GetMapping("/{id}")
    @SaCheckPermission("model:entities:properties:genIdProperty:get")
    @Throws(AuthorizeException::class)
    fun get(@PathVariable id: Int): GenIdPropertyDetailView? =
        sqlClient.findById(GenIdPropertyDetailView::class, id)

    /**
     * 根据提供的查询参数列出ID属性。
     *
     * @param spec 查询参数。
     * @return ID属性列表数据。
     */
    @PostMapping("/list")
    @SaCheckPermission("model:entities:properties:genIdProperty:list")
    @Throws(AuthorizeException::class)
    fun list(@RequestBody spec: GenIdPropertySpec): List<GenIdPropertyListView> =
        sqlClient.executeQuery(GenIdProperty::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenIdPropertyListView::class))
        }

    /**
     * 根据提供的查询参数分页查询ID属性。
     *
     * @param query 分页查询参数。
     * @return ID属性分页数据。
     */
    @PostMapping("/page")
    @SaCheckPermission("model:entities:properties:genIdProperty:list")
    @Throws(AuthorizeException::class)
    fun page(@RequestBody query: PageQuery<GenIdPropertySpec>): Page<GenIdPropertyListView> =
        sqlClient.createQuery(GenIdProperty::class) {
            where(query.spec)
            orderBy(table.id.asc())
            select(table.fetch(GenIdPropertyListView::class))
        }.fetchPage(query.pageIndex, query.pageSize)

    /**
     * 根据提供的查询参数列出ID属性选项。
     *
     * @param spec 查询参数。
     * @return ID属性列表数据。
     */
    @PostMapping("/list/options")
    @SaCheckPermission("model:entities:properties:genIdProperty:select")
    @Throws(AuthorizeException::class)
    fun listOptions(@RequestBody spec: GenIdPropertySpec): List<GenIdPropertyOptionView> =
        sqlClient.executeQuery(GenIdProperty::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenIdPropertyOptionView::class))
        }

    /**
     * 插入新的ID属性。
     *
     * @param input ID属性插入输入对象。
     * @return 插入的ID属性的ID。
     */
    @PostMapping
    @SaCheckPermission("model:entities:properties:genIdProperty:insert")
    @Throws(AuthorizeException::class)
    @Transactional
    fun insert(@RequestBody @Valid input: GenIdPropertyInsertInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.INSERT_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 根据ID获取ID属性的更新回填信息。
     *
     * @param id ID属性的ID。
     * @return ID属性的更新回填信息。
     */
    @GetMapping("/{id}/forUpdate")
    @SaCheckPermission("model:entities:properties:genIdProperty:update")
    @Throws(AuthorizeException::class)
    fun getForUpdate(@PathVariable id: Int): GenIdPropertyUpdateFillView? =
        sqlClient.findById(GenIdPropertyUpdateFillView::class, id)

    /**
     * 更新ID属性。
     *
     * @param input ID属性更新输入对象。
     * @return 更新的ID属性的ID。
     */
    @PutMapping
    @SaCheckPermission("model:entities:properties:genIdProperty:update")
    @Throws(AuthorizeException::class)
    @Transactional
    fun update(@RequestBody @Valid input: GenIdPropertyUpdateInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.UPDATE_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 删除指定ID的ID属性。
     *
     * @param ids 要删除的ID属性ID列表。
     * @return 删除的ID属性的行数。
     */
    @DeleteMapping
    @SaCheckPermission("model:entities:properties:genIdProperty:delete")
    @Throws(AuthorizeException::class)
    @Transactional
    fun delete(@RequestParam ids: List<Int>): Int =
        sqlClient.deleteByIds(GenIdProperty::class, ids).affectedRowCount(GenIdProperty::class)

    /**
     * 根据 属性 校验ID属性是否存在。
     *
     * @param spec ID属性校验规格对象。
     * @return ID属性是否存在。
     */
    @PostMapping("/existByProperty")
    @SaCheckPermission("model:entities:properties:genIdProperty:list")
    @Throws(AuthorizeException::class)
    fun existByProperty(@RequestBody spec: GenIdPropertyExistByPropertySpec): Boolean =
        sqlClient.createQuery(GenIdProperty::class) {
            where(spec)
            select(table)
        }.exists()
}