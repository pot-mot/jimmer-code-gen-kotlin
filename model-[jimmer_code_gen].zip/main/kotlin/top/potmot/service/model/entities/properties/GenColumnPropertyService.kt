package top.potmot.service.model.entities.properties

import cn.dev33.satoken.annotation.SaCheckPermission
import jakarta.validation.Valid
import org.babyfish.jimmer.Page
import org.babyfish.jimmer.sql.ast.mutation.AssociatedSaveMode
import org.babyfish.jimmer.sql.ast.mutation.SaveMode
import org.babyfish.jimmer.sql.kt.KSqlClient
import org.babyfish.jimmer.sql.kt.ast.expression.asc
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import top.potmot.entity.dto.query.PageQuery
import top.potmot.entity.model.entities.properties.GenColumnProperty
import top.potmot.entity.model.entities.properties.dto.GenColumnPropertyDetailView
import top.potmot.entity.model.entities.properties.dto.GenColumnPropertyExistByPropertySpec
import top.potmot.entity.model.entities.properties.dto.GenColumnPropertyInsertInput
import top.potmot.entity.model.entities.properties.dto.GenColumnPropertyListView
import top.potmot.entity.model.entities.properties.dto.GenColumnPropertyOptionView
import top.potmot.entity.model.entities.properties.dto.GenColumnPropertySpec
import top.potmot.entity.model.entities.properties.dto.GenColumnPropertyUpdateFillView
import top.potmot.entity.model.entities.properties.dto.GenColumnPropertyUpdateInput
import top.potmot.entity.model.entities.properties.id
import top.potmot.exception.AuthorizeException

@RestController
@RequestMapping("/genColumnProperty")
class GenColumnPropertyService(
    private val sqlClient: KSqlClient
) {
    /**
     * 根据ID获取列属性。
     *
     * @param id 列属性的ID。
     * @return 列属性的详细信息。
     */
    @GetMapping("/{id}")
    @SaCheckPermission("model:entities:properties:genColumnProperty:get")
    @Throws(AuthorizeException::class)
    fun get(@PathVariable id: Int): GenColumnPropertyDetailView? =
        sqlClient.findById(GenColumnPropertyDetailView::class, id)

    /**
     * 根据提供的查询参数列出列属性。
     *
     * @param spec 查询参数。
     * @return 列属性列表数据。
     */
    @PostMapping("/list")
    @SaCheckPermission("model:entities:properties:genColumnProperty:list")
    @Throws(AuthorizeException::class)
    fun list(@RequestBody spec: GenColumnPropertySpec): List<GenColumnPropertyListView> =
        sqlClient.executeQuery(GenColumnProperty::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenColumnPropertyListView::class))
        }

    /**
     * 根据提供的查询参数分页查询列属性。
     *
     * @param query 分页查询参数。
     * @return 列属性分页数据。
     */
    @PostMapping("/page")
    @SaCheckPermission("model:entities:properties:genColumnProperty:list")
    @Throws(AuthorizeException::class)
    fun page(@RequestBody query: PageQuery<GenColumnPropertySpec>): Page<GenColumnPropertyListView> =
        sqlClient.createQuery(GenColumnProperty::class) {
            where(query.spec)
            orderBy(table.id.asc())
            select(table.fetch(GenColumnPropertyListView::class))
        }.fetchPage(query.pageIndex, query.pageSize)

    /**
     * 根据提供的查询参数列出列属性选项。
     *
     * @param spec 查询参数。
     * @return 列属性列表数据。
     */
    @PostMapping("/list/options")
    @SaCheckPermission("model:entities:properties:genColumnProperty:select")
    @Throws(AuthorizeException::class)
    fun listOptions(@RequestBody spec: GenColumnPropertySpec): List<GenColumnPropertyOptionView> =
        sqlClient.executeQuery(GenColumnProperty::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenColumnPropertyOptionView::class))
        }

    /**
     * 插入新的列属性。
     *
     * @param input 列属性插入输入对象。
     * @return 插入的列属性的ID。
     */
    @PostMapping
    @SaCheckPermission("model:entities:properties:genColumnProperty:insert")
    @Throws(AuthorizeException::class)
    @Transactional
    fun insert(@RequestBody @Valid input: GenColumnPropertyInsertInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.INSERT_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 根据ID获取列属性的更新回填信息。
     *
     * @param id 列属性的ID。
     * @return 列属性的更新回填信息。
     */
    @GetMapping("/{id}/forUpdate")
    @SaCheckPermission("model:entities:properties:genColumnProperty:update")
    @Throws(AuthorizeException::class)
    fun getForUpdate(@PathVariable id: Int): GenColumnPropertyUpdateFillView? =
        sqlClient.findById(GenColumnPropertyUpdateFillView::class, id)

    /**
     * 更新列属性。
     *
     * @param input 列属性更新输入对象。
     * @return 更新的列属性的ID。
     */
    @PutMapping
    @SaCheckPermission("model:entities:properties:genColumnProperty:update")
    @Throws(AuthorizeException::class)
    @Transactional
    fun update(@RequestBody @Valid input: GenColumnPropertyUpdateInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.UPDATE_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 删除指定ID的列属性。
     *
     * @param ids 要删除的列属性ID列表。
     * @return 删除的列属性的行数。
     */
    @DeleteMapping
    @SaCheckPermission("model:entities:properties:genColumnProperty:delete")
    @Throws(AuthorizeException::class)
    @Transactional
    fun delete(@RequestParam ids: List<Int>): Int =
        sqlClient.deleteByIds(GenColumnProperty::class, ids).affectedRowCount(GenColumnProperty::class)

    /**
     * 根据 属性 校验列属性是否存在。
     *
     * @param spec 列属性校验规格对象。
     * @return 列属性是否存在。
     */
    @PostMapping("/existByProperty")
    @SaCheckPermission("model:entities:properties:genColumnProperty:list")
    @Throws(AuthorizeException::class)
    fun existByProperty(@RequestBody spec: GenColumnPropertyExistByPropertySpec): Boolean =
        sqlClient.createQuery(GenColumnProperty::class) {
            where(spec)
            select(table)
        }.exists()
}