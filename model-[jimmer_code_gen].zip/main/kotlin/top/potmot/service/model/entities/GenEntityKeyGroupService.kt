package top.potmot.service.model.entities

import cn.dev33.satoken.annotation.SaCheckPermission
import jakarta.validation.Valid
import org.babyfish.jimmer.Page
import org.babyfish.jimmer.sql.ast.mutation.AssociatedSaveMode
import org.babyfish.jimmer.sql.ast.mutation.SaveMode
import org.babyfish.jimmer.sql.kt.KSqlClient
import org.babyfish.jimmer.sql.kt.ast.expression.asc
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import top.potmot.entity.dto.query.PageQuery
import top.potmot.entity.model.entities.GenEntityKeyGroup
import top.potmot.entity.model.entities.dto.GenEntityKeyGroupDetailView
import top.potmot.entity.model.entities.dto.GenEntityKeyGroupExistByIndexSpec
import top.potmot.entity.model.entities.dto.GenEntityKeyGroupInsertInput
import top.potmot.entity.model.entities.dto.GenEntityKeyGroupListView
import top.potmot.entity.model.entities.dto.GenEntityKeyGroupOptionView
import top.potmot.entity.model.entities.dto.GenEntityKeyGroupSpec
import top.potmot.entity.model.entities.dto.GenEntityKeyGroupUpdateFillView
import top.potmot.entity.model.entities.dto.GenEntityKeyGroupUpdateInput
import top.potmot.entity.model.entities.id
import top.potmot.exception.AuthorizeException

@RestController
@RequestMapping("/genEntityKeyGroup")
class GenEntityKeyGroupService(
    private val sqlClient: KSqlClient
) {
    /**
     * 根据ID获取实体业务键组。
     *
     * @param id 实体业务键组的ID。
     * @return 实体业务键组的详细信息。
     */
    @GetMapping("/{id}")
    @SaCheckPermission("model:entities:genEntityKeyGroup:get")
    @Throws(AuthorizeException::class)
    fun get(@PathVariable id: Int): GenEntityKeyGroupDetailView? =
        sqlClient.findById(GenEntityKeyGroupDetailView::class, id)

    /**
     * 根据提供的查询参数列出实体业务键组。
     *
     * @param spec 查询参数。
     * @return 实体业务键组列表数据。
     */
    @PostMapping("/list")
    @SaCheckPermission("model:entities:genEntityKeyGroup:list")
    @Throws(AuthorizeException::class)
    fun list(@RequestBody spec: GenEntityKeyGroupSpec): List<GenEntityKeyGroupListView> =
        sqlClient.executeQuery(GenEntityKeyGroup::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenEntityKeyGroupListView::class))
        }

    /**
     * 根据提供的查询参数分页查询实体业务键组。
     *
     * @param query 分页查询参数。
     * @return 实体业务键组分页数据。
     */
    @PostMapping("/page")
    @SaCheckPermission("model:entities:genEntityKeyGroup:list")
    @Throws(AuthorizeException::class)
    fun page(@RequestBody query: PageQuery<GenEntityKeyGroupSpec>): Page<GenEntityKeyGroupListView> =
        sqlClient.createQuery(GenEntityKeyGroup::class) {
            where(query.spec)
            orderBy(table.id.asc())
            select(table.fetch(GenEntityKeyGroupListView::class))
        }.fetchPage(query.pageIndex, query.pageSize)

    /**
     * 根据提供的查询参数列出实体业务键组选项。
     *
     * @param spec 查询参数。
     * @return 实体业务键组列表数据。
     */
    @PostMapping("/list/options")
    @SaCheckPermission("model:entities:genEntityKeyGroup:select")
    @Throws(AuthorizeException::class)
    fun listOptions(@RequestBody spec: GenEntityKeyGroupSpec): List<GenEntityKeyGroupOptionView> =
        sqlClient.executeQuery(GenEntityKeyGroup::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenEntityKeyGroupOptionView::class))
        }

    /**
     * 插入新的实体业务键组。
     *
     * @param input 实体业务键组插入输入对象。
     * @return 插入的实体业务键组的ID。
     */
    @PostMapping
    @SaCheckPermission("model:entities:genEntityKeyGroup:insert")
    @Throws(AuthorizeException::class)
    @Transactional
    fun insert(@RequestBody @Valid input: GenEntityKeyGroupInsertInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.INSERT_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 根据ID获取实体业务键组的更新回填信息。
     *
     * @param id 实体业务键组的ID。
     * @return 实体业务键组的更新回填信息。
     */
    @GetMapping("/{id}/forUpdate")
    @SaCheckPermission("model:entities:genEntityKeyGroup:update")
    @Throws(AuthorizeException::class)
    fun getForUpdate(@PathVariable id: Int): GenEntityKeyGroupUpdateFillView? =
        sqlClient.findById(GenEntityKeyGroupUpdateFillView::class, id)

    /**
     * 更新实体业务键组。
     *
     * @param input 实体业务键组更新输入对象。
     * @return 更新的实体业务键组的ID。
     */
    @PutMapping
    @SaCheckPermission("model:entities:genEntityKeyGroup:update")
    @Throws(AuthorizeException::class)
    @Transactional
    fun update(@RequestBody @Valid input: GenEntityKeyGroupUpdateInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.UPDATE_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 删除指定ID的实体业务键组。
     *
     * @param ids 要删除的实体业务键组ID列表。
     * @return 删除的实体业务键组的行数。
     */
    @DeleteMapping
    @SaCheckPermission("model:entities:genEntityKeyGroup:delete")
    @Throws(AuthorizeException::class)
    @Transactional
    fun delete(@RequestParam ids: List<Int>): Int =
        sqlClient.deleteByIds(GenEntityKeyGroup::class, ids).affectedRowCount(GenEntityKeyGroup::class)

    /**
     * 根据 对应索引 校验实体业务键组是否存在。
     *
     * @param spec 实体业务键组校验规格对象。
     * @return 实体业务键组是否存在。
     */
    @PostMapping("/existByIndex")
    @SaCheckPermission("model:entities:genEntityKeyGroup:list")
    @Throws(AuthorizeException::class)
    fun existByIndex(@RequestBody spec: GenEntityKeyGroupExistByIndexSpec): Boolean =
        sqlClient.createQuery(GenEntityKeyGroup::class) {
            where(spec)
            select(table)
        }.exists()
}