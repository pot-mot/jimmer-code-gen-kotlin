package top.potmot.service.model.entities

import cn.dev33.satoken.annotation.SaCheckPermission
import jakarta.validation.Valid
import org.babyfish.jimmer.Page
import org.babyfish.jimmer.sql.ast.mutation.AssociatedSaveMode
import org.babyfish.jimmer.sql.ast.mutation.SaveMode
import org.babyfish.jimmer.sql.kt.KSqlClient
import org.babyfish.jimmer.sql.kt.ast.expression.asc
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import top.potmot.entity.dto.query.PageQuery
import top.potmot.entity.model.entities.GenEntityGraphData
import top.potmot.entity.model.entities.dto.GenEntityGraphDataDetailView
import top.potmot.entity.model.entities.dto.GenEntityGraphDataInsertInput
import top.potmot.entity.model.entities.dto.GenEntityGraphDataListView
import top.potmot.entity.model.entities.dto.GenEntityGraphDataOptionView
import top.potmot.entity.model.entities.dto.GenEntityGraphDataSpec
import top.potmot.entity.model.entities.dto.GenEntityGraphDataUpdateFillView
import top.potmot.entity.model.entities.dto.GenEntityGraphDataUpdateInput
import top.potmot.entity.model.entities.id
import top.potmot.exception.AuthorizeException

@RestController
@RequestMapping("/genEntityGraphData")
class GenEntityGraphDataService(
    private val sqlClient: KSqlClient
) {
    /**
     * 根据ID获取实体图数据。
     *
     * @param id 实体图数据的ID。
     * @return 实体图数据的详细信息。
     */
    @GetMapping("/{id}")
    @SaCheckPermission("model:entities:genEntityGraphData:get")
    @Throws(AuthorizeException::class)
    fun get(@PathVariable id: Int): GenEntityGraphDataDetailView? =
        sqlClient.findById(GenEntityGraphDataDetailView::class, id)

    /**
     * 根据提供的查询参数列出实体图数据。
     *
     * @param spec 查询参数。
     * @return 实体图数据列表数据。
     */
    @PostMapping("/list")
    @SaCheckPermission("model:entities:genEntityGraphData:list")
    @Throws(AuthorizeException::class)
    fun list(@RequestBody spec: GenEntityGraphDataSpec): List<GenEntityGraphDataListView> =
        sqlClient.executeQuery(GenEntityGraphData::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenEntityGraphDataListView::class))
        }

    /**
     * 根据提供的查询参数分页查询实体图数据。
     *
     * @param query 分页查询参数。
     * @return 实体图数据分页数据。
     */
    @PostMapping("/page")
    @SaCheckPermission("model:entities:genEntityGraphData:list")
    @Throws(AuthorizeException::class)
    fun page(@RequestBody query: PageQuery<GenEntityGraphDataSpec>): Page<GenEntityGraphDataListView> =
        sqlClient.createQuery(GenEntityGraphData::class) {
            where(query.spec)
            orderBy(table.id.asc())
            select(table.fetch(GenEntityGraphDataListView::class))
        }.fetchPage(query.pageIndex, query.pageSize)

    /**
     * 根据提供的查询参数列出实体图数据选项。
     *
     * @param spec 查询参数。
     * @return 实体图数据列表数据。
     */
    @PostMapping("/list/options")
    @SaCheckPermission("model:entities:genEntityGraphData:select")
    @Throws(AuthorizeException::class)
    fun listOptions(@RequestBody spec: GenEntityGraphDataSpec): List<GenEntityGraphDataOptionView> =
        sqlClient.executeQuery(GenEntityGraphData::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenEntityGraphDataOptionView::class))
        }

    /**
     * 插入新的实体图数据。
     *
     * @param input 实体图数据插入输入对象。
     * @return 插入的实体图数据的ID。
     */
    @PostMapping
    @SaCheckPermission("model:entities:genEntityGraphData:insert")
    @Throws(AuthorizeException::class)
    @Transactional
    fun insert(@RequestBody @Valid input: GenEntityGraphDataInsertInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.INSERT_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 根据ID获取实体图数据的更新回填信息。
     *
     * @param id 实体图数据的ID。
     * @return 实体图数据的更新回填信息。
     */
    @GetMapping("/{id}/forUpdate")
    @SaCheckPermission("model:entities:genEntityGraphData:update")
    @Throws(AuthorizeException::class)
    fun getForUpdate(@PathVariable id: Int): GenEntityGraphDataUpdateFillView? =
        sqlClient.findById(GenEntityGraphDataUpdateFillView::class, id)

    /**
     * 更新实体图数据。
     *
     * @param input 实体图数据更新输入对象。
     * @return 更新的实体图数据的ID。
     */
    @PutMapping
    @SaCheckPermission("model:entities:genEntityGraphData:update")
    @Throws(AuthorizeException::class)
    @Transactional
    fun update(@RequestBody @Valid input: GenEntityGraphDataUpdateInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.UPDATE_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 删除指定ID的实体图数据。
     *
     * @param ids 要删除的实体图数据ID列表。
     * @return 删除的实体图数据的行数。
     */
    @DeleteMapping
    @SaCheckPermission("model:entities:genEntityGraphData:delete")
    @Throws(AuthorizeException::class)
    @Transactional
    fun delete(@RequestParam ids: List<Int>): Int =
        sqlClient.deleteByIds(GenEntityGraphData::class, ids).affectedRowCount(GenEntityGraphData::class)
}