package top.potmot.service.model.entities.properties

import cn.dev33.satoken.annotation.SaCheckPermission
import jakarta.validation.Valid
import org.babyfish.jimmer.Page
import org.babyfish.jimmer.sql.ast.mutation.AssociatedSaveMode
import org.babyfish.jimmer.sql.ast.mutation.SaveMode
import org.babyfish.jimmer.sql.kt.KSqlClient
import org.babyfish.jimmer.sql.kt.ast.expression.asc
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import top.potmot.entity.dto.query.PageQuery
import top.potmot.entity.model.entities.properties.GenOneToOneMappedProperty
import top.potmot.entity.model.entities.properties.dto.GenOneToOneMappedPropertyDetailView
import top.potmot.entity.model.entities.properties.dto.GenOneToOneMappedPropertyExistByMappedBySpec
import top.potmot.entity.model.entities.properties.dto.GenOneToOneMappedPropertyExistByPropertySpec
import top.potmot.entity.model.entities.properties.dto.GenOneToOneMappedPropertyInsertInput
import top.potmot.entity.model.entities.properties.dto.GenOneToOneMappedPropertyListView
import top.potmot.entity.model.entities.properties.dto.GenOneToOneMappedPropertyOptionView
import top.potmot.entity.model.entities.properties.dto.GenOneToOneMappedPropertySpec
import top.potmot.entity.model.entities.properties.dto.GenOneToOneMappedPropertyUpdateFillView
import top.potmot.entity.model.entities.properties.dto.GenOneToOneMappedPropertyUpdateInput
import top.potmot.entity.model.entities.properties.id
import top.potmot.exception.AuthorizeException

@RestController
@RequestMapping("/genOneToOneMappedProperty")
class GenOneToOneMappedPropertyService(
    private val sqlClient: KSqlClient
) {
    /**
     * 根据ID获取一对一映射属性。
     *
     * @param id 一对一映射属性的ID。
     * @return 一对一映射属性的详细信息。
     */
    @GetMapping("/{id}")
    @SaCheckPermission("model:entities:properties:genOneToOneMappedProperty:get")
    @Throws(AuthorizeException::class)
    fun get(@PathVariable id: Int): GenOneToOneMappedPropertyDetailView? =
        sqlClient.findById(GenOneToOneMappedPropertyDetailView::class, id)

    /**
     * 根据提供的查询参数列出一对一映射属性。
     *
     * @param spec 查询参数。
     * @return 一对一映射属性列表数据。
     */
    @PostMapping("/list")
    @SaCheckPermission("model:entities:properties:genOneToOneMappedProperty:list")
    @Throws(AuthorizeException::class)
    fun list(@RequestBody spec: GenOneToOneMappedPropertySpec): List<GenOneToOneMappedPropertyListView> =
        sqlClient.executeQuery(GenOneToOneMappedProperty::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenOneToOneMappedPropertyListView::class))
        }

    /**
     * 根据提供的查询参数分页查询一对一映射属性。
     *
     * @param query 分页查询参数。
     * @return 一对一映射属性分页数据。
     */
    @PostMapping("/page")
    @SaCheckPermission("model:entities:properties:genOneToOneMappedProperty:list")
    @Throws(AuthorizeException::class)
    fun page(@RequestBody query: PageQuery<GenOneToOneMappedPropertySpec>): Page<GenOneToOneMappedPropertyListView> =
        sqlClient.createQuery(GenOneToOneMappedProperty::class) {
            where(query.spec)
            orderBy(table.id.asc())
            select(table.fetch(GenOneToOneMappedPropertyListView::class))
        }.fetchPage(query.pageIndex, query.pageSize)

    /**
     * 根据提供的查询参数列出一对一映射属性选项。
     *
     * @param spec 查询参数。
     * @return 一对一映射属性列表数据。
     */
    @PostMapping("/list/options")
    @SaCheckPermission("model:entities:properties:genOneToOneMappedProperty:select")
    @Throws(AuthorizeException::class)
    fun listOptions(@RequestBody spec: GenOneToOneMappedPropertySpec): List<GenOneToOneMappedPropertyOptionView> =
        sqlClient.executeQuery(GenOneToOneMappedProperty::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenOneToOneMappedPropertyOptionView::class))
        }

    /**
     * 插入新的一对一映射属性。
     *
     * @param input 一对一映射属性插入输入对象。
     * @return 插入的一对一映射属性的ID。
     */
    @PostMapping
    @SaCheckPermission("model:entities:properties:genOneToOneMappedProperty:insert")
    @Throws(AuthorizeException::class)
    @Transactional
    fun insert(@RequestBody @Valid input: GenOneToOneMappedPropertyInsertInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.INSERT_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 根据ID获取一对一映射属性的更新回填信息。
     *
     * @param id 一对一映射属性的ID。
     * @return 一对一映射属性的更新回填信息。
     */
    @GetMapping("/{id}/forUpdate")
    @SaCheckPermission("model:entities:properties:genOneToOneMappedProperty:update")
    @Throws(AuthorizeException::class)
    fun getForUpdate(@PathVariable id: Int): GenOneToOneMappedPropertyUpdateFillView? =
        sqlClient.findById(GenOneToOneMappedPropertyUpdateFillView::class, id)

    /**
     * 更新一对一映射属性。
     *
     * @param input 一对一映射属性更新输入对象。
     * @return 更新的一对一映射属性的ID。
     */
    @PutMapping
    @SaCheckPermission("model:entities:properties:genOneToOneMappedProperty:update")
    @Throws(AuthorizeException::class)
    @Transactional
    fun update(@RequestBody @Valid input: GenOneToOneMappedPropertyUpdateInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.UPDATE_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 删除指定ID的一对一映射属性。
     *
     * @param ids 要删除的一对一映射属性ID列表。
     * @return 删除的一对一映射属性的行数。
     */
    @DeleteMapping
    @SaCheckPermission("model:entities:properties:genOneToOneMappedProperty:delete")
    @Throws(AuthorizeException::class)
    @Transactional
    fun delete(@RequestParam ids: List<Int>): Int =
        sqlClient.deleteByIds(GenOneToOneMappedProperty::class, ids).affectedRowCount(GenOneToOneMappedProperty::class)

    /**
     * 根据 属性 校验一对一映射属性是否存在。
     *
     * @param spec 一对一映射属性校验规格对象。
     * @return 一对一映射属性是否存在。
     */
    @PostMapping("/existByProperty")
    @SaCheckPermission("model:entities:properties:genOneToOneMappedProperty:list")
    @Throws(AuthorizeException::class)
    fun existByProperty(@RequestBody spec: GenOneToOneMappedPropertyExistByPropertySpec): Boolean =
        sqlClient.createQuery(GenOneToOneMappedProperty::class) {
            where(spec)
            select(table)
        }.exists()

    /**
     * 根据 对应源属性 校验一对一映射属性是否存在。
     *
     * @param spec 一对一映射属性校验规格对象。
     * @return 一对一映射属性是否存在。
     */
    @PostMapping("/existByMappedBy")
    @SaCheckPermission("model:entities:properties:genOneToOneMappedProperty:list")
    @Throws(AuthorizeException::class)
    fun existByMappedBy(@RequestBody spec: GenOneToOneMappedPropertyExistByMappedBySpec): Boolean =
        sqlClient.createQuery(GenOneToOneMappedProperty::class) {
            where(spec)
            select(table)
        }.exists()
}