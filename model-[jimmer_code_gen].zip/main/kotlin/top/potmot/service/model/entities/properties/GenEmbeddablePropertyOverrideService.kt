package top.potmot.service.model.entities.properties

import cn.dev33.satoken.annotation.SaCheckPermission
import jakarta.validation.Valid
import org.babyfish.jimmer.Page
import org.babyfish.jimmer.sql.ast.mutation.AssociatedSaveMode
import org.babyfish.jimmer.sql.ast.mutation.SaveMode
import org.babyfish.jimmer.sql.kt.KSqlClient
import org.babyfish.jimmer.sql.kt.ast.expression.asc
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import top.potmot.entity.dto.query.PageQuery
import top.potmot.entity.model.entities.properties.GenEmbeddablePropertyOverride
import top.potmot.entity.model.entities.properties.dto.GenEmbeddablePropertyOverrideDetailView
import top.potmot.entity.model.entities.properties.dto.GenEmbeddablePropertyOverrideExistByEmbeddablePropertyAndDeepPropertyAndOverridePropertySpec
import top.potmot.entity.model.entities.properties.dto.GenEmbeddablePropertyOverrideInsertInput
import top.potmot.entity.model.entities.properties.dto.GenEmbeddablePropertyOverrideListView
import top.potmot.entity.model.entities.properties.dto.GenEmbeddablePropertyOverrideOptionView
import top.potmot.entity.model.entities.properties.dto.GenEmbeddablePropertyOverrideSpec
import top.potmot.entity.model.entities.properties.dto.GenEmbeddablePropertyOverrideUpdateFillView
import top.potmot.entity.model.entities.properties.dto.GenEmbeddablePropertyOverrideUpdateInput
import top.potmot.entity.model.entities.properties.id
import top.potmot.exception.AuthorizeException

@RestController
@RequestMapping("/genEmbeddablePropertyOverride")
class GenEmbeddablePropertyOverrideService(
    private val sqlClient: KSqlClient
) {
    /**
     * 根据ID获取复合属性列覆盖。
     *
     * @param id 复合属性列覆盖的ID。
     * @return 复合属性列覆盖的详细信息。
     */
    @GetMapping("/{id}")
    @SaCheckPermission("model:entities:properties:genEmbeddablePropertyOverride:get")
    @Throws(AuthorizeException::class)
    fun get(@PathVariable id: Int): GenEmbeddablePropertyOverrideDetailView? =
        sqlClient.findById(GenEmbeddablePropertyOverrideDetailView::class, id)

    /**
     * 根据提供的查询参数列出复合属性列覆盖。
     *
     * @param spec 查询参数。
     * @return 复合属性列覆盖列表数据。
     */
    @PostMapping("/list")
    @SaCheckPermission("model:entities:properties:genEmbeddablePropertyOverride:list")
    @Throws(AuthorizeException::class)
    fun list(@RequestBody spec: GenEmbeddablePropertyOverrideSpec): List<GenEmbeddablePropertyOverrideListView> =
        sqlClient.executeQuery(GenEmbeddablePropertyOverride::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenEmbeddablePropertyOverrideListView::class))
        }

    /**
     * 根据提供的查询参数分页查询复合属性列覆盖。
     *
     * @param query 分页查询参数。
     * @return 复合属性列覆盖分页数据。
     */
    @PostMapping("/page")
    @SaCheckPermission("model:entities:properties:genEmbeddablePropertyOverride:list")
    @Throws(AuthorizeException::class)
    fun page(@RequestBody query: PageQuery<GenEmbeddablePropertyOverrideSpec>): Page<GenEmbeddablePropertyOverrideListView> =
        sqlClient.createQuery(GenEmbeddablePropertyOverride::class) {
            where(query.spec)
            orderBy(table.id.asc())
            select(table.fetch(GenEmbeddablePropertyOverrideListView::class))
        }.fetchPage(query.pageIndex, query.pageSize)

    /**
     * 根据提供的查询参数列出复合属性列覆盖选项。
     *
     * @param spec 查询参数。
     * @return 复合属性列覆盖列表数据。
     */
    @PostMapping("/list/options")
    @SaCheckPermission("model:entities:properties:genEmbeddablePropertyOverride:select")
    @Throws(AuthorizeException::class)
    fun listOptions(@RequestBody spec: GenEmbeddablePropertyOverrideSpec): List<GenEmbeddablePropertyOverrideOptionView> =
        sqlClient.executeQuery(GenEmbeddablePropertyOverride::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenEmbeddablePropertyOverrideOptionView::class))
        }

    /**
     * 插入新的复合属性列覆盖。
     *
     * @param input 复合属性列覆盖插入输入对象。
     * @return 插入的复合属性列覆盖的ID。
     */
    @PostMapping
    @SaCheckPermission("model:entities:properties:genEmbeddablePropertyOverride:insert")
    @Throws(AuthorizeException::class)
    @Transactional
    fun insert(@RequestBody @Valid input: GenEmbeddablePropertyOverrideInsertInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.INSERT_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 根据ID获取复合属性列覆盖的更新回填信息。
     *
     * @param id 复合属性列覆盖的ID。
     * @return 复合属性列覆盖的更新回填信息。
     */
    @GetMapping("/{id}/forUpdate")
    @SaCheckPermission("model:entities:properties:genEmbeddablePropertyOverride:update")
    @Throws(AuthorizeException::class)
    fun getForUpdate(@PathVariable id: Int): GenEmbeddablePropertyOverrideUpdateFillView? =
        sqlClient.findById(GenEmbeddablePropertyOverrideUpdateFillView::class, id)

    /**
     * 更新复合属性列覆盖。
     *
     * @param input 复合属性列覆盖更新输入对象。
     * @return 更新的复合属性列覆盖的ID。
     */
    @PutMapping
    @SaCheckPermission("model:entities:properties:genEmbeddablePropertyOverride:update")
    @Throws(AuthorizeException::class)
    @Transactional
    fun update(@RequestBody @Valid input: GenEmbeddablePropertyOverrideUpdateInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.UPDATE_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 删除指定ID的复合属性列覆盖。
     *
     * @param ids 要删除的复合属性列覆盖ID列表。
     * @return 删除的复合属性列覆盖的行数。
     */
    @DeleteMapping
    @SaCheckPermission("model:entities:properties:genEmbeddablePropertyOverride:delete")
    @Throws(AuthorizeException::class)
    @Transactional
    fun delete(@RequestParam ids: List<Int>): Int =
        sqlClient.deleteByIds(GenEmbeddablePropertyOverride::class, ids).affectedRowCount(GenEmbeddablePropertyOverride::class)

    /**
     * 根据 复合属性 和 深层属性 和 覆盖属性 校验复合属性列覆盖是否存在。
     *
     * @param spec 复合属性列覆盖校验规格对象。
     * @return 复合属性列覆盖是否存在。
     */
    @PostMapping("/existByEmbeddablePropertyAndDeepPropertyAndOverrideProperty")
    @SaCheckPermission("model:entities:properties:genEmbeddablePropertyOverride:list")
    @Throws(AuthorizeException::class)
    fun existByEmbeddablePropertyAndDeepPropertyAndOverrideProperty(@RequestBody spec: GenEmbeddablePropertyOverrideExistByEmbeddablePropertyAndDeepPropertyAndOverridePropertySpec): Boolean =
        sqlClient.createQuery(GenEmbeddablePropertyOverride::class) {
            where(spec)
            select(table)
        }.exists()
}