package top.potmot.service.model.entities.properties

import cn.dev33.satoken.annotation.SaCheckPermission
import jakarta.validation.Valid
import org.babyfish.jimmer.Page
import org.babyfish.jimmer.sql.ast.mutation.AssociatedSaveMode
import org.babyfish.jimmer.sql.ast.mutation.SaveMode
import org.babyfish.jimmer.sql.kt.KSqlClient
import org.babyfish.jimmer.sql.kt.ast.expression.asc
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import top.potmot.entity.dto.query.PageQuery
import top.potmot.entity.model.entities.properties.GenVersionProperty
import top.potmot.entity.model.entities.properties.dto.GenVersionPropertyDetailView
import top.potmot.entity.model.entities.properties.dto.GenVersionPropertyExistByPropertySpec
import top.potmot.entity.model.entities.properties.dto.GenVersionPropertyInsertInput
import top.potmot.entity.model.entities.properties.dto.GenVersionPropertyListView
import top.potmot.entity.model.entities.properties.dto.GenVersionPropertyOptionView
import top.potmot.entity.model.entities.properties.dto.GenVersionPropertySpec
import top.potmot.entity.model.entities.properties.dto.GenVersionPropertyUpdateFillView
import top.potmot.entity.model.entities.properties.dto.GenVersionPropertyUpdateInput
import top.potmot.entity.model.entities.properties.id
import top.potmot.exception.AuthorizeException

@RestController
@RequestMapping("/genVersionProperty")
class GenVersionPropertyService(
    private val sqlClient: KSqlClient
) {
    /**
     * 根据ID获取乐观锁属性。
     *
     * @param id 乐观锁属性的ID。
     * @return 乐观锁属性的详细信息。
     */
    @GetMapping("/{id}")
    @SaCheckPermission("model:entities:properties:genVersionProperty:get")
    @Throws(AuthorizeException::class)
    fun get(@PathVariable id: Int): GenVersionPropertyDetailView? =
        sqlClient.findById(GenVersionPropertyDetailView::class, id)

    /**
     * 根据提供的查询参数列出乐观锁属性。
     *
     * @param spec 查询参数。
     * @return 乐观锁属性列表数据。
     */
    @PostMapping("/list")
    @SaCheckPermission("model:entities:properties:genVersionProperty:list")
    @Throws(AuthorizeException::class)
    fun list(@RequestBody spec: GenVersionPropertySpec): List<GenVersionPropertyListView> =
        sqlClient.executeQuery(GenVersionProperty::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenVersionPropertyListView::class))
        }

    /**
     * 根据提供的查询参数分页查询乐观锁属性。
     *
     * @param query 分页查询参数。
     * @return 乐观锁属性分页数据。
     */
    @PostMapping("/page")
    @SaCheckPermission("model:entities:properties:genVersionProperty:list")
    @Throws(AuthorizeException::class)
    fun page(@RequestBody query: PageQuery<GenVersionPropertySpec>): Page<GenVersionPropertyListView> =
        sqlClient.createQuery(GenVersionProperty::class) {
            where(query.spec)
            orderBy(table.id.asc())
            select(table.fetch(GenVersionPropertyListView::class))
        }.fetchPage(query.pageIndex, query.pageSize)

    /**
     * 根据提供的查询参数列出乐观锁属性选项。
     *
     * @param spec 查询参数。
     * @return 乐观锁属性列表数据。
     */
    @PostMapping("/list/options")
    @SaCheckPermission("model:entities:properties:genVersionProperty:select")
    @Throws(AuthorizeException::class)
    fun listOptions(@RequestBody spec: GenVersionPropertySpec): List<GenVersionPropertyOptionView> =
        sqlClient.executeQuery(GenVersionProperty::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenVersionPropertyOptionView::class))
        }

    /**
     * 插入新的乐观锁属性。
     *
     * @param input 乐观锁属性插入输入对象。
     * @return 插入的乐观锁属性的ID。
     */
    @PostMapping
    @SaCheckPermission("model:entities:properties:genVersionProperty:insert")
    @Throws(AuthorizeException::class)
    @Transactional
    fun insert(@RequestBody @Valid input: GenVersionPropertyInsertInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.INSERT_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 根据ID获取乐观锁属性的更新回填信息。
     *
     * @param id 乐观锁属性的ID。
     * @return 乐观锁属性的更新回填信息。
     */
    @GetMapping("/{id}/forUpdate")
    @SaCheckPermission("model:entities:properties:genVersionProperty:update")
    @Throws(AuthorizeException::class)
    fun getForUpdate(@PathVariable id: Int): GenVersionPropertyUpdateFillView? =
        sqlClient.findById(GenVersionPropertyUpdateFillView::class, id)

    /**
     * 更新乐观锁属性。
     *
     * @param input 乐观锁属性更新输入对象。
     * @return 更新的乐观锁属性的ID。
     */
    @PutMapping
    @SaCheckPermission("model:entities:properties:genVersionProperty:update")
    @Throws(AuthorizeException::class)
    @Transactional
    fun update(@RequestBody @Valid input: GenVersionPropertyUpdateInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.UPDATE_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 删除指定ID的乐观锁属性。
     *
     * @param ids 要删除的乐观锁属性ID列表。
     * @return 删除的乐观锁属性的行数。
     */
    @DeleteMapping
    @SaCheckPermission("model:entities:properties:genVersionProperty:delete")
    @Throws(AuthorizeException::class)
    @Transactional
    fun delete(@RequestParam ids: List<Int>): Int =
        sqlClient.deleteByIds(GenVersionProperty::class, ids).affectedRowCount(GenVersionProperty::class)

    /**
     * 根据 属性 校验乐观锁属性是否存在。
     *
     * @param spec 乐观锁属性校验规格对象。
     * @return 乐观锁属性是否存在。
     */
    @PostMapping("/existByProperty")
    @SaCheckPermission("model:entities:properties:genVersionProperty:list")
    @Throws(AuthorizeException::class)
    fun existByProperty(@RequestBody spec: GenVersionPropertyExistByPropertySpec): Boolean =
        sqlClient.createQuery(GenVersionProperty::class) {
            where(spec)
            select(table)
        }.exists()
}