package top.potmot.service.model.entities.properties

import cn.dev33.satoken.annotation.SaCheckPermission
import jakarta.validation.Valid
import org.babyfish.jimmer.Page
import org.babyfish.jimmer.sql.ast.mutation.AssociatedSaveMode
import org.babyfish.jimmer.sql.ast.mutation.SaveMode
import org.babyfish.jimmer.sql.kt.KSqlClient
import org.babyfish.jimmer.sql.kt.ast.expression.asc
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import top.potmot.entity.dto.query.PageQuery
import top.potmot.entity.model.entities.properties.GenManyToOneMappedProperty
import top.potmot.entity.model.entities.properties.dto.GenManyToOneMappedPropertyDetailView
import top.potmot.entity.model.entities.properties.dto.GenManyToOneMappedPropertyExistByMappedBySpec
import top.potmot.entity.model.entities.properties.dto.GenManyToOneMappedPropertyExistByPropertySpec
import top.potmot.entity.model.entities.properties.dto.GenManyToOneMappedPropertyInsertInput
import top.potmot.entity.model.entities.properties.dto.GenManyToOneMappedPropertyListView
import top.potmot.entity.model.entities.properties.dto.GenManyToOneMappedPropertyOptionView
import top.potmot.entity.model.entities.properties.dto.GenManyToOneMappedPropertySpec
import top.potmot.entity.model.entities.properties.dto.GenManyToOneMappedPropertyUpdateFillView
import top.potmot.entity.model.entities.properties.dto.GenManyToOneMappedPropertyUpdateInput
import top.potmot.entity.model.entities.properties.id
import top.potmot.exception.AuthorizeException

@RestController
@RequestMapping("/genManyToOneMappedProperty")
class GenManyToOneMappedPropertyService(
    private val sqlClient: KSqlClient
) {
    /**
     * 根据ID获取多对一映射属性（对多）。
     *
     * @param id 多对一映射属性（对多）的ID。
     * @return 多对一映射属性（对多）的详细信息。
     */
    @GetMapping("/{id}")
    @SaCheckPermission("model:entities:properties:genManyToOneMappedProperty:get")
    @Throws(AuthorizeException::class)
    fun get(@PathVariable id: Int): GenManyToOneMappedPropertyDetailView? =
        sqlClient.findById(GenManyToOneMappedPropertyDetailView::class, id)

    /**
     * 根据提供的查询参数列出多对一映射属性（对多）。
     *
     * @param spec 查询参数。
     * @return 多对一映射属性（对多）列表数据。
     */
    @PostMapping("/list")
    @SaCheckPermission("model:entities:properties:genManyToOneMappedProperty:list")
    @Throws(AuthorizeException::class)
    fun list(@RequestBody spec: GenManyToOneMappedPropertySpec): List<GenManyToOneMappedPropertyListView> =
        sqlClient.executeQuery(GenManyToOneMappedProperty::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenManyToOneMappedPropertyListView::class))
        }

    /**
     * 根据提供的查询参数分页查询多对一映射属性（对多）。
     *
     * @param query 分页查询参数。
     * @return 多对一映射属性（对多）分页数据。
     */
    @PostMapping("/page")
    @SaCheckPermission("model:entities:properties:genManyToOneMappedProperty:list")
    @Throws(AuthorizeException::class)
    fun page(@RequestBody query: PageQuery<GenManyToOneMappedPropertySpec>): Page<GenManyToOneMappedPropertyListView> =
        sqlClient.createQuery(GenManyToOneMappedProperty::class) {
            where(query.spec)
            orderBy(table.id.asc())
            select(table.fetch(GenManyToOneMappedPropertyListView::class))
        }.fetchPage(query.pageIndex, query.pageSize)

    /**
     * 根据提供的查询参数列出多对一映射属性（对多）选项。
     *
     * @param spec 查询参数。
     * @return 多对一映射属性（对多）列表数据。
     */
    @PostMapping("/list/options")
    @SaCheckPermission("model:entities:properties:genManyToOneMappedProperty:select")
    @Throws(AuthorizeException::class)
    fun listOptions(@RequestBody spec: GenManyToOneMappedPropertySpec): List<GenManyToOneMappedPropertyOptionView> =
        sqlClient.executeQuery(GenManyToOneMappedProperty::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenManyToOneMappedPropertyOptionView::class))
        }

    /**
     * 插入新的多对一映射属性（对多）。
     *
     * @param input 多对一映射属性（对多）插入输入对象。
     * @return 插入的多对一映射属性（对多）的ID。
     */
    @PostMapping
    @SaCheckPermission("model:entities:properties:genManyToOneMappedProperty:insert")
    @Throws(AuthorizeException::class)
    @Transactional
    fun insert(@RequestBody @Valid input: GenManyToOneMappedPropertyInsertInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.INSERT_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 根据ID获取多对一映射属性（对多）的更新回填信息。
     *
     * @param id 多对一映射属性（对多）的ID。
     * @return 多对一映射属性（对多）的更新回填信息。
     */
    @GetMapping("/{id}/forUpdate")
    @SaCheckPermission("model:entities:properties:genManyToOneMappedProperty:update")
    @Throws(AuthorizeException::class)
    fun getForUpdate(@PathVariable id: Int): GenManyToOneMappedPropertyUpdateFillView? =
        sqlClient.findById(GenManyToOneMappedPropertyUpdateFillView::class, id)

    /**
     * 更新多对一映射属性（对多）。
     *
     * @param input 多对一映射属性（对多）更新输入对象。
     * @return 更新的多对一映射属性（对多）的ID。
     */
    @PutMapping
    @SaCheckPermission("model:entities:properties:genManyToOneMappedProperty:update")
    @Throws(AuthorizeException::class)
    @Transactional
    fun update(@RequestBody @Valid input: GenManyToOneMappedPropertyUpdateInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.UPDATE_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 删除指定ID的多对一映射属性（对多）。
     *
     * @param ids 要删除的多对一映射属性（对多）ID列表。
     * @return 删除的多对一映射属性（对多）的行数。
     */
    @DeleteMapping
    @SaCheckPermission("model:entities:properties:genManyToOneMappedProperty:delete")
    @Throws(AuthorizeException::class)
    @Transactional
    fun delete(@RequestParam ids: List<Int>): Int =
        sqlClient.deleteByIds(GenManyToOneMappedProperty::class, ids).affectedRowCount(GenManyToOneMappedProperty::class)

    /**
     * 根据 属性 校验多对一映射属性（对多）是否存在。
     *
     * @param spec 多对一映射属性（对多）校验规格对象。
     * @return 多对一映射属性（对多）是否存在。
     */
    @PostMapping("/existByProperty")
    @SaCheckPermission("model:entities:properties:genManyToOneMappedProperty:list")
    @Throws(AuthorizeException::class)
    fun existByProperty(@RequestBody spec: GenManyToOneMappedPropertyExistByPropertySpec): Boolean =
        sqlClient.createQuery(GenManyToOneMappedProperty::class) {
            where(spec)
            select(table)
        }.exists()

    /**
     * 根据 对应源属性 校验多对一映射属性（对多）是否存在。
     *
     * @param spec 多对一映射属性（对多）校验规格对象。
     * @return 多对一映射属性（对多）是否存在。
     */
    @PostMapping("/existByMappedBy")
    @SaCheckPermission("model:entities:properties:genManyToOneMappedProperty:list")
    @Throws(AuthorizeException::class)
    fun existByMappedBy(@RequestBody spec: GenManyToOneMappedPropertyExistByMappedBySpec): Boolean =
        sqlClient.createQuery(GenManyToOneMappedProperty::class) {
            where(spec)
            select(table)
        }.exists()
}