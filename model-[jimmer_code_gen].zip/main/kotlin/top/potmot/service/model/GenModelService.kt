package top.potmot.service.model

import cn.dev33.satoken.annotation.SaCheckPermission
import jakarta.validation.Valid
import org.babyfish.jimmer.Page
import org.babyfish.jimmer.sql.ast.mutation.AssociatedSaveMode
import org.babyfish.jimmer.sql.ast.mutation.SaveMode
import org.babyfish.jimmer.sql.kt.KSqlClient
import org.babyfish.jimmer.sql.kt.ast.expression.asc
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import top.potmot.entity.dto.query.PageQuery
import top.potmot.entity.model.GenModel
import top.potmot.entity.model.dto.GenModelDetailView
import top.potmot.entity.model.dto.GenModelInsertInput
import top.potmot.entity.model.dto.GenModelListView
import top.potmot.entity.model.dto.GenModelOptionView
import top.potmot.entity.model.dto.GenModelSpec
import top.potmot.entity.model.dto.GenModelUpdateFillView
import top.potmot.entity.model.dto.GenModelUpdateInput
import top.potmot.entity.model.id
import top.potmot.exception.AuthorizeException

@RestController
@RequestMapping("/genModel")
class GenModelService(
    private val sqlClient: KSqlClient
) {
    /**
     * 根据ID获取模型。
     *
     * @param id 模型的ID。
     * @return 模型的详细信息。
     */
    @GetMapping("/{id}")
    @SaCheckPermission("model:genModel:get")
    @Throws(AuthorizeException::class)
    fun get(@PathVariable id: Int): GenModelDetailView? =
        sqlClient.findById(GenModelDetailView::class, id)

    /**
     * 根据提供的查询参数列出模型。
     *
     * @param spec 查询参数。
     * @return 模型列表数据。
     */
    @PostMapping("/list")
    @SaCheckPermission("model:genModel:list")
    @Throws(AuthorizeException::class)
    fun list(@RequestBody spec: GenModelSpec): List<GenModelListView> =
        sqlClient.executeQuery(GenModel::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenModelListView::class))
        }

    /**
     * 根据提供的查询参数分页查询模型。
     *
     * @param query 分页查询参数。
     * @return 模型分页数据。
     */
    @PostMapping("/page")
    @SaCheckPermission("model:genModel:list")
    @Throws(AuthorizeException::class)
    fun page(@RequestBody query: PageQuery<GenModelSpec>): Page<GenModelListView> =
        sqlClient.createQuery(GenModel::class) {
            where(query.spec)
            orderBy(table.id.asc())
            select(table.fetch(GenModelListView::class))
        }.fetchPage(query.pageIndex, query.pageSize)

    /**
     * 根据提供的查询参数列出模型选项。
     *
     * @param spec 查询参数。
     * @return 模型列表数据。
     */
    @PostMapping("/list/options")
    @SaCheckPermission("model:genModel:select")
    @Throws(AuthorizeException::class)
    fun listOptions(@RequestBody spec: GenModelSpec): List<GenModelOptionView> =
        sqlClient.executeQuery(GenModel::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenModelOptionView::class))
        }

    /**
     * 插入新的模型。
     *
     * @param input 模型插入输入对象。
     * @return 插入的模型的ID。
     */
    @PostMapping
    @SaCheckPermission("model:genModel:insert")
    @Throws(AuthorizeException::class)
    @Transactional
    fun insert(@RequestBody @Valid input: GenModelInsertInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.INSERT_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 根据ID获取模型的更新回填信息。
     *
     * @param id 模型的ID。
     * @return 模型的更新回填信息。
     */
    @GetMapping("/{id}/forUpdate")
    @SaCheckPermission("model:genModel:update")
    @Throws(AuthorizeException::class)
    fun getForUpdate(@PathVariable id: Int): GenModelUpdateFillView? =
        sqlClient.findById(GenModelUpdateFillView::class, id)

    /**
     * 更新模型。
     *
     * @param input 模型更新输入对象。
     * @return 更新的模型的ID。
     */
    @PutMapping
    @SaCheckPermission("model:genModel:update")
    @Throws(AuthorizeException::class)
    @Transactional
    fun update(@RequestBody @Valid input: GenModelUpdateInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.UPDATE_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 删除指定ID的模型。
     *
     * @param ids 要删除的模型ID列表。
     * @return 删除的模型的行数。
     */
    @DeleteMapping
    @SaCheckPermission("model:genModel:delete")
    @Throws(AuthorizeException::class)
    @Transactional
    fun delete(@RequestParam ids: List<Int>): Int =
        sqlClient.deleteByIds(GenModel::class, ids).affectedRowCount(GenModel::class)
}