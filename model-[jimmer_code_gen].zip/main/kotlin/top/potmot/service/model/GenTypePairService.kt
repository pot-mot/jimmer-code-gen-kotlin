package top.potmot.service.model

import cn.dev33.satoken.annotation.SaCheckPermission
import jakarta.validation.Valid
import org.babyfish.jimmer.Page
import org.babyfish.jimmer.sql.ast.mutation.AssociatedSaveMode
import org.babyfish.jimmer.sql.ast.mutation.SaveMode
import org.babyfish.jimmer.sql.kt.KSqlClient
import org.babyfish.jimmer.sql.kt.ast.expression.asc
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import top.potmot.entity.dto.query.PageQuery
import top.potmot.entity.model.GenTypePair
import top.potmot.entity.model.dto.GenTypePairDetailView
import top.potmot.entity.model.dto.GenTypePairInsertInput
import top.potmot.entity.model.dto.GenTypePairListView
import top.potmot.entity.model.dto.GenTypePairOptionView
import top.potmot.entity.model.dto.GenTypePairSpec
import top.potmot.entity.model.dto.GenTypePairUpdateFillView
import top.potmot.entity.model.dto.GenTypePairUpdateInput
import top.potmot.entity.model.id
import top.potmot.exception.AuthorizeException

@RestController
@RequestMapping("/genTypePair")
class GenTypePairService(
    private val sqlClient: KSqlClient
) {
    /**
     * 根据ID获取类型对。
     *
     * @param id 类型对的ID。
     * @return 类型对的详细信息。
     */
    @GetMapping("/{id}")
    @SaCheckPermission("model:genTypePair:get")
    @Throws(AuthorizeException::class)
    fun get(@PathVariable id: Long): GenTypePairDetailView? =
        sqlClient.findById(GenTypePairDetailView::class, id)

    /**
     * 根据提供的查询参数列出类型对。
     *
     * @param spec 查询参数。
     * @return 类型对列表数据。
     */
    @PostMapping("/list")
    @SaCheckPermission("model:genTypePair:list")
    @Throws(AuthorizeException::class)
    fun list(@RequestBody spec: GenTypePairSpec): List<GenTypePairListView> =
        sqlClient.executeQuery(GenTypePair::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenTypePairListView::class))
        }

    /**
     * 根据提供的查询参数分页查询类型对。
     *
     * @param query 分页查询参数。
     * @return 类型对分页数据。
     */
    @PostMapping("/page")
    @SaCheckPermission("model:genTypePair:list")
    @Throws(AuthorizeException::class)
    fun page(@RequestBody query: PageQuery<GenTypePairSpec>): Page<GenTypePairListView> =
        sqlClient.createQuery(GenTypePair::class) {
            where(query.spec)
            orderBy(table.id.asc())
            select(table.fetch(GenTypePairListView::class))
        }.fetchPage(query.pageIndex, query.pageSize)

    /**
     * 根据提供的查询参数列出类型对选项。
     *
     * @param spec 查询参数。
     * @return 类型对列表数据。
     */
    @PostMapping("/list/options")
    @SaCheckPermission("model:genTypePair:select")
    @Throws(AuthorizeException::class)
    fun listOptions(@RequestBody spec: GenTypePairSpec): List<GenTypePairOptionView> =
        sqlClient.executeQuery(GenTypePair::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenTypePairOptionView::class))
        }

    /**
     * 插入新的类型对。
     *
     * @param input 类型对插入输入对象。
     * @return 插入的类型对的ID。
     */
    @PostMapping
    @SaCheckPermission("model:genTypePair:insert")
    @Throws(AuthorizeException::class)
    @Transactional
    fun insert(@RequestBody @Valid input: GenTypePairInsertInput): Long =
        sqlClient.save(input) {
            setMode(SaveMode.INSERT_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 根据ID获取类型对的更新回填信息。
     *
     * @param id 类型对的ID。
     * @return 类型对的更新回填信息。
     */
    @GetMapping("/{id}/forUpdate")
    @SaCheckPermission("model:genTypePair:update")
    @Throws(AuthorizeException::class)
    fun getForUpdate(@PathVariable id: Long): GenTypePairUpdateFillView? =
        sqlClient.findById(GenTypePairUpdateFillView::class, id)

    /**
     * 更新类型对。
     *
     * @param input 类型对更新输入对象。
     * @return 更新的类型对的ID。
     */
    @PutMapping
    @SaCheckPermission("model:genTypePair:update")
    @Throws(AuthorizeException::class)
    @Transactional
    fun update(@RequestBody @Valid input: GenTypePairUpdateInput): Long =
        sqlClient.save(input) {
            setMode(SaveMode.UPDATE_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 删除指定ID的类型对。
     *
     * @param ids 要删除的类型对ID列表。
     * @return 删除的类型对的行数。
     */
    @DeleteMapping
    @SaCheckPermission("model:genTypePair:delete")
    @Throws(AuthorizeException::class)
    @Transactional
    fun delete(@RequestParam ids: List<Long>): Int =
        sqlClient.deleteByIds(GenTypePair::class, ids).affectedRowCount(GenTypePair::class)
}