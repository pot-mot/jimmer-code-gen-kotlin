package top.potmot.service.model

import cn.dev33.satoken.annotation.SaCheckPermission
import jakarta.validation.Valid
import org.babyfish.jimmer.Page
import org.babyfish.jimmer.sql.ast.mutation.AssociatedSaveMode
import org.babyfish.jimmer.sql.ast.mutation.SaveMode
import org.babyfish.jimmer.sql.kt.KSqlClient
import org.babyfish.jimmer.sql.kt.ast.expression.asc
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import top.potmot.entity.dto.query.PageQuery
import top.potmot.entity.model.GenModelConfig
import top.potmot.entity.model.dto.GenModelConfigDetailView
import top.potmot.entity.model.dto.GenModelConfigExistByModelSpec
import top.potmot.entity.model.dto.GenModelConfigInsertInput
import top.potmot.entity.model.dto.GenModelConfigListView
import top.potmot.entity.model.dto.GenModelConfigOptionView
import top.potmot.entity.model.dto.GenModelConfigSpec
import top.potmot.entity.model.dto.GenModelConfigUpdateFillView
import top.potmot.entity.model.dto.GenModelConfigUpdateInput
import top.potmot.entity.model.id
import top.potmot.exception.AuthorizeException

@RestController
@RequestMapping("/genModelConfig")
class GenModelConfigService(
    private val sqlClient: KSqlClient
) {
    /**
     * 根据ID获取模型配置。
     *
     * @param id 模型配置的ID。
     * @return 模型配置的详细信息。
     */
    @GetMapping("/{id}")
    @SaCheckPermission("model:genModelConfig:get")
    @Throws(AuthorizeException::class)
    fun get(@PathVariable id: Int): GenModelConfigDetailView? =
        sqlClient.findById(GenModelConfigDetailView::class, id)

    /**
     * 根据提供的查询参数列出模型配置。
     *
     * @param spec 查询参数。
     * @return 模型配置列表数据。
     */
    @PostMapping("/list")
    @SaCheckPermission("model:genModelConfig:list")
    @Throws(AuthorizeException::class)
    fun list(@RequestBody spec: GenModelConfigSpec): List<GenModelConfigListView> =
        sqlClient.executeQuery(GenModelConfig::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenModelConfigListView::class))
        }

    /**
     * 根据提供的查询参数分页查询模型配置。
     *
     * @param query 分页查询参数。
     * @return 模型配置分页数据。
     */
    @PostMapping("/page")
    @SaCheckPermission("model:genModelConfig:list")
    @Throws(AuthorizeException::class)
    fun page(@RequestBody query: PageQuery<GenModelConfigSpec>): Page<GenModelConfigListView> =
        sqlClient.createQuery(GenModelConfig::class) {
            where(query.spec)
            orderBy(table.id.asc())
            select(table.fetch(GenModelConfigListView::class))
        }.fetchPage(query.pageIndex, query.pageSize)

    /**
     * 根据提供的查询参数列出模型配置选项。
     *
     * @param spec 查询参数。
     * @return 模型配置列表数据。
     */
    @PostMapping("/list/options")
    @SaCheckPermission("model:genModelConfig:select")
    @Throws(AuthorizeException::class)
    fun listOptions(@RequestBody spec: GenModelConfigSpec): List<GenModelConfigOptionView> =
        sqlClient.executeQuery(GenModelConfig::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenModelConfigOptionView::class))
        }

    /**
     * 插入新的模型配置。
     *
     * @param input 模型配置插入输入对象。
     * @return 插入的模型配置的ID。
     */
    @PostMapping
    @SaCheckPermission("model:genModelConfig:insert")
    @Throws(AuthorizeException::class)
    @Transactional
    fun insert(@RequestBody @Valid input: GenModelConfigInsertInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.INSERT_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 根据ID获取模型配置的更新回填信息。
     *
     * @param id 模型配置的ID。
     * @return 模型配置的更新回填信息。
     */
    @GetMapping("/{id}/forUpdate")
    @SaCheckPermission("model:genModelConfig:update")
    @Throws(AuthorizeException::class)
    fun getForUpdate(@PathVariable id: Int): GenModelConfigUpdateFillView? =
        sqlClient.findById(GenModelConfigUpdateFillView::class, id)

    /**
     * 更新模型配置。
     *
     * @param input 模型配置更新输入对象。
     * @return 更新的模型配置的ID。
     */
    @PutMapping
    @SaCheckPermission("model:genModelConfig:update")
    @Throws(AuthorizeException::class)
    @Transactional
    fun update(@RequestBody @Valid input: GenModelConfigUpdateInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.UPDATE_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 删除指定ID的模型配置。
     *
     * @param ids 要删除的模型配置ID列表。
     * @return 删除的模型配置的行数。
     */
    @DeleteMapping
    @SaCheckPermission("model:genModelConfig:delete")
    @Throws(AuthorizeException::class)
    @Transactional
    fun delete(@RequestParam ids: List<Int>): Int =
        sqlClient.deleteByIds(GenModelConfig::class, ids).affectedRowCount(GenModelConfig::class)

    /**
     * 根据 模型 校验模型配置是否存在。
     *
     * @param spec 模型配置校验规格对象。
     * @return 模型配置是否存在。
     */
    @PostMapping("/existByModel")
    @SaCheckPermission("model:genModelConfig:list")
    @Throws(AuthorizeException::class)
    fun existByModel(@RequestBody spec: GenModelConfigExistByModelSpec): Boolean =
        sqlClient.createQuery(GenModelConfig::class) {
            where(spec)
            select(table)
        }.exists()
}