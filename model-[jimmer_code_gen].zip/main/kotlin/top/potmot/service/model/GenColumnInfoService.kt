package top.potmot.service.model

import cn.dev33.satoken.annotation.SaCheckPermission
import jakarta.validation.Valid
import org.babyfish.jimmer.Page
import org.babyfish.jimmer.sql.ast.mutation.AssociatedSaveMode
import org.babyfish.jimmer.sql.ast.mutation.SaveMode
import org.babyfish.jimmer.sql.kt.KSqlClient
import org.babyfish.jimmer.sql.kt.ast.expression.asc
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import top.potmot.entity.dto.query.PageQuery
import top.potmot.entity.model.GenColumnInfo
import top.potmot.entity.model.dto.GenColumnInfoDetailView
import top.potmot.entity.model.dto.GenColumnInfoInsertInput
import top.potmot.entity.model.dto.GenColumnInfoListView
import top.potmot.entity.model.dto.GenColumnInfoOptionView
import top.potmot.entity.model.dto.GenColumnInfoSpec
import top.potmot.entity.model.dto.GenColumnInfoUpdateFillView
import top.potmot.entity.model.dto.GenColumnInfoUpdateInput
import top.potmot.entity.model.id
import top.potmot.exception.AuthorizeException

@RestController
@RequestMapping("/genColumnInfo")
class GenColumnInfoService(
    private val sqlClient: KSqlClient
) {
    /**
     * 根据ID获取列信息。
     *
     * @param id 列信息的ID。
     * @return 列信息的详细信息。
     */
    @GetMapping("/{id}")
    @SaCheckPermission("model:genColumnInfo:get")
    @Throws(AuthorizeException::class)
    fun get(@PathVariable id: Int): GenColumnInfoDetailView? =
        sqlClient.findById(GenColumnInfoDetailView::class, id)

    /**
     * 根据提供的查询参数列出列信息。
     *
     * @param spec 查询参数。
     * @return 列信息列表数据。
     */
    @PostMapping("/list")
    @SaCheckPermission("model:genColumnInfo:list")
    @Throws(AuthorizeException::class)
    fun list(@RequestBody spec: GenColumnInfoSpec): List<GenColumnInfoListView> =
        sqlClient.executeQuery(GenColumnInfo::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenColumnInfoListView::class))
        }

    /**
     * 根据提供的查询参数分页查询列信息。
     *
     * @param query 分页查询参数。
     * @return 列信息分页数据。
     */
    @PostMapping("/page")
    @SaCheckPermission("model:genColumnInfo:list")
    @Throws(AuthorizeException::class)
    fun page(@RequestBody query: PageQuery<GenColumnInfoSpec>): Page<GenColumnInfoListView> =
        sqlClient.createQuery(GenColumnInfo::class) {
            where(query.spec)
            orderBy(table.id.asc())
            select(table.fetch(GenColumnInfoListView::class))
        }.fetchPage(query.pageIndex, query.pageSize)

    /**
     * 根据提供的查询参数列出列信息选项。
     *
     * @param spec 查询参数。
     * @return 列信息列表数据。
     */
    @PostMapping("/list/options")
    @SaCheckPermission("model:genColumnInfo:select")
    @Throws(AuthorizeException::class)
    fun listOptions(@RequestBody spec: GenColumnInfoSpec): List<GenColumnInfoOptionView> =
        sqlClient.executeQuery(GenColumnInfo::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenColumnInfoOptionView::class))
        }

    /**
     * 插入新的列信息。
     *
     * @param input 列信息插入输入对象。
     * @return 插入的列信息的ID。
     */
    @PostMapping
    @SaCheckPermission("model:genColumnInfo:insert")
    @Throws(AuthorizeException::class)
    @Transactional
    fun insert(@RequestBody @Valid input: GenColumnInfoInsertInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.INSERT_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 根据ID获取列信息的更新回填信息。
     *
     * @param id 列信息的ID。
     * @return 列信息的更新回填信息。
     */
    @GetMapping("/{id}/forUpdate")
    @SaCheckPermission("model:genColumnInfo:update")
    @Throws(AuthorizeException::class)
    fun getForUpdate(@PathVariable id: Int): GenColumnInfoUpdateFillView? =
        sqlClient.findById(GenColumnInfoUpdateFillView::class, id)

    /**
     * 更新列信息。
     *
     * @param input 列信息更新输入对象。
     * @return 更新的列信息的ID。
     */
    @PutMapping
    @SaCheckPermission("model:genColumnInfo:update")
    @Throws(AuthorizeException::class)
    @Transactional
    fun update(@RequestBody @Valid input: GenColumnInfoUpdateInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.UPDATE_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 删除指定ID的列信息。
     *
     * @param ids 要删除的列信息ID列表。
     * @return 删除的列信息的行数。
     */
    @DeleteMapping
    @SaCheckPermission("model:genColumnInfo:delete")
    @Throws(AuthorizeException::class)
    @Transactional
    fun delete(@RequestParam ids: List<Int>): Int =
        sqlClient.deleteByIds(GenColumnInfo::class, ids).affectedRowCount(GenColumnInfo::class)
}