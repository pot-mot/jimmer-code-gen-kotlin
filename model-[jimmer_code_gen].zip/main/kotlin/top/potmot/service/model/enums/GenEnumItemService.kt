package top.potmot.service.model.enums

import cn.dev33.satoken.annotation.SaCheckPermission
import jakarta.validation.Valid
import org.babyfish.jimmer.Page
import org.babyfish.jimmer.sql.ast.mutation.AssociatedSaveMode
import org.babyfish.jimmer.sql.ast.mutation.SaveMode
import org.babyfish.jimmer.sql.kt.KSqlClient
import org.babyfish.jimmer.sql.kt.ast.expression.asc
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import top.potmot.entity.dto.query.PageQuery
import top.potmot.entity.model.enums.GenEnumItem
import top.potmot.entity.model.enums.dto.GenEnumItemDetailView
import top.potmot.entity.model.enums.dto.GenEnumItemExistByEnumAndNameSpec
import top.potmot.entity.model.enums.dto.GenEnumItemInsertInput
import top.potmot.entity.model.enums.dto.GenEnumItemListView
import top.potmot.entity.model.enums.dto.GenEnumItemOptionView
import top.potmot.entity.model.enums.dto.GenEnumItemSpec
import top.potmot.entity.model.enums.dto.GenEnumItemUpdateFillView
import top.potmot.entity.model.enums.dto.GenEnumItemUpdateInput
import top.potmot.entity.model.enums.id
import top.potmot.exception.AuthorizeException

@RestController
@RequestMapping("/genEnumItem")
class GenEnumItemService(
    private val sqlClient: KSqlClient
) {
    /**
     * 根据ID获取枚举元素。
     *
     * @param id 枚举元素的ID。
     * @return 枚举元素的详细信息。
     */
    @GetMapping("/{id}")
    @SaCheckPermission("model:enums:genEnumItem:get")
    @Throws(AuthorizeException::class)
    fun get(@PathVariable id: Int): GenEnumItemDetailView? =
        sqlClient.findById(GenEnumItemDetailView::class, id)

    /**
     * 根据提供的查询参数列出枚举元素。
     *
     * @param spec 查询参数。
     * @return 枚举元素列表数据。
     */
    @PostMapping("/list")
    @SaCheckPermission("model:enums:genEnumItem:list")
    @Throws(AuthorizeException::class)
    fun list(@RequestBody spec: GenEnumItemSpec): List<GenEnumItemListView> =
        sqlClient.executeQuery(GenEnumItem::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenEnumItemListView::class))
        }

    /**
     * 根据提供的查询参数分页查询枚举元素。
     *
     * @param query 分页查询参数。
     * @return 枚举元素分页数据。
     */
    @PostMapping("/page")
    @SaCheckPermission("model:enums:genEnumItem:list")
    @Throws(AuthorizeException::class)
    fun page(@RequestBody query: PageQuery<GenEnumItemSpec>): Page<GenEnumItemListView> =
        sqlClient.createQuery(GenEnumItem::class) {
            where(query.spec)
            orderBy(table.id.asc())
            select(table.fetch(GenEnumItemListView::class))
        }.fetchPage(query.pageIndex, query.pageSize)

    /**
     * 根据提供的查询参数列出枚举元素选项。
     *
     * @param spec 查询参数。
     * @return 枚举元素列表数据。
     */
    @PostMapping("/list/options")
    @SaCheckPermission("model:enums:genEnumItem:select")
    @Throws(AuthorizeException::class)
    fun listOptions(@RequestBody spec: GenEnumItemSpec): List<GenEnumItemOptionView> =
        sqlClient.executeQuery(GenEnumItem::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenEnumItemOptionView::class))
        }

    /**
     * 插入新的枚举元素。
     *
     * @param input 枚举元素插入输入对象。
     * @return 插入的枚举元素的ID。
     */
    @PostMapping
    @SaCheckPermission("model:enums:genEnumItem:insert")
    @Throws(AuthorizeException::class)
    @Transactional
    fun insert(@RequestBody @Valid input: GenEnumItemInsertInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.INSERT_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 根据ID获取枚举元素的更新回填信息。
     *
     * @param id 枚举元素的ID。
     * @return 枚举元素的更新回填信息。
     */
    @GetMapping("/{id}/forUpdate")
    @SaCheckPermission("model:enums:genEnumItem:update")
    @Throws(AuthorizeException::class)
    fun getForUpdate(@PathVariable id: Int): GenEnumItemUpdateFillView? =
        sqlClient.findById(GenEnumItemUpdateFillView::class, id)

    /**
     * 更新枚举元素。
     *
     * @param input 枚举元素更新输入对象。
     * @return 更新的枚举元素的ID。
     */
    @PutMapping
    @SaCheckPermission("model:enums:genEnumItem:update")
    @Throws(AuthorizeException::class)
    @Transactional
    fun update(@RequestBody @Valid input: GenEnumItemUpdateInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.UPDATE_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 删除指定ID的枚举元素。
     *
     * @param ids 要删除的枚举元素ID列表。
     * @return 删除的枚举元素的行数。
     */
    @DeleteMapping
    @SaCheckPermission("model:enums:genEnumItem:delete")
    @Throws(AuthorizeException::class)
    @Transactional
    fun delete(@RequestParam ids: List<Int>): Int =
        sqlClient.deleteByIds(GenEnumItem::class, ids).affectedRowCount(GenEnumItem::class)

    /**
     * 根据 枚举 和 名称 校验枚举元素是否存在。
     *
     * @param spec 枚举元素校验规格对象。
     * @return 枚举元素是否存在。
     */
    @PostMapping("/existByEnumAndName")
    @SaCheckPermission("model:enums:genEnumItem:list")
    @Throws(AuthorizeException::class)
    fun existByEnumAndName(@RequestBody spec: GenEnumItemExistByEnumAndNameSpec): Boolean =
        sqlClient.createQuery(GenEnumItem::class) {
            where(spec)
            select(table)
        }.exists()
}