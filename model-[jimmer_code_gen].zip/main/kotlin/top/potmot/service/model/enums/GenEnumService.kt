package top.potmot.service.model.enums

import cn.dev33.satoken.annotation.SaCheckPermission
import jakarta.validation.Valid
import org.babyfish.jimmer.Page
import org.babyfish.jimmer.sql.ast.mutation.AssociatedSaveMode
import org.babyfish.jimmer.sql.ast.mutation.SaveMode
import org.babyfish.jimmer.sql.kt.KSqlClient
import org.babyfish.jimmer.sql.kt.ast.expression.asc
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import top.potmot.entity.dto.query.PageQuery
import top.potmot.entity.model.enums.GenEnum
import top.potmot.entity.model.enums.dto.GenEnumDetailView
import top.potmot.entity.model.enums.dto.GenEnumExistByGroupAndNameSpec
import top.potmot.entity.model.enums.dto.GenEnumInsertInput
import top.potmot.entity.model.enums.dto.GenEnumListView
import top.potmot.entity.model.enums.dto.GenEnumOptionView
import top.potmot.entity.model.enums.dto.GenEnumSpec
import top.potmot.entity.model.enums.dto.GenEnumUpdateFillView
import top.potmot.entity.model.enums.dto.GenEnumUpdateInput
import top.potmot.entity.model.enums.id
import top.potmot.exception.AuthorizeException

@RestController
@RequestMapping("/genEnum")
class GenEnumService(
    private val sqlClient: KSqlClient
) {
    /**
     * 根据ID获取枚举。
     *
     * @param id 枚举的ID。
     * @return 枚举的详细信息。
     */
    @GetMapping("/{id}")
    @SaCheckPermission("model:enums:genEnum:get")
    @Throws(AuthorizeException::class)
    fun get(@PathVariable id: Int): GenEnumDetailView? =
        sqlClient.findById(GenEnumDetailView::class, id)

    /**
     * 根据提供的查询参数列出枚举。
     *
     * @param spec 查询参数。
     * @return 枚举列表数据。
     */
    @PostMapping("/list")
    @SaCheckPermission("model:enums:genEnum:list")
    @Throws(AuthorizeException::class)
    fun list(@RequestBody spec: GenEnumSpec): List<GenEnumListView> =
        sqlClient.executeQuery(GenEnum::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenEnumListView::class))
        }

    /**
     * 根据提供的查询参数分页查询枚举。
     *
     * @param query 分页查询参数。
     * @return 枚举分页数据。
     */
    @PostMapping("/page")
    @SaCheckPermission("model:enums:genEnum:list")
    @Throws(AuthorizeException::class)
    fun page(@RequestBody query: PageQuery<GenEnumSpec>): Page<GenEnumListView> =
        sqlClient.createQuery(GenEnum::class) {
            where(query.spec)
            orderBy(table.id.asc())
            select(table.fetch(GenEnumListView::class))
        }.fetchPage(query.pageIndex, query.pageSize)

    /**
     * 根据提供的查询参数列出枚举选项。
     *
     * @param spec 查询参数。
     * @return 枚举列表数据。
     */
    @PostMapping("/list/options")
    @SaCheckPermission("model:enums:genEnum:select")
    @Throws(AuthorizeException::class)
    fun listOptions(@RequestBody spec: GenEnumSpec): List<GenEnumOptionView> =
        sqlClient.executeQuery(GenEnum::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenEnumOptionView::class))
        }

    /**
     * 插入新的枚举。
     *
     * @param input 枚举插入输入对象。
     * @return 插入的枚举的ID。
     */
    @PostMapping
    @SaCheckPermission("model:enums:genEnum:insert")
    @Throws(AuthorizeException::class)
    @Transactional
    fun insert(@RequestBody @Valid input: GenEnumInsertInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.INSERT_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 根据ID获取枚举的更新回填信息。
     *
     * @param id 枚举的ID。
     * @return 枚举的更新回填信息。
     */
    @GetMapping("/{id}/forUpdate")
    @SaCheckPermission("model:enums:genEnum:update")
    @Throws(AuthorizeException::class)
    fun getForUpdate(@PathVariable id: Int): GenEnumUpdateFillView? =
        sqlClient.findById(GenEnumUpdateFillView::class, id)

    /**
     * 更新枚举。
     *
     * @param input 枚举更新输入对象。
     * @return 更新的枚举的ID。
     */
    @PutMapping
    @SaCheckPermission("model:enums:genEnum:update")
    @Throws(AuthorizeException::class)
    @Transactional
    fun update(@RequestBody @Valid input: GenEnumUpdateInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.UPDATE_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 删除指定ID的枚举。
     *
     * @param ids 要删除的枚举ID列表。
     * @return 删除的枚举的行数。
     */
    @DeleteMapping
    @SaCheckPermission("model:enums:genEnum:delete")
    @Throws(AuthorizeException::class)
    @Transactional
    fun delete(@RequestParam ids: List<Int>): Int =
        sqlClient.deleteByIds(GenEnum::class, ids).affectedRowCount(GenEnum::class)

    /**
     * 根据 分组 和 枚举名 校验枚举是否存在。
     *
     * @param spec 枚举校验规格对象。
     * @return 枚举是否存在。
     */
    @PostMapping("/existByGroupAndName")
    @SaCheckPermission("model:enums:genEnum:list")
    @Throws(AuthorizeException::class)
    fun existByGroupAndName(@RequestBody spec: GenEnumExistByGroupAndNameSpec): Boolean =
        sqlClient.createQuery(GenEnum::class) {
            where(spec)
            select(table)
        }.exists()
}