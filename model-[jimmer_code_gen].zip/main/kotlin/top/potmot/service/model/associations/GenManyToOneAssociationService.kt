package top.potmot.service.model.associations

import cn.dev33.satoken.annotation.SaCheckPermission
import jakarta.validation.Valid
import org.babyfish.jimmer.Page
import org.babyfish.jimmer.sql.ast.mutation.AssociatedSaveMode
import org.babyfish.jimmer.sql.ast.mutation.SaveMode
import org.babyfish.jimmer.sql.kt.KSqlClient
import org.babyfish.jimmer.sql.kt.ast.expression.asc
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import top.potmot.entity.dto.query.PageQuery
import top.potmot.entity.model.associations.GenManyToOneAssociation
import top.potmot.entity.model.associations.dto.GenManyToOneAssociationDetailView
import top.potmot.entity.model.associations.dto.GenManyToOneAssociationInsertInput
import top.potmot.entity.model.associations.dto.GenManyToOneAssociationListView
import top.potmot.entity.model.associations.dto.GenManyToOneAssociationOptionView
import top.potmot.entity.model.associations.dto.GenManyToOneAssociationSpec
import top.potmot.entity.model.associations.dto.GenManyToOneAssociationUpdateFillView
import top.potmot.entity.model.associations.dto.GenManyToOneAssociationUpdateInput
import top.potmot.entity.model.associations.id
import top.potmot.exception.AuthorizeException

@RestController
@RequestMapping("/genManyToOneAssociation")
class GenManyToOneAssociationService(
    private val sqlClient: KSqlClient
) {
    /**
     * 根据ID获取多对一关联。
     *
     * @param id 多对一关联的ID。
     * @return 多对一关联的详细信息。
     */
    @GetMapping("/{id}")
    @SaCheckPermission("model:associations:genManyToOneAssociation:get")
    @Throws(AuthorizeException::class)
    fun get(@PathVariable id: Int): GenManyToOneAssociationDetailView? =
        sqlClient.findById(GenManyToOneAssociationDetailView::class, id)

    /**
     * 根据提供的查询参数列出多对一关联。
     *
     * @param spec 查询参数。
     * @return 多对一关联列表数据。
     */
    @PostMapping("/list")
    @SaCheckPermission("model:associations:genManyToOneAssociation:list")
    @Throws(AuthorizeException::class)
    fun list(@RequestBody spec: GenManyToOneAssociationSpec): List<GenManyToOneAssociationListView> =
        sqlClient.executeQuery(GenManyToOneAssociation::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenManyToOneAssociationListView::class))
        }

    /**
     * 根据提供的查询参数分页查询多对一关联。
     *
     * @param query 分页查询参数。
     * @return 多对一关联分页数据。
     */
    @PostMapping("/page")
    @SaCheckPermission("model:associations:genManyToOneAssociation:list")
    @Throws(AuthorizeException::class)
    fun page(@RequestBody query: PageQuery<GenManyToOneAssociationSpec>): Page<GenManyToOneAssociationListView> =
        sqlClient.createQuery(GenManyToOneAssociation::class) {
            where(query.spec)
            orderBy(table.id.asc())
            select(table.fetch(GenManyToOneAssociationListView::class))
        }.fetchPage(query.pageIndex, query.pageSize)

    /**
     * 根据提供的查询参数列出多对一关联选项。
     *
     * @param spec 查询参数。
     * @return 多对一关联列表数据。
     */
    @PostMapping("/list/options")
    @SaCheckPermission("model:associations:genManyToOneAssociation:select")
    @Throws(AuthorizeException::class)
    fun listOptions(@RequestBody spec: GenManyToOneAssociationSpec): List<GenManyToOneAssociationOptionView> =
        sqlClient.executeQuery(GenManyToOneAssociation::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenManyToOneAssociationOptionView::class))
        }

    /**
     * 插入新的多对一关联。
     *
     * @param input 多对一关联插入输入对象。
     * @return 插入的多对一关联的ID。
     */
    @PostMapping
    @SaCheckPermission("model:associations:genManyToOneAssociation:insert")
    @Throws(AuthorizeException::class)
    @Transactional
    fun insert(@RequestBody @Valid input: GenManyToOneAssociationInsertInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.INSERT_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 根据ID获取多对一关联的更新回填信息。
     *
     * @param id 多对一关联的ID。
     * @return 多对一关联的更新回填信息。
     */
    @GetMapping("/{id}/forUpdate")
    @SaCheckPermission("model:associations:genManyToOneAssociation:update")
    @Throws(AuthorizeException::class)
    fun getForUpdate(@PathVariable id: Int): GenManyToOneAssociationUpdateFillView? =
        sqlClient.findById(GenManyToOneAssociationUpdateFillView::class, id)

    /**
     * 更新多对一关联。
     *
     * @param input 多对一关联更新输入对象。
     * @return 更新的多对一关联的ID。
     */
    @PutMapping
    @SaCheckPermission("model:associations:genManyToOneAssociation:update")
    @Throws(AuthorizeException::class)
    @Transactional
    fun update(@RequestBody @Valid input: GenManyToOneAssociationUpdateInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.UPDATE_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 删除指定ID的多对一关联。
     *
     * @param ids 要删除的多对一关联ID列表。
     * @return 删除的多对一关联的行数。
     */
    @DeleteMapping
    @SaCheckPermission("model:associations:genManyToOneAssociation:delete")
    @Throws(AuthorizeException::class)
    @Transactional
    fun delete(@RequestParam ids: List<Int>): Int =
        sqlClient.deleteByIds(GenManyToOneAssociation::class, ids).affectedRowCount(GenManyToOneAssociation::class)
}