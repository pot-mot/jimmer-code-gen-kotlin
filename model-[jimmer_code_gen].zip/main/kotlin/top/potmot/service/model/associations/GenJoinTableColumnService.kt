package top.potmot.service.model.associations

import cn.dev33.satoken.annotation.SaCheckPermission
import jakarta.validation.Valid
import org.babyfish.jimmer.Page
import org.babyfish.jimmer.sql.ast.mutation.AssociatedSaveMode
import org.babyfish.jimmer.sql.ast.mutation.SaveMode
import org.babyfish.jimmer.sql.kt.KSqlClient
import org.babyfish.jimmer.sql.kt.ast.expression.asc
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import top.potmot.entity.dto.query.PageQuery
import top.potmot.entity.model.associations.GenJoinTableColumn
import top.potmot.entity.model.associations.dto.GenJoinTableColumnDetailView
import top.potmot.entity.model.associations.dto.GenJoinTableColumnExistByJoinTableAndColumnNameSpec
import top.potmot.entity.model.associations.dto.GenJoinTableColumnInsertInput
import top.potmot.entity.model.associations.dto.GenJoinTableColumnListView
import top.potmot.entity.model.associations.dto.GenJoinTableColumnOptionView
import top.potmot.entity.model.associations.dto.GenJoinTableColumnSpec
import top.potmot.entity.model.associations.dto.GenJoinTableColumnUpdateFillView
import top.potmot.entity.model.associations.dto.GenJoinTableColumnUpdateInput
import top.potmot.entity.model.associations.id
import top.potmot.exception.AuthorizeException

@RestController
@RequestMapping("/genJoinTableColumn")
class GenJoinTableColumnService(
    private val sqlClient: KSqlClient
) {
    /**
     * 根据ID获取Join Table Join Column。
     *
     * @param id Join Table Join Column的ID。
     * @return Join Table Join Column的详细信息。
     */
    @GetMapping("/{id}")
    @SaCheckPermission("model:associations:genJoinTableColumn:get")
    @Throws(AuthorizeException::class)
    fun get(@PathVariable id: Int): GenJoinTableColumnDetailView? =
        sqlClient.findById(GenJoinTableColumnDetailView::class, id)

    /**
     * 根据提供的查询参数列出Join Table Join Column。
     *
     * @param spec 查询参数。
     * @return Join Table Join Column列表数据。
     */
    @PostMapping("/list")
    @SaCheckPermission("model:associations:genJoinTableColumn:list")
    @Throws(AuthorizeException::class)
    fun list(@RequestBody spec: GenJoinTableColumnSpec): List<GenJoinTableColumnListView> =
        sqlClient.executeQuery(GenJoinTableColumn::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenJoinTableColumnListView::class))
        }

    /**
     * 根据提供的查询参数分页查询Join Table Join Column。
     *
     * @param query 分页查询参数。
     * @return Join Table Join Column分页数据。
     */
    @PostMapping("/page")
    @SaCheckPermission("model:associations:genJoinTableColumn:list")
    @Throws(AuthorizeException::class)
    fun page(@RequestBody query: PageQuery<GenJoinTableColumnSpec>): Page<GenJoinTableColumnListView> =
        sqlClient.createQuery(GenJoinTableColumn::class) {
            where(query.spec)
            orderBy(table.id.asc())
            select(table.fetch(GenJoinTableColumnListView::class))
        }.fetchPage(query.pageIndex, query.pageSize)

    /**
     * 根据提供的查询参数列出Join Table Join Column选项。
     *
     * @param spec 查询参数。
     * @return Join Table Join Column列表数据。
     */
    @PostMapping("/list/options")
    @SaCheckPermission("model:associations:genJoinTableColumn:select")
    @Throws(AuthorizeException::class)
    fun listOptions(@RequestBody spec: GenJoinTableColumnSpec): List<GenJoinTableColumnOptionView> =
        sqlClient.executeQuery(GenJoinTableColumn::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenJoinTableColumnOptionView::class))
        }

    /**
     * 插入新的Join Table Join Column。
     *
     * @param input Join Table Join Column插入输入对象。
     * @return 插入的Join Table Join Column的ID。
     */
    @PostMapping
    @SaCheckPermission("model:associations:genJoinTableColumn:insert")
    @Throws(AuthorizeException::class)
    @Transactional
    fun insert(@RequestBody @Valid input: GenJoinTableColumnInsertInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.INSERT_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 根据ID获取Join Table Join Column的更新回填信息。
     *
     * @param id Join Table Join Column的ID。
     * @return Join Table Join Column的更新回填信息。
     */
    @GetMapping("/{id}/forUpdate")
    @SaCheckPermission("model:associations:genJoinTableColumn:update")
    @Throws(AuthorizeException::class)
    fun getForUpdate(@PathVariable id: Int): GenJoinTableColumnUpdateFillView? =
        sqlClient.findById(GenJoinTableColumnUpdateFillView::class, id)

    /**
     * 更新Join Table Join Column。
     *
     * @param input Join Table Join Column更新输入对象。
     * @return 更新的Join Table Join Column的ID。
     */
    @PutMapping
    @SaCheckPermission("model:associations:genJoinTableColumn:update")
    @Throws(AuthorizeException::class)
    @Transactional
    fun update(@RequestBody @Valid input: GenJoinTableColumnUpdateInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.UPDATE_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 删除指定ID的Join Table Join Column。
     *
     * @param ids 要删除的Join Table Join ColumnID列表。
     * @return 删除的Join Table Join Column的行数。
     */
    @DeleteMapping
    @SaCheckPermission("model:associations:genJoinTableColumn:delete")
    @Throws(AuthorizeException::class)
    @Transactional
    fun delete(@RequestParam ids: List<Int>): Int =
        sqlClient.deleteByIds(GenJoinTableColumn::class, ids).affectedRowCount(GenJoinTableColumn::class)

    /**
     * 根据 Join Table 和 本地列名称 校验Join Table Join Column是否存在。
     *
     * @param spec Join Table Join Column校验规格对象。
     * @return Join Table Join Column是否存在。
     */
    @PostMapping("/existByJoinTableAndColumnName")
    @SaCheckPermission("model:associations:genJoinTableColumn:list")
    @Throws(AuthorizeException::class)
    fun existByJoinTableAndColumnName(@RequestBody spec: GenJoinTableColumnExistByJoinTableAndColumnNameSpec): Boolean =
        sqlClient.createQuery(GenJoinTableColumn::class) {
            where(spec)
            select(table)
        }.exists()
}