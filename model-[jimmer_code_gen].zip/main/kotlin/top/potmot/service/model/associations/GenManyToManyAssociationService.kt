package top.potmot.service.model.associations

import cn.dev33.satoken.annotation.SaCheckPermission
import jakarta.validation.Valid
import org.babyfish.jimmer.Page
import org.babyfish.jimmer.sql.ast.mutation.AssociatedSaveMode
import org.babyfish.jimmer.sql.ast.mutation.SaveMode
import org.babyfish.jimmer.sql.kt.KSqlClient
import org.babyfish.jimmer.sql.kt.ast.expression.asc
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import top.potmot.entity.dto.query.PageQuery
import top.potmot.entity.model.associations.GenManyToManyAssociation
import top.potmot.entity.model.associations.dto.GenManyToManyAssociationDetailView
import top.potmot.entity.model.associations.dto.GenManyToManyAssociationInsertInput
import top.potmot.entity.model.associations.dto.GenManyToManyAssociationListView
import top.potmot.entity.model.associations.dto.GenManyToManyAssociationOptionView
import top.potmot.entity.model.associations.dto.GenManyToManyAssociationSpec
import top.potmot.entity.model.associations.dto.GenManyToManyAssociationUpdateFillView
import top.potmot.entity.model.associations.dto.GenManyToManyAssociationUpdateInput
import top.potmot.entity.model.associations.id
import top.potmot.exception.AuthorizeException

@RestController
@RequestMapping("/genManyToManyAssociation")
class GenManyToManyAssociationService(
    private val sqlClient: KSqlClient
) {
    /**
     * 根据ID获取多对多关联。
     *
     * @param id 多对多关联的ID。
     * @return 多对多关联的详细信息。
     */
    @GetMapping("/{id}")
    @SaCheckPermission("model:associations:genManyToManyAssociation:get")
    @Throws(AuthorizeException::class)
    fun get(@PathVariable id: Int): GenManyToManyAssociationDetailView? =
        sqlClient.findById(GenManyToManyAssociationDetailView::class, id)

    /**
     * 根据提供的查询参数列出多对多关联。
     *
     * @param spec 查询参数。
     * @return 多对多关联列表数据。
     */
    @PostMapping("/list")
    @SaCheckPermission("model:associations:genManyToManyAssociation:list")
    @Throws(AuthorizeException::class)
    fun list(@RequestBody spec: GenManyToManyAssociationSpec): List<GenManyToManyAssociationListView> =
        sqlClient.executeQuery(GenManyToManyAssociation::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenManyToManyAssociationListView::class))
        }

    /**
     * 根据提供的查询参数分页查询多对多关联。
     *
     * @param query 分页查询参数。
     * @return 多对多关联分页数据。
     */
    @PostMapping("/page")
    @SaCheckPermission("model:associations:genManyToManyAssociation:list")
    @Throws(AuthorizeException::class)
    fun page(@RequestBody query: PageQuery<GenManyToManyAssociationSpec>): Page<GenManyToManyAssociationListView> =
        sqlClient.createQuery(GenManyToManyAssociation::class) {
            where(query.spec)
            orderBy(table.id.asc())
            select(table.fetch(GenManyToManyAssociationListView::class))
        }.fetchPage(query.pageIndex, query.pageSize)

    /**
     * 根据提供的查询参数列出多对多关联选项。
     *
     * @param spec 查询参数。
     * @return 多对多关联列表数据。
     */
    @PostMapping("/list/options")
    @SaCheckPermission("model:associations:genManyToManyAssociation:select")
    @Throws(AuthorizeException::class)
    fun listOptions(@RequestBody spec: GenManyToManyAssociationSpec): List<GenManyToManyAssociationOptionView> =
        sqlClient.executeQuery(GenManyToManyAssociation::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenManyToManyAssociationOptionView::class))
        }

    /**
     * 插入新的多对多关联。
     *
     * @param input 多对多关联插入输入对象。
     * @return 插入的多对多关联的ID。
     */
    @PostMapping
    @SaCheckPermission("model:associations:genManyToManyAssociation:insert")
    @Throws(AuthorizeException::class)
    @Transactional
    fun insert(@RequestBody @Valid input: GenManyToManyAssociationInsertInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.INSERT_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 根据ID获取多对多关联的更新回填信息。
     *
     * @param id 多对多关联的ID。
     * @return 多对多关联的更新回填信息。
     */
    @GetMapping("/{id}/forUpdate")
    @SaCheckPermission("model:associations:genManyToManyAssociation:update")
    @Throws(AuthorizeException::class)
    fun getForUpdate(@PathVariable id: Int): GenManyToManyAssociationUpdateFillView? =
        sqlClient.findById(GenManyToManyAssociationUpdateFillView::class, id)

    /**
     * 更新多对多关联。
     *
     * @param input 多对多关联更新输入对象。
     * @return 更新的多对多关联的ID。
     */
    @PutMapping
    @SaCheckPermission("model:associations:genManyToManyAssociation:update")
    @Throws(AuthorizeException::class)
    @Transactional
    fun update(@RequestBody @Valid input: GenManyToManyAssociationUpdateInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.UPDATE_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 删除指定ID的多对多关联。
     *
     * @param ids 要删除的多对多关联ID列表。
     * @return 删除的多对多关联的行数。
     */
    @DeleteMapping
    @SaCheckPermission("model:associations:genManyToManyAssociation:delete")
    @Throws(AuthorizeException::class)
    @Transactional
    fun delete(@RequestParam ids: List<Int>): Int =
        sqlClient.deleteByIds(GenManyToManyAssociation::class, ids).affectedRowCount(GenManyToManyAssociation::class)
}