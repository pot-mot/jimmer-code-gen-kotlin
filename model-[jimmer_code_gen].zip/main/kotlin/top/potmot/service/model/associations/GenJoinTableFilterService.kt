package top.potmot.service.model.associations

import cn.dev33.satoken.annotation.SaCheckPermission
import jakarta.validation.Valid
import org.babyfish.jimmer.Page
import org.babyfish.jimmer.sql.ast.mutation.AssociatedSaveMode
import org.babyfish.jimmer.sql.ast.mutation.SaveMode
import org.babyfish.jimmer.sql.kt.KSqlClient
import org.babyfish.jimmer.sql.kt.ast.expression.asc
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import top.potmot.entity.dto.query.PageQuery
import top.potmot.entity.model.associations.GenJoinTableFilter
import top.potmot.entity.model.associations.dto.GenJoinTableFilterDetailView
import top.potmot.entity.model.associations.dto.GenJoinTableFilterInsertInput
import top.potmot.entity.model.associations.dto.GenJoinTableFilterListView
import top.potmot.entity.model.associations.dto.GenJoinTableFilterOptionView
import top.potmot.entity.model.associations.dto.GenJoinTableFilterSpec
import top.potmot.entity.model.associations.dto.GenJoinTableFilterUpdateFillView
import top.potmot.entity.model.associations.dto.GenJoinTableFilterUpdateInput
import top.potmot.entity.model.associations.id
import top.potmot.exception.AuthorizeException

@RestController
@RequestMapping("/genJoinTableFilter")
class GenJoinTableFilterService(
    private val sqlClient: KSqlClient
) {
    /**
     * 根据ID获取Join Table 过滤器。
     *
     * @param id Join Table 过滤器的ID。
     * @return Join Table 过滤器的详细信息。
     */
    @GetMapping("/{id}")
    @SaCheckPermission("model:associations:genJoinTableFilter:get")
    @Throws(AuthorizeException::class)
    fun get(@PathVariable id: Int): GenJoinTableFilterDetailView? =
        sqlClient.findById(GenJoinTableFilterDetailView::class, id)

    /**
     * 根据提供的查询参数列出Join Table 过滤器。
     *
     * @param spec 查询参数。
     * @return Join Table 过滤器列表数据。
     */
    @PostMapping("/list")
    @SaCheckPermission("model:associations:genJoinTableFilter:list")
    @Throws(AuthorizeException::class)
    fun list(@RequestBody spec: GenJoinTableFilterSpec): List<GenJoinTableFilterListView> =
        sqlClient.executeQuery(GenJoinTableFilter::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenJoinTableFilterListView::class))
        }

    /**
     * 根据提供的查询参数分页查询Join Table 过滤器。
     *
     * @param query 分页查询参数。
     * @return Join Table 过滤器分页数据。
     */
    @PostMapping("/page")
    @SaCheckPermission("model:associations:genJoinTableFilter:list")
    @Throws(AuthorizeException::class)
    fun page(@RequestBody query: PageQuery<GenJoinTableFilterSpec>): Page<GenJoinTableFilterListView> =
        sqlClient.createQuery(GenJoinTableFilter::class) {
            where(query.spec)
            orderBy(table.id.asc())
            select(table.fetch(GenJoinTableFilterListView::class))
        }.fetchPage(query.pageIndex, query.pageSize)

    /**
     * 根据提供的查询参数列出Join Table 过滤器选项。
     *
     * @param spec 查询参数。
     * @return Join Table 过滤器列表数据。
     */
    @PostMapping("/list/options")
    @SaCheckPermission("model:associations:genJoinTableFilter:select")
    @Throws(AuthorizeException::class)
    fun listOptions(@RequestBody spec: GenJoinTableFilterSpec): List<GenJoinTableFilterOptionView> =
        sqlClient.executeQuery(GenJoinTableFilter::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenJoinTableFilterOptionView::class))
        }

    /**
     * 插入新的Join Table 过滤器。
     *
     * @param input Join Table 过滤器插入输入对象。
     * @return 插入的Join Table 过滤器的ID。
     */
    @PostMapping
    @SaCheckPermission("model:associations:genJoinTableFilter:insert")
    @Throws(AuthorizeException::class)
    @Transactional
    fun insert(@RequestBody @Valid input: GenJoinTableFilterInsertInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.INSERT_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 根据ID获取Join Table 过滤器的更新回填信息。
     *
     * @param id Join Table 过滤器的ID。
     * @return Join Table 过滤器的更新回填信息。
     */
    @GetMapping("/{id}/forUpdate")
    @SaCheckPermission("model:associations:genJoinTableFilter:update")
    @Throws(AuthorizeException::class)
    fun getForUpdate(@PathVariable id: Int): GenJoinTableFilterUpdateFillView? =
        sqlClient.findById(GenJoinTableFilterUpdateFillView::class, id)

    /**
     * 更新Join Table 过滤器。
     *
     * @param input Join Table 过滤器更新输入对象。
     * @return 更新的Join Table 过滤器的ID。
     */
    @PutMapping
    @SaCheckPermission("model:associations:genJoinTableFilter:update")
    @Throws(AuthorizeException::class)
    @Transactional
    fun update(@RequestBody @Valid input: GenJoinTableFilterUpdateInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.UPDATE_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 删除指定ID的Join Table 过滤器。
     *
     * @param ids 要删除的Join Table 过滤器ID列表。
     * @return 删除的Join Table 过滤器的行数。
     */
    @DeleteMapping
    @SaCheckPermission("model:associations:genJoinTableFilter:delete")
    @Throws(AuthorizeException::class)
    @Transactional
    fun delete(@RequestParam ids: List<Int>): Int =
        sqlClient.deleteByIds(GenJoinTableFilter::class, ids).affectedRowCount(GenJoinTableFilter::class)
}