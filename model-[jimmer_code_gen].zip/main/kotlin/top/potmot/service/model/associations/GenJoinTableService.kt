package top.potmot.service.model.associations

import cn.dev33.satoken.annotation.SaCheckPermission
import jakarta.validation.Valid
import org.babyfish.jimmer.Page
import org.babyfish.jimmer.sql.ast.mutation.AssociatedSaveMode
import org.babyfish.jimmer.sql.ast.mutation.SaveMode
import org.babyfish.jimmer.sql.kt.KSqlClient
import org.babyfish.jimmer.sql.kt.ast.expression.asc
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import top.potmot.entity.dto.query.PageQuery
import top.potmot.entity.model.associations.GenJoinTable
import top.potmot.entity.model.associations.dto.GenJoinTableDetailView
import top.potmot.entity.model.associations.dto.GenJoinTableInsertInput
import top.potmot.entity.model.associations.dto.GenJoinTableListView
import top.potmot.entity.model.associations.dto.GenJoinTableOptionView
import top.potmot.entity.model.associations.dto.GenJoinTableSpec
import top.potmot.entity.model.associations.dto.GenJoinTableUpdateFillView
import top.potmot.entity.model.associations.dto.GenJoinTableUpdateInput
import top.potmot.entity.model.associations.id
import top.potmot.exception.AuthorizeException

@RestController
@RequestMapping("/genJoinTable")
class GenJoinTableService(
    private val sqlClient: KSqlClient
) {
    /**
     * 根据ID获取Join Table。
     *
     * @param id Join Table的ID。
     * @return Join Table的详细信息。
     */
    @GetMapping("/{id}")
    @SaCheckPermission("model:associations:genJoinTable:get")
    @Throws(AuthorizeException::class)
    fun get(@PathVariable id: Int): GenJoinTableDetailView? =
        sqlClient.findById(GenJoinTableDetailView::class, id)

    /**
     * 根据提供的查询参数列出Join Table。
     *
     * @param spec 查询参数。
     * @return Join Table列表数据。
     */
    @PostMapping("/list")
    @SaCheckPermission("model:associations:genJoinTable:list")
    @Throws(AuthorizeException::class)
    fun list(@RequestBody spec: GenJoinTableSpec): List<GenJoinTableListView> =
        sqlClient.executeQuery(GenJoinTable::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenJoinTableListView::class))
        }

    /**
     * 根据提供的查询参数分页查询Join Table。
     *
     * @param query 分页查询参数。
     * @return Join Table分页数据。
     */
    @PostMapping("/page")
    @SaCheckPermission("model:associations:genJoinTable:list")
    @Throws(AuthorizeException::class)
    fun page(@RequestBody query: PageQuery<GenJoinTableSpec>): Page<GenJoinTableListView> =
        sqlClient.createQuery(GenJoinTable::class) {
            where(query.spec)
            orderBy(table.id.asc())
            select(table.fetch(GenJoinTableListView::class))
        }.fetchPage(query.pageIndex, query.pageSize)

    /**
     * 根据提供的查询参数列出Join Table选项。
     *
     * @param spec 查询参数。
     * @return Join Table列表数据。
     */
    @PostMapping("/list/options")
    @SaCheckPermission("model:associations:genJoinTable:select")
    @Throws(AuthorizeException::class)
    fun listOptions(@RequestBody spec: GenJoinTableSpec): List<GenJoinTableOptionView> =
        sqlClient.executeQuery(GenJoinTable::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenJoinTableOptionView::class))
        }

    /**
     * 插入新的Join Table。
     *
     * @param input Join Table插入输入对象。
     * @return 插入的Join Table的ID。
     */
    @PostMapping
    @SaCheckPermission("model:associations:genJoinTable:insert")
    @Throws(AuthorizeException::class)
    @Transactional
    fun insert(@RequestBody @Valid input: GenJoinTableInsertInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.INSERT_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 根据ID获取Join Table的更新回填信息。
     *
     * @param id Join Table的ID。
     * @return Join Table的更新回填信息。
     */
    @GetMapping("/{id}/forUpdate")
    @SaCheckPermission("model:associations:genJoinTable:update")
    @Throws(AuthorizeException::class)
    fun getForUpdate(@PathVariable id: Int): GenJoinTableUpdateFillView? =
        sqlClient.findById(GenJoinTableUpdateFillView::class, id)

    /**
     * 更新Join Table。
     *
     * @param input Join Table更新输入对象。
     * @return 更新的Join Table的ID。
     */
    @PutMapping
    @SaCheckPermission("model:associations:genJoinTable:update")
    @Throws(AuthorizeException::class)
    @Transactional
    fun update(@RequestBody @Valid input: GenJoinTableUpdateInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.UPDATE_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 删除指定ID的Join Table。
     *
     * @param ids 要删除的Join TableID列表。
     * @return 删除的Join Table的行数。
     */
    @DeleteMapping
    @SaCheckPermission("model:associations:genJoinTable:delete")
    @Throws(AuthorizeException::class)
    @Transactional
    fun delete(@RequestParam ids: List<Int>): Int =
        sqlClient.deleteByIds(GenJoinTable::class, ids).affectedRowCount(GenJoinTable::class)
}