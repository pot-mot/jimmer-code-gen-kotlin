package top.potmot.service.model.associations

import cn.dev33.satoken.annotation.SaCheckPermission
import jakarta.validation.Valid
import org.babyfish.jimmer.Page
import org.babyfish.jimmer.sql.ast.mutation.AssociatedSaveMode
import org.babyfish.jimmer.sql.ast.mutation.SaveMode
import org.babyfish.jimmer.sql.kt.KSqlClient
import org.babyfish.jimmer.sql.kt.ast.expression.asc
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import top.potmot.entity.dto.query.PageQuery
import top.potmot.entity.model.associations.GenJoinTableLogicalDeleteFilter
import top.potmot.entity.model.associations.dto.GenJoinTableLogicalDeleteFilterDetailView
import top.potmot.entity.model.associations.dto.GenJoinTableLogicalDeleteFilterInsertInput
import top.potmot.entity.model.associations.dto.GenJoinTableLogicalDeleteFilterListView
import top.potmot.entity.model.associations.dto.GenJoinTableLogicalDeleteFilterOptionView
import top.potmot.entity.model.associations.dto.GenJoinTableLogicalDeleteFilterSpec
import top.potmot.entity.model.associations.dto.GenJoinTableLogicalDeleteFilterUpdateFillView
import top.potmot.entity.model.associations.dto.GenJoinTableLogicalDeleteFilterUpdateInput
import top.potmot.entity.model.associations.id
import top.potmot.exception.AuthorizeException

@RestController
@RequestMapping("/genJoinTableLogicalDeleteFilter")
class GenJoinTableLogicalDeleteFilterService(
    private val sqlClient: KSqlClient
) {
    /**
     * 根据ID获取Join Table 逻辑删除过滤器。
     *
     * @param id Join Table 逻辑删除过滤器的ID。
     * @return Join Table 逻辑删除过滤器的详细信息。
     */
    @GetMapping("/{id}")
    @SaCheckPermission("model:associations:genJoinTableLogicalDeleteFilter:get")
    @Throws(AuthorizeException::class)
    fun get(@PathVariable id: Int): GenJoinTableLogicalDeleteFilterDetailView? =
        sqlClient.findById(GenJoinTableLogicalDeleteFilterDetailView::class, id)

    /**
     * 根据提供的查询参数列出Join Table 逻辑删除过滤器。
     *
     * @param spec 查询参数。
     * @return Join Table 逻辑删除过滤器列表数据。
     */
    @PostMapping("/list")
    @SaCheckPermission("model:associations:genJoinTableLogicalDeleteFilter:list")
    @Throws(AuthorizeException::class)
    fun list(@RequestBody spec: GenJoinTableLogicalDeleteFilterSpec): List<GenJoinTableLogicalDeleteFilterListView> =
        sqlClient.executeQuery(GenJoinTableLogicalDeleteFilter::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenJoinTableLogicalDeleteFilterListView::class))
        }

    /**
     * 根据提供的查询参数分页查询Join Table 逻辑删除过滤器。
     *
     * @param query 分页查询参数。
     * @return Join Table 逻辑删除过滤器分页数据。
     */
    @PostMapping("/page")
    @SaCheckPermission("model:associations:genJoinTableLogicalDeleteFilter:list")
    @Throws(AuthorizeException::class)
    fun page(@RequestBody query: PageQuery<GenJoinTableLogicalDeleteFilterSpec>): Page<GenJoinTableLogicalDeleteFilterListView> =
        sqlClient.createQuery(GenJoinTableLogicalDeleteFilter::class) {
            where(query.spec)
            orderBy(table.id.asc())
            select(table.fetch(GenJoinTableLogicalDeleteFilterListView::class))
        }.fetchPage(query.pageIndex, query.pageSize)

    /**
     * 根据提供的查询参数列出Join Table 逻辑删除过滤器选项。
     *
     * @param spec 查询参数。
     * @return Join Table 逻辑删除过滤器列表数据。
     */
    @PostMapping("/list/options")
    @SaCheckPermission("model:associations:genJoinTableLogicalDeleteFilter:select")
    @Throws(AuthorizeException::class)
    fun listOptions(@RequestBody spec: GenJoinTableLogicalDeleteFilterSpec): List<GenJoinTableLogicalDeleteFilterOptionView> =
        sqlClient.executeQuery(GenJoinTableLogicalDeleteFilter::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenJoinTableLogicalDeleteFilterOptionView::class))
        }

    /**
     * 插入新的Join Table 逻辑删除过滤器。
     *
     * @param input Join Table 逻辑删除过滤器插入输入对象。
     * @return 插入的Join Table 逻辑删除过滤器的ID。
     */
    @PostMapping
    @SaCheckPermission("model:associations:genJoinTableLogicalDeleteFilter:insert")
    @Throws(AuthorizeException::class)
    @Transactional
    fun insert(@RequestBody @Valid input: GenJoinTableLogicalDeleteFilterInsertInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.INSERT_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 根据ID获取Join Table 逻辑删除过滤器的更新回填信息。
     *
     * @param id Join Table 逻辑删除过滤器的ID。
     * @return Join Table 逻辑删除过滤器的更新回填信息。
     */
    @GetMapping("/{id}/forUpdate")
    @SaCheckPermission("model:associations:genJoinTableLogicalDeleteFilter:update")
    @Throws(AuthorizeException::class)
    fun getForUpdate(@PathVariable id: Int): GenJoinTableLogicalDeleteFilterUpdateFillView? =
        sqlClient.findById(GenJoinTableLogicalDeleteFilterUpdateFillView::class, id)

    /**
     * 更新Join Table 逻辑删除过滤器。
     *
     * @param input Join Table 逻辑删除过滤器更新输入对象。
     * @return 更新的Join Table 逻辑删除过滤器的ID。
     */
    @PutMapping
    @SaCheckPermission("model:associations:genJoinTableLogicalDeleteFilter:update")
    @Throws(AuthorizeException::class)
    @Transactional
    fun update(@RequestBody @Valid input: GenJoinTableLogicalDeleteFilterUpdateInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.UPDATE_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 删除指定ID的Join Table 逻辑删除过滤器。
     *
     * @param ids 要删除的Join Table 逻辑删除过滤器ID列表。
     * @return 删除的Join Table 逻辑删除过滤器的行数。
     */
    @DeleteMapping
    @SaCheckPermission("model:associations:genJoinTableLogicalDeleteFilter:delete")
    @Throws(AuthorizeException::class)
    @Transactional
    fun delete(@RequestParam ids: List<Int>): Int =
        sqlClient.deleteByIds(GenJoinTableLogicalDeleteFilter::class, ids).affectedRowCount(GenJoinTableLogicalDeleteFilter::class)
}