package top.potmot.service.model.associations

import cn.dev33.satoken.annotation.SaCheckPermission
import jakarta.validation.Valid
import org.babyfish.jimmer.Page
import org.babyfish.jimmer.sql.ast.mutation.AssociatedSaveMode
import org.babyfish.jimmer.sql.ast.mutation.SaveMode
import org.babyfish.jimmer.sql.kt.KSqlClient
import org.babyfish.jimmer.sql.kt.ast.expression.asc
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import top.potmot.entity.dto.query.PageQuery
import top.potmot.entity.model.associations.GenOneToOneAssociation
import top.potmot.entity.model.associations.dto.GenOneToOneAssociationDetailView
import top.potmot.entity.model.associations.dto.GenOneToOneAssociationInsertInput
import top.potmot.entity.model.associations.dto.GenOneToOneAssociationListView
import top.potmot.entity.model.associations.dto.GenOneToOneAssociationOptionView
import top.potmot.entity.model.associations.dto.GenOneToOneAssociationSpec
import top.potmot.entity.model.associations.dto.GenOneToOneAssociationUpdateFillView
import top.potmot.entity.model.associations.dto.GenOneToOneAssociationUpdateInput
import top.potmot.entity.model.associations.id
import top.potmot.exception.AuthorizeException

@RestController
@RequestMapping("/genOneToOneAssociation")
class GenOneToOneAssociationService(
    private val sqlClient: KSqlClient
) {
    /**
     * 根据ID获取一对一关联。
     *
     * @param id 一对一关联的ID。
     * @return 一对一关联的详细信息。
     */
    @GetMapping("/{id}")
    @SaCheckPermission("model:associations:genOneToOneAssociation:get")
    @Throws(AuthorizeException::class)
    fun get(@PathVariable id: Int): GenOneToOneAssociationDetailView? =
        sqlClient.findById(GenOneToOneAssociationDetailView::class, id)

    /**
     * 根据提供的查询参数列出一对一关联。
     *
     * @param spec 查询参数。
     * @return 一对一关联列表数据。
     */
    @PostMapping("/list")
    @SaCheckPermission("model:associations:genOneToOneAssociation:list")
    @Throws(AuthorizeException::class)
    fun list(@RequestBody spec: GenOneToOneAssociationSpec): List<GenOneToOneAssociationListView> =
        sqlClient.executeQuery(GenOneToOneAssociation::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenOneToOneAssociationListView::class))
        }

    /**
     * 根据提供的查询参数分页查询一对一关联。
     *
     * @param query 分页查询参数。
     * @return 一对一关联分页数据。
     */
    @PostMapping("/page")
    @SaCheckPermission("model:associations:genOneToOneAssociation:list")
    @Throws(AuthorizeException::class)
    fun page(@RequestBody query: PageQuery<GenOneToOneAssociationSpec>): Page<GenOneToOneAssociationListView> =
        sqlClient.createQuery(GenOneToOneAssociation::class) {
            where(query.spec)
            orderBy(table.id.asc())
            select(table.fetch(GenOneToOneAssociationListView::class))
        }.fetchPage(query.pageIndex, query.pageSize)

    /**
     * 根据提供的查询参数列出一对一关联选项。
     *
     * @param spec 查询参数。
     * @return 一对一关联列表数据。
     */
    @PostMapping("/list/options")
    @SaCheckPermission("model:associations:genOneToOneAssociation:select")
    @Throws(AuthorizeException::class)
    fun listOptions(@RequestBody spec: GenOneToOneAssociationSpec): List<GenOneToOneAssociationOptionView> =
        sqlClient.executeQuery(GenOneToOneAssociation::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenOneToOneAssociationOptionView::class))
        }

    /**
     * 插入新的一对一关联。
     *
     * @param input 一对一关联插入输入对象。
     * @return 插入的一对一关联的ID。
     */
    @PostMapping
    @SaCheckPermission("model:associations:genOneToOneAssociation:insert")
    @Throws(AuthorizeException::class)
    @Transactional
    fun insert(@RequestBody @Valid input: GenOneToOneAssociationInsertInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.INSERT_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 根据ID获取一对一关联的更新回填信息。
     *
     * @param id 一对一关联的ID。
     * @return 一对一关联的更新回填信息。
     */
    @GetMapping("/{id}/forUpdate")
    @SaCheckPermission("model:associations:genOneToOneAssociation:update")
    @Throws(AuthorizeException::class)
    fun getForUpdate(@PathVariable id: Int): GenOneToOneAssociationUpdateFillView? =
        sqlClient.findById(GenOneToOneAssociationUpdateFillView::class, id)

    /**
     * 更新一对一关联。
     *
     * @param input 一对一关联更新输入对象。
     * @return 更新的一对一关联的ID。
     */
    @PutMapping
    @SaCheckPermission("model:associations:genOneToOneAssociation:update")
    @Throws(AuthorizeException::class)
    @Transactional
    fun update(@RequestBody @Valid input: GenOneToOneAssociationUpdateInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.UPDATE_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 删除指定ID的一对一关联。
     *
     * @param ids 要删除的一对一关联ID列表。
     * @return 删除的一对一关联的行数。
     */
    @DeleteMapping
    @SaCheckPermission("model:associations:genOneToOneAssociation:delete")
    @Throws(AuthorizeException::class)
    @Transactional
    fun delete(@RequestParam ids: List<Int>): Int =
        sqlClient.deleteByIds(GenOneToOneAssociation::class, ids).affectedRowCount(GenOneToOneAssociation::class)
}