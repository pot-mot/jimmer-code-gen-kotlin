package top.potmot.service.model

import cn.dev33.satoken.annotation.SaCheckPermission
import jakarta.validation.Valid
import org.babyfish.jimmer.Page
import org.babyfish.jimmer.sql.ast.mutation.AssociatedSaveMode
import org.babyfish.jimmer.sql.ast.mutation.SaveMode
import org.babyfish.jimmer.sql.kt.KSqlClient
import org.babyfish.jimmer.sql.kt.ast.expression.asc
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import top.potmot.entity.dto.query.PageQuery
import top.potmot.entity.model.GenModelGroup
import top.potmot.entity.model.dto.GenModelGroupDetailView
import top.potmot.entity.model.dto.GenModelGroupExistByModelAndNameSpec
import top.potmot.entity.model.dto.GenModelGroupInsertInput
import top.potmot.entity.model.dto.GenModelGroupListView
import top.potmot.entity.model.dto.GenModelGroupOptionView
import top.potmot.entity.model.dto.GenModelGroupSpec
import top.potmot.entity.model.dto.GenModelGroupUpdateFillView
import top.potmot.entity.model.dto.GenModelGroupUpdateInput
import top.potmot.entity.model.id
import top.potmot.exception.AuthorizeException

@RestController
@RequestMapping("/genModelGroup")
class GenModelGroupService(
    private val sqlClient: KSqlClient
) {
    /**
     * 根据ID获取模型分组。
     *
     * @param id 模型分组的ID。
     * @return 模型分组的详细信息。
     */
    @GetMapping("/{id}")
    @SaCheckPermission("model:genModelGroup:get")
    @Throws(AuthorizeException::class)
    fun get(@PathVariable id: Int): GenModelGroupDetailView? =
        sqlClient.findById(GenModelGroupDetailView::class, id)

    /**
     * 根据提供的查询参数列出模型分组。
     *
     * @param spec 查询参数。
     * @return 模型分组列表数据。
     */
    @PostMapping("/list")
    @SaCheckPermission("model:genModelGroup:list")
    @Throws(AuthorizeException::class)
    fun list(@RequestBody spec: GenModelGroupSpec): List<GenModelGroupListView> =
        sqlClient.executeQuery(GenModelGroup::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenModelGroupListView::class))
        }

    /**
     * 根据提供的查询参数分页查询模型分组。
     *
     * @param query 分页查询参数。
     * @return 模型分组分页数据。
     */
    @PostMapping("/page")
    @SaCheckPermission("model:genModelGroup:list")
    @Throws(AuthorizeException::class)
    fun page(@RequestBody query: PageQuery<GenModelGroupSpec>): Page<GenModelGroupListView> =
        sqlClient.createQuery(GenModelGroup::class) {
            where(query.spec)
            orderBy(table.id.asc())
            select(table.fetch(GenModelGroupListView::class))
        }.fetchPage(query.pageIndex, query.pageSize)

    /**
     * 根据提供的查询参数列出模型分组选项。
     *
     * @param spec 查询参数。
     * @return 模型分组列表数据。
     */
    @PostMapping("/list/options")
    @SaCheckPermission("model:genModelGroup:select")
    @Throws(AuthorizeException::class)
    fun listOptions(@RequestBody spec: GenModelGroupSpec): List<GenModelGroupOptionView> =
        sqlClient.executeQuery(GenModelGroup::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenModelGroupOptionView::class))
        }

    /**
     * 插入新的模型分组。
     *
     * @param input 模型分组插入输入对象。
     * @return 插入的模型分组的ID。
     */
    @PostMapping
    @SaCheckPermission("model:genModelGroup:insert")
    @Throws(AuthorizeException::class)
    @Transactional
    fun insert(@RequestBody @Valid input: GenModelGroupInsertInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.INSERT_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 根据ID获取模型分组的更新回填信息。
     *
     * @param id 模型分组的ID。
     * @return 模型分组的更新回填信息。
     */
    @GetMapping("/{id}/forUpdate")
    @SaCheckPermission("model:genModelGroup:update")
    @Throws(AuthorizeException::class)
    fun getForUpdate(@PathVariable id: Int): GenModelGroupUpdateFillView? =
        sqlClient.findById(GenModelGroupUpdateFillView::class, id)

    /**
     * 更新模型分组。
     *
     * @param input 模型分组更新输入对象。
     * @return 更新的模型分组的ID。
     */
    @PutMapping
    @SaCheckPermission("model:genModelGroup:update")
    @Throws(AuthorizeException::class)
    @Transactional
    fun update(@RequestBody @Valid input: GenModelGroupUpdateInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.UPDATE_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 删除指定ID的模型分组。
     *
     * @param ids 要删除的模型分组ID列表。
     * @return 删除的模型分组的行数。
     */
    @DeleteMapping
    @SaCheckPermission("model:genModelGroup:delete")
    @Throws(AuthorizeException::class)
    @Transactional
    fun delete(@RequestParam ids: List<Int>): Int =
        sqlClient.deleteByIds(GenModelGroup::class, ids).affectedRowCount(GenModelGroup::class)

    /**
     * 根据 模型 和 名称 校验模型分组是否存在。
     *
     * @param spec 模型分组校验规格对象。
     * @return 模型分组是否存在。
     */
    @PostMapping("/existByModelAndName")
    @SaCheckPermission("model:genModelGroup:list")
    @Throws(AuthorizeException::class)
    fun existByModelAndName(@RequestBody spec: GenModelGroupExistByModelAndNameSpec): Boolean =
        sqlClient.createQuery(GenModelGroup::class) {
            where(spec)
            select(table)
        }.exists()
}