package top.potmot.service.model.embeddables

import cn.dev33.satoken.annotation.SaCheckPermission
import jakarta.validation.Valid
import org.babyfish.jimmer.Page
import org.babyfish.jimmer.sql.ast.mutation.AssociatedSaveMode
import org.babyfish.jimmer.sql.ast.mutation.SaveMode
import org.babyfish.jimmer.sql.kt.KSqlClient
import org.babyfish.jimmer.sql.kt.ast.expression.asc
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import top.potmot.entity.dto.query.PageQuery
import top.potmot.entity.model.embeddables.GenEmbeddableTypeDeepProperty
import top.potmot.entity.model.embeddables.dto.GenEmbeddableTypeDeepPropertyDetailView
import top.potmot.entity.model.embeddables.dto.GenEmbeddableTypeDeepPropertyExistByEmbeddableAndNameSpec
import top.potmot.entity.model.embeddables.dto.GenEmbeddableTypeDeepPropertyInsertInput
import top.potmot.entity.model.embeddables.dto.GenEmbeddableTypeDeepPropertyListView
import top.potmot.entity.model.embeddables.dto.GenEmbeddableTypeDeepPropertyOptionView
import top.potmot.entity.model.embeddables.dto.GenEmbeddableTypeDeepPropertySpec
import top.potmot.entity.model.embeddables.dto.GenEmbeddableTypeDeepPropertyUpdateFillView
import top.potmot.entity.model.embeddables.dto.GenEmbeddableTypeDeepPropertyUpdateInput
import top.potmot.entity.model.embeddables.id
import top.potmot.exception.AuthorizeException

@RestController
@RequestMapping("/genEmbeddableTypeDeepProperty")
class GenEmbeddableTypeDeepPropertyService(
    private val sqlClient: KSqlClient
) {
    /**
     * 根据ID获取深层复合属性。
     *
     * @param id 深层复合属性的ID。
     * @return 深层复合属性的详细信息。
     */
    @GetMapping("/{id}")
    @SaCheckPermission("model:embeddables:genEmbeddableTypeDeepProperty:get")
    @Throws(AuthorizeException::class)
    fun get(@PathVariable id: Int): GenEmbeddableTypeDeepPropertyDetailView? =
        sqlClient.findById(GenEmbeddableTypeDeepPropertyDetailView::class, id)

    /**
     * 根据提供的查询参数列出深层复合属性。
     *
     * @param spec 查询参数。
     * @return 深层复合属性列表数据。
     */
    @PostMapping("/list")
    @SaCheckPermission("model:embeddables:genEmbeddableTypeDeepProperty:list")
    @Throws(AuthorizeException::class)
    fun list(@RequestBody spec: GenEmbeddableTypeDeepPropertySpec): List<GenEmbeddableTypeDeepPropertyListView> =
        sqlClient.executeQuery(GenEmbeddableTypeDeepProperty::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenEmbeddableTypeDeepPropertyListView::class))
        }

    /**
     * 根据提供的查询参数分页查询深层复合属性。
     *
     * @param query 分页查询参数。
     * @return 深层复合属性分页数据。
     */
    @PostMapping("/page")
    @SaCheckPermission("model:embeddables:genEmbeddableTypeDeepProperty:list")
    @Throws(AuthorizeException::class)
    fun page(@RequestBody query: PageQuery<GenEmbeddableTypeDeepPropertySpec>): Page<GenEmbeddableTypeDeepPropertyListView> =
        sqlClient.createQuery(GenEmbeddableTypeDeepProperty::class) {
            where(query.spec)
            orderBy(table.id.asc())
            select(table.fetch(GenEmbeddableTypeDeepPropertyListView::class))
        }.fetchPage(query.pageIndex, query.pageSize)

    /**
     * 根据提供的查询参数列出深层复合属性选项。
     *
     * @param spec 查询参数。
     * @return 深层复合属性列表数据。
     */
    @PostMapping("/list/options")
    @SaCheckPermission("model:embeddables:genEmbeddableTypeDeepProperty:select")
    @Throws(AuthorizeException::class)
    fun listOptions(@RequestBody spec: GenEmbeddableTypeDeepPropertySpec): List<GenEmbeddableTypeDeepPropertyOptionView> =
        sqlClient.executeQuery(GenEmbeddableTypeDeepProperty::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenEmbeddableTypeDeepPropertyOptionView::class))
        }

    /**
     * 插入新的深层复合属性。
     *
     * @param input 深层复合属性插入输入对象。
     * @return 插入的深层复合属性的ID。
     */
    @PostMapping
    @SaCheckPermission("model:embeddables:genEmbeddableTypeDeepProperty:insert")
    @Throws(AuthorizeException::class)
    @Transactional
    fun insert(@RequestBody @Valid input: GenEmbeddableTypeDeepPropertyInsertInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.INSERT_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 根据ID获取深层复合属性的更新回填信息。
     *
     * @param id 深层复合属性的ID。
     * @return 深层复合属性的更新回填信息。
     */
    @GetMapping("/{id}/forUpdate")
    @SaCheckPermission("model:embeddables:genEmbeddableTypeDeepProperty:update")
    @Throws(AuthorizeException::class)
    fun getForUpdate(@PathVariable id: Int): GenEmbeddableTypeDeepPropertyUpdateFillView? =
        sqlClient.findById(GenEmbeddableTypeDeepPropertyUpdateFillView::class, id)

    /**
     * 更新深层复合属性。
     *
     * @param input 深层复合属性更新输入对象。
     * @return 更新的深层复合属性的ID。
     */
    @PutMapping
    @SaCheckPermission("model:embeddables:genEmbeddableTypeDeepProperty:update")
    @Throws(AuthorizeException::class)
    @Transactional
    fun update(@RequestBody @Valid input: GenEmbeddableTypeDeepPropertyUpdateInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.UPDATE_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 删除指定ID的深层复合属性。
     *
     * @param ids 要删除的深层复合属性ID列表。
     * @return 删除的深层复合属性的行数。
     */
    @DeleteMapping
    @SaCheckPermission("model:embeddables:genEmbeddableTypeDeepProperty:delete")
    @Throws(AuthorizeException::class)
    @Transactional
    fun delete(@RequestParam ids: List<Int>): Int =
        sqlClient.deleteByIds(GenEmbeddableTypeDeepProperty::class, ids).affectedRowCount(GenEmbeddableTypeDeepProperty::class)

    /**
     * 根据 嵌入类型 和 名称 校验深层复合属性是否存在。
     *
     * @param spec 深层复合属性校验规格对象。
     * @return 深层复合属性是否存在。
     */
    @PostMapping("/existByEmbeddableAndName")
    @SaCheckPermission("model:embeddables:genEmbeddableTypeDeepProperty:list")
    @Throws(AuthorizeException::class)
    fun existByEmbeddableAndName(@RequestBody spec: GenEmbeddableTypeDeepPropertyExistByEmbeddableAndNameSpec): Boolean =
        sqlClient.createQuery(GenEmbeddableTypeDeepProperty::class) {
            where(spec)
            select(table)
        }.exists()
}