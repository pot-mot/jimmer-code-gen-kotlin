package top.potmot.service.model.embeddables

import cn.dev33.satoken.annotation.SaCheckPermission
import jakarta.validation.Valid
import org.babyfish.jimmer.Page
import org.babyfish.jimmer.sql.ast.mutation.AssociatedSaveMode
import org.babyfish.jimmer.sql.ast.mutation.SaveMode
import org.babyfish.jimmer.sql.kt.KSqlClient
import org.babyfish.jimmer.sql.kt.ast.expression.asc
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import top.potmot.entity.dto.query.PageQuery
import top.potmot.entity.model.embeddables.GenEmbeddableTypeProperty
import top.potmot.entity.model.embeddables.dto.GenEmbeddableTypePropertyDetailView
import top.potmot.entity.model.embeddables.dto.GenEmbeddableTypePropertyExistByEmbeddableAndNameSpec
import top.potmot.entity.model.embeddables.dto.GenEmbeddableTypePropertyInsertInput
import top.potmot.entity.model.embeddables.dto.GenEmbeddableTypePropertyListView
import top.potmot.entity.model.embeddables.dto.GenEmbeddableTypePropertyOptionView
import top.potmot.entity.model.embeddables.dto.GenEmbeddableTypePropertySpec
import top.potmot.entity.model.embeddables.dto.GenEmbeddableTypePropertyUpdateFillView
import top.potmot.entity.model.embeddables.dto.GenEmbeddableTypePropertyUpdateInput
import top.potmot.entity.model.embeddables.id
import top.potmot.exception.AuthorizeException

@RestController
@RequestMapping("/genEmbeddableTypeProperty")
class GenEmbeddableTypePropertyService(
    private val sqlClient: KSqlClient
) {
    /**
     * 根据ID获取复合类型属性。
     *
     * @param id 复合类型属性的ID。
     * @return 复合类型属性的详细信息。
     */
    @GetMapping("/{id}")
    @SaCheckPermission("model:embeddables:genEmbeddableTypeProperty:get")
    @Throws(AuthorizeException::class)
    fun get(@PathVariable id: Int): GenEmbeddableTypePropertyDetailView? =
        sqlClient.findById(GenEmbeddableTypePropertyDetailView::class, id)

    /**
     * 根据提供的查询参数列出复合类型属性。
     *
     * @param spec 查询参数。
     * @return 复合类型属性列表数据。
     */
    @PostMapping("/list")
    @SaCheckPermission("model:embeddables:genEmbeddableTypeProperty:list")
    @Throws(AuthorizeException::class)
    fun list(@RequestBody spec: GenEmbeddableTypePropertySpec): List<GenEmbeddableTypePropertyListView> =
        sqlClient.executeQuery(GenEmbeddableTypeProperty::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenEmbeddableTypePropertyListView::class))
        }

    /**
     * 根据提供的查询参数分页查询复合类型属性。
     *
     * @param query 分页查询参数。
     * @return 复合类型属性分页数据。
     */
    @PostMapping("/page")
    @SaCheckPermission("model:embeddables:genEmbeddableTypeProperty:list")
    @Throws(AuthorizeException::class)
    fun page(@RequestBody query: PageQuery<GenEmbeddableTypePropertySpec>): Page<GenEmbeddableTypePropertyListView> =
        sqlClient.createQuery(GenEmbeddableTypeProperty::class) {
            where(query.spec)
            orderBy(table.id.asc())
            select(table.fetch(GenEmbeddableTypePropertyListView::class))
        }.fetchPage(query.pageIndex, query.pageSize)

    /**
     * 根据提供的查询参数列出复合类型属性选项。
     *
     * @param spec 查询参数。
     * @return 复合类型属性列表数据。
     */
    @PostMapping("/list/options")
    @SaCheckPermission("model:embeddables:genEmbeddableTypeProperty:select")
    @Throws(AuthorizeException::class)
    fun listOptions(@RequestBody spec: GenEmbeddableTypePropertySpec): List<GenEmbeddableTypePropertyOptionView> =
        sqlClient.executeQuery(GenEmbeddableTypeProperty::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenEmbeddableTypePropertyOptionView::class))
        }

    /**
     * 插入新的复合类型属性。
     *
     * @param input 复合类型属性插入输入对象。
     * @return 插入的复合类型属性的ID。
     */
    @PostMapping
    @SaCheckPermission("model:embeddables:genEmbeddableTypeProperty:insert")
    @Throws(AuthorizeException::class)
    @Transactional
    fun insert(@RequestBody @Valid input: GenEmbeddableTypePropertyInsertInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.INSERT_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 根据ID获取复合类型属性的更新回填信息。
     *
     * @param id 复合类型属性的ID。
     * @return 复合类型属性的更新回填信息。
     */
    @GetMapping("/{id}/forUpdate")
    @SaCheckPermission("model:embeddables:genEmbeddableTypeProperty:update")
    @Throws(AuthorizeException::class)
    fun getForUpdate(@PathVariable id: Int): GenEmbeddableTypePropertyUpdateFillView? =
        sqlClient.findById(GenEmbeddableTypePropertyUpdateFillView::class, id)

    /**
     * 更新复合类型属性。
     *
     * @param input 复合类型属性更新输入对象。
     * @return 更新的复合类型属性的ID。
     */
    @PutMapping
    @SaCheckPermission("model:embeddables:genEmbeddableTypeProperty:update")
    @Throws(AuthorizeException::class)
    @Transactional
    fun update(@RequestBody @Valid input: GenEmbeddableTypePropertyUpdateInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.UPDATE_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 删除指定ID的复合类型属性。
     *
     * @param ids 要删除的复合类型属性ID列表。
     * @return 删除的复合类型属性的行数。
     */
    @DeleteMapping
    @SaCheckPermission("model:embeddables:genEmbeddableTypeProperty:delete")
    @Throws(AuthorizeException::class)
    @Transactional
    fun delete(@RequestParam ids: List<Int>): Int =
        sqlClient.deleteByIds(GenEmbeddableTypeProperty::class, ids).affectedRowCount(GenEmbeddableTypeProperty::class)

    /**
     * 根据 嵌入类型 和 名称 校验复合类型属性是否存在。
     *
     * @param spec 复合类型属性校验规格对象。
     * @return 复合类型属性是否存在。
     */
    @PostMapping("/existByEmbeddableAndName")
    @SaCheckPermission("model:embeddables:genEmbeddableTypeProperty:list")
    @Throws(AuthorizeException::class)
    fun existByEmbeddableAndName(@RequestBody spec: GenEmbeddableTypePropertyExistByEmbeddableAndNameSpec): Boolean =
        sqlClient.createQuery(GenEmbeddableTypeProperty::class) {
            where(spec)
            select(table)
        }.exists()
}