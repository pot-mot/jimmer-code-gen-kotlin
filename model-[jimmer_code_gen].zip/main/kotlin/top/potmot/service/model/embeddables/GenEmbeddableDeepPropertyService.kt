package top.potmot.service.model.embeddables

import cn.dev33.satoken.annotation.SaCheckPermission
import jakarta.validation.Valid
import org.babyfish.jimmer.Page
import org.babyfish.jimmer.sql.ast.mutation.AssociatedSaveMode
import org.babyfish.jimmer.sql.ast.mutation.SaveMode
import org.babyfish.jimmer.sql.kt.KSqlClient
import org.babyfish.jimmer.sql.kt.ast.expression.asc
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import top.potmot.entity.dto.query.PageQuery
import top.potmot.entity.model.embeddables.GenEmbeddableDeepProperty
import top.potmot.entity.model.embeddables.dto.GenEmbeddableDeepPropertyDetailView
import top.potmot.entity.model.embeddables.dto.GenEmbeddableDeepPropertyExistByEmbeddableAndNameSpec
import top.potmot.entity.model.embeddables.dto.GenEmbeddableDeepPropertyInsertInput
import top.potmot.entity.model.embeddables.dto.GenEmbeddableDeepPropertyListView
import top.potmot.entity.model.embeddables.dto.GenEmbeddableDeepPropertyOptionView
import top.potmot.entity.model.embeddables.dto.GenEmbeddableDeepPropertySpec
import top.potmot.entity.model.embeddables.dto.GenEmbeddableDeepPropertyUpdateFillView
import top.potmot.entity.model.embeddables.dto.GenEmbeddableDeepPropertyUpdateInput
import top.potmot.entity.model.embeddables.id
import top.potmot.exception.AuthorizeException

@RestController
@RequestMapping("/genEmbeddableDeepProperty")
class GenEmbeddableDeepPropertyService(
    private val sqlClient: KSqlClient
) {
    /**
     * 根据ID获取嵌入类型深层属性。
     *
     * @param id 嵌入类型深层属性的ID。
     * @return 嵌入类型深层属性的详细信息。
     */
    @GetMapping("/{id}")
    @SaCheckPermission("model:embeddables:genEmbeddableDeepProperty:get")
    @Throws(AuthorizeException::class)
    fun get(@PathVariable id: Int): GenEmbeddableDeepPropertyDetailView? =
        sqlClient.findById(GenEmbeddableDeepPropertyDetailView::class, id)

    /**
     * 根据提供的查询参数列出嵌入类型深层属性。
     *
     * @param spec 查询参数。
     * @return 嵌入类型深层属性列表数据。
     */
    @PostMapping("/list")
    @SaCheckPermission("model:embeddables:genEmbeddableDeepProperty:list")
    @Throws(AuthorizeException::class)
    fun list(@RequestBody spec: GenEmbeddableDeepPropertySpec): List<GenEmbeddableDeepPropertyListView> =
        sqlClient.executeQuery(GenEmbeddableDeepProperty::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenEmbeddableDeepPropertyListView::class))
        }

    /**
     * 根据提供的查询参数分页查询嵌入类型深层属性。
     *
     * @param query 分页查询参数。
     * @return 嵌入类型深层属性分页数据。
     */
    @PostMapping("/page")
    @SaCheckPermission("model:embeddables:genEmbeddableDeepProperty:list")
    @Throws(AuthorizeException::class)
    fun page(@RequestBody query: PageQuery<GenEmbeddableDeepPropertySpec>): Page<GenEmbeddableDeepPropertyListView> =
        sqlClient.createQuery(GenEmbeddableDeepProperty::class) {
            where(query.spec)
            orderBy(table.id.asc())
            select(table.fetch(GenEmbeddableDeepPropertyListView::class))
        }.fetchPage(query.pageIndex, query.pageSize)

    /**
     * 根据提供的查询参数列出嵌入类型深层属性选项。
     *
     * @param spec 查询参数。
     * @return 嵌入类型深层属性列表数据。
     */
    @PostMapping("/list/options")
    @SaCheckPermission("model:embeddables:genEmbeddableDeepProperty:select")
    @Throws(AuthorizeException::class)
    fun listOptions(@RequestBody spec: GenEmbeddableDeepPropertySpec): List<GenEmbeddableDeepPropertyOptionView> =
        sqlClient.executeQuery(GenEmbeddableDeepProperty::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenEmbeddableDeepPropertyOptionView::class))
        }

    /**
     * 插入新的嵌入类型深层属性。
     *
     * @param input 嵌入类型深层属性插入输入对象。
     * @return 插入的嵌入类型深层属性的ID。
     */
    @PostMapping
    @SaCheckPermission("model:embeddables:genEmbeddableDeepProperty:insert")
    @Throws(AuthorizeException::class)
    @Transactional
    fun insert(@RequestBody @Valid input: GenEmbeddableDeepPropertyInsertInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.INSERT_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 根据ID获取嵌入类型深层属性的更新回填信息。
     *
     * @param id 嵌入类型深层属性的ID。
     * @return 嵌入类型深层属性的更新回填信息。
     */
    @GetMapping("/{id}/forUpdate")
    @SaCheckPermission("model:embeddables:genEmbeddableDeepProperty:update")
    @Throws(AuthorizeException::class)
    fun getForUpdate(@PathVariable id: Int): GenEmbeddableDeepPropertyUpdateFillView? =
        sqlClient.findById(GenEmbeddableDeepPropertyUpdateFillView::class, id)

    /**
     * 更新嵌入类型深层属性。
     *
     * @param input 嵌入类型深层属性更新输入对象。
     * @return 更新的嵌入类型深层属性的ID。
     */
    @PutMapping
    @SaCheckPermission("model:embeddables:genEmbeddableDeepProperty:update")
    @Throws(AuthorizeException::class)
    @Transactional
    fun update(@RequestBody @Valid input: GenEmbeddableDeepPropertyUpdateInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.UPDATE_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 删除指定ID的嵌入类型深层属性。
     *
     * @param ids 要删除的嵌入类型深层属性ID列表。
     * @return 删除的嵌入类型深层属性的行数。
     */
    @DeleteMapping
    @SaCheckPermission("model:embeddables:genEmbeddableDeepProperty:delete")
    @Throws(AuthorizeException::class)
    @Transactional
    fun delete(@RequestParam ids: List<Int>): Int =
        sqlClient.deleteByIds(GenEmbeddableDeepProperty::class, ids).affectedRowCount(GenEmbeddableDeepProperty::class)

    /**
     * 根据 嵌入类型 和 名称 校验嵌入类型深层属性是否存在。
     *
     * @param spec 嵌入类型深层属性校验规格对象。
     * @return 嵌入类型深层属性是否存在。
     */
    @PostMapping("/existByEmbeddableAndName")
    @SaCheckPermission("model:embeddables:genEmbeddableDeepProperty:list")
    @Throws(AuthorizeException::class)
    fun existByEmbeddableAndName(@RequestBody spec: GenEmbeddableDeepPropertyExistByEmbeddableAndNameSpec): Boolean =
        sqlClient.createQuery(GenEmbeddableDeepProperty::class) {
            where(spec)
            select(table)
        }.exists()
}