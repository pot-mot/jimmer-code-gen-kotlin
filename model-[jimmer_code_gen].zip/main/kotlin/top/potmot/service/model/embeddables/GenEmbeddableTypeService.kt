package top.potmot.service.model.embeddables

import cn.dev33.satoken.annotation.SaCheckPermission
import jakarta.validation.Valid
import org.babyfish.jimmer.Page
import org.babyfish.jimmer.sql.ast.mutation.AssociatedSaveMode
import org.babyfish.jimmer.sql.ast.mutation.SaveMode
import org.babyfish.jimmer.sql.kt.KSqlClient
import org.babyfish.jimmer.sql.kt.ast.expression.asc
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import top.potmot.entity.dto.query.PageQuery
import top.potmot.entity.model.embeddables.GenEmbeddableType
import top.potmot.entity.model.embeddables.dto.GenEmbeddableTypeDetailView
import top.potmot.entity.model.embeddables.dto.GenEmbeddableTypeExistByGroupAndNameSpec
import top.potmot.entity.model.embeddables.dto.GenEmbeddableTypeInsertInput
import top.potmot.entity.model.embeddables.dto.GenEmbeddableTypeListView
import top.potmot.entity.model.embeddables.dto.GenEmbeddableTypeOptionView
import top.potmot.entity.model.embeddables.dto.GenEmbeddableTypeSpec
import top.potmot.entity.model.embeddables.dto.GenEmbeddableTypeUpdateFillView
import top.potmot.entity.model.embeddables.dto.GenEmbeddableTypeUpdateInput
import top.potmot.entity.model.embeddables.id
import top.potmot.exception.AuthorizeException

@RestController
@RequestMapping("/genEmbeddableType")
class GenEmbeddableTypeService(
    private val sqlClient: KSqlClient
) {
    /**
     * 根据ID获取复合类型。
     *
     * @param id 复合类型的ID。
     * @return 复合类型的详细信息。
     */
    @GetMapping("/{id}")
    @SaCheckPermission("model:embeddables:genEmbeddableType:get")
    @Throws(AuthorizeException::class)
    fun get(@PathVariable id: Int): GenEmbeddableTypeDetailView? =
        sqlClient.findById(GenEmbeddableTypeDetailView::class, id)

    /**
     * 根据提供的查询参数列出复合类型。
     *
     * @param spec 查询参数。
     * @return 复合类型列表数据。
     */
    @PostMapping("/list")
    @SaCheckPermission("model:embeddables:genEmbeddableType:list")
    @Throws(AuthorizeException::class)
    fun list(@RequestBody spec: GenEmbeddableTypeSpec): List<GenEmbeddableTypeListView> =
        sqlClient.executeQuery(GenEmbeddableType::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenEmbeddableTypeListView::class))
        }

    /**
     * 根据提供的查询参数分页查询复合类型。
     *
     * @param query 分页查询参数。
     * @return 复合类型分页数据。
     */
    @PostMapping("/page")
    @SaCheckPermission("model:embeddables:genEmbeddableType:list")
    @Throws(AuthorizeException::class)
    fun page(@RequestBody query: PageQuery<GenEmbeddableTypeSpec>): Page<GenEmbeddableTypeListView> =
        sqlClient.createQuery(GenEmbeddableType::class) {
            where(query.spec)
            orderBy(table.id.asc())
            select(table.fetch(GenEmbeddableTypeListView::class))
        }.fetchPage(query.pageIndex, query.pageSize)

    /**
     * 根据提供的查询参数列出复合类型选项。
     *
     * @param spec 查询参数。
     * @return 复合类型列表数据。
     */
    @PostMapping("/list/options")
    @SaCheckPermission("model:embeddables:genEmbeddableType:select")
    @Throws(AuthorizeException::class)
    fun listOptions(@RequestBody spec: GenEmbeddableTypeSpec): List<GenEmbeddableTypeOptionView> =
        sqlClient.executeQuery(GenEmbeddableType::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenEmbeddableTypeOptionView::class))
        }

    /**
     * 插入新的复合类型。
     *
     * @param input 复合类型插入输入对象。
     * @return 插入的复合类型的ID。
     */
    @PostMapping
    @SaCheckPermission("model:embeddables:genEmbeddableType:insert")
    @Throws(AuthorizeException::class)
    @Transactional
    fun insert(@RequestBody @Valid input: GenEmbeddableTypeInsertInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.INSERT_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 根据ID获取复合类型的更新回填信息。
     *
     * @param id 复合类型的ID。
     * @return 复合类型的更新回填信息。
     */
    @GetMapping("/{id}/forUpdate")
    @SaCheckPermission("model:embeddables:genEmbeddableType:update")
    @Throws(AuthorizeException::class)
    fun getForUpdate(@PathVariable id: Int): GenEmbeddableTypeUpdateFillView? =
        sqlClient.findById(GenEmbeddableTypeUpdateFillView::class, id)

    /**
     * 更新复合类型。
     *
     * @param input 复合类型更新输入对象。
     * @return 更新的复合类型的ID。
     */
    @PutMapping
    @SaCheckPermission("model:embeddables:genEmbeddableType:update")
    @Throws(AuthorizeException::class)
    @Transactional
    fun update(@RequestBody @Valid input: GenEmbeddableTypeUpdateInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.UPDATE_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 删除指定ID的复合类型。
     *
     * @param ids 要删除的复合类型ID列表。
     * @return 删除的复合类型的行数。
     */
    @DeleteMapping
    @SaCheckPermission("model:embeddables:genEmbeddableType:delete")
    @Throws(AuthorizeException::class)
    @Transactional
    fun delete(@RequestParam ids: List<Int>): Int =
        sqlClient.deleteByIds(GenEmbeddableType::class, ids).affectedRowCount(GenEmbeddableType::class)

    /**
     * 根据 分组 和 名称 校验复合类型是否存在。
     *
     * @param spec 复合类型校验规格对象。
     * @return 复合类型是否存在。
     */
    @PostMapping("/existByGroupAndName")
    @SaCheckPermission("model:embeddables:genEmbeddableType:list")
    @Throws(AuthorizeException::class)
    fun existByGroupAndName(@RequestBody spec: GenEmbeddableTypeExistByGroupAndNameSpec): Boolean =
        sqlClient.createQuery(GenEmbeddableType::class) {
            where(spec)
            select(table)
        }.exists()
}