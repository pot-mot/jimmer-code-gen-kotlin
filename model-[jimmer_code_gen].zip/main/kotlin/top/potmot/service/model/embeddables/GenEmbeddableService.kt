package top.potmot.service.model.embeddables

import cn.dev33.satoken.annotation.SaCheckPermission
import jakarta.validation.Valid
import org.babyfish.jimmer.Page
import org.babyfish.jimmer.sql.ast.mutation.AssociatedSaveMode
import org.babyfish.jimmer.sql.ast.mutation.SaveMode
import org.babyfish.jimmer.sql.kt.KSqlClient
import org.babyfish.jimmer.sql.kt.ast.expression.asc
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import top.potmot.entity.dto.query.PageQuery
import top.potmot.entity.model.embeddables.GenEmbeddable
import top.potmot.entity.model.embeddables.dto.GenEmbeddableDetailView
import top.potmot.entity.model.embeddables.dto.GenEmbeddableExistByGroupAndNameSpec
import top.potmot.entity.model.embeddables.dto.GenEmbeddableInsertInput
import top.potmot.entity.model.embeddables.dto.GenEmbeddableListView
import top.potmot.entity.model.embeddables.dto.GenEmbeddableOptionView
import top.potmot.entity.model.embeddables.dto.GenEmbeddableSpec
import top.potmot.entity.model.embeddables.dto.GenEmbeddableUpdateFillView
import top.potmot.entity.model.embeddables.dto.GenEmbeddableUpdateInput
import top.potmot.entity.model.embeddables.id
import top.potmot.exception.AuthorizeException

@RestController
@RequestMapping("/genEmbeddable")
class GenEmbeddableService(
    private val sqlClient: KSqlClient
) {
    /**
     * 根据ID获取嵌入类型。
     *
     * @param id 嵌入类型的ID。
     * @return 嵌入类型的详细信息。
     */
    @GetMapping("/{id}")
    @SaCheckPermission("model:embeddables:genEmbeddable:get")
    @Throws(AuthorizeException::class)
    fun get(@PathVariable id: Int): GenEmbeddableDetailView? =
        sqlClient.findById(GenEmbeddableDetailView::class, id)

    /**
     * 根据提供的查询参数列出嵌入类型。
     *
     * @param spec 查询参数。
     * @return 嵌入类型列表数据。
     */
    @PostMapping("/list")
    @SaCheckPermission("model:embeddables:genEmbeddable:list")
    @Throws(AuthorizeException::class)
    fun list(@RequestBody spec: GenEmbeddableSpec): List<GenEmbeddableListView> =
        sqlClient.executeQuery(GenEmbeddable::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenEmbeddableListView::class))
        }

    /**
     * 根据提供的查询参数分页查询嵌入类型。
     *
     * @param query 分页查询参数。
     * @return 嵌入类型分页数据。
     */
    @PostMapping("/page")
    @SaCheckPermission("model:embeddables:genEmbeddable:list")
    @Throws(AuthorizeException::class)
    fun page(@RequestBody query: PageQuery<GenEmbeddableSpec>): Page<GenEmbeddableListView> =
        sqlClient.createQuery(GenEmbeddable::class) {
            where(query.spec)
            orderBy(table.id.asc())
            select(table.fetch(GenEmbeddableListView::class))
        }.fetchPage(query.pageIndex, query.pageSize)

    /**
     * 根据提供的查询参数列出嵌入类型选项。
     *
     * @param spec 查询参数。
     * @return 嵌入类型列表数据。
     */
    @PostMapping("/list/options")
    @SaCheckPermission("model:embeddables:genEmbeddable:select")
    @Throws(AuthorizeException::class)
    fun listOptions(@RequestBody spec: GenEmbeddableSpec): List<GenEmbeddableOptionView> =
        sqlClient.executeQuery(GenEmbeddable::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenEmbeddableOptionView::class))
        }

    /**
     * 插入新的嵌入类型。
     *
     * @param input 嵌入类型插入输入对象。
     * @return 插入的嵌入类型的ID。
     */
    @PostMapping
    @SaCheckPermission("model:embeddables:genEmbeddable:insert")
    @Throws(AuthorizeException::class)
    @Transactional
    fun insert(@RequestBody @Valid input: GenEmbeddableInsertInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.INSERT_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 根据ID获取嵌入类型的更新回填信息。
     *
     * @param id 嵌入类型的ID。
     * @return 嵌入类型的更新回填信息。
     */
    @GetMapping("/{id}/forUpdate")
    @SaCheckPermission("model:embeddables:genEmbeddable:update")
    @Throws(AuthorizeException::class)
    fun getForUpdate(@PathVariable id: Int): GenEmbeddableUpdateFillView? =
        sqlClient.findById(GenEmbeddableUpdateFillView::class, id)

    /**
     * 更新嵌入类型。
     *
     * @param input 嵌入类型更新输入对象。
     * @return 更新的嵌入类型的ID。
     */
    @PutMapping
    @SaCheckPermission("model:embeddables:genEmbeddable:update")
    @Throws(AuthorizeException::class)
    @Transactional
    fun update(@RequestBody @Valid input: GenEmbeddableUpdateInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.UPDATE_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 删除指定ID的嵌入类型。
     *
     * @param ids 要删除的嵌入类型ID列表。
     * @return 删除的嵌入类型的行数。
     */
    @DeleteMapping
    @SaCheckPermission("model:embeddables:genEmbeddable:delete")
    @Throws(AuthorizeException::class)
    @Transactional
    fun delete(@RequestParam ids: List<Int>): Int =
        sqlClient.deleteByIds(GenEmbeddable::class, ids).affectedRowCount(GenEmbeddable::class)

    /**
     * 根据 分组 和 名称 校验嵌入类型是否存在。
     *
     * @param spec 嵌入类型校验规格对象。
     * @return 嵌入类型是否存在。
     */
    @PostMapping("/existByGroupAndName")
    @SaCheckPermission("model:embeddables:genEmbeddable:list")
    @Throws(AuthorizeException::class)
    fun existByGroupAndName(@RequestBody spec: GenEmbeddableExistByGroupAndNameSpec): Boolean =
        sqlClient.createQuery(GenEmbeddable::class) {
            where(spec)
            select(table)
        }.exists()
}