package top.potmot.service.model.embeddables

import cn.dev33.satoken.annotation.SaCheckPermission
import jakarta.validation.Valid
import org.babyfish.jimmer.Page
import org.babyfish.jimmer.sql.ast.mutation.AssociatedSaveMode
import org.babyfish.jimmer.sql.ast.mutation.SaveMode
import org.babyfish.jimmer.sql.kt.KSqlClient
import org.babyfish.jimmer.sql.kt.ast.expression.asc
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import top.potmot.entity.dto.query.PageQuery
import top.potmot.entity.model.embeddables.GenEmbeddableProperty
import top.potmot.entity.model.embeddables.dto.GenEmbeddablePropertyDetailView
import top.potmot.entity.model.embeddables.dto.GenEmbeddablePropertyExistByEmbeddableAndNameSpec
import top.potmot.entity.model.embeddables.dto.GenEmbeddablePropertyInsertInput
import top.potmot.entity.model.embeddables.dto.GenEmbeddablePropertyListView
import top.potmot.entity.model.embeddables.dto.GenEmbeddablePropertyOptionView
import top.potmot.entity.model.embeddables.dto.GenEmbeddablePropertySpec
import top.potmot.entity.model.embeddables.dto.GenEmbeddablePropertyUpdateFillView
import top.potmot.entity.model.embeddables.dto.GenEmbeddablePropertyUpdateInput
import top.potmot.entity.model.embeddables.id
import top.potmot.exception.AuthorizeException

@RestController
@RequestMapping("/genEmbeddableProperty")
class GenEmbeddablePropertyService(
    private val sqlClient: KSqlClient
) {
    /**
     * 根据ID获取嵌入类型属性。
     *
     * @param id 嵌入类型属性的ID。
     * @return 嵌入类型属性的详细信息。
     */
    @GetMapping("/{id}")
    @SaCheckPermission("model:embeddables:genEmbeddableProperty:get")
    @Throws(AuthorizeException::class)
    fun get(@PathVariable id: Int): GenEmbeddablePropertyDetailView? =
        sqlClient.findById(GenEmbeddablePropertyDetailView::class, id)

    /**
     * 根据提供的查询参数列出嵌入类型属性。
     *
     * @param spec 查询参数。
     * @return 嵌入类型属性列表数据。
     */
    @PostMapping("/list")
    @SaCheckPermission("model:embeddables:genEmbeddableProperty:list")
    @Throws(AuthorizeException::class)
    fun list(@RequestBody spec: GenEmbeddablePropertySpec): List<GenEmbeddablePropertyListView> =
        sqlClient.executeQuery(GenEmbeddableProperty::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenEmbeddablePropertyListView::class))
        }

    /**
     * 根据提供的查询参数分页查询嵌入类型属性。
     *
     * @param query 分页查询参数。
     * @return 嵌入类型属性分页数据。
     */
    @PostMapping("/page")
    @SaCheckPermission("model:embeddables:genEmbeddableProperty:list")
    @Throws(AuthorizeException::class)
    fun page(@RequestBody query: PageQuery<GenEmbeddablePropertySpec>): Page<GenEmbeddablePropertyListView> =
        sqlClient.createQuery(GenEmbeddableProperty::class) {
            where(query.spec)
            orderBy(table.id.asc())
            select(table.fetch(GenEmbeddablePropertyListView::class))
        }.fetchPage(query.pageIndex, query.pageSize)

    /**
     * 根据提供的查询参数列出嵌入类型属性选项。
     *
     * @param spec 查询参数。
     * @return 嵌入类型属性列表数据。
     */
    @PostMapping("/list/options")
    @SaCheckPermission("model:embeddables:genEmbeddableProperty:select")
    @Throws(AuthorizeException::class)
    fun listOptions(@RequestBody spec: GenEmbeddablePropertySpec): List<GenEmbeddablePropertyOptionView> =
        sqlClient.executeQuery(GenEmbeddableProperty::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenEmbeddablePropertyOptionView::class))
        }

    /**
     * 插入新的嵌入类型属性。
     *
     * @param input 嵌入类型属性插入输入对象。
     * @return 插入的嵌入类型属性的ID。
     */
    @PostMapping
    @SaCheckPermission("model:embeddables:genEmbeddableProperty:insert")
    @Throws(AuthorizeException::class)
    @Transactional
    fun insert(@RequestBody @Valid input: GenEmbeddablePropertyInsertInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.INSERT_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 根据ID获取嵌入类型属性的更新回填信息。
     *
     * @param id 嵌入类型属性的ID。
     * @return 嵌入类型属性的更新回填信息。
     */
    @GetMapping("/{id}/forUpdate")
    @SaCheckPermission("model:embeddables:genEmbeddableProperty:update")
    @Throws(AuthorizeException::class)
    fun getForUpdate(@PathVariable id: Int): GenEmbeddablePropertyUpdateFillView? =
        sqlClient.findById(GenEmbeddablePropertyUpdateFillView::class, id)

    /**
     * 更新嵌入类型属性。
     *
     * @param input 嵌入类型属性更新输入对象。
     * @return 更新的嵌入类型属性的ID。
     */
    @PutMapping
    @SaCheckPermission("model:embeddables:genEmbeddableProperty:update")
    @Throws(AuthorizeException::class)
    @Transactional
    fun update(@RequestBody @Valid input: GenEmbeddablePropertyUpdateInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.UPDATE_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 删除指定ID的嵌入类型属性。
     *
     * @param ids 要删除的嵌入类型属性ID列表。
     * @return 删除的嵌入类型属性的行数。
     */
    @DeleteMapping
    @SaCheckPermission("model:embeddables:genEmbeddableProperty:delete")
    @Throws(AuthorizeException::class)
    @Transactional
    fun delete(@RequestParam ids: List<Int>): Int =
        sqlClient.deleteByIds(GenEmbeddableProperty::class, ids).affectedRowCount(GenEmbeddableProperty::class)

    /**
     * 根据 嵌入类型 和 名称 校验嵌入类型属性是否存在。
     *
     * @param spec 嵌入类型属性校验规格对象。
     * @return 嵌入类型属性是否存在。
     */
    @PostMapping("/existByEmbeddableAndName")
    @SaCheckPermission("model:embeddables:genEmbeddableProperty:list")
    @Throws(AuthorizeException::class)
    fun existByEmbeddableAndName(@RequestBody spec: GenEmbeddablePropertyExistByEmbeddableAndNameSpec): Boolean =
        sqlClient.createQuery(GenEmbeddableProperty::class) {
            where(spec)
            select(table)
        }.exists()
}