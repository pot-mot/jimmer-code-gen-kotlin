package top.potmot.service.model.embeddables

import cn.dev33.satoken.annotation.SaCheckPermission
import jakarta.validation.Valid
import org.babyfish.jimmer.Page
import org.babyfish.jimmer.sql.ast.mutation.AssociatedSaveMode
import org.babyfish.jimmer.sql.ast.mutation.SaveMode
import org.babyfish.jimmer.sql.kt.KSqlClient
import org.babyfish.jimmer.sql.kt.ast.expression.asc
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import top.potmot.entity.dto.query.PageQuery
import top.potmot.entity.model.embeddables.GenDeepEmbeddablePropertyOverride
import top.potmot.entity.model.embeddables.dto.GenDeepEmbeddablePropertyOverrideDetailView
import top.potmot.entity.model.embeddables.dto.GenDeepEmbeddablePropertyOverrideExistByDeepPropertyAndOverridePropertySpec
import top.potmot.entity.model.embeddables.dto.GenDeepEmbeddablePropertyOverrideInsertInput
import top.potmot.entity.model.embeddables.dto.GenDeepEmbeddablePropertyOverrideListView
import top.potmot.entity.model.embeddables.dto.GenDeepEmbeddablePropertyOverrideOptionView
import top.potmot.entity.model.embeddables.dto.GenDeepEmbeddablePropertyOverrideSpec
import top.potmot.entity.model.embeddables.dto.GenDeepEmbeddablePropertyOverrideUpdateFillView
import top.potmot.entity.model.embeddables.dto.GenDeepEmbeddablePropertyOverrideUpdateInput
import top.potmot.entity.model.embeddables.id
import top.potmot.exception.AuthorizeException

@RestController
@RequestMapping("/genDeepEmbeddablePropertyOverride")
class GenDeepEmbeddablePropertyOverrideService(
    private val sqlClient: KSqlClient
) {
    /**
     * 根据ID获取深层复合属性列覆盖。
     *
     * @param id 深层复合属性列覆盖的ID。
     * @return 深层复合属性列覆盖的详细信息。
     */
    @GetMapping("/{id}")
    @SaCheckPermission("model:embeddables:genDeepEmbeddablePropertyOverride:get")
    @Throws(AuthorizeException::class)
    fun get(@PathVariable id: Int): GenDeepEmbeddablePropertyOverrideDetailView? =
        sqlClient.findById(GenDeepEmbeddablePropertyOverrideDetailView::class, id)

    /**
     * 根据提供的查询参数列出深层复合属性列覆盖。
     *
     * @param spec 查询参数。
     * @return 深层复合属性列覆盖列表数据。
     */
    @PostMapping("/list")
    @SaCheckPermission("model:embeddables:genDeepEmbeddablePropertyOverride:list")
    @Throws(AuthorizeException::class)
    fun list(@RequestBody spec: GenDeepEmbeddablePropertyOverrideSpec): List<GenDeepEmbeddablePropertyOverrideListView> =
        sqlClient.executeQuery(GenDeepEmbeddablePropertyOverride::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenDeepEmbeddablePropertyOverrideListView::class))
        }

    /**
     * 根据提供的查询参数分页查询深层复合属性列覆盖。
     *
     * @param query 分页查询参数。
     * @return 深层复合属性列覆盖分页数据。
     */
    @PostMapping("/page")
    @SaCheckPermission("model:embeddables:genDeepEmbeddablePropertyOverride:list")
    @Throws(AuthorizeException::class)
    fun page(@RequestBody query: PageQuery<GenDeepEmbeddablePropertyOverrideSpec>): Page<GenDeepEmbeddablePropertyOverrideListView> =
        sqlClient.createQuery(GenDeepEmbeddablePropertyOverride::class) {
            where(query.spec)
            orderBy(table.id.asc())
            select(table.fetch(GenDeepEmbeddablePropertyOverrideListView::class))
        }.fetchPage(query.pageIndex, query.pageSize)

    /**
     * 根据提供的查询参数列出深层复合属性列覆盖选项。
     *
     * @param spec 查询参数。
     * @return 深层复合属性列覆盖列表数据。
     */
    @PostMapping("/list/options")
    @SaCheckPermission("model:embeddables:genDeepEmbeddablePropertyOverride:select")
    @Throws(AuthorizeException::class)
    fun listOptions(@RequestBody spec: GenDeepEmbeddablePropertyOverrideSpec): List<GenDeepEmbeddablePropertyOverrideOptionView> =
        sqlClient.executeQuery(GenDeepEmbeddablePropertyOverride::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(GenDeepEmbeddablePropertyOverrideOptionView::class))
        }

    /**
     * 插入新的深层复合属性列覆盖。
     *
     * @param input 深层复合属性列覆盖插入输入对象。
     * @return 插入的深层复合属性列覆盖的ID。
     */
    @PostMapping
    @SaCheckPermission("model:embeddables:genDeepEmbeddablePropertyOverride:insert")
    @Throws(AuthorizeException::class)
    @Transactional
    fun insert(@RequestBody @Valid input: GenDeepEmbeddablePropertyOverrideInsertInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.INSERT_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 根据ID获取深层复合属性列覆盖的更新回填信息。
     *
     * @param id 深层复合属性列覆盖的ID。
     * @return 深层复合属性列覆盖的更新回填信息。
     */
    @GetMapping("/{id}/forUpdate")
    @SaCheckPermission("model:embeddables:genDeepEmbeddablePropertyOverride:update")
    @Throws(AuthorizeException::class)
    fun getForUpdate(@PathVariable id: Int): GenDeepEmbeddablePropertyOverrideUpdateFillView? =
        sqlClient.findById(GenDeepEmbeddablePropertyOverrideUpdateFillView::class, id)

    /**
     * 更新深层复合属性列覆盖。
     *
     * @param input 深层复合属性列覆盖更新输入对象。
     * @return 更新的深层复合属性列覆盖的ID。
     */
    @PutMapping
    @SaCheckPermission("model:embeddables:genDeepEmbeddablePropertyOverride:update")
    @Throws(AuthorizeException::class)
    @Transactional
    fun update(@RequestBody @Valid input: GenDeepEmbeddablePropertyOverrideUpdateInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.UPDATE_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 删除指定ID的深层复合属性列覆盖。
     *
     * @param ids 要删除的深层复合属性列覆盖ID列表。
     * @return 删除的深层复合属性列覆盖的行数。
     */
    @DeleteMapping
    @SaCheckPermission("model:embeddables:genDeepEmbeddablePropertyOverride:delete")
    @Throws(AuthorizeException::class)
    @Transactional
    fun delete(@RequestParam ids: List<Int>): Int =
        sqlClient.deleteByIds(GenDeepEmbeddablePropertyOverride::class, ids).affectedRowCount(GenDeepEmbeddablePropertyOverride::class)

    /**
     * 根据 深层属性 和 覆盖属性 校验深层复合属性列覆盖是否存在。
     *
     * @param spec 深层复合属性列覆盖校验规格对象。
     * @return 深层复合属性列覆盖是否存在。
     */
    @PostMapping("/existByDeepPropertyAndOverrideProperty")
    @SaCheckPermission("model:embeddables:genDeepEmbeddablePropertyOverride:list")
    @Throws(AuthorizeException::class)
    fun existByDeepPropertyAndOverrideProperty(@RequestBody spec: GenDeepEmbeddablePropertyOverrideExistByDeepPropertyAndOverridePropertySpec): Boolean =
        sqlClient.createQuery(GenDeepEmbeddablePropertyOverride::class) {
            where(spec)
            select(table)
        }.exists()
}