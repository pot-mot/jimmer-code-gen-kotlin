package top.potmot.service.database

import cn.dev33.satoken.annotation.SaCheckPermission
import jakarta.validation.Valid
import org.babyfish.jimmer.Page
import org.babyfish.jimmer.sql.ast.mutation.AssociatedSaveMode
import org.babyfish.jimmer.sql.ast.mutation.SaveMode
import org.babyfish.jimmer.sql.kt.KSqlClient
import org.babyfish.jimmer.sql.kt.ast.expression.asc
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import top.potmot.entity.database.DbSchema
import top.potmot.entity.database.dto.DbSchemaDetailView
import top.potmot.entity.database.dto.DbSchemaExistByDataSourceAndNameSpec
import top.potmot.entity.database.dto.DbSchemaInsertInput
import top.potmot.entity.database.dto.DbSchemaListView
import top.potmot.entity.database.dto.DbSchemaOptionView
import top.potmot.entity.database.dto.DbSchemaSpec
import top.potmot.entity.database.dto.DbSchemaUpdateFillView
import top.potmot.entity.database.dto.DbSchemaUpdateInput
import top.potmot.entity.database.id
import top.potmot.entity.dto.query.PageQuery
import top.potmot.exception.AuthorizeException

@RestController
@RequestMapping("/dbSchema")
class DbSchemaService(
    private val sqlClient: KSqlClient
) {
    /**
     * 根据ID获取数据架构。
     *
     * @param id 数据架构的ID。
     * @return 数据架构的详细信息。
     */
    @GetMapping("/{id}")
    @SaCheckPermission("database:dbSchema:get")
    @Throws(AuthorizeException::class)
    fun get(@PathVariable id: Int): DbSchemaDetailView? =
        sqlClient.findById(DbSchemaDetailView::class, id)

    /**
     * 根据提供的查询参数列出数据架构。
     *
     * @param spec 查询参数。
     * @return 数据架构列表数据。
     */
    @PostMapping("/list")
    @SaCheckPermission("database:dbSchema:list")
    @Throws(AuthorizeException::class)
    fun list(@RequestBody spec: DbSchemaSpec): List<DbSchemaListView> =
        sqlClient.executeQuery(DbSchema::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(DbSchemaListView::class))
        }

    /**
     * 根据提供的查询参数分页查询数据架构。
     *
     * @param query 分页查询参数。
     * @return 数据架构分页数据。
     */
    @PostMapping("/page")
    @SaCheckPermission("database:dbSchema:list")
    @Throws(AuthorizeException::class)
    fun page(@RequestBody query: PageQuery<DbSchemaSpec>): Page<DbSchemaListView> =
        sqlClient.createQuery(DbSchema::class) {
            where(query.spec)
            orderBy(table.id.asc())
            select(table.fetch(DbSchemaListView::class))
        }.fetchPage(query.pageIndex, query.pageSize)

    /**
     * 根据提供的查询参数列出数据架构选项。
     *
     * @param spec 查询参数。
     * @return 数据架构列表数据。
     */
    @PostMapping("/list/options")
    @SaCheckPermission("database:dbSchema:select")
    @Throws(AuthorizeException::class)
    fun listOptions(@RequestBody spec: DbSchemaSpec): List<DbSchemaOptionView> =
        sqlClient.executeQuery(DbSchema::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(DbSchemaOptionView::class))
        }

    /**
     * 插入新的数据架构。
     *
     * @param input 数据架构插入输入对象。
     * @return 插入的数据架构的ID。
     */
    @PostMapping
    @SaCheckPermission("database:dbSchema:insert")
    @Throws(AuthorizeException::class)
    @Transactional
    fun insert(@RequestBody @Valid input: DbSchemaInsertInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.INSERT_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 根据ID获取数据架构的更新回填信息。
     *
     * @param id 数据架构的ID。
     * @return 数据架构的更新回填信息。
     */
    @GetMapping("/{id}/forUpdate")
    @SaCheckPermission("database:dbSchema:update")
    @Throws(AuthorizeException::class)
    fun getForUpdate(@PathVariable id: Int): DbSchemaUpdateFillView? =
        sqlClient.findById(DbSchemaUpdateFillView::class, id)

    /**
     * 更新数据架构。
     *
     * @param input 数据架构更新输入对象。
     * @return 更新的数据架构的ID。
     */
    @PutMapping
    @SaCheckPermission("database:dbSchema:update")
    @Throws(AuthorizeException::class)
    @Transactional
    fun update(@RequestBody @Valid input: DbSchemaUpdateInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.UPDATE_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 删除指定ID的数据架构。
     *
     * @param ids 要删除的数据架构ID列表。
     * @return 删除的数据架构的行数。
     */
    @DeleteMapping
    @SaCheckPermission("database:dbSchema:delete")
    @Throws(AuthorizeException::class)
    @Transactional
    fun delete(@RequestParam ids: List<Int>): Int =
        sqlClient.deleteByIds(DbSchema::class, ids).affectedRowCount(DbSchema::class)

    /**
     * 根据 数据源 和 名称 校验数据架构是否存在。
     *
     * @param spec 数据架构校验规格对象。
     * @return 数据架构是否存在。
     */
    @PostMapping("/existByDataSourceAndName")
    @SaCheckPermission("database:dbSchema:list")
    @Throws(AuthorizeException::class)
    fun existByDataSourceAndName(@RequestBody spec: DbSchemaExistByDataSourceAndNameSpec): Boolean =
        sqlClient.createQuery(DbSchema::class) {
            where(spec)
            select(table)
        }.exists()
}