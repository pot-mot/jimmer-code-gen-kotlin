package top.potmot.service.database

import cn.dev33.satoken.annotation.SaCheckPermission
import jakarta.validation.Valid
import org.babyfish.jimmer.Page
import org.babyfish.jimmer.sql.ast.mutation.AssociatedSaveMode
import org.babyfish.jimmer.sql.ast.mutation.SaveMode
import org.babyfish.jimmer.sql.kt.KSqlClient
import org.babyfish.jimmer.sql.kt.ast.expression.asc
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import top.potmot.entity.database.DbTableColumn
import top.potmot.entity.database.dto.DbTableColumnDetailView
import top.potmot.entity.database.dto.DbTableColumnExistByTableAndNameSpec
import top.potmot.entity.database.dto.DbTableColumnInsertInput
import top.potmot.entity.database.dto.DbTableColumnListView
import top.potmot.entity.database.dto.DbTableColumnOptionView
import top.potmot.entity.database.dto.DbTableColumnSpec
import top.potmot.entity.database.dto.DbTableColumnUpdateFillView
import top.potmot.entity.database.dto.DbTableColumnUpdateInput
import top.potmot.entity.database.id
import top.potmot.entity.dto.query.PageQuery
import top.potmot.exception.AuthorizeException

@RestController
@RequestMapping("/dbTableColumn")
class DbTableColumnService(
    private val sqlClient: KSqlClient
) {
    /**
     * 根据ID获取列。
     *
     * @param id 列的ID。
     * @return 列的详细信息。
     */
    @GetMapping("/{id}")
    @SaCheckPermission("database:dbTableColumn:get")
    @Throws(AuthorizeException::class)
    fun get(@PathVariable id: Int): DbTableColumnDetailView? =
        sqlClient.findById(DbTableColumnDetailView::class, id)

    /**
     * 根据提供的查询参数列出列。
     *
     * @param spec 查询参数。
     * @return 列列表数据。
     */
    @PostMapping("/list")
    @SaCheckPermission("database:dbTableColumn:list")
    @Throws(AuthorizeException::class)
    fun list(@RequestBody spec: DbTableColumnSpec): List<DbTableColumnListView> =
        sqlClient.executeQuery(DbTableColumn::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(DbTableColumnListView::class))
        }

    /**
     * 根据提供的查询参数分页查询列。
     *
     * @param query 分页查询参数。
     * @return 列分页数据。
     */
    @PostMapping("/page")
    @SaCheckPermission("database:dbTableColumn:list")
    @Throws(AuthorizeException::class)
    fun page(@RequestBody query: PageQuery<DbTableColumnSpec>): Page<DbTableColumnListView> =
        sqlClient.createQuery(DbTableColumn::class) {
            where(query.spec)
            orderBy(table.id.asc())
            select(table.fetch(DbTableColumnListView::class))
        }.fetchPage(query.pageIndex, query.pageSize)

    /**
     * 根据提供的查询参数列出列选项。
     *
     * @param spec 查询参数。
     * @return 列列表数据。
     */
    @PostMapping("/list/options")
    @SaCheckPermission("database:dbTableColumn:select")
    @Throws(AuthorizeException::class)
    fun listOptions(@RequestBody spec: DbTableColumnSpec): List<DbTableColumnOptionView> =
        sqlClient.executeQuery(DbTableColumn::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(DbTableColumnOptionView::class))
        }

    /**
     * 插入新的列。
     *
     * @param input 列插入输入对象。
     * @return 插入的列的ID。
     */
    @PostMapping
    @SaCheckPermission("database:dbTableColumn:insert")
    @Throws(AuthorizeException::class)
    @Transactional
    fun insert(@RequestBody @Valid input: DbTableColumnInsertInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.INSERT_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 根据ID获取列的更新回填信息。
     *
     * @param id 列的ID。
     * @return 列的更新回填信息。
     */
    @GetMapping("/{id}/forUpdate")
    @SaCheckPermission("database:dbTableColumn:update")
    @Throws(AuthorizeException::class)
    fun getForUpdate(@PathVariable id: Int): DbTableColumnUpdateFillView? =
        sqlClient.findById(DbTableColumnUpdateFillView::class, id)

    /**
     * 更新列。
     *
     * @param input 列更新输入对象。
     * @return 更新的列的ID。
     */
    @PutMapping
    @SaCheckPermission("database:dbTableColumn:update")
    @Throws(AuthorizeException::class)
    @Transactional
    fun update(@RequestBody @Valid input: DbTableColumnUpdateInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.UPDATE_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 删除指定ID的列。
     *
     * @param ids 要删除的列ID列表。
     * @return 删除的列的行数。
     */
    @DeleteMapping
    @SaCheckPermission("database:dbTableColumn:delete")
    @Throws(AuthorizeException::class)
    @Transactional
    fun delete(@RequestParam ids: List<Int>): Int =
        sqlClient.deleteByIds(DbTableColumn::class, ids).affectedRowCount(DbTableColumn::class)

    /**
     * 根据 归属表 和 名称 校验列是否存在。
     *
     * @param spec 列校验规格对象。
     * @return 列是否存在。
     */
    @PostMapping("/existByTableAndName")
    @SaCheckPermission("database:dbTableColumn:list")
    @Throws(AuthorizeException::class)
    fun existByTableAndName(@RequestBody spec: DbTableColumnExistByTableAndNameSpec): Boolean =
        sqlClient.createQuery(DbTableColumn::class) {
            where(spec)
            select(table)
        }.exists()
}