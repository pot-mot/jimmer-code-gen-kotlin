package top.potmot.service.database

import cn.dev33.satoken.annotation.SaCheckPermission
import jakarta.validation.Valid
import org.babyfish.jimmer.Page
import org.babyfish.jimmer.sql.ast.mutation.AssociatedSaveMode
import org.babyfish.jimmer.sql.ast.mutation.SaveMode
import org.babyfish.jimmer.sql.kt.KSqlClient
import org.babyfish.jimmer.sql.kt.ast.expression.asc
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import top.potmot.entity.database.DbForeignKey
import top.potmot.entity.database.dto.DbForeignKeyDetailView
import top.potmot.entity.database.dto.DbForeignKeyInsertInput
import top.potmot.entity.database.dto.DbForeignKeyListView
import top.potmot.entity.database.dto.DbForeignKeyOptionView
import top.potmot.entity.database.dto.DbForeignKeySpec
import top.potmot.entity.database.dto.DbForeignKeyUpdateFillView
import top.potmot.entity.database.dto.DbForeignKeyUpdateInput
import top.potmot.entity.database.id
import top.potmot.entity.dto.query.PageQuery
import top.potmot.exception.AuthorizeException

@RestController
@RequestMapping("/dbForeignKey")
class DbForeignKeyService(
    private val sqlClient: KSqlClient
) {
    /**
     * 根据ID获取外键。
     *
     * @param id 外键的ID。
     * @return 外键的详细信息。
     */
    @GetMapping("/{id}")
    @SaCheckPermission("database:dbForeignKey:get")
    @Throws(AuthorizeException::class)
    fun get(@PathVariable id: Int): DbForeignKeyDetailView? =
        sqlClient.findById(DbForeignKeyDetailView::class, id)

    /**
     * 根据提供的查询参数列出外键。
     *
     * @param spec 查询参数。
     * @return 外键列表数据。
     */
    @PostMapping("/list")
    @SaCheckPermission("database:dbForeignKey:list")
    @Throws(AuthorizeException::class)
    fun list(@RequestBody spec: DbForeignKeySpec): List<DbForeignKeyListView> =
        sqlClient.executeQuery(DbForeignKey::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(DbForeignKeyListView::class))
        }

    /**
     * 根据提供的查询参数分页查询外键。
     *
     * @param query 分页查询参数。
     * @return 外键分页数据。
     */
    @PostMapping("/page")
    @SaCheckPermission("database:dbForeignKey:list")
    @Throws(AuthorizeException::class)
    fun page(@RequestBody query: PageQuery<DbForeignKeySpec>): Page<DbForeignKeyListView> =
        sqlClient.createQuery(DbForeignKey::class) {
            where(query.spec)
            orderBy(table.id.asc())
            select(table.fetch(DbForeignKeyListView::class))
        }.fetchPage(query.pageIndex, query.pageSize)

    /**
     * 根据提供的查询参数列出外键选项。
     *
     * @param spec 查询参数。
     * @return 外键列表数据。
     */
    @PostMapping("/list/options")
    @SaCheckPermission("database:dbForeignKey:select")
    @Throws(AuthorizeException::class)
    fun listOptions(@RequestBody spec: DbForeignKeySpec): List<DbForeignKeyOptionView> =
        sqlClient.executeQuery(DbForeignKey::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(DbForeignKeyOptionView::class))
        }

    /**
     * 插入新的外键。
     *
     * @param input 外键插入输入对象。
     * @return 插入的外键的ID。
     */
    @PostMapping
    @SaCheckPermission("database:dbForeignKey:insert")
    @Throws(AuthorizeException::class)
    @Transactional
    fun insert(@RequestBody @Valid input: DbForeignKeyInsertInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.INSERT_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 根据ID获取外键的更新回填信息。
     *
     * @param id 外键的ID。
     * @return 外键的更新回填信息。
     */
    @GetMapping("/{id}/forUpdate")
    @SaCheckPermission("database:dbForeignKey:update")
    @Throws(AuthorizeException::class)
    fun getForUpdate(@PathVariable id: Int): DbForeignKeyUpdateFillView? =
        sqlClient.findById(DbForeignKeyUpdateFillView::class, id)

    /**
     * 更新外键。
     *
     * @param input 外键更新输入对象。
     * @return 更新的外键的ID。
     */
    @PutMapping
    @SaCheckPermission("database:dbForeignKey:update")
    @Throws(AuthorizeException::class)
    @Transactional
    fun update(@RequestBody @Valid input: DbForeignKeyUpdateInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.UPDATE_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 删除指定ID的外键。
     *
     * @param ids 要删除的外键ID列表。
     * @return 删除的外键的行数。
     */
    @DeleteMapping
    @SaCheckPermission("database:dbForeignKey:delete")
    @Throws(AuthorizeException::class)
    @Transactional
    fun delete(@RequestParam ids: List<Int>): Int =
        sqlClient.deleteByIds(DbForeignKey::class, ids).affectedRowCount(DbForeignKey::class)
}