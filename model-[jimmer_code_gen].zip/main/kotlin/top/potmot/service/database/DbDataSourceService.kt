package top.potmot.service.database

import cn.dev33.satoken.annotation.SaCheckPermission
import jakarta.validation.Valid
import org.babyfish.jimmer.Page
import org.babyfish.jimmer.sql.ast.mutation.AssociatedSaveMode
import org.babyfish.jimmer.sql.ast.mutation.SaveMode
import org.babyfish.jimmer.sql.kt.KSqlClient
import org.babyfish.jimmer.sql.kt.ast.expression.asc
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import top.potmot.entity.database.DbDataSource
import top.potmot.entity.database.dto.DbDataSourceDetailView
import top.potmot.entity.database.dto.DbDataSourceInsertInput
import top.potmot.entity.database.dto.DbDataSourceListView
import top.potmot.entity.database.dto.DbDataSourceOptionView
import top.potmot.entity.database.dto.DbDataSourceSpec
import top.potmot.entity.database.dto.DbDataSourceUpdateFillView
import top.potmot.entity.database.dto.DbDataSourceUpdateInput
import top.potmot.entity.database.id
import top.potmot.entity.dto.query.PageQuery
import top.potmot.exception.AuthorizeException

@RestController
@RequestMapping("/dbDataSource")
class DbDataSourceService(
    private val sqlClient: KSqlClient
) {
    /**
     * 根据ID获取数据源。
     *
     * @param id 数据源的ID。
     * @return 数据源的详细信息。
     */
    @GetMapping("/{id}")
    @SaCheckPermission("database:dbDataSource:get")
    @Throws(AuthorizeException::class)
    fun get(@PathVariable id: Int): DbDataSourceDetailView? =
        sqlClient.findById(DbDataSourceDetailView::class, id)

    /**
     * 根据提供的查询参数列出数据源。
     *
     * @param spec 查询参数。
     * @return 数据源列表数据。
     */
    @PostMapping("/list")
    @SaCheckPermission("database:dbDataSource:list")
    @Throws(AuthorizeException::class)
    fun list(@RequestBody spec: DbDataSourceSpec): List<DbDataSourceListView> =
        sqlClient.executeQuery(DbDataSource::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(DbDataSourceListView::class))
        }

    /**
     * 根据提供的查询参数分页查询数据源。
     *
     * @param query 分页查询参数。
     * @return 数据源分页数据。
     */
    @PostMapping("/page")
    @SaCheckPermission("database:dbDataSource:list")
    @Throws(AuthorizeException::class)
    fun page(@RequestBody query: PageQuery<DbDataSourceSpec>): Page<DbDataSourceListView> =
        sqlClient.createQuery(DbDataSource::class) {
            where(query.spec)
            orderBy(table.id.asc())
            select(table.fetch(DbDataSourceListView::class))
        }.fetchPage(query.pageIndex, query.pageSize)

    /**
     * 根据提供的查询参数列出数据源选项。
     *
     * @param spec 查询参数。
     * @return 数据源列表数据。
     */
    @PostMapping("/list/options")
    @SaCheckPermission("database:dbDataSource:select")
    @Throws(AuthorizeException::class)
    fun listOptions(@RequestBody spec: DbDataSourceSpec): List<DbDataSourceOptionView> =
        sqlClient.executeQuery(DbDataSource::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(DbDataSourceOptionView::class))
        }

    /**
     * 插入新的数据源。
     *
     * @param input 数据源插入输入对象。
     * @return 插入的数据源的ID。
     */
    @PostMapping
    @SaCheckPermission("database:dbDataSource:insert")
    @Throws(AuthorizeException::class)
    @Transactional
    fun insert(@RequestBody @Valid input: DbDataSourceInsertInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.INSERT_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 根据ID获取数据源的更新回填信息。
     *
     * @param id 数据源的ID。
     * @return 数据源的更新回填信息。
     */
    @GetMapping("/{id}/forUpdate")
    @SaCheckPermission("database:dbDataSource:update")
    @Throws(AuthorizeException::class)
    fun getForUpdate(@PathVariable id: Int): DbDataSourceUpdateFillView? =
        sqlClient.findById(DbDataSourceUpdateFillView::class, id)

    /**
     * 更新数据源。
     *
     * @param input 数据源更新输入对象。
     * @return 更新的数据源的ID。
     */
    @PutMapping
    @SaCheckPermission("database:dbDataSource:update")
    @Throws(AuthorizeException::class)
    @Transactional
    fun update(@RequestBody @Valid input: DbDataSourceUpdateInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.UPDATE_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 删除指定ID的数据源。
     *
     * @param ids 要删除的数据源ID列表。
     * @return 删除的数据源的行数。
     */
    @DeleteMapping
    @SaCheckPermission("database:dbDataSource:delete")
    @Throws(AuthorizeException::class)
    @Transactional
    fun delete(@RequestParam ids: List<Int>): Int =
        sqlClient.deleteByIds(DbDataSource::class, ids).affectedRowCount(DbDataSource::class)
}