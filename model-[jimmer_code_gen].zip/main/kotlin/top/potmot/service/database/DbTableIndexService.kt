package top.potmot.service.database

import cn.dev33.satoken.annotation.SaCheckPermission
import jakarta.validation.Valid
import org.babyfish.jimmer.Page
import org.babyfish.jimmer.sql.ast.mutation.AssociatedSaveMode
import org.babyfish.jimmer.sql.ast.mutation.SaveMode
import org.babyfish.jimmer.sql.kt.KSqlClient
import org.babyfish.jimmer.sql.kt.ast.expression.asc
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import top.potmot.entity.database.DbTableIndex
import top.potmot.entity.database.dto.DbTableIndexDetailView
import top.potmot.entity.database.dto.DbTableIndexExistByTableAndNameSpec
import top.potmot.entity.database.dto.DbTableIndexInsertInput
import top.potmot.entity.database.dto.DbTableIndexListView
import top.potmot.entity.database.dto.DbTableIndexOptionView
import top.potmot.entity.database.dto.DbTableIndexSpec
import top.potmot.entity.database.dto.DbTableIndexUpdateFillView
import top.potmot.entity.database.dto.DbTableIndexUpdateInput
import top.potmot.entity.database.id
import top.potmot.entity.dto.query.PageQuery
import top.potmot.exception.AuthorizeException

@RestController
@RequestMapping("/dbTableIndex")
class DbTableIndexService(
    private val sqlClient: KSqlClient
) {
    /**
     * 根据ID获取表索引。
     *
     * @param id 表索引的ID。
     * @return 表索引的详细信息。
     */
    @GetMapping("/{id}")
    @SaCheckPermission("database:dbTableIndex:get")
    @Throws(AuthorizeException::class)
    fun get(@PathVariable id: Int): DbTableIndexDetailView? =
        sqlClient.findById(DbTableIndexDetailView::class, id)

    /**
     * 根据提供的查询参数列出表索引。
     *
     * @param spec 查询参数。
     * @return 表索引列表数据。
     */
    @PostMapping("/list")
    @SaCheckPermission("database:dbTableIndex:list")
    @Throws(AuthorizeException::class)
    fun list(@RequestBody spec: DbTableIndexSpec): List<DbTableIndexListView> =
        sqlClient.executeQuery(DbTableIndex::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(DbTableIndexListView::class))
        }

    /**
     * 根据提供的查询参数分页查询表索引。
     *
     * @param query 分页查询参数。
     * @return 表索引分页数据。
     */
    @PostMapping("/page")
    @SaCheckPermission("database:dbTableIndex:list")
    @Throws(AuthorizeException::class)
    fun page(@RequestBody query: PageQuery<DbTableIndexSpec>): Page<DbTableIndexListView> =
        sqlClient.createQuery(DbTableIndex::class) {
            where(query.spec)
            orderBy(table.id.asc())
            select(table.fetch(DbTableIndexListView::class))
        }.fetchPage(query.pageIndex, query.pageSize)

    /**
     * 根据提供的查询参数列出表索引选项。
     *
     * @param spec 查询参数。
     * @return 表索引列表数据。
     */
    @PostMapping("/list/options")
    @SaCheckPermission("database:dbTableIndex:select")
    @Throws(AuthorizeException::class)
    fun listOptions(@RequestBody spec: DbTableIndexSpec): List<DbTableIndexOptionView> =
        sqlClient.executeQuery(DbTableIndex::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(DbTableIndexOptionView::class))
        }

    /**
     * 插入新的表索引。
     *
     * @param input 表索引插入输入对象。
     * @return 插入的表索引的ID。
     */
    @PostMapping
    @SaCheckPermission("database:dbTableIndex:insert")
    @Throws(AuthorizeException::class)
    @Transactional
    fun insert(@RequestBody @Valid input: DbTableIndexInsertInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.INSERT_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 根据ID获取表索引的更新回填信息。
     *
     * @param id 表索引的ID。
     * @return 表索引的更新回填信息。
     */
    @GetMapping("/{id}/forUpdate")
    @SaCheckPermission("database:dbTableIndex:update")
    @Throws(AuthorizeException::class)
    fun getForUpdate(@PathVariable id: Int): DbTableIndexUpdateFillView? =
        sqlClient.findById(DbTableIndexUpdateFillView::class, id)

    /**
     * 更新表索引。
     *
     * @param input 表索引更新输入对象。
     * @return 更新的表索引的ID。
     */
    @PutMapping
    @SaCheckPermission("database:dbTableIndex:update")
    @Throws(AuthorizeException::class)
    @Transactional
    fun update(@RequestBody @Valid input: DbTableIndexUpdateInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.UPDATE_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 删除指定ID的表索引。
     *
     * @param ids 要删除的表索引ID列表。
     * @return 删除的表索引的行数。
     */
    @DeleteMapping
    @SaCheckPermission("database:dbTableIndex:delete")
    @Throws(AuthorizeException::class)
    @Transactional
    fun delete(@RequestParam ids: List<Int>): Int =
        sqlClient.deleteByIds(DbTableIndex::class, ids).affectedRowCount(DbTableIndex::class)

    /**
     * 根据 归属表 和 名称 校验表索引是否存在。
     *
     * @param spec 表索引校验规格对象。
     * @return 表索引是否存在。
     */
    @PostMapping("/existByTableAndName")
    @SaCheckPermission("database:dbTableIndex:list")
    @Throws(AuthorizeException::class)
    fun existByTableAndName(@RequestBody spec: DbTableIndexExistByTableAndNameSpec): Boolean =
        sqlClient.createQuery(DbTableIndex::class) {
            where(spec)
            select(table)
        }.exists()
}