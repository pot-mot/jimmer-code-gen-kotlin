package top.potmot.service.database

import cn.dev33.satoken.annotation.SaCheckPermission
import jakarta.validation.Valid
import org.babyfish.jimmer.Page
import org.babyfish.jimmer.sql.ast.mutation.AssociatedSaveMode
import org.babyfish.jimmer.sql.ast.mutation.SaveMode
import org.babyfish.jimmer.sql.kt.KSqlClient
import org.babyfish.jimmer.sql.kt.ast.expression.asc
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import top.potmot.entity.database.DbForeignKeyColumnReference
import top.potmot.entity.database.dto.DbForeignKeyColumnReferenceDetailView
import top.potmot.entity.database.dto.DbForeignKeyColumnReferenceExistByAssociationAndSourceColumnAndTargetColumnSpec
import top.potmot.entity.database.dto.DbForeignKeyColumnReferenceInsertInput
import top.potmot.entity.database.dto.DbForeignKeyColumnReferenceListView
import top.potmot.entity.database.dto.DbForeignKeyColumnReferenceOptionView
import top.potmot.entity.database.dto.DbForeignKeyColumnReferenceSpec
import top.potmot.entity.database.dto.DbForeignKeyColumnReferenceUpdateFillView
import top.potmot.entity.database.dto.DbForeignKeyColumnReferenceUpdateInput
import top.potmot.entity.database.id
import top.potmot.entity.dto.query.PageQuery
import top.potmot.exception.AuthorizeException

@RestController
@RequestMapping("/dbForeignKeyColumnReference")
class DbForeignKeyColumnReferenceService(
    private val sqlClient: KSqlClient
) {
    /**
     * 根据ID获取外键列引用。
     *
     * @param id 外键列引用的ID。
     * @return 外键列引用的详细信息。
     */
    @GetMapping("/{id}")
    @SaCheckPermission("database:dbForeignKeyColumnReference:get")
    @Throws(AuthorizeException::class)
    fun get(@PathVariable id: Int): DbForeignKeyColumnReferenceDetailView? =
        sqlClient.findById(DbForeignKeyColumnReferenceDetailView::class, id)

    /**
     * 根据提供的查询参数列出外键列引用。
     *
     * @param spec 查询参数。
     * @return 外键列引用列表数据。
     */
    @PostMapping("/list")
    @SaCheckPermission("database:dbForeignKeyColumnReference:list")
    @Throws(AuthorizeException::class)
    fun list(@RequestBody spec: DbForeignKeyColumnReferenceSpec): List<DbForeignKeyColumnReferenceListView> =
        sqlClient.executeQuery(DbForeignKeyColumnReference::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(DbForeignKeyColumnReferenceListView::class))
        }

    /**
     * 根据提供的查询参数分页查询外键列引用。
     *
     * @param query 分页查询参数。
     * @return 外键列引用分页数据。
     */
    @PostMapping("/page")
    @SaCheckPermission("database:dbForeignKeyColumnReference:list")
    @Throws(AuthorizeException::class)
    fun page(@RequestBody query: PageQuery<DbForeignKeyColumnReferenceSpec>): Page<DbForeignKeyColumnReferenceListView> =
        sqlClient.createQuery(DbForeignKeyColumnReference::class) {
            where(query.spec)
            orderBy(table.id.asc())
            select(table.fetch(DbForeignKeyColumnReferenceListView::class))
        }.fetchPage(query.pageIndex, query.pageSize)

    /**
     * 根据提供的查询参数列出外键列引用选项。
     *
     * @param spec 查询参数。
     * @return 外键列引用列表数据。
     */
    @PostMapping("/list/options")
    @SaCheckPermission("database:dbForeignKeyColumnReference:select")
    @Throws(AuthorizeException::class)
    fun listOptions(@RequestBody spec: DbForeignKeyColumnReferenceSpec): List<DbForeignKeyColumnReferenceOptionView> =
        sqlClient.executeQuery(DbForeignKeyColumnReference::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(DbForeignKeyColumnReferenceOptionView::class))
        }

    /**
     * 插入新的外键列引用。
     *
     * @param input 外键列引用插入输入对象。
     * @return 插入的外键列引用的ID。
     */
    @PostMapping
    @SaCheckPermission("database:dbForeignKeyColumnReference:insert")
    @Throws(AuthorizeException::class)
    @Transactional
    fun insert(@RequestBody @Valid input: DbForeignKeyColumnReferenceInsertInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.INSERT_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 根据ID获取外键列引用的更新回填信息。
     *
     * @param id 外键列引用的ID。
     * @return 外键列引用的更新回填信息。
     */
    @GetMapping("/{id}/forUpdate")
    @SaCheckPermission("database:dbForeignKeyColumnReference:update")
    @Throws(AuthorizeException::class)
    fun getForUpdate(@PathVariable id: Int): DbForeignKeyColumnReferenceUpdateFillView? =
        sqlClient.findById(DbForeignKeyColumnReferenceUpdateFillView::class, id)

    /**
     * 更新外键列引用。
     *
     * @param input 外键列引用更新输入对象。
     * @return 更新的外键列引用的ID。
     */
    @PutMapping
    @SaCheckPermission("database:dbForeignKeyColumnReference:update")
    @Throws(AuthorizeException::class)
    @Transactional
    fun update(@RequestBody @Valid input: DbForeignKeyColumnReferenceUpdateInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.UPDATE_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 删除指定ID的外键列引用。
     *
     * @param ids 要删除的外键列引用ID列表。
     * @return 删除的外键列引用的行数。
     */
    @DeleteMapping
    @SaCheckPermission("database:dbForeignKeyColumnReference:delete")
    @Throws(AuthorizeException::class)
    @Transactional
    fun delete(@RequestParam ids: List<Int>): Int =
        sqlClient.deleteByIds(DbForeignKeyColumnReference::class, ids).affectedRowCount(DbForeignKeyColumnReference::class)

    /**
     * 根据 关联 和 主列 和 从列 校验外键列引用是否存在。
     *
     * @param spec 外键列引用校验规格对象。
     * @return 外键列引用是否存在。
     */
    @PostMapping("/existByAssociationAndSourceColumnAndTargetColumn")
    @SaCheckPermission("database:dbForeignKeyColumnReference:list")
    @Throws(AuthorizeException::class)
    fun existByAssociationAndSourceColumnAndTargetColumn(@RequestBody spec: DbForeignKeyColumnReferenceExistByAssociationAndSourceColumnAndTargetColumnSpec): Boolean =
        sqlClient.createQuery(DbForeignKeyColumnReference::class) {
            where(spec)
            select(table)
        }.exists()
}