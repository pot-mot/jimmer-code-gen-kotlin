package top.potmot.service.database

import cn.dev33.satoken.annotation.SaCheckPermission
import jakarta.validation.Valid
import org.babyfish.jimmer.Page
import org.babyfish.jimmer.sql.ast.mutation.AssociatedSaveMode
import org.babyfish.jimmer.sql.ast.mutation.SaveMode
import org.babyfish.jimmer.sql.kt.KSqlClient
import org.babyfish.jimmer.sql.kt.ast.expression.asc
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import top.potmot.entity.database.DbTable
import top.potmot.entity.database.dto.DbTableDetailView
import top.potmot.entity.database.dto.DbTableExistBySchemaAndNameSpec
import top.potmot.entity.database.dto.DbTableInsertInput
import top.potmot.entity.database.dto.DbTableListView
import top.potmot.entity.database.dto.DbTableOptionView
import top.potmot.entity.database.dto.DbTableSpec
import top.potmot.entity.database.dto.DbTableUpdateFillView
import top.potmot.entity.database.dto.DbTableUpdateInput
import top.potmot.entity.database.id
import top.potmot.entity.dto.query.PageQuery
import top.potmot.exception.AuthorizeException

@RestController
@RequestMapping("/dbTable")
class DbTableService(
    private val sqlClient: KSqlClient
) {
    /**
     * 根据ID获取。
     *
     * @param id 的ID。
     * @return 的详细信息。
     */
    @GetMapping("/{id}")
    @SaCheckPermission("database:dbTable:get")
    @Throws(AuthorizeException::class)
    fun get(@PathVariable id: Int): DbTableDetailView? =
        sqlClient.findById(DbTableDetailView::class, id)

    /**
     * 根据提供的查询参数列出。
     *
     * @param spec 查询参数。
     * @return 列表数据。
     */
    @PostMapping("/list")
    @SaCheckPermission("database:dbTable:list")
    @Throws(AuthorizeException::class)
    fun list(@RequestBody spec: DbTableSpec): List<DbTableListView> =
        sqlClient.executeQuery(DbTable::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(DbTableListView::class))
        }

    /**
     * 根据提供的查询参数分页查询。
     *
     * @param query 分页查询参数。
     * @return 分页数据。
     */
    @PostMapping("/page")
    @SaCheckPermission("database:dbTable:list")
    @Throws(AuthorizeException::class)
    fun page(@RequestBody query: PageQuery<DbTableSpec>): Page<DbTableListView> =
        sqlClient.createQuery(DbTable::class) {
            where(query.spec)
            orderBy(table.id.asc())
            select(table.fetch(DbTableListView::class))
        }.fetchPage(query.pageIndex, query.pageSize)

    /**
     * 根据提供的查询参数列出选项。
     *
     * @param spec 查询参数。
     * @return 列表数据。
     */
    @PostMapping("/list/options")
    @SaCheckPermission("database:dbTable:select")
    @Throws(AuthorizeException::class)
    fun listOptions(@RequestBody spec: DbTableSpec): List<DbTableOptionView> =
        sqlClient.executeQuery(DbTable::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(DbTableOptionView::class))
        }

    /**
     * 插入新的。
     *
     * @param input 插入输入对象。
     * @return 插入的的ID。
     */
    @PostMapping
    @SaCheckPermission("database:dbTable:insert")
    @Throws(AuthorizeException::class)
    @Transactional
    fun insert(@RequestBody @Valid input: DbTableInsertInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.INSERT_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 根据ID获取的更新回填信息。
     *
     * @param id 的ID。
     * @return 的更新回填信息。
     */
    @GetMapping("/{id}/forUpdate")
    @SaCheckPermission("database:dbTable:update")
    @Throws(AuthorizeException::class)
    fun getForUpdate(@PathVariable id: Int): DbTableUpdateFillView? =
        sqlClient.findById(DbTableUpdateFillView::class, id)

    /**
     * 更新。
     *
     * @param input 更新输入对象。
     * @return 更新的的ID。
     */
    @PutMapping
    @SaCheckPermission("database:dbTable:update")
    @Throws(AuthorizeException::class)
    @Transactional
    fun update(@RequestBody @Valid input: DbTableUpdateInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.UPDATE_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 删除指定ID的。
     *
     * @param ids 要删除的ID列表。
     * @return 删除的的行数。
     */
    @DeleteMapping
    @SaCheckPermission("database:dbTable:delete")
    @Throws(AuthorizeException::class)
    @Transactional
    fun delete(@RequestParam ids: List<Int>): Int =
        sqlClient.deleteByIds(DbTable::class, ids).affectedRowCount(DbTable::class)

    /**
     * 根据 数据架构 和 名称 校验是否存在。
     *
     * @param spec 校验规格对象。
     * @return 是否存在。
     */
    @PostMapping("/existBySchemaAndName")
    @SaCheckPermission("database:dbTable:list")
    @Throws(AuthorizeException::class)
    fun existBySchemaAndName(@RequestBody spec: DbTableExistBySchemaAndNameSpec): Boolean =
        sqlClient.createQuery(DbTable::class) {
            where(spec)
            select(table)
        }.exists()
}