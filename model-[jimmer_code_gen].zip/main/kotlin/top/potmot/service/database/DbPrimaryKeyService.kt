package top.potmot.service.database

import cn.dev33.satoken.annotation.SaCheckPermission
import jakarta.validation.Valid
import org.babyfish.jimmer.Page
import org.babyfish.jimmer.sql.ast.mutation.AssociatedSaveMode
import org.babyfish.jimmer.sql.ast.mutation.SaveMode
import org.babyfish.jimmer.sql.kt.KSqlClient
import org.babyfish.jimmer.sql.kt.ast.expression.asc
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import top.potmot.entity.database.DbPrimaryKey
import top.potmot.entity.database.dto.DbPrimaryKeyDetailView
import top.potmot.entity.database.dto.DbPrimaryKeyExistByTableSpec
import top.potmot.entity.database.dto.DbPrimaryKeyInsertInput
import top.potmot.entity.database.dto.DbPrimaryKeyListView
import top.potmot.entity.database.dto.DbPrimaryKeyOptionView
import top.potmot.entity.database.dto.DbPrimaryKeySpec
import top.potmot.entity.database.dto.DbPrimaryKeyUpdateFillView
import top.potmot.entity.database.dto.DbPrimaryKeyUpdateInput
import top.potmot.entity.database.id
import top.potmot.entity.dto.query.PageQuery
import top.potmot.exception.AuthorizeException

@RestController
@RequestMapping("/dbPrimaryKey")
class DbPrimaryKeyService(
    private val sqlClient: KSqlClient
) {
    /**
     * 根据ID获取主键。
     *
     * @param id 主键的ID。
     * @return 主键的详细信息。
     */
    @GetMapping("/{id}")
    @SaCheckPermission("database:dbPrimaryKey:get")
    @Throws(AuthorizeException::class)
    fun get(@PathVariable id: Int): DbPrimaryKeyDetailView? =
        sqlClient.findById(DbPrimaryKeyDetailView::class, id)

    /**
     * 根据提供的查询参数列出主键。
     *
     * @param spec 查询参数。
     * @return 主键列表数据。
     */
    @PostMapping("/list")
    @SaCheckPermission("database:dbPrimaryKey:list")
    @Throws(AuthorizeException::class)
    fun list(@RequestBody spec: DbPrimaryKeySpec): List<DbPrimaryKeyListView> =
        sqlClient.executeQuery(DbPrimaryKey::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(DbPrimaryKeyListView::class))
        }

    /**
     * 根据提供的查询参数分页查询主键。
     *
     * @param query 分页查询参数。
     * @return 主键分页数据。
     */
    @PostMapping("/page")
    @SaCheckPermission("database:dbPrimaryKey:list")
    @Throws(AuthorizeException::class)
    fun page(@RequestBody query: PageQuery<DbPrimaryKeySpec>): Page<DbPrimaryKeyListView> =
        sqlClient.createQuery(DbPrimaryKey::class) {
            where(query.spec)
            orderBy(table.id.asc())
            select(table.fetch(DbPrimaryKeyListView::class))
        }.fetchPage(query.pageIndex, query.pageSize)

    /**
     * 根据提供的查询参数列出主键选项。
     *
     * @param spec 查询参数。
     * @return 主键列表数据。
     */
    @PostMapping("/list/options")
    @SaCheckPermission("database:dbPrimaryKey:select")
    @Throws(AuthorizeException::class)
    fun listOptions(@RequestBody spec: DbPrimaryKeySpec): List<DbPrimaryKeyOptionView> =
        sqlClient.executeQuery(DbPrimaryKey::class) {
            where(spec)
            orderBy(table.id.asc())
            select(table.fetch(DbPrimaryKeyOptionView::class))
        }

    /**
     * 插入新的主键。
     *
     * @param input 主键插入输入对象。
     * @return 插入的主键的ID。
     */
    @PostMapping
    @SaCheckPermission("database:dbPrimaryKey:insert")
    @Throws(AuthorizeException::class)
    @Transactional
    fun insert(@RequestBody @Valid input: DbPrimaryKeyInsertInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.INSERT_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 根据ID获取主键的更新回填信息。
     *
     * @param id 主键的ID。
     * @return 主键的更新回填信息。
     */
    @GetMapping("/{id}/forUpdate")
    @SaCheckPermission("database:dbPrimaryKey:update")
    @Throws(AuthorizeException::class)
    fun getForUpdate(@PathVariable id: Int): DbPrimaryKeyUpdateFillView? =
        sqlClient.findById(DbPrimaryKeyUpdateFillView::class, id)

    /**
     * 更新主键。
     *
     * @param input 主键更新输入对象。
     * @return 更新的主键的ID。
     */
    @PutMapping
    @SaCheckPermission("database:dbPrimaryKey:update")
    @Throws(AuthorizeException::class)
    @Transactional
    fun update(@RequestBody @Valid input: DbPrimaryKeyUpdateInput): Int =
        sqlClient.save(input) {
            setMode(SaveMode.UPDATE_ONLY)
            setAssociatedModeAll(AssociatedSaveMode.REPLACE)
        }.modifiedEntity.id

    /**
     * 删除指定ID的主键。
     *
     * @param ids 要删除的主键ID列表。
     * @return 删除的主键的行数。
     */
    @DeleteMapping
    @SaCheckPermission("database:dbPrimaryKey:delete")
    @Throws(AuthorizeException::class)
    @Transactional
    fun delete(@RequestParam ids: List<Int>): Int =
        sqlClient.deleteByIds(DbPrimaryKey::class, ids).affectedRowCount(DbPrimaryKey::class)

    /**
     * 根据 表 校验主键是否存在。
     *
     * @param spec 主键校验规格对象。
     * @return 主键是否存在。
     */
    @PostMapping("/existByTable")
    @SaCheckPermission("database:dbPrimaryKey:list")
    @Throws(AuthorizeException::class)
    fun existByTable(@RequestBody spec: DbPrimaryKeyExistByTableSpec): Boolean =
        sqlClient.createQuery(DbPrimaryKey::class) {
            where(spec)
            select(table)
        }.exists()
}