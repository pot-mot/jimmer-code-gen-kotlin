import top.potmot.service.database.DbDataSourceService}
import top.potmot.service.database.DbSchemaService}
import top.potmot.service.database.DbTableService}
@SpringBootTest
@ActiveProfiles("test")
class DbTableTest(
    private val dbDataSourceService: DbDataSourceService,
    private val dbSchemaService: DbSchemaService,
    private val dbTableService: DbTableService,
) {
    fun insertAndReturnId(): Int {
        val dbSchemaDataSourceId = dbDataSourceService.insert(DbDataSourceInsertInput (
            type = DatabaseType.PostgreSQL,
            name = "",
            url = "",
            username = "",
            password = "",
            remark = "",
        ))

        val dbTableSchemaId = dbSchemaService.insert(DbSchemaInsertInput (
            dataSourceId = dbSchemaDataSourceId,
            name = "",
            remark = "",
        ))

        return dbTableService.insert(DbTableInsertInput (
            schemaId = dbTableSchemaId,
            name = "",
            comment = "",
            type = TableType.TABLE,
            remark = "",
        ))
    }

    fun updateAndReturnId(updateId: Int): Int {
        val dbSchemaDataSourceId = dbDataSourceService.insert(DbDataSourceInsertInput (
            type = DatabaseType.PostgreSQL,
            name = "",
            url = "",
            username = "",
            password = "",
            remark = "",
        ))

        val dbTableSchemaId = dbSchemaService.insert(DbSchemaInsertInput (
            dataSourceId = dbSchemaDataSourceId,
            name = "",
            remark = "",
        ))

        return dbTableService.update(DbTableUpdateInput (
            id = updateId,
            schemaId = dbTableSchemaId,
            name = "",
            comment = "",
            type = TableType.TABLE,
            remark = "",
        ))
    }

    fun testInsert() {
    }

    fun testUpdate() {
    }

    fun testDelete() {
    }
}
