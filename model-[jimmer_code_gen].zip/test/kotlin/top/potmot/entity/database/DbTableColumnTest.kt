import top.potmot.service.database.DbDataSourceService}
import top.potmot.service.database.DbSchemaService}
import top.potmot.service.database.DbTableService}
import top.potmot.service.database.DbTableColumnService}
@SpringBootTest
@ActiveProfiles("test")
class DbTableColumnTest(
    private val dbDataSourceService: DbDataSourceService,
    private val dbSchemaService: DbSchemaService,
    private val dbTableService: DbTableService,
    private val dbTableColumnService: DbTableColumnService,
) {
    fun insertAndReturnId(): Int {
        val dbSchemaDataSourceId = dbDataSourceService.insert(DbDataSourceInsertInput (
            type = DatabaseType.PostgreSQL,
            name = "",
            url = "",
            username = "",
            password = "",
            remark = "",
        ))

        val dbTableSchemaId = dbSchemaService.insert(DbSchemaInsertInput (
            dataSourceId = dbSchemaDataSourceId,
            name = "",
            remark = "",
        ))

        val dbTableColumnTableId = dbTableService.insert(DbTableInsertInput (
            schemaId = dbTableSchemaId,
            name = "",
            comment = "",
            type = TableType.TABLE,
            remark = "",
        ))

        return dbTableColumnService.insert(DbTableColumnInsertInput (
            tableId = dbTableColumnTableId,
            name = "",
            orderKey = 0,
            jdbcTypeCode = 0,
            rawType = "",
            typeIsNotNull = false,
            dataSize = null,
            numericPrecision = null,
            defaultValue = null,
            comment = "",
            remark = "",
        ))
    }

    fun updateAndReturnId(updateId: Int): Int {
        val dbSchemaDataSourceId = dbDataSourceService.insert(DbDataSourceInsertInput (
            type = DatabaseType.PostgreSQL,
            name = "",
            url = "",
            username = "",
            password = "",
            remark = "",
        ))

        val dbTableSchemaId = dbSchemaService.insert(DbSchemaInsertInput (
            dataSourceId = dbSchemaDataSourceId,
            name = "",
            remark = "",
        ))

        val dbTableColumnTableId = dbTableService.insert(DbTableInsertInput (
            schemaId = dbTableSchemaId,
            name = "",
            comment = "",
            type = TableType.TABLE,
            remark = "",
        ))

        return dbTableColumnService.update(DbTableColumnUpdateInput (
            id = updateId,
            tableId = dbTableColumnTableId,
            name = "",
            orderKey = 0,
            jdbcTypeCode = 0,
            rawType = "",
            typeIsNotNull = false,
            dataSize = null,
            numericPrecision = null,
            defaultValue = null,
            comment = "",
            remark = "",
        ))
    }

    fun testInsert() {
    }

    fun testUpdate() {
    }

    fun testDelete() {
    }
}
