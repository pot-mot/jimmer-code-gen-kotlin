import top.potmot.service.database.DbDataSourceService}
import top.potmot.service.database.DbSchemaService}
@SpringBootTest
@ActiveProfiles("test")
class DbSchemaTest(
    private val dbDataSourceService: DbDataSourceService,
    private val dbSchemaService: DbSchemaService,
) {
    fun insertAndReturnId(): Int {
        val dbSchemaDataSourceId = dbDataSourceService.insert(DbDataSourceInsertInput (
            type = DatabaseType.PostgreSQL,
            name = "",
            url = "",
            username = "",
            password = "",
            remark = "",
        ))

        return dbSchemaService.insert(DbSchemaInsertInput (
            dataSourceId = dbSchemaDataSourceId,
            name = "",
            remark = "",
        ))
    }

    fun updateAndReturnId(updateId: Int): Int {
        val dbSchemaDataSourceId = dbDataSourceService.insert(DbDataSourceInsertInput (
            type = DatabaseType.PostgreSQL,
            name = "",
            url = "",
            username = "",
            password = "",
            remark = "",
        ))

        return dbSchemaService.update(DbSchemaUpdateInput (
            id = updateId,
            dataSourceId = dbSchemaDataSourceId,
            name = "",
            remark = "",
        ))
    }

    fun testInsert() {
    }

    fun testUpdate() {
    }

    fun testDelete() {
    }
}
