import top.potmot.service.database.DbDataSourceService}
import top.potmot.service.database.DbSchemaService}
import top.potmot.service.database.DbTableService}
import top.potmot.service.database.DbPrimaryKeyService}
@SpringBootTest
@ActiveProfiles("test")
class DbPrimaryKeyTest(
    private val dbDataSourceService: DbDataSourceService,
    private val dbSchemaService: DbSchemaService,
    private val dbTableService: DbTableService,
    private val dbPrimaryKeyService: DbPrimaryKeyService,
) {
    fun insertAndReturnId(): Int {
        val dbSchemaDataSourceId = dbDataSourceService.insert(DbDataSourceInsertInput (
            type = DatabaseType.PostgreSQL,
            name = "",
            url = "",
            username = "",
            password = "",
            remark = "",
        ))

        val dbTableSchemaId = dbSchemaService.insert(DbSchemaInsertInput (
            dataSourceId = dbSchemaDataSourceId,
            name = "",
            remark = "",
        ))

        val dbPrimaryKeyTableId = dbTableService.insert(DbTableInsertInput (
            schemaId = dbTableSchemaId,
            name = "",
            comment = "",
            type = TableType.TABLE,
            remark = "",
        ))

        return dbPrimaryKeyService.insert(DbPrimaryKeyInsertInput (
            tableId = dbPrimaryKeyTableId,
            name = "",
            serialName = null,
            autoIncrement = false,
            remark = "",
        ))
    }

    fun updateAndReturnId(updateId: Int): Int {
        val dbSchemaDataSourceId = dbDataSourceService.insert(DbDataSourceInsertInput (
            type = DatabaseType.PostgreSQL,
            name = "",
            url = "",
            username = "",
            password = "",
            remark = "",
        ))

        val dbTableSchemaId = dbSchemaService.insert(DbSchemaInsertInput (
            dataSourceId = dbSchemaDataSourceId,
            name = "",
            remark = "",
        ))

        val dbPrimaryKeyTableId = dbTableService.insert(DbTableInsertInput (
            schemaId = dbTableSchemaId,
            name = "",
            comment = "",
            type = TableType.TABLE,
            remark = "",
        ))

        return dbPrimaryKeyService.update(DbPrimaryKeyUpdateInput (
            id = updateId,
            tableId = dbPrimaryKeyTableId,
            name = "",
            serialName = null,
            autoIncrement = false,
            remark = "",
        ))
    }

    fun testInsert() {
    }

    fun testUpdate() {
    }

    fun testDelete() {
    }
}
