import top.potmot.service.database.DbDataSourceService}
import top.potmot.service.database.DbSchemaService}
import top.potmot.service.database.DbTableService}
import top.potmot.service.database.DbForeignKeyService}
import top.potmot.service.database.DbTableColumnService}
import top.potmot.service.database.DbForeignKeyColumnReferenceService}
@SpringBootTest
@ActiveProfiles("test")
class DbForeignKeyColumnReferenceTest(
    private val dbDataSourceService: DbDataSourceService,
    private val dbSchemaService: DbSchemaService,
    private val dbTableService: DbTableService,
    private val dbForeignKeyService: DbForeignKeyService,
    private val dbTableColumnService: DbTableColumnService,
    private val dbForeignKeyColumnReferenceService: DbForeignKeyColumnReferenceService,
) {
    fun insertAndReturnId(): Int {
        val dbSchemaDataSourceId = dbDataSourceService.insert(DbDataSourceInsertInput (
            type = DatabaseType.PostgreSQL,
            name = "",
            url = "",
            username = "",
            password = "",
            remark = "",
        ))

        val dbTableSchemaId = dbSchemaService.insert(DbSchemaInsertInput (
            dataSourceId = dbSchemaDataSourceId,
            name = "",
            remark = "",
        ))

        val dbForeignKeySourceTableId = dbTableService.insert(DbTableInsertInput (
            schemaId = dbTableSchemaId,
            name = "",
            comment = "",
            type = TableType.TABLE,
            remark = "",
        ))

        val dbForeignKeyTargetTableId = dbTableService.insert(DbTableInsertInput (
            schemaId = dbTableSchemaId,
            name = "",
            comment = "",
            type = TableType.TABLE,
            remark = "",
        ))

        val dbForeignKeyColumnReferenceAssociationId = dbForeignKeyService.insert(DbForeignKeyInsertInput (
            name = "",
            sourceTableId = dbForeignKeySourceTableId,
            targetTableId = dbForeignKeyTargetTableId,
            type = "",
            updateAction = "",
            deleteAction = "",
            remark = "",
        ))

        val dbTableColumnTableId = dbTableService.insert(DbTableInsertInput (
            schemaId = dbTableSchemaId,
            name = "",
            comment = "",
            type = TableType.TABLE,
            remark = "",
        ))

        val dbForeignKeyColumnReferenceSourceColumnId = dbTableColumnService.insert(DbTableColumnInsertInput (
            tableId = dbTableColumnTableId,
            name = "",
            orderKey = 0,
            jdbcTypeCode = 0,
            rawType = "",
            typeIsNotNull = false,
            dataSize = null,
            numericPrecision = null,
            defaultValue = null,
            comment = "",
            remark = "",
        ))

        val dbForeignKeyColumnReferenceTargetColumnId = dbTableColumnService.insert(DbTableColumnInsertInput (
            tableId = dbTableColumnTableId,
            name = "",
            orderKey = 0,
            jdbcTypeCode = 0,
            rawType = "",
            typeIsNotNull = false,
            dataSize = null,
            numericPrecision = null,
            defaultValue = null,
            comment = "",
            remark = "",
        ))

        return dbForeignKeyColumnReferenceService.insert(DbForeignKeyColumnReferenceInsertInput (
            associationId = dbForeignKeyColumnReferenceAssociationId,
            sourceColumnId = dbForeignKeyColumnReferenceSourceColumnId,
            targetColumnId = dbForeignKeyColumnReferenceTargetColumnId,
            remark = "",
        ))
    }

    fun updateAndReturnId(updateId: Int): Int {
        val dbSchemaDataSourceId = dbDataSourceService.insert(DbDataSourceInsertInput (
            type = DatabaseType.PostgreSQL,
            name = "",
            url = "",
            username = "",
            password = "",
            remark = "",
        ))

        val dbTableSchemaId = dbSchemaService.insert(DbSchemaInsertInput (
            dataSourceId = dbSchemaDataSourceId,
            name = "",
            remark = "",
        ))

        val dbForeignKeySourceTableId = dbTableService.insert(DbTableInsertInput (
            schemaId = dbTableSchemaId,
            name = "",
            comment = "",
            type = TableType.TABLE,
            remark = "",
        ))

        val dbForeignKeyTargetTableId = dbTableService.insert(DbTableInsertInput (
            schemaId = dbTableSchemaId,
            name = "",
            comment = "",
            type = TableType.TABLE,
            remark = "",
        ))

        val dbForeignKeyColumnReferenceAssociationId = dbForeignKeyService.insert(DbForeignKeyInsertInput (
            name = "",
            sourceTableId = dbForeignKeySourceTableId,
            targetTableId = dbForeignKeyTargetTableId,
            type = "",
            updateAction = "",
            deleteAction = "",
            remark = "",
        ))

        val dbTableColumnTableId = dbTableService.insert(DbTableInsertInput (
            schemaId = dbTableSchemaId,
            name = "",
            comment = "",
            type = TableType.TABLE,
            remark = "",
        ))

        val dbForeignKeyColumnReferenceSourceColumnId = dbTableColumnService.insert(DbTableColumnInsertInput (
            tableId = dbTableColumnTableId,
            name = "",
            orderKey = 0,
            jdbcTypeCode = 0,
            rawType = "",
            typeIsNotNull = false,
            dataSize = null,
            numericPrecision = null,
            defaultValue = null,
            comment = "",
            remark = "",
        ))

        val dbForeignKeyColumnReferenceTargetColumnId = dbTableColumnService.insert(DbTableColumnInsertInput (
            tableId = dbTableColumnTableId,
            name = "",
            orderKey = 0,
            jdbcTypeCode = 0,
            rawType = "",
            typeIsNotNull = false,
            dataSize = null,
            numericPrecision = null,
            defaultValue = null,
            comment = "",
            remark = "",
        ))

        return dbForeignKeyColumnReferenceService.update(DbForeignKeyColumnReferenceUpdateInput (
            id = updateId,
            associationId = dbForeignKeyColumnReferenceAssociationId,
            sourceColumnId = dbForeignKeyColumnReferenceSourceColumnId,
            targetColumnId = dbForeignKeyColumnReferenceTargetColumnId,
            remark = "",
        ))
    }

    fun testInsert() {
    }

    fun testUpdate() {
    }

    fun testDelete() {
    }
}
