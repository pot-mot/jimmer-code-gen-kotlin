import top.potmot.service.database.DbDataSourceService}
import top.potmot.service.database.DbSchemaService}
import top.potmot.service.database.DbTableService}
import top.potmot.service.database.DbForeignKeyService}
@SpringBootTest
@ActiveProfiles("test")
class DbForeignKeyTest(
    private val dbDataSourceService: DbDataSourceService,
    private val dbSchemaService: DbSchemaService,
    private val dbTableService: DbTableService,
    private val dbForeignKeyService: DbForeignKeyService,
) {
    fun insertAndReturnId(): Int {
        val dbSchemaDataSourceId = dbDataSourceService.insert(DbDataSourceInsertInput (
            type = DatabaseType.PostgreSQL,
            name = "",
            url = "",
            username = "",
            password = "",
            remark = "",
        ))

        val dbTableSchemaId = dbSchemaService.insert(DbSchemaInsertInput (
            dataSourceId = dbSchemaDataSourceId,
            name = "",
            remark = "",
        ))

        val dbForeignKeySourceTableId = dbTableService.insert(DbTableInsertInput (
            schemaId = dbTableSchemaId,
            name = "",
            comment = "",
            type = TableType.TABLE,
            remark = "",
        ))

        val dbForeignKeyTargetTableId = dbTableService.insert(DbTableInsertInput (
            schemaId = dbTableSchemaId,
            name = "",
            comment = "",
            type = TableType.TABLE,
            remark = "",
        ))

        return dbForeignKeyService.insert(DbForeignKeyInsertInput (
            name = "",
            sourceTableId = dbForeignKeySourceTableId,
            targetTableId = dbForeignKeyTargetTableId,
            type = "",
            updateAction = "",
            deleteAction = "",
            remark = "",
        ))
    }

    fun updateAndReturnId(updateId: Int): Int {
        val dbSchemaDataSourceId = dbDataSourceService.insert(DbDataSourceInsertInput (
            type = DatabaseType.PostgreSQL,
            name = "",
            url = "",
            username = "",
            password = "",
            remark = "",
        ))

        val dbTableSchemaId = dbSchemaService.insert(DbSchemaInsertInput (
            dataSourceId = dbSchemaDataSourceId,
            name = "",
            remark = "",
        ))

        val dbForeignKeySourceTableId = dbTableService.insert(DbTableInsertInput (
            schemaId = dbTableSchemaId,
            name = "",
            comment = "",
            type = TableType.TABLE,
            remark = "",
        ))

        val dbForeignKeyTargetTableId = dbTableService.insert(DbTableInsertInput (
            schemaId = dbTableSchemaId,
            name = "",
            comment = "",
            type = TableType.TABLE,
            remark = "",
        ))

        return dbForeignKeyService.update(DbForeignKeyUpdateInput (
            id = updateId,
            name = "",
            sourceTableId = dbForeignKeySourceTableId,
            targetTableId = dbForeignKeyTargetTableId,
            type = "",
            updateAction = "",
            deleteAction = "",
            remark = "",
        ))
    }

    fun testInsert() {
    }

    fun testUpdate() {
    }

    fun testDelete() {
    }
}
