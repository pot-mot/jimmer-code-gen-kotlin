import top.potmot.service.database.DbDataSourceService}
@SpringBootTest
@ActiveProfiles("test")
class DbDataSourceTest(
    private val dbDataSourceService: DbDataSourceService,
) {
    fun insertAndReturnId(): Int {
        return dbDataSourceService.insert(DbDataSourceInsertInput (
            type = DatabaseType.PostgreSQL,
            name = "",
            url = "",
            username = "",
            password = "",
            remark = "",
        ))
    }

    fun updateAndReturnId(updateId: Int): Int {
        return dbDataSourceService.update(DbDataSourceUpdateInput (
            id = updateId,
            type = DatabaseType.PostgreSQL,
            name = "",
            url = "",
            username = "",
            password = "",
            remark = "",
        ))
    }

    fun testInsert() {
    }

    fun testUpdate() {
    }

    fun testDelete() {
    }
}
