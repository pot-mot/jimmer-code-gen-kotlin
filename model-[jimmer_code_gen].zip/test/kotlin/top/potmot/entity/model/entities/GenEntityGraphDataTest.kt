import top.potmot.service.model.entities.GenEntityGraphDataService}
@SpringBootTest
@ActiveProfiles("test")
class GenEntityGraphDataTest(
    private val genEntityGraphDataService: GenEntityGraphDataService,
) {
    fun insertAndReturnId(): Int {
        return genEntityGraphDataService.insert(GenEntityGraphDataInsertInput (
            x = 0,
            y = 0,
        ))
    }

    fun updateAndReturnId(updateId: Int): Int {
        return genEntityGraphDataService.update(GenEntityGraphDataUpdateInput (
            id = updateId,
            x = 0,
            y = 0,
        ))
    }

    fun testInsert() {
    }

    fun testUpdate() {
    }

    fun testDelete() {
    }
}
