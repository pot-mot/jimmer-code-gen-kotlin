import top.potmot.service.model.GenModelService}
import top.potmot.service.model.GenModelGroupService}
import top.potmot.service.model.entities.GenEntityGraphDataService}
import top.potmot.service.model.entities.GenEntityService}
import top.potmot.service.model.entities.properties.GenPropertyService}
import top.potmot.service.model.entities.properties.GenManyToOneSourcePropertyService}
@SpringBootTest
@ActiveProfiles("test")
class GenManyToOneSourcePropertyTest(
    private val genModelService: GenModelService,
    private val genModelGroupService: GenModelGroupService,
    private val genEntityGraphDataService: GenEntityGraphDataService,
    private val genEntityService: GenEntityService,
    private val genPropertyService: GenPropertyService,
    private val genManyToOneSourcePropertyService: GenManyToOneSourcePropertyService,
) {
    fun insertAndReturnId(): Int {
        val genModelGroupModelId = genModelService.insert(GenModelInsertInput (
            name = "",
            author = "",
            language = DevLanguage.Kotlin,
            databaseType = DatabaseType.PostgreSQL,
            databaseNamingStrategy = DatabaseNamingStrategyType.RAW,
            createdTime = LocalDateTime(),
            modifiedTime = LocalDateTime(),
        ))

        val genEntityGroupId = genModelGroupService.insert(GenModelGroupInsertInput (
            modelId = genModelGroupModelId,
            name = "",
            comment = "",
            packagePath = "",
            tablePath = "",
            style = "",
            orderKey = 0,
        ))

        val genEntityGraphDataId = genEntityGraphDataService.insert(GenEntityGraphDataInsertInput (
            x = 0,
            y = 0,
        ))

        val genManyToOneSourcePropertyTypeEntityId = genEntityService.insert(GenEntityInsertInput (
            groupId = genEntityGroupId,
            interfaceName = "",
            mappedSuper = false,
            tableName = "",
            pluralName = "",
            author = "",
            comment = "",
            subPackagePath = "",
            otherAnnotations = "",
            otherImports = "",
            remark = "",
            idPropertyId = null,
            logicalDeletePropertyId = null,
            versionPropertyId = null,
            graphDataId = genEntityGraphDataId,
        ))

        val genPropertyEntityId = genEntityService.insert(GenEntityInsertInput (
            groupId = genEntityGroupId,
            interfaceName = "",
            mappedSuper = false,
            tableName = "",
            pluralName = "",
            author = "",
            comment = "",
            subPackagePath = "",
            otherAnnotations = "",
            otherImports = "",
            remark = "",
            idPropertyId = null,
            logicalDeletePropertyId = null,
            versionPropertyId = null,
            graphDataId = genEntityGraphDataId,
        ))

        val genManyToOneSourcePropertyPropertyId = genPropertyService.insert(GenPropertyInsertInput (
            idPropertyId = null,
            logicalDeletePropertyId = null,
            manyToManyMappedPropertyId = null,
            manyToManySourcePropertyId = null,
            manyToOneMappedPropertyId = null,
            manyToOneSourcePropertyId = null,
            oneToOneMappedPropertyId = null,
            oneToOneSourcePropertyId = null,
            scalarPropertyId = null,
            sortPropertyId = null,
            versionPropertyId = null,
            entityId = genPropertyEntityId,
            name = "",
            comment = "",
            extraAnnotations = null,
            extraImports = null,
            extraValidations = null,
            remark = "",
        ))

        return genManyToOneSourcePropertyService.insert(GenManyToOneSourcePropertyInsertInput (
            typeEntityId = genManyToOneSourcePropertyTypeEntityId,
            propertyId = genManyToOneSourcePropertyPropertyId,
            idViewName = "",
        ))
    }

    fun updateAndReturnId(updateId: Int): Int {
        val genModelGroupModelId = genModelService.insert(GenModelInsertInput (
            name = "",
            author = "",
            language = DevLanguage.Kotlin,
            databaseType = DatabaseType.PostgreSQL,
            databaseNamingStrategy = DatabaseNamingStrategyType.RAW,
            createdTime = LocalDateTime(),
            modifiedTime = LocalDateTime(),
        ))

        val genEntityGroupId = genModelGroupService.insert(GenModelGroupInsertInput (
            modelId = genModelGroupModelId,
            name = "",
            comment = "",
            packagePath = "",
            tablePath = "",
            style = "",
            orderKey = 0,
        ))

        val genEntityGraphDataId = genEntityGraphDataService.insert(GenEntityGraphDataInsertInput (
            x = 0,
            y = 0,
        ))

        val genManyToOneSourcePropertyTypeEntityId = genEntityService.insert(GenEntityInsertInput (
            groupId = genEntityGroupId,
            interfaceName = "",
            mappedSuper = false,
            tableName = "",
            pluralName = "",
            author = "",
            comment = "",
            subPackagePath = "",
            otherAnnotations = "",
            otherImports = "",
            remark = "",
            idPropertyId = null,
            logicalDeletePropertyId = null,
            versionPropertyId = null,
            graphDataId = genEntityGraphDataId,
        ))

        val genPropertyEntityId = genEntityService.insert(GenEntityInsertInput (
            groupId = genEntityGroupId,
            interfaceName = "",
            mappedSuper = false,
            tableName = "",
            pluralName = "",
            author = "",
            comment = "",
            subPackagePath = "",
            otherAnnotations = "",
            otherImports = "",
            remark = "",
            idPropertyId = null,
            logicalDeletePropertyId = null,
            versionPropertyId = null,
            graphDataId = genEntityGraphDataId,
        ))

        val genManyToOneSourcePropertyPropertyId = genPropertyService.insert(GenPropertyInsertInput (
            idPropertyId = null,
            logicalDeletePropertyId = null,
            manyToManyMappedPropertyId = null,
            manyToManySourcePropertyId = null,
            manyToOneMappedPropertyId = null,
            manyToOneSourcePropertyId = null,
            oneToOneMappedPropertyId = null,
            oneToOneSourcePropertyId = null,
            scalarPropertyId = null,
            sortPropertyId = null,
            versionPropertyId = null,
            entityId = genPropertyEntityId,
            name = "",
            comment = "",
            extraAnnotations = null,
            extraImports = null,
            extraValidations = null,
            remark = "",
        ))

        return genManyToOneSourcePropertyService.update(GenManyToOneSourcePropertyUpdateInput (
            id = updateId,
            typeEntityId = genManyToOneSourcePropertyTypeEntityId,
            manyToOneAssociationId = null,
            manyToOneMappedPropertyId = null,
            propertyId = genManyToOneSourcePropertyPropertyId,
            idViewName = "",
        ))
    }

    fun testInsert() {
    }

    fun testUpdate() {
    }

    fun testDelete() {
    }
}
