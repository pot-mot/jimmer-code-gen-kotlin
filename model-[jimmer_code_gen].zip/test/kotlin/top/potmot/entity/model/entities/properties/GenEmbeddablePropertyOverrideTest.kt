import top.potmot.service.model.GenModelService}
import top.potmot.service.model.GenModelGroupService}
import top.potmot.service.model.entities.GenEntityService}
import top.potmot.service.model.entities.properties.GenPropertyService}
import top.potmot.service.model.embeddables.GenEmbeddableTypeService}
import top.potmot.service.model.entities.properties.GenEmbeddablePropertyService}
import top.potmot.service.model.embeddables.GenEmbeddableTypeDeepPropertyService}
import top.potmot.service.model.embeddables.GenEmbeddableTypePropertyService}
import top.potmot.service.model.entities.properties.GenEmbeddablePropertyOverrideService}
@SpringBootTest
@ActiveProfiles("test")
class GenEmbeddablePropertyOverrideTest(
    private val genModelService: GenModelService,
    private val genModelGroupService: GenModelGroupService,
    private val genEntityService: GenEntityService,
    private val genPropertyService: GenPropertyService,
    private val genEmbeddableTypeService: GenEmbeddableTypeService,
    private val genEmbeddablePropertyService: GenEmbeddablePropertyService,
    private val genEmbeddableTypeDeepPropertyService: GenEmbeddableTypeDeepPropertyService,
    private val genEmbeddableTypePropertyService: GenEmbeddableTypePropertyService,
    private val genEmbeddablePropertyOverrideService: GenEmbeddablePropertyOverrideService,
) {
    fun insertAndReturnId(): Int {
        val genModelGroupModelId = genModelService.insert(GenModelInsertInput (
            name = "",
            author = "",
            language = DevLanguage.Kotlin,
            databaseType = DatabaseType.PostgreSQL,
            databaseNamingStrategy = DatabaseNamingStrategyType.RAW,
            createdTime = LocalDateTime(),
            modifiedTime = LocalDateTime(),
        ))

        val genEntityGroupId = genModelGroupService.insert(GenModelGroupInsertInput (
            modelId = genModelGroupModelId,
            name = "",
            comment = "",
            packagePath = "",
            tablePath = "",
            style = "",
            orderKey = 0,
        ))

        val genPropertyEntityId = genEntityService.insert(GenEntityInsertInput (
            groupId = genEntityGroupId,
            interfaceName = "",
            mappedSuper = false,
            tableName = "",
            pluralName = "",
            author = "",
            comment = "",
            subPackagePath = "",
            otherAnnotations = "",
            otherImports = "",
            remark = "",
            idPropertyId = null,
            logicalDeletePropertyId = null,
            versionPropertyId = null,
            x = 0,
            y = 0,
        ))

        val genEmbeddablePropertyPropertyId = genPropertyService.insert(GenPropertyInsertInput (
            embeddablePropertyId = null,
            enumColumnPropertyId = null,
            extraPropertyId = null,
            idPropertyId = null,
            logicalDeletePropertyId = null,
            manyToManyMappedPropertyId = null,
            manyToManySourcePropertyId = null,
            manyToOneMappedPropertyId = null,
            manyToOneSourcePropertyId = null,
            oneToOneMappedPropertyId = null,
            oneToOneSourcePropertyId = null,
            sortPropertyId = null,
            versionPropertyId = null,
            entityId = genPropertyEntityId,
            name = "",
            comment = "",
            extraAnnotations = null,
            extraImports = null,
            extraValidations = null,
            remark = "",
            orderKey = 0,
        ))

        val genEmbeddablePropertyEntityId = genEntityService.insert(GenEntityInsertInput (
            groupId = genEntityGroupId,
            interfaceName = "",
            mappedSuper = false,
            tableName = "",
            pluralName = "",
            author = "",
            comment = "",
            subPackagePath = "",
            otherAnnotations = "",
            otherImports = "",
            remark = "",
            idPropertyId = null,
            logicalDeletePropertyId = null,
            versionPropertyId = null,
            x = 0,
            y = 0,
        ))

        val genEmbeddableTypeGroupId = genModelGroupService.insert(GenModelGroupInsertInput (
            modelId = genModelGroupModelId,
            name = "",
            comment = "",
            packagePath = "",
            tablePath = "",
            style = "",
            orderKey = 0,
        ))

        val genEmbeddablePropertyTypeEmbeddableId = genEmbeddableTypeService.insert(GenEmbeddableTypeInsertInput (
            groupId = genEmbeddableTypeGroupId,
            name = "",
            subPackagePath = "",
            comment = "",
        ))

        val genEmbeddablePropertyOverrideEmbeddablePropertyId = genEmbeddablePropertyService.insert(GenEmbeddablePropertyInsertInput (
            propertyId = genEmbeddablePropertyPropertyId,
            entityId = genEmbeddablePropertyEntityId,
            typeEmbeddableId = genEmbeddablePropertyTypeEmbeddableId,
        ))

        val genEmbeddableTypeDeepPropertyEmbeddableId = genEmbeddableTypeService.insert(GenEmbeddableTypeInsertInput (
            groupId = genEmbeddableTypeGroupId,
            name = "",
            subPackagePath = "",
            comment = "",
        ))

        val genEmbeddableTypeDeepPropertyTypeEmbeddableId = genEmbeddableTypeService.insert(GenEmbeddableTypeInsertInput (
            groupId = genEmbeddableTypeGroupId,
            name = "",
            subPackagePath = "",
            comment = "",
        ))

        val genEmbeddablePropertyOverrideDeepPropertyId = genEmbeddableTypeDeepPropertyService.insert(GenEmbeddableTypeDeepPropertyInsertInput (
            embeddableId = genEmbeddableTypeDeepPropertyEmbeddableId,
            name = "",
            comment = "",
            typeEmbeddableId = genEmbeddableTypeDeepPropertyTypeEmbeddableId,
            extraAnnotations = null,
            extraImports = null,
            extraValidations = null,
            remark = "",
            orderKey = 0,
        ))

        val genEmbeddableTypePropertyEmbeddableId = genEmbeddableTypeService.insert(GenEmbeddableTypeInsertInput (
            groupId = genEmbeddableTypeGroupId,
            name = "",
            subPackagePath = "",
            comment = "",
        ))

        val genEmbeddablePropertyOverrideOverridePropertyId = genEmbeddableTypePropertyService.insert(GenEmbeddableTypePropertyInsertInput (
            jdbcTypeCode = 0,
            rawType = "",
            typeIsNotNull = false,
            dataSize = null,
            numericPrecision = null,
            columnDefaultExp = null,
            typeEnumId = null,
            embeddableId = genEmbeddableTypePropertyEmbeddableId,
            name = "",
            comment = "",
            type = null,
            columnName = "",
            extraAnnotations = null,
            extraImports = null,
            extraValidations = null,
            remark = "",
            orderKey = 0,
        ))

        return genEmbeddablePropertyOverrideService.insert(GenEmbeddablePropertyOverrideInsertInput (
            embeddablePropertyId = genEmbeddablePropertyOverrideEmbeddablePropertyId,
            deepPropertyId = genEmbeddablePropertyOverrideDeepPropertyId,
            overridePropertyId = genEmbeddablePropertyOverrideOverridePropertyId,
            columnName = "",
        ))
    }

    fun updateAndReturnId(updateId: Int): Int {
        val genModelGroupModelId = genModelService.insert(GenModelInsertInput (
            name = "",
            author = "",
            language = DevLanguage.Kotlin,
            databaseType = DatabaseType.PostgreSQL,
            databaseNamingStrategy = DatabaseNamingStrategyType.RAW,
            createdTime = LocalDateTime(),
            modifiedTime = LocalDateTime(),
        ))

        val genEntityGroupId = genModelGroupService.insert(GenModelGroupInsertInput (
            modelId = genModelGroupModelId,
            name = "",
            comment = "",
            packagePath = "",
            tablePath = "",
            style = "",
            orderKey = 0,
        ))

        val genPropertyEntityId = genEntityService.insert(GenEntityInsertInput (
            groupId = genEntityGroupId,
            interfaceName = "",
            mappedSuper = false,
            tableName = "",
            pluralName = "",
            author = "",
            comment = "",
            subPackagePath = "",
            otherAnnotations = "",
            otherImports = "",
            remark = "",
            idPropertyId = null,
            logicalDeletePropertyId = null,
            versionPropertyId = null,
            x = 0,
            y = 0,
        ))

        val genEmbeddablePropertyPropertyId = genPropertyService.insert(GenPropertyInsertInput (
            embeddablePropertyId = null,
            enumColumnPropertyId = null,
            extraPropertyId = null,
            idPropertyId = null,
            logicalDeletePropertyId = null,
            manyToManyMappedPropertyId = null,
            manyToManySourcePropertyId = null,
            manyToOneMappedPropertyId = null,
            manyToOneSourcePropertyId = null,
            oneToOneMappedPropertyId = null,
            oneToOneSourcePropertyId = null,
            sortPropertyId = null,
            versionPropertyId = null,
            entityId = genPropertyEntityId,
            name = "",
            comment = "",
            extraAnnotations = null,
            extraImports = null,
            extraValidations = null,
            remark = "",
            orderKey = 0,
        ))

        val genEmbeddablePropertyEntityId = genEntityService.insert(GenEntityInsertInput (
            groupId = genEntityGroupId,
            interfaceName = "",
            mappedSuper = false,
            tableName = "",
            pluralName = "",
            author = "",
            comment = "",
            subPackagePath = "",
            otherAnnotations = "",
            otherImports = "",
            remark = "",
            idPropertyId = null,
            logicalDeletePropertyId = null,
            versionPropertyId = null,
            x = 0,
            y = 0,
        ))

        val genEmbeddableTypeGroupId = genModelGroupService.insert(GenModelGroupInsertInput (
            modelId = genModelGroupModelId,
            name = "",
            comment = "",
            packagePath = "",
            tablePath = "",
            style = "",
            orderKey = 0,
        ))

        val genEmbeddablePropertyTypeEmbeddableId = genEmbeddableTypeService.insert(GenEmbeddableTypeInsertInput (
            groupId = genEmbeddableTypeGroupId,
            name = "",
            subPackagePath = "",
            comment = "",
        ))

        val genEmbeddablePropertyOverrideEmbeddablePropertyId = genEmbeddablePropertyService.insert(GenEmbeddablePropertyInsertInput (
            propertyId = genEmbeddablePropertyPropertyId,
            entityId = genEmbeddablePropertyEntityId,
            typeEmbeddableId = genEmbeddablePropertyTypeEmbeddableId,
        ))

        val genEmbeddableTypeDeepPropertyEmbeddableId = genEmbeddableTypeService.insert(GenEmbeddableTypeInsertInput (
            groupId = genEmbeddableTypeGroupId,
            name = "",
            subPackagePath = "",
            comment = "",
        ))

        val genEmbeddableTypeDeepPropertyTypeEmbeddableId = genEmbeddableTypeService.insert(GenEmbeddableTypeInsertInput (
            groupId = genEmbeddableTypeGroupId,
            name = "",
            subPackagePath = "",
            comment = "",
        ))

        val genEmbeddablePropertyOverrideDeepPropertyId = genEmbeddableTypeDeepPropertyService.insert(GenEmbeddableTypeDeepPropertyInsertInput (
            embeddableId = genEmbeddableTypeDeepPropertyEmbeddableId,
            name = "",
            comment = "",
            typeEmbeddableId = genEmbeddableTypeDeepPropertyTypeEmbeddableId,
            extraAnnotations = null,
            extraImports = null,
            extraValidations = null,
            remark = "",
            orderKey = 0,
        ))

        val genEmbeddableTypePropertyEmbeddableId = genEmbeddableTypeService.insert(GenEmbeddableTypeInsertInput (
            groupId = genEmbeddableTypeGroupId,
            name = "",
            subPackagePath = "",
            comment = "",
        ))

        val genEmbeddablePropertyOverrideOverridePropertyId = genEmbeddableTypePropertyService.insert(GenEmbeddableTypePropertyInsertInput (
            jdbcTypeCode = 0,
            rawType = "",
            typeIsNotNull = false,
            dataSize = null,
            numericPrecision = null,
            columnDefaultExp = null,
            typeEnumId = null,
            embeddableId = genEmbeddableTypePropertyEmbeddableId,
            name = "",
            comment = "",
            type = null,
            columnName = "",
            extraAnnotations = null,
            extraImports = null,
            extraValidations = null,
            remark = "",
            orderKey = 0,
        ))

        return genEmbeddablePropertyOverrideService.update(GenEmbeddablePropertyOverrideUpdateInput (
            id = updateId,
            embeddablePropertyId = genEmbeddablePropertyOverrideEmbeddablePropertyId,
            deepPropertyId = genEmbeddablePropertyOverrideDeepPropertyId,
            overridePropertyId = genEmbeddablePropertyOverrideOverridePropertyId,
            columnName = "",
        ))
    }

    fun testInsert() {
    }

    fun testUpdate() {
    }

    fun testDelete() {
    }
}
