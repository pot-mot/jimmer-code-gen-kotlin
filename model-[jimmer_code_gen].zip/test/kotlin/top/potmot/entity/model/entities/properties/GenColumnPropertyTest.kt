import top.potmot.service.model.GenModelService}
import top.potmot.service.model.GenModelGroupService}
import top.potmot.service.model.entities.GenEntityService}
import top.potmot.service.model.entities.properties.GenPropertyService}
import top.potmot.service.model.entities.properties.GenColumnPropertyService}
@SpringBootTest
@ActiveProfiles("test")
class GenColumnPropertyTest(
    private val genModelService: GenModelService,
    private val genModelGroupService: GenModelGroupService,
    private val genEntityService: GenEntityService,
    private val genPropertyService: GenPropertyService,
    private val genColumnPropertyService: GenColumnPropertyService,
) {
    fun insertAndReturnId(): Int {
        val genModelGroupModelId = genModelService.insert(GenModelInsertInput (
            name = "",
            author = "",
            language = DevLanguage.Kotlin,
            databaseType = DatabaseType.PostgreSQL,
            databaseNamingStrategy = DatabaseNamingStrategyType.RAW,
            createdTime = LocalDateTime(),
            modifiedTime = LocalDateTime(),
        ))

        val genEntityGroupId = genModelGroupService.insert(GenModelGroupInsertInput (
            modelId = genModelGroupModelId,
            name = "",
            comment = "",
            packagePath = "",
            tablePath = "",
            style = "",
            orderKey = 0,
        ))

        val genPropertyEntityId = genEntityService.insert(GenEntityInsertInput (
            groupId = genEntityGroupId,
            interfaceName = "",
            mappedSuper = false,
            tableName = "",
            pluralName = "",
            author = "",
            comment = "",
            subPackagePath = "",
            otherAnnotations = "",
            otherImports = "",
            remark = "",
            idPropertyId = null,
            logicalDeletePropertyId = null,
            versionPropertyId = null,
            x = 0,
            y = 0,
        ))

        val genColumnPropertyPropertyId = genPropertyService.insert(GenPropertyInsertInput (
            embeddablePropertyId = null,
            enumColumnPropertyId = null,
            extraPropertyId = null,
            idPropertyId = null,
            logicalDeletePropertyId = null,
            manyToManyMappedPropertyId = null,
            manyToManySourcePropertyId = null,
            manyToOneMappedPropertyId = null,
            manyToOneSourcePropertyId = null,
            oneToOneMappedPropertyId = null,
            oneToOneSourcePropertyId = null,
            sortPropertyId = null,
            versionPropertyId = null,
            entityId = genPropertyEntityId,
            name = "",
            comment = "",
            extraAnnotations = null,
            extraImports = null,
            extraValidations = null,
            remark = "",
            orderKey = 0,
        ))

        val genColumnPropertyEntityId = genEntityService.insert(GenEntityInsertInput (
            groupId = genEntityGroupId,
            interfaceName = "",
            mappedSuper = false,
            tableName = "",
            pluralName = "",
            author = "",
            comment = "",
            subPackagePath = "",
            otherAnnotations = "",
            otherImports = "",
            remark = "",
            idPropertyId = null,
            logicalDeletePropertyId = null,
            versionPropertyId = null,
            x = 0,
            y = 0,
        ))

        return genColumnPropertyService.insert(GenColumnPropertyInsertInput (
            jdbcTypeCode = 0,
            rawType = "",
            typeIsNotNull = false,
            dataSize = null,
            numericPrecision = null,
            columnDefaultExp = null,
            propertyId = genColumnPropertyPropertyId,
            entityId = genColumnPropertyEntityId,
            type = "",
            columnName = "",
        ))
    }

    fun updateAndReturnId(updateId: Int): Int {
        val genModelGroupModelId = genModelService.insert(GenModelInsertInput (
            name = "",
            author = "",
            language = DevLanguage.Kotlin,
            databaseType = DatabaseType.PostgreSQL,
            databaseNamingStrategy = DatabaseNamingStrategyType.RAW,
            createdTime = LocalDateTime(),
            modifiedTime = LocalDateTime(),
        ))

        val genEntityGroupId = genModelGroupService.insert(GenModelGroupInsertInput (
            modelId = genModelGroupModelId,
            name = "",
            comment = "",
            packagePath = "",
            tablePath = "",
            style = "",
            orderKey = 0,
        ))

        val genPropertyEntityId = genEntityService.insert(GenEntityInsertInput (
            groupId = genEntityGroupId,
            interfaceName = "",
            mappedSuper = false,
            tableName = "",
            pluralName = "",
            author = "",
            comment = "",
            subPackagePath = "",
            otherAnnotations = "",
            otherImports = "",
            remark = "",
            idPropertyId = null,
            logicalDeletePropertyId = null,
            versionPropertyId = null,
            x = 0,
            y = 0,
        ))

        val genColumnPropertyPropertyId = genPropertyService.insert(GenPropertyInsertInput (
            embeddablePropertyId = null,
            enumColumnPropertyId = null,
            extraPropertyId = null,
            idPropertyId = null,
            logicalDeletePropertyId = null,
            manyToManyMappedPropertyId = null,
            manyToManySourcePropertyId = null,
            manyToOneMappedPropertyId = null,
            manyToOneSourcePropertyId = null,
            oneToOneMappedPropertyId = null,
            oneToOneSourcePropertyId = null,
            sortPropertyId = null,
            versionPropertyId = null,
            entityId = genPropertyEntityId,
            name = "",
            comment = "",
            extraAnnotations = null,
            extraImports = null,
            extraValidations = null,
            remark = "",
            orderKey = 0,
        ))

        val genColumnPropertyEntityId = genEntityService.insert(GenEntityInsertInput (
            groupId = genEntityGroupId,
            interfaceName = "",
            mappedSuper = false,
            tableName = "",
            pluralName = "",
            author = "",
            comment = "",
            subPackagePath = "",
            otherAnnotations = "",
            otherImports = "",
            remark = "",
            idPropertyId = null,
            logicalDeletePropertyId = null,
            versionPropertyId = null,
            x = 0,
            y = 0,
        ))

        return genColumnPropertyService.update(GenColumnPropertyUpdateInput (
            id = updateId,
            jdbcTypeCode = 0,
            rawType = "",
            typeIsNotNull = false,
            dataSize = null,
            numericPrecision = null,
            columnDefaultExp = null,
            propertyId = genColumnPropertyPropertyId,
            entityId = genColumnPropertyEntityId,
            type = "",
            columnName = "",
        ))
    }

    fun testInsert() {
    }

    fun testUpdate() {
    }

    fun testDelete() {
    }
}
