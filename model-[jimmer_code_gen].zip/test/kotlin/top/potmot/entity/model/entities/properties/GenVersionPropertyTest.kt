import top.potmot.service.model.GenModelService}
import top.potmot.service.model.GenModelGroupService}
import top.potmot.service.model.entities.GenEntityService}
import top.potmot.service.model.entities.properties.GenPropertyService}
import top.potmot.service.model.entities.properties.GenVersionPropertyService}
@SpringBootTest
@ActiveProfiles("test")
class GenVersionPropertyTest(
    private val genModelService: GenModelService,
    private val genModelGroupService: GenModelGroupService,
    private val genEntityService: GenEntityService,
    private val genPropertyService: GenPropertyService,
    private val genVersionPropertyService: GenVersionPropertyService,
) {
    fun insertAndReturnId(): Int {
        val genModelGroupModelId = genModelService.insert(GenModelInsertInput (
            name = "",
            author = "",
            language = DevLanguage.Kotlin,
            databaseType = DatabaseType.PostgreSQL,
            databaseNamingStrategy = DatabaseNamingStrategyType.RAW,
            transition = "",
            createdTime = LocalDateTime(),
            modifiedTime = LocalDateTime(),
        ))

        val genEntityGroupId = genModelGroupService.insert(GenModelGroupInsertInput (
            modelId = genModelGroupModelId,
            name = "",
            comment = "",
            packagePath = "",
            tablePath = "",
            color = "",
            orderKey = 0,
        ))

        val genPropertyEntityId = genEntityService.insert(GenEntityInsertInput (
            groupId = genEntityGroupId,
            interfaceName = "",
            mappedSuper = false,
            tableName = "",
            pluralName = "",
            author = "",
            comment = "",
            subPackagePath = "",
            otherAnnotations = "",
            otherImports = "",
            remark = "",
            idPropertyId = null,
            logicalDeletePropertyId = null,
            versionPropertyId = null,
            x = 0,
            y = 0,
        ))

        val genVersionPropertyPropertyId = genPropertyService.insert(GenPropertyInsertInput (
            rawType = null,
            typeEnumId = null,
            typeEmbeddableId = null,
            columnInfoId = null,
            genIdPropertyId = null,
            genLogicalDeletePropertyId = null,
            genManyToManyMappedPropertyId = null,
            genManyToManySourcePropertyId = null,
            genManyToOneMappedPropertyId = null,
            genManyToOneSourcePropertyId = null,
            genOneToOneMappedPropertyId = null,
            genOneToOneSourcePropertyId = null,
            genSortPropertyId = null,
            genVersionPropertyId = null,
            entityId = genPropertyEntityId,
            name = "",
            comment = "",
            extraAnnotations = null,
            extraImports = null,
            extraValidations = null,
            remark = "",
            orderKey = 0,
        ))

        return genVersionPropertyService.insert(GenVersionPropertyInsertInput (
            propertyId = genVersionPropertyPropertyId,
            columnName = "",
        ))
    }

    fun updateAndReturnId(updateId: Int): Int {
        val genModelGroupModelId = genModelService.insert(GenModelInsertInput (
            name = "",
            author = "",
            language = DevLanguage.Kotlin,
            databaseType = DatabaseType.PostgreSQL,
            databaseNamingStrategy = DatabaseNamingStrategyType.RAW,
            transition = "",
            createdTime = LocalDateTime(),
            modifiedTime = LocalDateTime(),
        ))

        val genEntityGroupId = genModelGroupService.insert(GenModelGroupInsertInput (
            modelId = genModelGroupModelId,
            name = "",
            comment = "",
            packagePath = "",
            tablePath = "",
            color = "",
            orderKey = 0,
        ))

        val genPropertyEntityId = genEntityService.insert(GenEntityInsertInput (
            groupId = genEntityGroupId,
            interfaceName = "",
            mappedSuper = false,
            tableName = "",
            pluralName = "",
            author = "",
            comment = "",
            subPackagePath = "",
            otherAnnotations = "",
            otherImports = "",
            remark = "",
            idPropertyId = null,
            logicalDeletePropertyId = null,
            versionPropertyId = null,
            x = 0,
            y = 0,
        ))

        val genVersionPropertyPropertyId = genPropertyService.insert(GenPropertyInsertInput (
            rawType = null,
            typeEnumId = null,
            typeEmbeddableId = null,
            columnInfoId = null,
            genIdPropertyId = null,
            genLogicalDeletePropertyId = null,
            genManyToManyMappedPropertyId = null,
            genManyToManySourcePropertyId = null,
            genManyToOneMappedPropertyId = null,
            genManyToOneSourcePropertyId = null,
            genOneToOneMappedPropertyId = null,
            genOneToOneSourcePropertyId = null,
            genSortPropertyId = null,
            genVersionPropertyId = null,
            entityId = genPropertyEntityId,
            name = "",
            comment = "",
            extraAnnotations = null,
            extraImports = null,
            extraValidations = null,
            remark = "",
            orderKey = 0,
        ))

        return genVersionPropertyService.update(GenVersionPropertyUpdateInput (
            id = updateId,
            propertyId = genVersionPropertyPropertyId,
            columnName = "",
        ))
    }

    fun testInsert() {
    }

    fun testUpdate() {
    }

    fun testDelete() {
    }
}
