import top.potmot.service.model.GenModelService}
import top.potmot.service.model.GenModelGroupService}
import top.potmot.service.model.entities.GenEntityGraphDataService}
import top.potmot.service.model.entities.GenEntityService}
import top.potmot.service.model.entities.properties.GenPropertyService}
import top.potmot.service.model.entities.properties.GenSortPropertyService}
@SpringBootTest
@ActiveProfiles("test")
class GenSortPropertyTest(
    private val genModelService: GenModelService,
    private val genModelGroupService: GenModelGroupService,
    private val genEntityGraphDataService: GenEntityGraphDataService,
    private val genEntityService: GenEntityService,
    private val genPropertyService: GenPropertyService,
    private val genSortPropertyService: GenSortPropertyService,
) {
    fun insertAndReturnId(): Int {
        val genModelGroupModelId = genModelService.insert(GenModelInsertInput (
            name = "",
            author = "",
            language = DevLanguage.Kotlin,
            databaseType = DatabaseType.PostgreSQL,
            databaseNamingStrategy = DatabaseNamingStrategyType.RAW,
            createdTime = LocalDateTime(),
            modifiedTime = LocalDateTime(),
        ))

        val genEntityGroupId = genModelGroupService.insert(GenModelGroupInsertInput (
            modelId = genModelGroupModelId,
            name = "",
            comment = "",
            packagePath = "",
            tablePath = "",
            style = "",
            orderKey = 0,
        ))

        val genEntityGraphDataId = genEntityGraphDataService.insert(GenEntityGraphDataInsertInput (
            x = 0,
            y = 0,
        ))

        val genPropertyEntityId = genEntityService.insert(GenEntityInsertInput (
            groupId = genEntityGroupId,
            interfaceName = "",
            mappedSuper = false,
            tableName = "",
            pluralName = "",
            author = "",
            comment = "",
            subPackagePath = "",
            otherAnnotations = "",
            otherImports = "",
            remark = "",
            idPropertyId = null,
            logicalDeletePropertyId = null,
            versionPropertyId = null,
            graphDataId = genEntityGraphDataId,
        ))

        val genSortPropertyPropertyId = genPropertyService.insert(GenPropertyInsertInput (
            idPropertyId = null,
            logicalDeletePropertyId = null,
            manyToManyMappedPropertyId = null,
            manyToManySourcePropertyId = null,
            manyToOneMappedPropertyId = null,
            manyToOneSourcePropertyId = null,
            oneToOneMappedPropertyId = null,
            oneToOneSourcePropertyId = null,
            scalarPropertyId = null,
            sortPropertyId = null,
            versionPropertyId = null,
            entityId = genPropertyEntityId,
            name = "",
            comment = "",
            extraAnnotations = null,
            extraImports = null,
            extraValidations = null,
            remark = "",
        ))

        val genSortPropertyEntityId = genEntityService.insert(GenEntityInsertInput (
            groupId = genEntityGroupId,
            interfaceName = "",
            mappedSuper = false,
            tableName = "",
            pluralName = "",
            author = "",
            comment = "",
            subPackagePath = "",
            otherAnnotations = "",
            otherImports = "",
            remark = "",
            idPropertyId = null,
            logicalDeletePropertyId = null,
            versionPropertyId = null,
            graphDataId = genEntityGraphDataId,
        ))

        return genSortPropertyService.insert(GenSortPropertyInsertInput (
            propertyId = genSortPropertyPropertyId,
            entityId = genSortPropertyEntityId,
            orderDirection = OrderDirection.ASC,
        ))
    }

    fun updateAndReturnId(updateId: Int): Int {
        val genModelGroupModelId = genModelService.insert(GenModelInsertInput (
            name = "",
            author = "",
            language = DevLanguage.Kotlin,
            databaseType = DatabaseType.PostgreSQL,
            databaseNamingStrategy = DatabaseNamingStrategyType.RAW,
            createdTime = LocalDateTime(),
            modifiedTime = LocalDateTime(),
        ))

        val genEntityGroupId = genModelGroupService.insert(GenModelGroupInsertInput (
            modelId = genModelGroupModelId,
            name = "",
            comment = "",
            packagePath = "",
            tablePath = "",
            style = "",
            orderKey = 0,
        ))

        val genEntityGraphDataId = genEntityGraphDataService.insert(GenEntityGraphDataInsertInput (
            x = 0,
            y = 0,
        ))

        val genPropertyEntityId = genEntityService.insert(GenEntityInsertInput (
            groupId = genEntityGroupId,
            interfaceName = "",
            mappedSuper = false,
            tableName = "",
            pluralName = "",
            author = "",
            comment = "",
            subPackagePath = "",
            otherAnnotations = "",
            otherImports = "",
            remark = "",
            idPropertyId = null,
            logicalDeletePropertyId = null,
            versionPropertyId = null,
            graphDataId = genEntityGraphDataId,
        ))

        val genSortPropertyPropertyId = genPropertyService.insert(GenPropertyInsertInput (
            idPropertyId = null,
            logicalDeletePropertyId = null,
            manyToManyMappedPropertyId = null,
            manyToManySourcePropertyId = null,
            manyToOneMappedPropertyId = null,
            manyToOneSourcePropertyId = null,
            oneToOneMappedPropertyId = null,
            oneToOneSourcePropertyId = null,
            scalarPropertyId = null,
            sortPropertyId = null,
            versionPropertyId = null,
            entityId = genPropertyEntityId,
            name = "",
            comment = "",
            extraAnnotations = null,
            extraImports = null,
            extraValidations = null,
            remark = "",
        ))

        val genSortPropertyEntityId = genEntityService.insert(GenEntityInsertInput (
            groupId = genEntityGroupId,
            interfaceName = "",
            mappedSuper = false,
            tableName = "",
            pluralName = "",
            author = "",
            comment = "",
            subPackagePath = "",
            otherAnnotations = "",
            otherImports = "",
            remark = "",
            idPropertyId = null,
            logicalDeletePropertyId = null,
            versionPropertyId = null,
            graphDataId = genEntityGraphDataId,
        ))

        return genSortPropertyService.update(GenSortPropertyUpdateInput (
            id = updateId,
            propertyId = genSortPropertyPropertyId,
            entityId = genSortPropertyEntityId,
            orderDirection = OrderDirection.ASC,
        ))
    }

    fun testInsert() {
    }

    fun testUpdate() {
    }

    fun testDelete() {
    }
}
