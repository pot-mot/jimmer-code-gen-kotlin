import top.potmot.service.model.GenModelService}
import top.potmot.service.model.GenModelGroupService}
import top.potmot.service.model.entities.GenEntityGraphDataService}
import top.potmot.service.model.entities.GenEntityService}
import top.potmot.service.model.entities.GenEntityIndexService}
@SpringBootTest
@ActiveProfiles("test")
class GenEntityIndexTest(
    private val genModelService: GenModelService,
    private val genModelGroupService: GenModelGroupService,
    private val genEntityGraphDataService: GenEntityGraphDataService,
    private val genEntityService: GenEntityService,
    private val genEntityIndexService: GenEntityIndexService,
) {
    fun insertAndReturnId(): Int {
        val genModelGroupModelId = genModelService.insert(GenModelInsertInput (
            name = "",
            author = "",
            language = DevLanguage.Kotlin,
            databaseType = DatabaseType.PostgreSQL,
            databaseNamingStrategy = DatabaseNamingStrategyType.RAW,
            createdTime = LocalDateTime(),
            modifiedTime = LocalDateTime(),
        ))

        val genEntityGroupId = genModelGroupService.insert(GenModelGroupInsertInput (
            modelId = genModelGroupModelId,
            name = "",
            comment = "",
            packagePath = "",
            tablePath = "",
            style = "",
            orderKey = 0,
        ))

        val genEntityGraphDataId = genEntityGraphDataService.insert(GenEntityGraphDataInsertInput (
            x = 0,
            y = 0,
        ))

        val genEntityIndexEntityId = genEntityService.insert(GenEntityInsertInput (
            groupId = genEntityGroupId,
            interfaceName = "",
            mappedSuper = false,
            tableName = "",
            pluralName = "",
            author = "",
            comment = "",
            subPackagePath = "",
            otherAnnotations = "",
            otherImports = "",
            remark = "",
            idPropertyId = null,
            logicalDeletePropertyId = null,
            versionPropertyId = null,
            graphDataId = genEntityGraphDataId,
        ))

        return genEntityIndexService.insert(GenEntityIndexInsertInput (
            entityId = genEntityIndexEntityId,
            name = "",
            uniqueIndex = false,
            remark = "",
        ))
    }

    fun updateAndReturnId(updateId: Int): Int {
        val genModelGroupModelId = genModelService.insert(GenModelInsertInput (
            name = "",
            author = "",
            language = DevLanguage.Kotlin,
            databaseType = DatabaseType.PostgreSQL,
            databaseNamingStrategy = DatabaseNamingStrategyType.RAW,
            createdTime = LocalDateTime(),
            modifiedTime = LocalDateTime(),
        ))

        val genEntityGroupId = genModelGroupService.insert(GenModelGroupInsertInput (
            modelId = genModelGroupModelId,
            name = "",
            comment = "",
            packagePath = "",
            tablePath = "",
            style = "",
            orderKey = 0,
        ))

        val genEntityGraphDataId = genEntityGraphDataService.insert(GenEntityGraphDataInsertInput (
            x = 0,
            y = 0,
        ))

        val genEntityIndexEntityId = genEntityService.insert(GenEntityInsertInput (
            groupId = genEntityGroupId,
            interfaceName = "",
            mappedSuper = false,
            tableName = "",
            pluralName = "",
            author = "",
            comment = "",
            subPackagePath = "",
            otherAnnotations = "",
            otherImports = "",
            remark = "",
            idPropertyId = null,
            logicalDeletePropertyId = null,
            versionPropertyId = null,
            graphDataId = genEntityGraphDataId,
        ))

        return genEntityIndexService.update(GenEntityIndexUpdateInput (
            id = updateId,
            entityKeyGroupId = null,
            entityId = genEntityIndexEntityId,
            name = "",
            uniqueIndex = false,
            remark = "",
        ))
    }

    fun testInsert() {
    }

    fun testUpdate() {
    }

    fun testDelete() {
    }
}
