import top.potmot.service.model.GenTypePairService}
@SpringBootTest
@ActiveProfiles("test")
class GenTypePairTest(
    private val genTypePairService: GenTypePairService,
) {
    fun insertAndReturnId(): Long {
        return genTypePairService.insert(GenTypePairInsertInput (
            databaseType = null,
            jdbcTypeCode = 0,
            rawType = "",
            defaultDataSize = null,
            defaultNumericPrecision = null,
            language = null,
            propertyType = "",
            orderKey = 0,
            remark = "",
        ))
    }

    fun updateAndReturnId(updateId: Long): Long {
        return genTypePairService.update(GenTypePairUpdateInput (
            id = updateId,
            databaseType = null,
            jdbcTypeCode = 0,
            rawType = "",
            defaultDataSize = null,
            defaultNumericPrecision = null,
            language = null,
            propertyType = "",
            orderKey = 0,
            remark = "",
        ))
    }

    fun testInsert() {
    }

    fun testUpdate() {
    }

    fun testDelete() {
    }
}
