import top.potmot.service.model.GenModelService}
@SpringBootTest
@ActiveProfiles("test")
class GenModelTest(
    private val genModelService: GenModelService,
) {
    fun insertAndReturnId(): Int {
        return genModelService.insert(GenModelInsertInput (
            name = "",
            author = "",
            language = DevLanguage.Kotlin,
            databaseType = DatabaseType.PostgreSQL,
            databaseNamingStrategy = DatabaseNamingStrategyType.RAW,
            transition = "",
            createdTime = LocalDateTime(),
            modifiedTime = LocalDateTime(),
        ))
    }

    fun updateAndReturnId(updateId: Int): Int {
        return genModelService.update(GenModelUpdateInput (
            id = updateId,
            genModelConfigId = null,
            name = "",
            author = "",
            language = DevLanguage.Kotlin,
            databaseType = DatabaseType.PostgreSQL,
            databaseNamingStrategy = DatabaseNamingStrategyType.RAW,
            transition = "",
            createdTime = LocalDateTime(),
            modifiedTime = LocalDateTime(),
        ))
    }

    fun testInsert() {
    }

    fun testUpdate() {
    }

    fun testDelete() {
    }
}
