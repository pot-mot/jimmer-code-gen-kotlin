import top.potmot.service.model.GenModelService}
import top.potmot.service.model.GenModelGroupService}
import top.potmot.service.model.enums.GenEnumService}
import top.potmot.service.model.enums.GenEnumItemService}
@SpringBootTest
@ActiveProfiles("test")
class GenEnumItemTest(
    private val genModelService: GenModelService,
    private val genModelGroupService: GenModelGroupService,
    private val genEnumService: GenEnumService,
    private val genEnumItemService: GenEnumItemService,
) {
    fun insertAndReturnId(): Int {
        val genModelGroupModelId = genModelService.insert(GenModelInsertInput (
            name = "",
            author = "",
            language = DevLanguage.Kotlin,
            databaseType = DatabaseType.PostgreSQL,
            databaseNamingStrategy = DatabaseNamingStrategyType.RAW,
            createdTime = LocalDateTime(),
            modifiedTime = LocalDateTime(),
        ))

        val genEnumGroupId = genModelGroupService.insert(GenModelGroupInsertInput (
            modelId = genModelGroupModelId,
            name = "",
            comment = "",
            packagePath = "",
            tablePath = "",
            style = "",
            orderKey = 0,
        ))

        val genEnumItemEnumId = genEnumService.insert(GenEnumInsertInput (
            jdbcTypeCode = 0,
            rawType = "",
            typeIsNotNull = false,
            dataSize = null,
            numericPrecision = null,
            columnDefaultExp = null,
            groupId = genEnumGroupId,
            name = "",
            comment = "",
            enumType = EnumType.DEFAULT,
            subPackagePath = "",
            remark = "",
        ))

        return genEnumItemService.insert(GenEnumItemInsertInput (
            enumId = genEnumItemEnumId,
            name = "",
            mappedValue = "",
            comment = "",
            defaultItem = false,
            remark = "",
            orderKey = 0,
        ))
    }

    fun updateAndReturnId(updateId: Int): Int {
        val genModelGroupModelId = genModelService.insert(GenModelInsertInput (
            name = "",
            author = "",
            language = DevLanguage.Kotlin,
            databaseType = DatabaseType.PostgreSQL,
            databaseNamingStrategy = DatabaseNamingStrategyType.RAW,
            createdTime = LocalDateTime(),
            modifiedTime = LocalDateTime(),
        ))

        val genEnumGroupId = genModelGroupService.insert(GenModelGroupInsertInput (
            modelId = genModelGroupModelId,
            name = "",
            comment = "",
            packagePath = "",
            tablePath = "",
            style = "",
            orderKey = 0,
        ))

        val genEnumItemEnumId = genEnumService.insert(GenEnumInsertInput (
            jdbcTypeCode = 0,
            rawType = "",
            typeIsNotNull = false,
            dataSize = null,
            numericPrecision = null,
            columnDefaultExp = null,
            groupId = genEnumGroupId,
            name = "",
            comment = "",
            enumType = EnumType.DEFAULT,
            subPackagePath = "",
            remark = "",
        ))

        return genEnumItemService.update(GenEnumItemUpdateInput (
            id = updateId,
            enumId = genEnumItemEnumId,
            name = "",
            mappedValue = "",
            comment = "",
            defaultItem = false,
            remark = "",
            orderKey = 0,
        ))
    }

    fun testInsert() {
    }

    fun testUpdate() {
    }

    fun testDelete() {
    }
}
