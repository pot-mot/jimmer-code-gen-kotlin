import top.potmot.service.model.GenModelService}
import top.potmot.service.model.GenModelGroupService}
import top.potmot.service.model.enums.GenEnumService}
@SpringBootTest
@ActiveProfiles("test")
class GenEnumTest(
    private val genModelService: GenModelService,
    private val genModelGroupService: GenModelGroupService,
    private val genEnumService: GenEnumService,
) {
    fun insertAndReturnId(): Int {
        val genModelGroupModelId = genModelService.insert(GenModelInsertInput (
            name = "",
            author = "",
            language = DevLanguage.Kotlin,
            databaseType = DatabaseType.PostgreSQL,
            databaseNamingStrategy = DatabaseNamingStrategyType.RAW,
            createdTime = LocalDateTime(),
            modifiedTime = LocalDateTime(),
        ))

        val genEnumGroupId = genModelGroupService.insert(GenModelGroupInsertInput (
            modelId = genModelGroupModelId,
            name = "",
            comment = "",
            packagePath = "",
            tablePath = "",
            style = "",
            orderKey = 0,
        ))

        return genEnumService.insert(GenEnumInsertInput (
            jdbcTypeCode = 0,
            rawType = "",
            typeIsNotNull = false,
            dataSize = null,
            numericPrecision = null,
            columnDefaultExp = null,
            groupId = genEnumGroupId,
            name = "",
            comment = "",
            enumType = EnumType.DEFAULT,
            subPackagePath = "",
            remark = "",
        ))
    }

    fun updateAndReturnId(updateId: Int): Int {
        val genModelGroupModelId = genModelService.insert(GenModelInsertInput (
            name = "",
            author = "",
            language = DevLanguage.Kotlin,
            databaseType = DatabaseType.PostgreSQL,
            databaseNamingStrategy = DatabaseNamingStrategyType.RAW,
            createdTime = LocalDateTime(),
            modifiedTime = LocalDateTime(),
        ))

        val genEnumGroupId = genModelGroupService.insert(GenModelGroupInsertInput (
            modelId = genModelGroupModelId,
            name = "",
            comment = "",
            packagePath = "",
            tablePath = "",
            style = "",
            orderKey = 0,
        ))

        return genEnumService.update(GenEnumUpdateInput (
            id = updateId,
            jdbcTypeCode = 0,
            rawType = "",
            typeIsNotNull = false,
            dataSize = null,
            numericPrecision = null,
            columnDefaultExp = null,
            groupId = genEnumGroupId,
            name = "",
            comment = "",
            enumType = EnumType.DEFAULT,
            subPackagePath = "",
            remark = "",
        ))
    }

    fun testInsert() {
    }

    fun testUpdate() {
    }

    fun testDelete() {
    }
}
