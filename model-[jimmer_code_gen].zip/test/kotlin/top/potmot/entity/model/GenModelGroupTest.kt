import top.potmot.service.model.GenModelService}
import top.potmot.service.model.GenModelGroupService}
@SpringBootTest
@ActiveProfiles("test")
class GenModelGroupTest(
    private val genModelService: GenModelService,
    private val genModelGroupService: GenModelGroupService,
) {
    fun insertAndReturnId(): Int {
        val genModelGroupModelId = genModelService.insert(GenModelInsertInput (
            name = "",
            author = "",
            language = DevLanguage.Kotlin,
            databaseType = DatabaseType.PostgreSQL,
            databaseNamingStrategy = DatabaseNamingStrategyType.RAW,
            transition = "",
            createdTime = LocalDateTime(),
            modifiedTime = LocalDateTime(),
        ))

        return genModelGroupService.insert(GenModelGroupInsertInput (
            modelId = genModelGroupModelId,
            name = "",
            comment = "",
            packagePath = "",
            tablePath = "",
            color = "",
            orderKey = 0,
        ))
    }

    fun updateAndReturnId(updateId: Int): Int {
        val genModelGroupModelId = genModelService.insert(GenModelInsertInput (
            name = "",
            author = "",
            language = DevLanguage.Kotlin,
            databaseType = DatabaseType.PostgreSQL,
            databaseNamingStrategy = DatabaseNamingStrategyType.RAW,
            transition = "",
            createdTime = LocalDateTime(),
            modifiedTime = LocalDateTime(),
        ))

        return genModelGroupService.update(GenModelGroupUpdateInput (
            id = updateId,
            modelId = genModelGroupModelId,
            name = "",
            comment = "",
            packagePath = "",
            tablePath = "",
            color = "",
            orderKey = 0,
        ))
    }

    fun testInsert() {
    }

    fun testUpdate() {
    }

    fun testDelete() {
    }
}
