import top.potmot.service.model.GenModelService}
import top.potmot.service.model.GenModelGroupService}
import top.potmot.service.model.embeddables.GenEmbeddableService}
import top.potmot.service.model.embeddables.GenEmbeddableDeepPropertyService}
@SpringBootTest
@ActiveProfiles("test")
class GenEmbeddableDeepPropertyTest(
    private val genModelService: GenModelService,
    private val genModelGroupService: GenModelGroupService,
    private val genEmbeddableService: GenEmbeddableService,
    private val genEmbeddableDeepPropertyService: GenEmbeddableDeepPropertyService,
) {
    fun insertAndReturnId(): Int {
        val genModelGroupModelId = genModelService.insert(GenModelInsertInput (
            name = "",
            author = "",
            language = DevLanguage.Kotlin,
            databaseType = DatabaseType.PostgreSQL,
            databaseNamingStrategy = DatabaseNamingStrategyType.RAW,
            createdTime = LocalDateTime(),
            modifiedTime = LocalDateTime(),
        ))

        val genEmbeddableGroupId = genModelGroupService.insert(GenModelGroupInsertInput (
            modelId = genModelGroupModelId,
            name = "",
            comment = "",
            packagePath = "",
            tablePath = "",
            style = "",
            orderKey = 0,
        ))

        val genEmbeddableDeepPropertyEmbeddableId = genEmbeddableService.insert(GenEmbeddableInsertInput (
            groupId = genEmbeddableGroupId,
            name = "",
            subPackagePath = "",
            comment = "",
        ))

        val genEmbeddableDeepPropertyTypeEmbeddableId = genEmbeddableService.insert(GenEmbeddableInsertInput (
            groupId = genEmbeddableGroupId,
            name = "",
            subPackagePath = "",
            comment = "",
        ))

        return genEmbeddableDeepPropertyService.insert(GenEmbeddableDeepPropertyInsertInput (
            embeddableId = genEmbeddableDeepPropertyEmbeddableId,
            name = "",
            comment = "",
            typeEmbeddableId = genEmbeddableDeepPropertyTypeEmbeddableId,
            extraAnnotations = null,
            extraImports = null,
            extraValidations = null,
            remark = "",
        ))
    }

    fun updateAndReturnId(updateId: Int): Int {
        val genModelGroupModelId = genModelService.insert(GenModelInsertInput (
            name = "",
            author = "",
            language = DevLanguage.Kotlin,
            databaseType = DatabaseType.PostgreSQL,
            databaseNamingStrategy = DatabaseNamingStrategyType.RAW,
            createdTime = LocalDateTime(),
            modifiedTime = LocalDateTime(),
        ))

        val genEmbeddableGroupId = genModelGroupService.insert(GenModelGroupInsertInput (
            modelId = genModelGroupModelId,
            name = "",
            comment = "",
            packagePath = "",
            tablePath = "",
            style = "",
            orderKey = 0,
        ))

        val genEmbeddableDeepPropertyEmbeddableId = genEmbeddableService.insert(GenEmbeddableInsertInput (
            groupId = genEmbeddableGroupId,
            name = "",
            subPackagePath = "",
            comment = "",
        ))

        val genEmbeddableDeepPropertyTypeEmbeddableId = genEmbeddableService.insert(GenEmbeddableInsertInput (
            groupId = genEmbeddableGroupId,
            name = "",
            subPackagePath = "",
            comment = "",
        ))

        return genEmbeddableDeepPropertyService.update(GenEmbeddableDeepPropertyUpdateInput (
            id = updateId,
            embeddableId = genEmbeddableDeepPropertyEmbeddableId,
            name = "",
            comment = "",
            typeEmbeddableId = genEmbeddableDeepPropertyTypeEmbeddableId,
            extraAnnotations = null,
            extraImports = null,
            extraValidations = null,
            remark = "",
        ))
    }

    fun testInsert() {
    }

    fun testUpdate() {
    }

    fun testDelete() {
    }
}
