import top.potmot.service.model.GenModelService}
import top.potmot.service.model.GenModelGroupService}
import top.potmot.service.model.embeddables.GenEmbeddableService}
import top.potmot.service.model.embeddables.GenEmbeddablePropertyService}
@SpringBootTest
@ActiveProfiles("test")
class GenEmbeddablePropertyTest(
    private val genModelService: GenModelService,
    private val genModelGroupService: GenModelGroupService,
    private val genEmbeddableService: GenEmbeddableService,
    private val genEmbeddablePropertyService: GenEmbeddablePropertyService,
) {
    fun insertAndReturnId(): Int {
        val genModelGroupModelId = genModelService.insert(GenModelInsertInput (
            name = "",
            author = "",
            language = DevLanguage.Kotlin,
            databaseType = DatabaseType.PostgreSQL,
            databaseNamingStrategy = DatabaseNamingStrategyType.RAW,
            createdTime = LocalDateTime(),
            modifiedTime = LocalDateTime(),
        ))

        val genEmbeddableGroupId = genModelGroupService.insert(GenModelGroupInsertInput (
            modelId = genModelGroupModelId,
            name = "",
            comment = "",
            packagePath = "",
            tablePath = "",
            style = "",
            orderKey = 0,
        ))

        val genEmbeddablePropertyEmbeddableId = genEmbeddableService.insert(GenEmbeddableInsertInput (
            groupId = genEmbeddableGroupId,
            name = "",
            subPackagePath = "",
            comment = "",
        ))

        return genEmbeddablePropertyService.insert(GenEmbeddablePropertyInsertInput (
            jdbcTypeCode = 0,
            rawType = "",
            typeIsNotNull = false,
            dataSize = null,
            numericPrecision = null,
            columnDefaultExp = null,
            embeddableId = genEmbeddablePropertyEmbeddableId,
            name = "",
            comment = "",
            type = "",
            extraAnnotations = null,
            extraImports = null,
            extraValidations = null,
            remark = "",
        ))
    }

    fun updateAndReturnId(updateId: Int): Int {
        val genModelGroupModelId = genModelService.insert(GenModelInsertInput (
            name = "",
            author = "",
            language = DevLanguage.Kotlin,
            databaseType = DatabaseType.PostgreSQL,
            databaseNamingStrategy = DatabaseNamingStrategyType.RAW,
            createdTime = LocalDateTime(),
            modifiedTime = LocalDateTime(),
        ))

        val genEmbeddableGroupId = genModelGroupService.insert(GenModelGroupInsertInput (
            modelId = genModelGroupModelId,
            name = "",
            comment = "",
            packagePath = "",
            tablePath = "",
            style = "",
            orderKey = 0,
        ))

        val genEmbeddablePropertyEmbeddableId = genEmbeddableService.insert(GenEmbeddableInsertInput (
            groupId = genEmbeddableGroupId,
            name = "",
            subPackagePath = "",
            comment = "",
        ))

        return genEmbeddablePropertyService.update(GenEmbeddablePropertyUpdateInput (
            id = updateId,
            jdbcTypeCode = 0,
            rawType = "",
            typeIsNotNull = false,
            dataSize = null,
            numericPrecision = null,
            columnDefaultExp = null,
            embeddableId = genEmbeddablePropertyEmbeddableId,
            name = "",
            comment = "",
            type = "",
            extraAnnotations = null,
            extraImports = null,
            extraValidations = null,
            remark = "",
        ))
    }

    fun testInsert() {
    }

    fun testUpdate() {
    }

    fun testDelete() {
    }
}
