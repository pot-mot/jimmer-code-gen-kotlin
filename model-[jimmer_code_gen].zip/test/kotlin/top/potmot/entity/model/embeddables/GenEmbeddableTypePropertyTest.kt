import top.potmot.service.model.GenModelService}
import top.potmot.service.model.GenModelGroupService}
import top.potmot.service.model.embeddables.GenEmbeddableTypeService}
import top.potmot.service.model.embeddables.GenEmbeddableTypePropertyService}
@SpringBootTest
@ActiveProfiles("test")
class GenEmbeddableTypePropertyTest(
    private val genModelService: GenModelService,
    private val genModelGroupService: GenModelGroupService,
    private val genEmbeddableTypeService: GenEmbeddableTypeService,
    private val genEmbeddableTypePropertyService: GenEmbeddableTypePropertyService,
) {
    fun insertAndReturnId(): Int {
        val genModelGroupModelId = genModelService.insert(GenModelInsertInput (
            name = "",
            author = "",
            language = DevLanguage.Kotlin,
            databaseType = DatabaseType.PostgreSQL,
            databaseNamingStrategy = DatabaseNamingStrategyType.RAW,
            transition = "",
            createdTime = LocalDateTime(),
            modifiedTime = LocalDateTime(),
        ))

        val genEmbeddableTypeGroupId = genModelGroupService.insert(GenModelGroupInsertInput (
            modelId = genModelGroupModelId,
            name = "",
            comment = "",
            packagePath = "",
            tablePath = "",
            color = "",
            orderKey = 0,
        ))

        val genEmbeddableTypePropertyEmbeddableId = genEmbeddableTypeService.insert(GenEmbeddableTypeInsertInput (
            groupId = genEmbeddableTypeGroupId,
            name = "",
            subPackagePath = "",
            comment = "",
        ))

        return genEmbeddableTypePropertyService.insert(GenEmbeddableTypePropertyInsertInput (
            rawType = null,
            typeEnumId = null,
            typeEmbeddableId = null,
            columnInfoId = null,
            embeddableId = genEmbeddableTypePropertyEmbeddableId,
            name = "",
            comment = "",
            extraAnnotations = null,
            extraImports = null,
            extraValidations = null,
            remark = "",
            orderKey = 0,
        ))
    }

    fun updateAndReturnId(updateId: Int): Int {
        val genModelGroupModelId = genModelService.insert(GenModelInsertInput (
            name = "",
            author = "",
            language = DevLanguage.Kotlin,
            databaseType = DatabaseType.PostgreSQL,
            databaseNamingStrategy = DatabaseNamingStrategyType.RAW,
            transition = "",
            createdTime = LocalDateTime(),
            modifiedTime = LocalDateTime(),
        ))

        val genEmbeddableTypeGroupId = genModelGroupService.insert(GenModelGroupInsertInput (
            modelId = genModelGroupModelId,
            name = "",
            comment = "",
            packagePath = "",
            tablePath = "",
            color = "",
            orderKey = 0,
        ))

        val genEmbeddableTypePropertyEmbeddableId = genEmbeddableTypeService.insert(GenEmbeddableTypeInsertInput (
            groupId = genEmbeddableTypeGroupId,
            name = "",
            subPackagePath = "",
            comment = "",
        ))

        return genEmbeddableTypePropertyService.update(GenEmbeddableTypePropertyUpdateInput (
            id = updateId,
            rawType = null,
            typeEnumId = null,
            typeEmbeddableId = null,
            columnInfoId = null,
            embeddableId = genEmbeddableTypePropertyEmbeddableId,
            name = "",
            comment = "",
            extraAnnotations = null,
            extraImports = null,
            extraValidations = null,
            remark = "",
            orderKey = 0,
        ))
    }

    fun testInsert() {
    }

    fun testUpdate() {
    }

    fun testDelete() {
    }
}
