import top.potmot.service.model.GenModelService}
import top.potmot.service.model.GenModelGroupService}
import top.potmot.service.model.embeddables.GenEmbeddableTypeService}
import top.potmot.service.model.embeddables.GenEmbeddableTypeDeepPropertyService}
import top.potmot.service.model.embeddables.GenEmbeddableTypePropertyService}
import top.potmot.service.model.embeddables.GenDeepEmbeddablePropertyOverrideService}
@SpringBootTest
@ActiveProfiles("test")
class GenDeepEmbeddablePropertyOverrideTest(
    private val genModelService: GenModelService,
    private val genModelGroupService: GenModelGroupService,
    private val genEmbeddableTypeService: GenEmbeddableTypeService,
    private val genEmbeddableTypeDeepPropertyService: GenEmbeddableTypeDeepPropertyService,
    private val genEmbeddableTypePropertyService: GenEmbeddableTypePropertyService,
    private val genDeepEmbeddablePropertyOverrideService: GenDeepEmbeddablePropertyOverrideService,
) {
    fun insertAndReturnId(): Int {
        val genModelGroupModelId = genModelService.insert(GenModelInsertInput (
            name = "",
            author = "",
            language = DevLanguage.Kotlin,
            databaseType = DatabaseType.PostgreSQL,
            databaseNamingStrategy = DatabaseNamingStrategyType.RAW,
            createdTime = LocalDateTime(),
            modifiedTime = LocalDateTime(),
        ))

        val genEmbeddableTypeGroupId = genModelGroupService.insert(GenModelGroupInsertInput (
            modelId = genModelGroupModelId,
            name = "",
            comment = "",
            packagePath = "",
            tablePath = "",
            style = "",
            orderKey = 0,
        ))

        val genEmbeddableTypeDeepPropertyEmbeddableId = genEmbeddableTypeService.insert(GenEmbeddableTypeInsertInput (
            groupId = genEmbeddableTypeGroupId,
            name = "",
            subPackagePath = "",
            comment = "",
        ))

        val genEmbeddableTypeDeepPropertyTypeEmbeddableId = genEmbeddableTypeService.insert(GenEmbeddableTypeInsertInput (
            groupId = genEmbeddableTypeGroupId,
            name = "",
            subPackagePath = "",
            comment = "",
        ))

        val genDeepEmbeddablePropertyOverrideDeepPropertyId = genEmbeddableTypeDeepPropertyService.insert(GenEmbeddableTypeDeepPropertyInsertInput (
            embeddableId = genEmbeddableTypeDeepPropertyEmbeddableId,
            name = "",
            comment = "",
            typeEmbeddableId = genEmbeddableTypeDeepPropertyTypeEmbeddableId,
            extraAnnotations = null,
            extraImports = null,
            extraValidations = null,
            remark = "",
            orderKey = 0,
        ))

        val genEmbeddableTypePropertyEmbeddableId = genEmbeddableTypeService.insert(GenEmbeddableTypeInsertInput (
            groupId = genEmbeddableTypeGroupId,
            name = "",
            subPackagePath = "",
            comment = "",
        ))

        val genDeepEmbeddablePropertyOverrideOverridePropertyId = genEmbeddableTypePropertyService.insert(GenEmbeddableTypePropertyInsertInput (
            jdbcTypeCode = 0,
            rawType = "",
            typeIsNotNull = false,
            dataSize = null,
            numericPrecision = null,
            columnDefaultExp = null,
            typeEnumId = null,
            embeddableId = genEmbeddableTypePropertyEmbeddableId,
            name = "",
            comment = "",
            type = null,
            columnName = "",
            extraAnnotations = null,
            extraImports = null,
            extraValidations = null,
            remark = "",
            orderKey = 0,
        ))

        return genDeepEmbeddablePropertyOverrideService.insert(GenDeepEmbeddablePropertyOverrideInsertInput (
            deepPropertyId = genDeepEmbeddablePropertyOverrideDeepPropertyId,
            overridePropertyId = genDeepEmbeddablePropertyOverrideOverridePropertyId,
            columnName = "",
        ))
    }

    fun updateAndReturnId(updateId: Int): Int {
        val genModelGroupModelId = genModelService.insert(GenModelInsertInput (
            name = "",
            author = "",
            language = DevLanguage.Kotlin,
            databaseType = DatabaseType.PostgreSQL,
            databaseNamingStrategy = DatabaseNamingStrategyType.RAW,
            createdTime = LocalDateTime(),
            modifiedTime = LocalDateTime(),
        ))

        val genEmbeddableTypeGroupId = genModelGroupService.insert(GenModelGroupInsertInput (
            modelId = genModelGroupModelId,
            name = "",
            comment = "",
            packagePath = "",
            tablePath = "",
            style = "",
            orderKey = 0,
        ))

        val genEmbeddableTypeDeepPropertyEmbeddableId = genEmbeddableTypeService.insert(GenEmbeddableTypeInsertInput (
            groupId = genEmbeddableTypeGroupId,
            name = "",
            subPackagePath = "",
            comment = "",
        ))

        val genEmbeddableTypeDeepPropertyTypeEmbeddableId = genEmbeddableTypeService.insert(GenEmbeddableTypeInsertInput (
            groupId = genEmbeddableTypeGroupId,
            name = "",
            subPackagePath = "",
            comment = "",
        ))

        val genDeepEmbeddablePropertyOverrideDeepPropertyId = genEmbeddableTypeDeepPropertyService.insert(GenEmbeddableTypeDeepPropertyInsertInput (
            embeddableId = genEmbeddableTypeDeepPropertyEmbeddableId,
            name = "",
            comment = "",
            typeEmbeddableId = genEmbeddableTypeDeepPropertyTypeEmbeddableId,
            extraAnnotations = null,
            extraImports = null,
            extraValidations = null,
            remark = "",
            orderKey = 0,
        ))

        val genEmbeddableTypePropertyEmbeddableId = genEmbeddableTypeService.insert(GenEmbeddableTypeInsertInput (
            groupId = genEmbeddableTypeGroupId,
            name = "",
            subPackagePath = "",
            comment = "",
        ))

        val genDeepEmbeddablePropertyOverrideOverridePropertyId = genEmbeddableTypePropertyService.insert(GenEmbeddableTypePropertyInsertInput (
            jdbcTypeCode = 0,
            rawType = "",
            typeIsNotNull = false,
            dataSize = null,
            numericPrecision = null,
            columnDefaultExp = null,
            typeEnumId = null,
            embeddableId = genEmbeddableTypePropertyEmbeddableId,
            name = "",
            comment = "",
            type = null,
            columnName = "",
            extraAnnotations = null,
            extraImports = null,
            extraValidations = null,
            remark = "",
            orderKey = 0,
        ))

        return genDeepEmbeddablePropertyOverrideService.update(GenDeepEmbeddablePropertyOverrideUpdateInput (
            id = updateId,
            deepPropertyId = genDeepEmbeddablePropertyOverrideDeepPropertyId,
            overridePropertyId = genDeepEmbeddablePropertyOverrideOverridePropertyId,
            columnName = "",
        ))
    }

    fun testInsert() {
    }

    fun testUpdate() {
    }

    fun testDelete() {
    }
}
