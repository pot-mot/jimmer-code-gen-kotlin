import top.potmot.service.model.GenModelService}
import top.potmot.service.model.GenModelGroupService}
import top.potmot.service.model.embeddables.GenEmbeddableTypeService}
import top.potmot.service.model.embeddables.GenEmbeddableTypeDeepPropertyService}
@SpringBootTest
@ActiveProfiles("test")
class GenEmbeddableTypeDeepPropertyTest(
    private val genModelService: GenModelService,
    private val genModelGroupService: GenModelGroupService,
    private val genEmbeddableTypeService: GenEmbeddableTypeService,
    private val genEmbeddableTypeDeepPropertyService: GenEmbeddableTypeDeepPropertyService,
) {
    fun insertAndReturnId(): Int {
        val genModelGroupModelId = genModelService.insert(GenModelInsertInput (
            name = "",
            author = "",
            language = DevLanguage.Kotlin,
            databaseType = DatabaseType.PostgreSQL,
            databaseNamingStrategy = DatabaseNamingStrategyType.RAW,
            createdTime = LocalDateTime(),
            modifiedTime = LocalDateTime(),
        ))

        val genEmbeddableTypeGroupId = genModelGroupService.insert(GenModelGroupInsertInput (
            modelId = genModelGroupModelId,
            name = "",
            comment = "",
            packagePath = "",
            tablePath = "",
            style = "",
            orderKey = 0,
        ))

        val genEmbeddableTypeDeepPropertyEmbeddableId = genEmbeddableTypeService.insert(GenEmbeddableTypeInsertInput (
            groupId = genEmbeddableTypeGroupId,
            name = "",
            subPackagePath = "",
            comment = "",
        ))

        val genEmbeddableTypeDeepPropertyTypeEmbeddableId = genEmbeddableTypeService.insert(GenEmbeddableTypeInsertInput (
            groupId = genEmbeddableTypeGroupId,
            name = "",
            subPackagePath = "",
            comment = "",
        ))

        return genEmbeddableTypeDeepPropertyService.insert(GenEmbeddableTypeDeepPropertyInsertInput (
            embeddableId = genEmbeddableTypeDeepPropertyEmbeddableId,
            name = "",
            comment = "",
            typeEmbeddableId = genEmbeddableTypeDeepPropertyTypeEmbeddableId,
            extraAnnotations = null,
            extraImports = null,
            extraValidations = null,
            remark = "",
            orderKey = 0,
        ))
    }

    fun updateAndReturnId(updateId: Int): Int {
        val genModelGroupModelId = genModelService.insert(GenModelInsertInput (
            name = "",
            author = "",
            language = DevLanguage.Kotlin,
            databaseType = DatabaseType.PostgreSQL,
            databaseNamingStrategy = DatabaseNamingStrategyType.RAW,
            createdTime = LocalDateTime(),
            modifiedTime = LocalDateTime(),
        ))

        val genEmbeddableTypeGroupId = genModelGroupService.insert(GenModelGroupInsertInput (
            modelId = genModelGroupModelId,
            name = "",
            comment = "",
            packagePath = "",
            tablePath = "",
            style = "",
            orderKey = 0,
        ))

        val genEmbeddableTypeDeepPropertyEmbeddableId = genEmbeddableTypeService.insert(GenEmbeddableTypeInsertInput (
            groupId = genEmbeddableTypeGroupId,
            name = "",
            subPackagePath = "",
            comment = "",
        ))

        val genEmbeddableTypeDeepPropertyTypeEmbeddableId = genEmbeddableTypeService.insert(GenEmbeddableTypeInsertInput (
            groupId = genEmbeddableTypeGroupId,
            name = "",
            subPackagePath = "",
            comment = "",
        ))

        return genEmbeddableTypeDeepPropertyService.update(GenEmbeddableTypeDeepPropertyUpdateInput (
            id = updateId,
            embeddableId = genEmbeddableTypeDeepPropertyEmbeddableId,
            name = "",
            comment = "",
            typeEmbeddableId = genEmbeddableTypeDeepPropertyTypeEmbeddableId,
            extraAnnotations = null,
            extraImports = null,
            extraValidations = null,
            remark = "",
            orderKey = 0,
        ))
    }

    fun testInsert() {
    }

    fun testUpdate() {
    }

    fun testDelete() {
    }
}
