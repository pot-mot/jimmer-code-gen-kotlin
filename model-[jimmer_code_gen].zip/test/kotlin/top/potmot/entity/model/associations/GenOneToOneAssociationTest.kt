import top.potmot.service.model.GenModelService}
import top.potmot.service.model.GenModelGroupService}
import top.potmot.service.model.entities.GenEntityService}
import top.potmot.service.model.entities.properties.GenPropertyService}
import top.potmot.service.model.entities.properties.GenOneToOneSourcePropertyService}
import top.potmot.service.model.entities.properties.GenOneToOneMappedPropertyService}
import top.potmot.service.model.associations.GenOneToOneAssociationService}
@SpringBootTest
@ActiveProfiles("test")
class GenOneToOneAssociationTest(
    private val genModelService: GenModelService,
    private val genModelGroupService: GenModelGroupService,
    private val genEntityService: GenEntityService,
    private val genPropertyService: GenPropertyService,
    private val genOneToOneSourcePropertyService: GenOneToOneSourcePropertyService,
    private val genOneToOneMappedPropertyService: GenOneToOneMappedPropertyService,
    private val genOneToOneAssociationService: GenOneToOneAssociationService,
) {
    fun insertAndReturnId(): Int {
        val genModelGroupModelId = genModelService.insert(GenModelInsertInput (
            name = "",
            author = "",
            language = DevLanguage.Kotlin,
            databaseType = DatabaseType.PostgreSQL,
            databaseNamingStrategy = DatabaseNamingStrategyType.RAW,
            transition = "",
            createdTime = LocalDateTime(),
            modifiedTime = LocalDateTime(),
        ))

        val genEntityGroupId = genModelGroupService.insert(GenModelGroupInsertInput (
            modelId = genModelGroupModelId,
            name = "",
            comment = "",
            packagePath = "",
            tablePath = "",
            color = "",
            orderKey = 0,
        ))

        val genOneToOneSourcePropertyTypeEntityId = genEntityService.insert(GenEntityInsertInput (
            groupId = genEntityGroupId,
            interfaceName = "",
            mappedSuper = false,
            tableName = "",
            pluralName = "",
            author = "",
            comment = "",
            subPackagePath = "",
            otherAnnotations = "",
            otherImports = "",
            remark = "",
            idPropertyId = null,
            logicalDeletePropertyId = null,
            versionPropertyId = null,
            x = 0,
            y = 0,
        ))

        val genPropertyEntityId = genEntityService.insert(GenEntityInsertInput (
            groupId = genEntityGroupId,
            interfaceName = "",
            mappedSuper = false,
            tableName = "",
            pluralName = "",
            author = "",
            comment = "",
            subPackagePath = "",
            otherAnnotations = "",
            otherImports = "",
            remark = "",
            idPropertyId = null,
            logicalDeletePropertyId = null,
            versionPropertyId = null,
            x = 0,
            y = 0,
        ))

        val genOneToOneSourcePropertyPropertyId = genPropertyService.insert(GenPropertyInsertInput (
            rawType = null,
            typeEnumId = null,
            typeEmbeddableId = null,
            columnInfoId = null,
            genIdPropertyId = null,
            genLogicalDeletePropertyId = null,
            genManyToManyMappedPropertyId = null,
            genManyToManySourcePropertyId = null,
            genManyToOneMappedPropertyId = null,
            genManyToOneSourcePropertyId = null,
            genOneToOneMappedPropertyId = null,
            genOneToOneSourcePropertyId = null,
            genSortPropertyId = null,
            genVersionPropertyId = null,
            entityId = genPropertyEntityId,
            name = "",
            comment = "",
            extraAnnotations = null,
            extraImports = null,
            extraValidations = null,
            remark = "",
            orderKey = 0,
        ))

        val genOneToOneAssociationSourcePropertyId = genOneToOneSourcePropertyService.insert(GenOneToOneSourcePropertyInsertInput (
            typeEntityId = genOneToOneSourcePropertyTypeEntityId,
            genOneToOneMappedPropertyId = null,
            propertyId = genOneToOneSourcePropertyPropertyId,
            idViewName = "",
            typeIsNotNull = false,
        ))

        val genOneToOneMappedPropertyPropertyId = genPropertyService.insert(GenPropertyInsertInput (
            rawType = null,
            typeEnumId = null,
            typeEmbeddableId = null,
            columnInfoId = null,
            genIdPropertyId = null,
            genLogicalDeletePropertyId = null,
            genManyToManyMappedPropertyId = null,
            genManyToManySourcePropertyId = null,
            genManyToOneMappedPropertyId = null,
            genManyToOneSourcePropertyId = null,
            genOneToOneMappedPropertyId = null,
            genOneToOneSourcePropertyId = null,
            genSortPropertyId = null,
            genVersionPropertyId = null,
            entityId = genPropertyEntityId,
            name = "",
            comment = "",
            extraAnnotations = null,
            extraImports = null,
            extraValidations = null,
            remark = "",
            orderKey = 0,
        ))

        val genOneToOneMappedPropertyMappedById = genOneToOneSourcePropertyService.insert(GenOneToOneSourcePropertyInsertInput (
            typeEntityId = genOneToOneSourcePropertyTypeEntityId,
            genOneToOneAssociationId = null,
            propertyId = genOneToOneSourcePropertyPropertyId,
            idViewName = "",
            typeIsNotNull = false,
        ))

        val genOneToOneAssociationMappedPropertyId = genOneToOneMappedPropertyService.insert(GenOneToOneMappedPropertyInsertInput (
            typeEntityId = genOneToOneMappedPropertyTypeEntityId,
            propertyId = genOneToOneMappedPropertyPropertyId,
            mappedById = genOneToOneMappedPropertyMappedById,
            idViewName = "",
        ))

        return genOneToOneAssociationService.insert(GenOneToOneAssociationInsertInput (
            sourcePropertyId = genOneToOneAssociationSourcePropertyId,
            mappedPropertyId = genOneToOneAssociationMappedPropertyId,
            joinTableId = null,
        ))
    }

    fun updateAndReturnId(updateId: Int): Int {
        val genModelGroupModelId = genModelService.insert(GenModelInsertInput (
            name = "",
            author = "",
            language = DevLanguage.Kotlin,
            databaseType = DatabaseType.PostgreSQL,
            databaseNamingStrategy = DatabaseNamingStrategyType.RAW,
            transition = "",
            createdTime = LocalDateTime(),
            modifiedTime = LocalDateTime(),
        ))

        val genEntityGroupId = genModelGroupService.insert(GenModelGroupInsertInput (
            modelId = genModelGroupModelId,
            name = "",
            comment = "",
            packagePath = "",
            tablePath = "",
            color = "",
            orderKey = 0,
        ))

        val genOneToOneSourcePropertyTypeEntityId = genEntityService.insert(GenEntityInsertInput (
            groupId = genEntityGroupId,
            interfaceName = "",
            mappedSuper = false,
            tableName = "",
            pluralName = "",
            author = "",
            comment = "",
            subPackagePath = "",
            otherAnnotations = "",
            otherImports = "",
            remark = "",
            idPropertyId = null,
            logicalDeletePropertyId = null,
            versionPropertyId = null,
            x = 0,
            y = 0,
        ))

        val genPropertyEntityId = genEntityService.insert(GenEntityInsertInput (
            groupId = genEntityGroupId,
            interfaceName = "",
            mappedSuper = false,
            tableName = "",
            pluralName = "",
            author = "",
            comment = "",
            subPackagePath = "",
            otherAnnotations = "",
            otherImports = "",
            remark = "",
            idPropertyId = null,
            logicalDeletePropertyId = null,
            versionPropertyId = null,
            x = 0,
            y = 0,
        ))

        val genOneToOneSourcePropertyPropertyId = genPropertyService.insert(GenPropertyInsertInput (
            rawType = null,
            typeEnumId = null,
            typeEmbeddableId = null,
            columnInfoId = null,
            genIdPropertyId = null,
            genLogicalDeletePropertyId = null,
            genManyToManyMappedPropertyId = null,
            genManyToManySourcePropertyId = null,
            genManyToOneMappedPropertyId = null,
            genManyToOneSourcePropertyId = null,
            genOneToOneMappedPropertyId = null,
            genOneToOneSourcePropertyId = null,
            genSortPropertyId = null,
            genVersionPropertyId = null,
            entityId = genPropertyEntityId,
            name = "",
            comment = "",
            extraAnnotations = null,
            extraImports = null,
            extraValidations = null,
            remark = "",
            orderKey = 0,
        ))

        val genOneToOneAssociationSourcePropertyId = genOneToOneSourcePropertyService.insert(GenOneToOneSourcePropertyInsertInput (
            typeEntityId = genOneToOneSourcePropertyTypeEntityId,
            genOneToOneMappedPropertyId = null,
            propertyId = genOneToOneSourcePropertyPropertyId,
            idViewName = "",
            typeIsNotNull = false,
        ))

        val genOneToOneMappedPropertyPropertyId = genPropertyService.insert(GenPropertyInsertInput (
            rawType = null,
            typeEnumId = null,
            typeEmbeddableId = null,
            columnInfoId = null,
            genIdPropertyId = null,
            genLogicalDeletePropertyId = null,
            genManyToManyMappedPropertyId = null,
            genManyToManySourcePropertyId = null,
            genManyToOneMappedPropertyId = null,
            genManyToOneSourcePropertyId = null,
            genOneToOneMappedPropertyId = null,
            genOneToOneSourcePropertyId = null,
            genSortPropertyId = null,
            genVersionPropertyId = null,
            entityId = genPropertyEntityId,
            name = "",
            comment = "",
            extraAnnotations = null,
            extraImports = null,
            extraValidations = null,
            remark = "",
            orderKey = 0,
        ))

        val genOneToOneMappedPropertyMappedById = genOneToOneSourcePropertyService.insert(GenOneToOneSourcePropertyInsertInput (
            typeEntityId = genOneToOneSourcePropertyTypeEntityId,
            genOneToOneAssociationId = null,
            propertyId = genOneToOneSourcePropertyPropertyId,
            idViewName = "",
            typeIsNotNull = false,
        ))

        val genOneToOneAssociationMappedPropertyId = genOneToOneMappedPropertyService.insert(GenOneToOneMappedPropertyInsertInput (
            typeEntityId = genOneToOneMappedPropertyTypeEntityId,
            propertyId = genOneToOneMappedPropertyPropertyId,
            mappedById = genOneToOneMappedPropertyMappedById,
            idViewName = "",
        ))

        return genOneToOneAssociationService.update(GenOneToOneAssociationUpdateInput (
            id = updateId,
            sourcePropertyId = genOneToOneAssociationSourcePropertyId,
            mappedPropertyId = genOneToOneAssociationMappedPropertyId,
            joinTableId = null,
        ))
    }

    fun testInsert() {
    }

    fun testUpdate() {
    }

    fun testDelete() {
    }
}
