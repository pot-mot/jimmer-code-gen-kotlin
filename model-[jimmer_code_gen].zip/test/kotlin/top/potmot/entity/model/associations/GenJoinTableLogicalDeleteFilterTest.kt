import top.potmot.service.model.associations.GenJoinTableLogicalDeleteFilterService}
@SpringBootTest
@ActiveProfiles("test")
class GenJoinTableLogicalDeleteFilterTest(
    private val genJoinTableLogicalDeleteFilterService: GenJoinTableLogicalDeleteFilterService,
) {
    fun insertAndReturnId(): Int {
        return genJoinTableLogicalDeleteFilterService.insert(GenJoinTableLogicalDeleteFilterInsertInput (
            columnName = "",
            type = "",
            values = "",
            logicalDeletedAnnotation = "",
            nullable = false,
        ))
    }

    fun updateAndReturnId(updateId: Int): Int {
        return genJoinTableLogicalDeleteFilterService.update(GenJoinTableLogicalDeleteFilterUpdateInput (
            id = updateId,
            columnName = "",
            type = "",
            values = "",
            logicalDeletedAnnotation = "",
            nullable = false,
        ))
    }

    fun testInsert() {
    }

    fun testUpdate() {
    }

    fun testDelete() {
    }
}
