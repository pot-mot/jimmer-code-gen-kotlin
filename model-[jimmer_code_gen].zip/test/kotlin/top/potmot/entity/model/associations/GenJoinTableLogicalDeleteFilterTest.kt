import top.potmot.service.model.associations.GenJoinTableService}
import top.potmot.service.model.associations.GenJoinTableLogicalDeleteFilterService}
@SpringBootTest
@ActiveProfiles("test")
class GenJoinTableLogicalDeleteFilterTest(
    private val genJoinTableService: GenJoinTableService,
    private val genJoinTableLogicalDeleteFilterService: GenJoinTableLogicalDeleteFilterService,
) {
    fun insertAndReturnId(): Int {
        val genJoinTableLogicalDeleteFilterJoinTableId = genJoinTableService.insert(GenJoinTableInsertInput (
            name = "",
            comment = "",
            readonly = false,
            preventDeletionBySource = false,
            preventDeletionByTarget = false,
            deletedWhenEndpointIsLogicallyDeleted = false,
        ))

        return genJoinTableLogicalDeleteFilterService.insert(GenJoinTableLogicalDeleteFilterInsertInput (
            joinTableId = genJoinTableLogicalDeleteFilterJoinTableId,
            columnName = "",
            type = "",
            values = "",
            logicalDeletedAnnotation = "",
            nullable = false,
        ))
    }

    fun updateAndReturnId(updateId: Int): Int {
        val genJoinTableLogicalDeleteFilterJoinTableId = genJoinTableService.insert(GenJoinTableInsertInput (
            name = "",
            comment = "",
            readonly = false,
            preventDeletionBySource = false,
            preventDeletionByTarget = false,
            deletedWhenEndpointIsLogicallyDeleted = false,
        ))

        return genJoinTableLogicalDeleteFilterService.update(GenJoinTableLogicalDeleteFilterUpdateInput (
            id = updateId,
            joinTableId = genJoinTableLogicalDeleteFilterJoinTableId,
            columnName = "",
            type = "",
            values = "",
            logicalDeletedAnnotation = "",
            nullable = false,
        ))
    }

    fun testInsert() {
    }

    fun testUpdate() {
    }

    fun testDelete() {
    }
}
