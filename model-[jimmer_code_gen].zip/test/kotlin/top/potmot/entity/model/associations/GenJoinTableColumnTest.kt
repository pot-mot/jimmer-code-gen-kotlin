import top.potmot.service.model.associations.GenJoinTableService}
import top.potmot.service.model.associations.GenJoinTableColumnService}
@SpringBootTest
@ActiveProfiles("test")
class GenJoinTableColumnTest(
    private val genJoinTableService: GenJoinTableService,
    private val genJoinTableColumnService: GenJoinTableColumnService,
) {
    fun insertAndReturnId(): Int {
        val genJoinTableColumnJoinTableId = genJoinTableService.insert(GenJoinTableInsertInput (
            name = "",
            comment = "",
            readonly = false,
            preventDeletionBySource = false,
            preventDeletionByTarget = false,
            deletedWhenEndpointIsLogicallyDeleted = false,
        ))

        return genJoinTableColumnService.insert(GenJoinTableColumnInsertInput (
            jdbcTypeCode = 0,
            rawType = "",
            typeIsNotNull = false,
            dataSize = null,
            numericPrecision = null,
            columnDefaultExp = null,
            joinTableId = genJoinTableColumnJoinTableId,
            columnName = "",
            referenceColumnName = "",
            comment = "",
            fake = false,
        ))
    }

    fun updateAndReturnId(updateId: Int): Int {
        val genJoinTableColumnJoinTableId = genJoinTableService.insert(GenJoinTableInsertInput (
            name = "",
            comment = "",
            readonly = false,
            preventDeletionBySource = false,
            preventDeletionByTarget = false,
            deletedWhenEndpointIsLogicallyDeleted = false,
        ))

        return genJoinTableColumnService.update(GenJoinTableColumnUpdateInput (
            id = updateId,
            jdbcTypeCode = 0,
            rawType = "",
            typeIsNotNull = false,
            dataSize = null,
            numericPrecision = null,
            columnDefaultExp = null,
            joinTableId = genJoinTableColumnJoinTableId,
            columnName = "",
            referenceColumnName = "",
            comment = "",
            fake = false,
        ))
    }

    fun testInsert() {
    }

    fun testUpdate() {
    }

    fun testDelete() {
    }
}
