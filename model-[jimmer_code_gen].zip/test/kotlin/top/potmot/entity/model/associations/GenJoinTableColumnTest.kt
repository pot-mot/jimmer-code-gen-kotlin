import top.potmot.service.model.associations.GenJoinTableService}
import top.potmot.service.model.associations.GenJoinTableColumnService}
@SpringBootTest
@ActiveProfiles("test")
class GenJoinTableColumnTest(
    private val genJoinTableService: GenJoinTableService,
    private val genJoinTableColumnService: GenJoinTableColumnService,
) {
    fun insertAndReturnId(): Int {
        val genJoinTableColumnJoinTableId = genJoinTableService.insert(GenJoinTableInsertInput (
            name = "",
            comment = "",
            readonly = false,
            preventDeletionBySource = false,
            preventDeletionByTarget = false,
            deletedWhenEndpointIsLogicallyDeleted = false,
            logicalDeleteFilterId = null,
        ))

        return genJoinTableColumnService.insert(GenJoinTableColumnInsertInput (
            joinTableId = genJoinTableColumnJoinTableId,
            columnName = "",
            referenceColumnName = "",
            comment = "",
            fake = false,
        ))
    }

    fun updateAndReturnId(updateId: Int): Int {
        val genJoinTableColumnJoinTableId = genJoinTableService.insert(GenJoinTableInsertInput (
            name = "",
            comment = "",
            readonly = false,
            preventDeletionBySource = false,
            preventDeletionByTarget = false,
            deletedWhenEndpointIsLogicallyDeleted = false,
            logicalDeleteFilterId = null,
        ))

        return genJoinTableColumnService.update(GenJoinTableColumnUpdateInput (
            id = updateId,
            joinTableId = genJoinTableColumnJoinTableId,
            columnName = "",
            referenceColumnName = "",
            comment = "",
            fake = false,
        ))
    }

    fun testInsert() {
    }

    fun testUpdate() {
    }

    fun testDelete() {
    }
}
