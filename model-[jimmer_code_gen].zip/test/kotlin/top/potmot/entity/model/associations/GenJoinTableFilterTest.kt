import top.potmot.service.model.associations.GenJoinTableService}
import top.potmot.service.model.associations.GenJoinTableFilterService}
@SpringBootTest
@ActiveProfiles("test")
class GenJoinTableFilterTest(
    private val genJoinTableService: GenJoinTableService,
    private val genJoinTableFilterService: GenJoinTableFilterService,
) {
    fun insertAndReturnId(): Int {
        val genJoinTableFilterJoinTableId = genJoinTableService.insert(GenJoinTableInsertInput (
            name = "",
            comment = "",
            readonly = false,
            preventDeletionBySource = false,
            preventDeletionByTarget = false,
            deletedWhenEndpointIsLogicallyDeleted = false,
            logicalDeleteFilterId = null,
        ))

        return genJoinTableFilterService.insert(GenJoinTableFilterInsertInput (
            joinTableId = genJoinTableFilterJoinTableId,
            columnName = "",
            type = "",
            values = "",
        ))
    }

    fun updateAndReturnId(updateId: Int): Int {
        val genJoinTableFilterJoinTableId = genJoinTableService.insert(GenJoinTableInsertInput (
            name = "",
            comment = "",
            readonly = false,
            preventDeletionBySource = false,
            preventDeletionByTarget = false,
            deletedWhenEndpointIsLogicallyDeleted = false,
            logicalDeleteFilterId = null,
        ))

        return genJoinTableFilterService.update(GenJoinTableFilterUpdateInput (
            id = updateId,
            joinTableId = genJoinTableFilterJoinTableId,
            columnName = "",
            type = "",
            values = "",
        ))
    }

    fun testInsert() {
    }

    fun testUpdate() {
    }

    fun testDelete() {
    }
}
