import top.potmot.service.model.associations.GenJoinTableService}
@SpringBootTest
@ActiveProfiles("test")
class GenJoinTableTest(
    private val genJoinTableService: GenJoinTableService,
) {
    fun insertAndReturnId(): Int {
        return genJoinTableService.insert(GenJoinTableInsertInput (
            name = "",
            comment = "",
            readonly = false,
            preventDeletionBySource = false,
            preventDeletionByTarget = false,
            deletedWhenEndpointIsLogicallyDeleted = false,
            logicalDeleteFilterId = null,
        ))
    }

    fun updateAndReturnId(updateId: Int): Int {
        return genJoinTableService.update(GenJoinTableUpdateInput (
            id = updateId,
            name = "",
            comment = "",
            readonly = false,
            preventDeletionBySource = false,
            preventDeletionByTarget = false,
            deletedWhenEndpointIsLogicallyDeleted = false,
            logicalDeleteFilterId = null,
        ))
    }

    fun testInsert() {
    }

    fun testUpdate() {
    }

    fun testDelete() {
    }
}
