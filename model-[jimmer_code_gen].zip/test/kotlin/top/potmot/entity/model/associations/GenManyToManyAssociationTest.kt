import top.potmot.service.model.GenModelService}
import top.potmot.service.model.GenModelGroupService}
import top.potmot.service.model.entities.GenEntityService}
import top.potmot.service.model.entities.properties.GenPropertyService}
import top.potmot.service.model.entities.properties.GenManyToManySourcePropertyService}
import top.potmot.service.model.entities.properties.GenManyToManyMappedPropertyService}
import top.potmot.service.model.associations.GenJoinTableService}
import top.potmot.service.model.associations.GenManyToManyAssociationService}
@SpringBootTest
@ActiveProfiles("test")
class GenManyToManyAssociationTest(
    private val genModelService: GenModelService,
    private val genModelGroupService: GenModelGroupService,
    private val genEntityService: GenEntityService,
    private val genPropertyService: GenPropertyService,
    private val genManyToManySourcePropertyService: GenManyToManySourcePropertyService,
    private val genManyToManyMappedPropertyService: GenManyToManyMappedPropertyService,
    private val genJoinTableService: GenJoinTableService,
    private val genManyToManyAssociationService: GenManyToManyAssociationService,
) {
    fun insertAndReturnId(): Int {
        val genModelGroupModelId = genModelService.insert(GenModelInsertInput (
            name = "",
            author = "",
            language = DevLanguage.Kotlin,
            databaseType = DatabaseType.PostgreSQL,
            databaseNamingStrategy = DatabaseNamingStrategyType.RAW,
            transition = "",
            createdTime = LocalDateTime(),
            modifiedTime = LocalDateTime(),
        ))

        val genEntityGroupId = genModelGroupService.insert(GenModelGroupInsertInput (
            modelId = genModelGroupModelId,
            name = "",
            comment = "",
            packagePath = "",
            tablePath = "",
            color = "",
            orderKey = 0,
        ))

        val genManyToManySourcePropertyTypeEntityId = genEntityService.insert(GenEntityInsertInput (
            groupId = genEntityGroupId,
            interfaceName = "",
            mappedSuper = false,
            tableName = "",
            pluralName = "",
            author = "",
            comment = "",
            subPackagePath = "",
            otherAnnotations = "",
            otherImports = "",
            remark = "",
            idPropertyId = null,
            logicalDeletePropertyId = null,
            versionPropertyId = null,
            x = 0,
            y = 0,
        ))

        val genPropertyEntityId = genEntityService.insert(GenEntityInsertInput (
            groupId = genEntityGroupId,
            interfaceName = "",
            mappedSuper = false,
            tableName = "",
            pluralName = "",
            author = "",
            comment = "",
            subPackagePath = "",
            otherAnnotations = "",
            otherImports = "",
            remark = "",
            idPropertyId = null,
            logicalDeletePropertyId = null,
            versionPropertyId = null,
            x = 0,
            y = 0,
        ))

        val genManyToManySourcePropertyPropertyId = genPropertyService.insert(GenPropertyInsertInput (
            rawType = null,
            typeEnumId = null,
            typeEmbeddableId = null,
            columnInfoId = null,
            genIdPropertyId = null,
            genLogicalDeletePropertyId = null,
            genManyToManyMappedPropertyId = null,
            genManyToManySourcePropertyId = null,
            genManyToOneMappedPropertyId = null,
            genManyToOneSourcePropertyId = null,
            genOneToOneMappedPropertyId = null,
            genOneToOneSourcePropertyId = null,
            genSortPropertyId = null,
            genVersionPropertyId = null,
            entityId = genPropertyEntityId,
            name = "",
            comment = "",
            extraAnnotations = null,
            extraImports = null,
            extraValidations = null,
            remark = "",
            orderKey = 0,
        ))

        val genManyToManyAssociationSourcePropertyId = genManyToManySourcePropertyService.insert(GenManyToManySourcePropertyInsertInput (
            typeEntityId = genManyToManySourcePropertyTypeEntityId,
            genManyToManyMappedPropertyId = null,
            propertyId = genManyToManySourcePropertyPropertyId,
            idViewName = "",
        ))

        val genManyToManyMappedPropertyPropertyId = genPropertyService.insert(GenPropertyInsertInput (
            rawType = null,
            typeEnumId = null,
            typeEmbeddableId = null,
            columnInfoId = null,
            genIdPropertyId = null,
            genLogicalDeletePropertyId = null,
            genManyToManyMappedPropertyId = null,
            genManyToManySourcePropertyId = null,
            genManyToOneMappedPropertyId = null,
            genManyToOneSourcePropertyId = null,
            genOneToOneMappedPropertyId = null,
            genOneToOneSourcePropertyId = null,
            genSortPropertyId = null,
            genVersionPropertyId = null,
            entityId = genPropertyEntityId,
            name = "",
            comment = "",
            extraAnnotations = null,
            extraImports = null,
            extraValidations = null,
            remark = "",
            orderKey = 0,
        ))

        val genManyToManyMappedPropertyMappedById = genManyToManySourcePropertyService.insert(GenManyToManySourcePropertyInsertInput (
            typeEntityId = genManyToManySourcePropertyTypeEntityId,
            propertyId = genManyToManySourcePropertyPropertyId,
            idViewName = "",
        ))

        val genManyToManyAssociationMappedPropertyId = genManyToManyMappedPropertyService.insert(GenManyToManyMappedPropertyInsertInput (
            typeEntityId = genManyToManyMappedPropertyTypeEntityId,
            propertyId = genManyToManyMappedPropertyPropertyId,
            mappedById = genManyToManyMappedPropertyMappedById,
            idViewName = "",
        ))

        val genManyToManyAssociationJoinTableId = genJoinTableService.insert(GenJoinTableInsertInput (
            name = "",
            comment = "",
            readonly = false,
            preventDeletionBySource = false,
            preventDeletionByTarget = false,
            deletedWhenEndpointIsLogicallyDeleted = false,
            logicalDeleteFilterId = null,
        ))

        return genManyToManyAssociationService.insert(GenManyToManyAssociationInsertInput (
            sourcePropertyId = genManyToManyAssociationSourcePropertyId,
            mappedPropertyId = genManyToManyAssociationMappedPropertyId,
            joinTableId = genManyToManyAssociationJoinTableId,
        ))
    }

    fun updateAndReturnId(updateId: Int): Int {
        val genModelGroupModelId = genModelService.insert(GenModelInsertInput (
            name = "",
            author = "",
            language = DevLanguage.Kotlin,
            databaseType = DatabaseType.PostgreSQL,
            databaseNamingStrategy = DatabaseNamingStrategyType.RAW,
            transition = "",
            createdTime = LocalDateTime(),
            modifiedTime = LocalDateTime(),
        ))

        val genEntityGroupId = genModelGroupService.insert(GenModelGroupInsertInput (
            modelId = genModelGroupModelId,
            name = "",
            comment = "",
            packagePath = "",
            tablePath = "",
            color = "",
            orderKey = 0,
        ))

        val genManyToManySourcePropertyTypeEntityId = genEntityService.insert(GenEntityInsertInput (
            groupId = genEntityGroupId,
            interfaceName = "",
            mappedSuper = false,
            tableName = "",
            pluralName = "",
            author = "",
            comment = "",
            subPackagePath = "",
            otherAnnotations = "",
            otherImports = "",
            remark = "",
            idPropertyId = null,
            logicalDeletePropertyId = null,
            versionPropertyId = null,
            x = 0,
            y = 0,
        ))

        val genPropertyEntityId = genEntityService.insert(GenEntityInsertInput (
            groupId = genEntityGroupId,
            interfaceName = "",
            mappedSuper = false,
            tableName = "",
            pluralName = "",
            author = "",
            comment = "",
            subPackagePath = "",
            otherAnnotations = "",
            otherImports = "",
            remark = "",
            idPropertyId = null,
            logicalDeletePropertyId = null,
            versionPropertyId = null,
            x = 0,
            y = 0,
        ))

        val genManyToManySourcePropertyPropertyId = genPropertyService.insert(GenPropertyInsertInput (
            rawType = null,
            typeEnumId = null,
            typeEmbeddableId = null,
            columnInfoId = null,
            genIdPropertyId = null,
            genLogicalDeletePropertyId = null,
            genManyToManyMappedPropertyId = null,
            genManyToManySourcePropertyId = null,
            genManyToOneMappedPropertyId = null,
            genManyToOneSourcePropertyId = null,
            genOneToOneMappedPropertyId = null,
            genOneToOneSourcePropertyId = null,
            genSortPropertyId = null,
            genVersionPropertyId = null,
            entityId = genPropertyEntityId,
            name = "",
            comment = "",
            extraAnnotations = null,
            extraImports = null,
            extraValidations = null,
            remark = "",
            orderKey = 0,
        ))

        val genManyToManyAssociationSourcePropertyId = genManyToManySourcePropertyService.insert(GenManyToManySourcePropertyInsertInput (
            typeEntityId = genManyToManySourcePropertyTypeEntityId,
            genManyToManyMappedPropertyId = null,
            propertyId = genManyToManySourcePropertyPropertyId,
            idViewName = "",
        ))

        val genManyToManyMappedPropertyPropertyId = genPropertyService.insert(GenPropertyInsertInput (
            rawType = null,
            typeEnumId = null,
            typeEmbeddableId = null,
            columnInfoId = null,
            genIdPropertyId = null,
            genLogicalDeletePropertyId = null,
            genManyToManyMappedPropertyId = null,
            genManyToManySourcePropertyId = null,
            genManyToOneMappedPropertyId = null,
            genManyToOneSourcePropertyId = null,
            genOneToOneMappedPropertyId = null,
            genOneToOneSourcePropertyId = null,
            genSortPropertyId = null,
            genVersionPropertyId = null,
            entityId = genPropertyEntityId,
            name = "",
            comment = "",
            extraAnnotations = null,
            extraImports = null,
            extraValidations = null,
            remark = "",
            orderKey = 0,
        ))

        val genManyToManyMappedPropertyMappedById = genManyToManySourcePropertyService.insert(GenManyToManySourcePropertyInsertInput (
            typeEntityId = genManyToManySourcePropertyTypeEntityId,
            propertyId = genManyToManySourcePropertyPropertyId,
            idViewName = "",
        ))

        val genManyToManyAssociationMappedPropertyId = genManyToManyMappedPropertyService.insert(GenManyToManyMappedPropertyInsertInput (
            typeEntityId = genManyToManyMappedPropertyTypeEntityId,
            propertyId = genManyToManyMappedPropertyPropertyId,
            mappedById = genManyToManyMappedPropertyMappedById,
            idViewName = "",
        ))

        val genManyToManyAssociationJoinTableId = genJoinTableService.insert(GenJoinTableInsertInput (
            name = "",
            comment = "",
            readonly = false,
            preventDeletionBySource = false,
            preventDeletionByTarget = false,
            deletedWhenEndpointIsLogicallyDeleted = false,
            logicalDeleteFilterId = null,
        ))

        return genManyToManyAssociationService.update(GenManyToManyAssociationUpdateInput (
            id = updateId,
            sourcePropertyId = genManyToManyAssociationSourcePropertyId,
            mappedPropertyId = genManyToManyAssociationMappedPropertyId,
            joinTableId = genManyToManyAssociationJoinTableId,
        ))
    }

    fun testInsert() {
    }

    fun testUpdate() {
    }

    fun testDelete() {
    }
}
