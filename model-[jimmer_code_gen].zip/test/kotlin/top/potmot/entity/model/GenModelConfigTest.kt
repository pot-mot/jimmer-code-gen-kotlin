import top.potmot.service.model.GenModelService}
import top.potmot.service.model.GenModelConfigService}
@SpringBootTest
@ActiveProfiles("test")
class GenModelConfigTest(
    private val genModelService: GenModelService,
    private val genModelConfigService: GenModelConfigService,
) {
    fun insertAndReturnId(): Int {
        val genModelConfigModelId = genModelService.insert(GenModelInsertInput (
            name = "",
            author = "",
            language = DevLanguage.Kotlin,
            databaseType = DatabaseType.PostgreSQL,
            databaseNamingStrategy = DatabaseNamingStrategyType.RAW,
            createdTime = LocalDateTime(),
            modifiedTime = LocalDateTime(),
        ))

        return genModelConfigService.insert(GenModelConfigInsertInput (
            modelId = genModelConfigModelId,
            basePackagePath = "",
            baseTablePath = "",
            defaultDissociateAction = "",
            defaultUseRealFk = false,
            defaultIdType = 0,
            defaultGeneratedIdAnnotation = "",
            defaultLogicalDeletedAnnotation = "",
            erateTableAnnotation = false,
            erateColumnAnnotation = false,
            tableToEntityRemovedNamePrefixes = "",
            tableToEntityRemovedNameSuffixes = "",
            tableToEntityRemovedCommentPrefixes = "",
            tableToEntityRemovedCommentSuffixes = "",
            columnToPropertyRemovedNamePrefixes = "",
            columnToPropertyRemovedNameSuffixes = "",
            columnToPropertyRemovedCommentPrefixes = "",
            columnToPropertyRemovedCommentSuffixes = "",
            remark = "",
        ))
    }

    fun updateAndReturnId(updateId: Int): Int {
        val genModelConfigModelId = genModelService.insert(GenModelInsertInput (
            name = "",
            author = "",
            language = DevLanguage.Kotlin,
            databaseType = DatabaseType.PostgreSQL,
            databaseNamingStrategy = DatabaseNamingStrategyType.RAW,
            createdTime = LocalDateTime(),
            modifiedTime = LocalDateTime(),
        ))

        return genModelConfigService.update(GenModelConfigUpdateInput (
            id = updateId,
            modelId = genModelConfigModelId,
            basePackagePath = "",
            baseTablePath = "",
            defaultDissociateAction = "",
            defaultUseRealFk = false,
            defaultIdType = 0,
            defaultGeneratedIdAnnotation = "",
            defaultLogicalDeletedAnnotation = "",
            erateTableAnnotation = false,
            erateColumnAnnotation = false,
            tableToEntityRemovedNamePrefixes = "",
            tableToEntityRemovedNameSuffixes = "",
            tableToEntityRemovedCommentPrefixes = "",
            tableToEntityRemovedCommentSuffixes = "",
            columnToPropertyRemovedNamePrefixes = "",
            columnToPropertyRemovedNameSuffixes = "",
            columnToPropertyRemovedCommentPrefixes = "",
            columnToPropertyRemovedCommentSuffixes = "",
            remark = "",
        ))
    }

    fun testInsert() {
    }

    fun testUpdate() {
    }

    fun testDelete() {
    }
}
