import top.potmot.service.model.GenColumnInfoService}
@SpringBootTest
@ActiveProfiles("test")
class GenColumnInfoTest(
    private val genColumnInfoService: GenColumnInfoService,
) {
    fun insertAndReturnId(): Int {
        return genColumnInfoService.insert(GenColumnInfoInsertInput (
            columnName = "",
            jdbcTypeCode = 0,
            rawType = "",
            typeIsNotNull = false,
            dataSize = null,
            numericPrecision = null,
            columnDefaultExp = null,
        ))
    }

    fun updateAndReturnId(updateId: Int): Int {
        return genColumnInfoService.update(GenColumnInfoUpdateInput (
            id = updateId,
            columnName = "",
            jdbcTypeCode = 0,
            rawType = "",
            typeIsNotNull = false,
            dataSize = null,
            numericPrecision = null,
            columnDefaultExp = null,
        ))
    }

    fun testInsert() {
    }

    fun testUpdate() {
    }

    fun testDelete() {
    }
}
