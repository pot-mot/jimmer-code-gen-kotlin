DROP TABLE IF EXISTS `db_table_column` CASCADE;

CREATE TABLE `db_table_column` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `table_id` INTEGER NOT NULL,
    `name` CHARACTER VARYING(500) NOT NULL,
    `order_key` INTEGER NOT NULL,
    `jdbc_type_code` INTEGER NOT NULL,
    `raw_type` CHARACTER VARYING(500) NOT NULL,
    `type_is_not_null` BOOLEAN NOT NULL,
    `data_size` BIGINT DEFAULT NULL,
    `numeric_precision` BIGINT DEFAULT NULL,
    `default_value` CHARACTER VARYING(500) DEFAULT NULL,
    `comment` CHARACTER VARYING(500) NOT NULL,
    `remark` CHARACTER VARYING(500) NOT NULL,
    PRIMARY KEY (`id`)
);

CREATE UNIQUE INDEX `key_of_db_table_column` ON `db_table_column` (`table_id`, `name`);

COMMENT ON TABLE `db_table_column` IS '列';
COMMENT ON COLUMN `db_table_column`.`id` IS 'ID';
COMMENT ON COLUMN `db_table_column`.`table_id` IS '归属表';
COMMENT ON COLUMN `db_table_column`.`name` IS '名称';
COMMENT ON COLUMN `db_table_column`.`order_key` IS '排序键';
COMMENT ON COLUMN `db_table_column`.`jdbc_type_code` IS 'JdbcType 码值';
COMMENT ON COLUMN `db_table_column`.`raw_type` IS '字面类型';
COMMENT ON COLUMN `db_table_column`.`type_is_not_null` IS '类型是否非空';
COMMENT ON COLUMN `db_table_column`.`data_size` IS '长度';
COMMENT ON COLUMN `db_table_column`.`numeric_precision` IS '精度';
COMMENT ON COLUMN `db_table_column`.`default_value` IS '列默认值';
COMMENT ON COLUMN `db_table_column`.`comment` IS '注释';
COMMENT ON COLUMN `db_table_column`.`remark` IS '备注';

DROP TABLE IF EXISTS `db_table_column_db_primary_key_mapping` CASCADE;

CREATE TABLE `db_table_column_db_primary_key_mapping` (
    `db_table_column_id` INTEGER NOT NULL,
    `db_primary_key_id` INTEGER NOT NULL
);

ALTER TABLE `db_table_column_db_primary_key_mapping` ADD CONSTRAINT `pk_db_table_column_db_primary_key_mapping` PRIMARY KEY (`db_table_column_id`,`db_primary_key_id`);

ALTER TABLE `db_table_column_db_primary_key_mapping`
    ADD CONSTRAINT `db_table_column_db_primary_key_mapping_S`
        FOREIGN KEY (`db_table_column_id`)
            REFERENCES `db_table_column` (`id`);

ALTER TABLE `db_table_column_db_primary_key_mapping`
    ADD CONSTRAINT `db_table_column_db_primary_key_mapping_T`
        FOREIGN KEY (`db_primary_key_id`)
            REFERENCES `db_primary_key` (`id`);

COMMENT ON TABLE `db_table_column_db_primary_key_mapping` IS '列与主键的映射关系表';

ALTER TABLE `db_table_column`
    ADD CONSTRAINT `fk_db_table_column_table_id`
        FOREIGN KEY (`table_id`)
            REFERENCES `db_table` (`id`)
                ON UPDATE restrict
                ON DELETE restrict;

DROP TABLE IF EXISTS `db_table_index_db_table_column_mapping` CASCADE;

CREATE TABLE `db_table_index_db_table_column_mapping` (
    `db_table_index_id` INTEGER NOT NULL,
    `db_table_column_id` INTEGER NOT NULL
);

ALTER TABLE `db_table_index_db_table_column_mapping` ADD CONSTRAINT `pk_db_table_index_db_table_column_mapping` PRIMARY KEY (`db_table_index_id`,`db_table_column_id`);

ALTER TABLE `db_table_index_db_table_column_mapping`
    ADD CONSTRAINT `db_table_index_db_table_column_mapping_S`
        FOREIGN KEY (`db_table_index_id`)
            REFERENCES `db_table_index` (`id`);

ALTER TABLE `db_table_index_db_table_column_mapping`
    ADD CONSTRAINT `db_table_index_db_table_column_mapping_T`
        FOREIGN KEY (`db_table_column_id`)
            REFERENCES `db_table_column` (`id`);

COMMENT ON TABLE `db_table_index_db_table_column_mapping` IS '表索引与列的映射关系表';

ALTER TABLE `db_foreign_key_column_reference`
    ADD CONSTRAINT `fk_db_foreign_key_column_reference_source_column_id`
        FOREIGN KEY (`source_column_id`)
            REFERENCES `db_table_column` (`id`)
                ON UPDATE restrict
                ON DELETE restrict;

ALTER TABLE `db_foreign_key_column_reference`
    ADD CONSTRAINT `fk_db_foreign_key_column_reference_target_column_id`
        FOREIGN KEY (`target_column_id`)
            REFERENCES `db_table_column` (`id`)
                ON UPDATE restrict
                ON DELETE restrict;

