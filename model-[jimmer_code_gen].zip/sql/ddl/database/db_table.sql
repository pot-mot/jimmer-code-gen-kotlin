DROP TABLE IF EXISTS `db_table` CASCADE;

CREATE TABLE `db_table` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `schema_id` INTEGER NOT NULL,
    `name` CHARACTER VARYING(500) NOT NULL,
    `comment` CHARACTER VARYING(500) NOT NULL,
    `type` CHARACTER VARYING(500) NOT NULL,
    `remark` CHARACTER VARYING(500) NOT NULL,
    PRIMARY KEY (`id`)
);

CREATE UNIQUE INDEX `key_of_db_table` ON `db_table` (`schema_id`, `name`);

COMMENT ON TABLE `db_table` IS '表';
COMMENT ON COLUMN `db_table`.`id` IS 'ID';
COMMENT ON COLUMN `db_table`.`schema_id` IS '数据架构';
COMMENT ON COLUMN `db_table`.`name` IS '名称';
COMMENT ON COLUMN `db_table`.`comment` IS '注释';
COMMENT ON COLUMN `db_table`.`type` IS '类型';
COMMENT ON COLUMN `db_table`.`remark` IS '备注';

ALTER TABLE `db_table`
    ADD CONSTRAINT `fk_db_table_schema_id`
        FOREIGN KEY (`schema_id`)
            REFERENCES `db_schema` (`id`)
                ON UPDATE restrict
                ON DELETE restrict;

ALTER TABLE `db_foreign_key`
    ADD CONSTRAINT `fk_db_foreign_key_source_table_id`
        FOREIGN KEY (`source_table_id`)
            REFERENCES `db_table` (`id`)
                ON UPDATE restrict
                ON DELETE restrict;

ALTER TABLE `db_foreign_key`
    ADD CONSTRAINT `fk_db_foreign_key_target_table_id`
        FOREIGN KEY (`target_table_id`)
            REFERENCES `db_table` (`id`)
                ON UPDATE restrict
                ON DELETE restrict;

ALTER TABLE `db_primary_key`
    ADD CONSTRAINT `fk_db_primary_key_table_id`
        FOREIGN KEY (`table_id`)
            REFERENCES `db_table` (`id`);

ALTER TABLE `db_table_column`
    ADD CONSTRAINT `fk_db_table_column_table_id`
        FOREIGN KEY (`table_id`)
            REFERENCES `db_table` (`id`)
                ON UPDATE restrict
                ON DELETE restrict;

ALTER TABLE `db_table_index`
    ADD CONSTRAINT `fk_db_table_index_table_id`
        FOREIGN KEY (`table_id`)
            REFERENCES `db_table` (`id`)
                ON UPDATE restrict
                ON DELETE restrict;

