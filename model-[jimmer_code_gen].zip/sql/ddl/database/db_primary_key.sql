DROP TABLE IF EXISTS `db_primary_key` CASCADE;

CREATE TABLE `db_primary_key` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `table_id` INTEGER NOT NULL,
    `name` CHARACTER VARYING(500) NOT NULL,
    `serial_name` VARCHAR(255) DEFAULT NULL,
    `auto_increment` BOOLEAN NOT NULL,
    `remark` CHARACTER VARYING(500) NOT NULL,
    PRIMARY KEY (`id`)
);

CREATE UNIQUE INDEX `key_of_db_primary_key` ON `db_primary_key` (`table_id`);

COMMENT ON TABLE `db_primary_key` IS '主键';
COMMENT ON COLUMN `db_primary_key`.`id` IS 'ID';
COMMENT ON COLUMN `db_primary_key`.`table_id` IS '表';
COMMENT ON COLUMN `db_primary_key`.`name` IS '名称';
COMMENT ON COLUMN `db_primary_key`.`serial_name` IS '对应序列';
COMMENT ON COLUMN `db_primary_key`.`auto_increment` IS '是否自增';
COMMENT ON COLUMN `db_primary_key`.`remark` IS '备注';

ALTER TABLE `db_primary_key`
    ADD CONSTRAINT `fk_db_primary_key_table_id`
        FOREIGN KEY (`table_id`)
            REFERENCES `db_table` (`id`);

DROP TABLE IF EXISTS `db_table_column_db_primary_key_mapping` CASCADE;

CREATE TABLE `db_table_column_db_primary_key_mapping` (
    `db_table_column_id` INTEGER NOT NULL,
    `db_primary_key_id` INTEGER NOT NULL
);

ALTER TABLE `db_table_column_db_primary_key_mapping` ADD CONSTRAINT `pk_db_table_column_db_primary_key_mapping` PRIMARY KEY (`db_table_column_id`,`db_primary_key_id`);

ALTER TABLE `db_table_column_db_primary_key_mapping`
    ADD CONSTRAINT `db_table_column_db_primary_key_mapping_S`
        FOREIGN KEY (`db_table_column_id`)
            REFERENCES `db_table_column` (`id`);

ALTER TABLE `db_table_column_db_primary_key_mapping`
    ADD CONSTRAINT `db_table_column_db_primary_key_mapping_T`
        FOREIGN KEY (`db_primary_key_id`)
            REFERENCES `db_primary_key` (`id`);

COMMENT ON TABLE `db_table_column_db_primary_key_mapping` IS '列与主键的映射关系表';

