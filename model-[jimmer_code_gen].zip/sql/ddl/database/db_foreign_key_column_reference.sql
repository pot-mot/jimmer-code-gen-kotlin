DROP TABLE IF EXISTS `db_foreign_key_column_reference` CASCADE;

CREATE TABLE `db_foreign_key_column_reference` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `association_id` INTEGER NOT NULL,
    `source_column_id` INTEGER NOT NULL,
    `target_column_id` INTEGER NOT NULL,
    `remark` CHARACTER VARYING(500) NOT NULL,
    PRIMARY KEY (`id`)
);

CREATE UNIQUE INDEX `key_of_db_foreign_key_column_reference` ON `db_foreign_key_column_reference` (`association_id`, `source_column_id`, `target_column_id`);

COMMENT ON TABLE `db_foreign_key_column_reference` IS '外键列引用';
COMMENT ON COLUMN `db_foreign_key_column_reference`.`id` IS 'ID';
COMMENT ON COLUMN `db_foreign_key_column_reference`.`association_id` IS '关联';
COMMENT ON COLUMN `db_foreign_key_column_reference`.`source_column_id` IS '主列';
COMMENT ON COLUMN `db_foreign_key_column_reference`.`target_column_id` IS '从列';
COMMENT ON COLUMN `db_foreign_key_column_reference`.`remark` IS '备注';

ALTER TABLE `db_foreign_key_column_reference`
    ADD CONSTRAINT `fk_db_foreign_key_column_reference_association_id`
        FOREIGN KEY (`association_id`)
            REFERENCES `db_foreign_key` (`id`)
                ON UPDATE restrict
                ON DELETE restrict;

ALTER TABLE `db_foreign_key_column_reference`
    ADD CONSTRAINT `fk_db_foreign_key_column_reference_source_column_id`
        FOREIGN KEY (`source_column_id`)
            REFERENCES `db_table_column` (`id`)
                ON UPDATE restrict
                ON DELETE restrict;

ALTER TABLE `db_foreign_key_column_reference`
    ADD CONSTRAINT `fk_db_foreign_key_column_reference_target_column_id`
        FOREIGN KEY (`target_column_id`)
            REFERENCES `db_table_column` (`id`)
                ON UPDATE restrict
                ON DELETE restrict;

