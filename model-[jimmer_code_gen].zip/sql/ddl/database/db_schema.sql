DROP TABLE IF EXISTS `db_schema` CASCADE;

CREATE TABLE `db_schema` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `data_source_id` INTEGER NOT NULL,
    `name` CHARACTER VARYING(500) NOT NULL,
    `remark` CHARACTER VARYING(500) NOT NULL,
    PRIMARY KEY (`id`)
);

CREATE UNIQUE INDEX `key_of_db_schema` ON `db_schema` (`data_source_id`, `name`);

COMMENT ON TABLE `db_schema` IS '数据架构';
COMMENT ON COLUMN `db_schema`.`id` IS 'ID';
COMMENT ON COLUMN `db_schema`.`data_source_id` IS '数据源';
COMMENT ON COLUMN `db_schema`.`name` IS '名称';
COMMENT ON COLUMN `db_schema`.`remark` IS '备注';

ALTER TABLE `db_schema`
    ADD CONSTRAINT `fk_db_schema_data_source_id`
        FOREIGN KEY (`data_source_id`)
            REFERENCES `db_data_source` (`id`)
                ON UPDATE restrict
                ON DELETE restrict;

ALTER TABLE `db_table`
    ADD CONSTRAINT `fk_db_table_schema_id`
        FOREIGN KEY (`schema_id`)
            REFERENCES `db_schema` (`id`)
                ON UPDATE restrict
                ON DELETE restrict;

