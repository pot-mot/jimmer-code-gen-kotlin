DROP TABLE IF EXISTS `db_foreign_key` CASCADE;

CREATE TABLE `db_foreign_key` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `name` CHARACTER VARYING(500) NOT NULL,
    `source_table_id` INTEGER NOT NULL,
    `target_table_id` INTEGER NOT NULL,
    `type` CHARACTER VARYING(500) NOT NULL,
    `update_action` CHARACTER VARYING(500) NOT NULL,
    `delete_action` CHARACTER VARYING(500) NOT NULL,
    `remark` CHARACTER VARYING(500) NOT NULL,
    PRIMARY KEY (`id`)
);

COMMENT ON TABLE `db_foreign_key` IS '外键';
COMMENT ON COLUMN `db_foreign_key`.`id` IS 'ID';
COMMENT ON COLUMN `db_foreign_key`.`name` IS '关联名称';
COMMENT ON COLUMN `db_foreign_key`.`source_table_id` IS '主表';
COMMENT ON COLUMN `db_foreign_key`.`target_table_id` IS '从表';
COMMENT ON COLUMN `db_foreign_key`.`type` IS '关联类型';
COMMENT ON COLUMN `db_foreign_key`.`update_action` IS '更新行为';
COMMENT ON COLUMN `db_foreign_key`.`delete_action` IS '删除行为';
COMMENT ON COLUMN `db_foreign_key`.`remark` IS '备注';

ALTER TABLE `db_foreign_key`
    ADD CONSTRAINT `fk_db_foreign_key_source_table_id`
        FOREIGN KEY (`source_table_id`)
            REFERENCES `db_table` (`id`)
                ON UPDATE restrict
                ON DELETE restrict;

ALTER TABLE `db_foreign_key`
    ADD CONSTRAINT `fk_db_foreign_key_target_table_id`
        FOREIGN KEY (`target_table_id`)
            REFERENCES `db_table` (`id`)
                ON UPDATE restrict
                ON DELETE restrict;

ALTER TABLE `db_foreign_key_column_reference`
    ADD CONSTRAINT `fk_db_foreign_key_column_reference_association_id`
        FOREIGN KEY (`association_id`)
            REFERENCES `db_foreign_key` (`id`)
                ON UPDATE restrict
                ON DELETE restrict;

