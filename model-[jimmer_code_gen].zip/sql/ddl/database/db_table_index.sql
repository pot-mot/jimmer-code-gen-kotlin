DROP TABLE IF EXISTS `db_table_index` CASCADE;

CREATE TABLE `db_table_index` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `table_id` INTEGER NOT NULL,
    `name` CHARACTER VARYING(500) NOT NULL,
    `unique_index` BOOLEAN NOT NULL,
    `remark` CHARACTER VARYING(500) NOT NULL,
    PRIMARY KEY (`id`)
);

CREATE UNIQUE INDEX `key_of_db_table_index` ON `db_table_index` (`table_id`, `name`);

COMMENT ON TABLE `db_table_index` IS '表索引';
COMMENT ON COLUMN `db_table_index`.`id` IS 'ID';
COMMENT ON COLUMN `db_table_index`.`table_id` IS '归属表';
COMMENT ON COLUMN `db_table_index`.`name` IS '名称';
COMMENT ON COLUMN `db_table_index`.`unique_index` IS '是否是唯一索引';
COMMENT ON COLUMN `db_table_index`.`remark` IS '备注';

DROP TABLE IF EXISTS `db_table_index_db_table_column_mapping` CASCADE;

CREATE TABLE `db_table_index_db_table_column_mapping` (
    `db_table_index_id` INTEGER NOT NULL,
    `db_table_column_id` INTEGER NOT NULL
);

ALTER TABLE `db_table_index_db_table_column_mapping` ADD CONSTRAINT `pk_db_table_index_db_table_column_mapping` PRIMARY KEY (`db_table_index_id`,`db_table_column_id`);

ALTER TABLE `db_table_index_db_table_column_mapping`
    ADD CONSTRAINT `db_table_index_db_table_column_mapping_S`
        FOREIGN KEY (`db_table_index_id`)
            REFERENCES `db_table_index` (`id`);

ALTER TABLE `db_table_index_db_table_column_mapping`
    ADD CONSTRAINT `db_table_index_db_table_column_mapping_T`
        FOREIGN KEY (`db_table_column_id`)
            REFERENCES `db_table_column` (`id`);

COMMENT ON TABLE `db_table_index_db_table_column_mapping` IS '表索引与列的映射关系表';

ALTER TABLE `db_table_index`
    ADD CONSTRAINT `fk_db_table_index_table_id`
        FOREIGN KEY (`table_id`)
            REFERENCES `db_table` (`id`)
                ON UPDATE restrict
                ON DELETE restrict;

