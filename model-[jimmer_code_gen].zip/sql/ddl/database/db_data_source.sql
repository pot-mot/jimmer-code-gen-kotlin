DROP TABLE IF EXISTS `db_data_source` CASCADE;

CREATE TABLE `db_data_source` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `type` CHARACTER VARYING(500) NOT NULL,
    `name` CHARACTER VARYING(500) NOT NULL,
    `url` CHARACTER VARYING(500) NOT NULL,
    `username` CHARACTER VARYING(500) NOT NULL,
    `password` CHARACTER VARYING(500) NOT NULL,
    `remark` CHARACTER VARYING(500) NOT NULL,
    PRIMARY KEY (`id`)
);

COMMENT ON TABLE `db_data_source` IS '数据源';
COMMENT ON COLUMN `db_data_source`.`id` IS 'ID';
COMMENT ON COLUMN `db_data_source`.`type` IS '数据库类型';
COMMENT ON COLUMN `db_data_source`.`name` IS '名称';
COMMENT ON COLUMN `db_data_source`.`url` IS '链接';
COMMENT ON COLUMN `db_data_source`.`username` IS '用户名';
COMMENT ON COLUMN `db_data_source`.`password` IS '密码';
COMMENT ON COLUMN `db_data_source`.`remark` IS '备注';

ALTER TABLE `db_schema`
    ADD CONSTRAINT `fk_db_schema_data_source_id`
        FOREIGN KEY (`data_source_id`)
            REFERENCES `db_data_source` (`id`)
                ON UPDATE restrict
                ON DELETE restrict;

