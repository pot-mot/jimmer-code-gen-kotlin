DROP TABLE IF EXISTS `gen_column_info` CASCADE;

CREATE TABLE `gen_column_info` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `column_name` VARCHAR(255) NOT NULL,
    `jdbc_type_code` INTEGER NOT NULL,
    `raw_type` CHARACTER VARYING(500) NOT NULL,
    `type_is_not_null` BOOLEAN NOT NULL,
    `data_size` INTEGER DEFAULT NULL,
    `numeric_precision` INTEGER DEFAULT NULL,
    `column_default_exp` CHARACTER VARYING(500) DEFAULT NULL,
    PRIMARY KEY (`id`)
);

COMMENT ON TABLE `gen_column_info` IS '列信息';
COMMENT ON COLUMN `gen_column_info`.`id` IS 'ID';
COMMENT ON COLUMN `gen_column_info`.`column_name` IS '列名';
COMMENT ON COLUMN `gen_column_info`.`jdbc_type_code` IS 'JdbcType 码值';
COMMENT ON COLUMN `gen_column_info`.`raw_type` IS '字面类型';
COMMENT ON COLUMN `gen_column_info`.`type_is_not_null` IS '类型是否非空';
COMMENT ON COLUMN `gen_column_info`.`data_size` IS '长度';
COMMENT ON COLUMN `gen_column_info`.`numeric_precision` IS '精度';
COMMENT ON COLUMN `gen_column_info`.`column_default_exp` IS '列默认表达式';

ALTER TABLE `gen_embeddable_type_property`
    ADD CONSTRAINT `fk_gen_embeddable_type_property_column_info_id`
        FOREIGN KEY (`column_info_id`)
            REFERENCES `gen_column_info` (`id`);

ALTER TABLE `gen_property`
    ADD CONSTRAINT `fk_gen_property_column_info_id`
        FOREIGN KEY (`column_info_id`)
            REFERENCES `gen_column_info` (`id`);

