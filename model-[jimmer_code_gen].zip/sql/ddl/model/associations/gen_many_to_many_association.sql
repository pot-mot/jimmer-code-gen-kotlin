DROP TABLE IF EXISTS `gen_many_to_many_association` CASCADE;

CREATE TABLE `gen_many_to_many_association` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `source_property_id` INTEGER NOT NULL,
    `mapped_property_id` INTEGER NOT NULL,
    `join_table_id` INTEGER NOT NULL,
    PRIMARY KEY (`id`)
);

COMMENT ON TABLE `gen_many_to_many_association` IS '多对多关联';
COMMENT ON COLUMN `gen_many_to_many_association`.`id` IS 'ID';
COMMENT ON COLUMN `gen_many_to_many_association`.`source_property_id` IS '源属性';
COMMENT ON COLUMN `gen_many_to_many_association`.`mapped_property_id` IS '目标属性';
COMMENT ON COLUMN `gen_many_to_many_association`.`join_table_id` IS 'Join Table';

ALTER TABLE `gen_many_to_many_association`
    ADD CONSTRAINT `fk_gen_many_to_many_association_join_table_id`
        FOREIGN KEY (`join_table_id`)
            REFERENCES `gen_join_table` (`id`);

ALTER TABLE `gen_many_to_many_association`
    ADD CONSTRAINT `fk_gen_many_to_many_association_mapped_property_id`
        FOREIGN KEY (`mapped_property_id`)
            REFERENCES `gen_many_to_many_mapped_property` (`id`);

ALTER TABLE `gen_many_to_many_association`
    ADD CONSTRAINT `fk_gen_many_to_many_association_source_property_id`
        FOREIGN KEY (`source_property_id`)
            REFERENCES `gen_many_to_many_source_property` (`id`);

