DROP TABLE IF EXISTS `gen_one_to_one_association` CASCADE;

CREATE TABLE `gen_one_to_one_association` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `source_property_id` INTEGER NOT NULL,
    `mapped_property_id` INTEGER NOT NULL,
    `join_table_id` INTEGER DEFAULT NULL,
    PRIMARY KEY (`id`)
);

COMMENT ON TABLE `gen_one_to_one_association` IS '一对一关联';
COMMENT ON COLUMN `gen_one_to_one_association`.`id` IS 'ID';
COMMENT ON COLUMN `gen_one_to_one_association`.`source_property_id` IS '源属性';
COMMENT ON COLUMN `gen_one_to_one_association`.`mapped_property_id` IS '目标属性';
COMMENT ON COLUMN `gen_one_to_one_association`.`join_table_id` IS 'Join Table';

ALTER TABLE `gen_one_to_one_association`
    ADD CONSTRAINT `fk_gen_one_to_one_association_join_table_id`
        FOREIGN KEY (`join_table_id`)
            REFERENCES `gen_join_table` (`id`);

ALTER TABLE `gen_one_to_one_association`
    ADD CONSTRAINT `fk_gen_one_to_one_association_mapped_property_id`
        FOREIGN KEY (`mapped_property_id`)
            REFERENCES `gen_one_to_one_mapped_property` (`id`);

ALTER TABLE `gen_one_to_one_association`
    ADD CONSTRAINT `fk_gen_one_to_one_association_source_property_id`
        FOREIGN KEY (`source_property_id`)
            REFERENCES `gen_one_to_one_source_property` (`id`);

