DROP TABLE IF EXISTS `gen_join_table_filter` CASCADE;

CREATE TABLE `gen_join_table_filter` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `join_table_id` INTEGER NOT NULL,
    `column_name` VARCHAR(255) NOT NULL,
    `type` VARCHAR(255) NOT NULL,
    `values` VARCHAR(255) NOT NULL,
    PRIMARY KEY (`id`)
);

COMMENT ON TABLE `gen_join_table_filter` IS 'Join Table 过滤器';
COMMENT ON COLUMN `gen_join_table_filter`.`id` IS 'ID';
COMMENT ON COLUMN `gen_join_table_filter`.`join_table_id` IS 'Join Table';
COMMENT ON COLUMN `gen_join_table_filter`.`column_name` IS '列名称';
COMMENT ON COLUMN `gen_join_table_filter`.`type` IS '类型';
COMMENT ON COLUMN `gen_join_table_filter`.`values` IS '值';

ALTER TABLE `gen_join_table_filter`
    ADD CONSTRAINT `fk_gen_join_table_filter_join_table_id`
        FOREIGN KEY (`join_table_id`)
            REFERENCES `gen_join_table` (`id`);

