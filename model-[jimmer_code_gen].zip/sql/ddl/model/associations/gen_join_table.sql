DROP TABLE IF EXISTS `gen_join_table` CASCADE;

CREATE TABLE `gen_join_table` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(255) NOT NULL,
    `comment` VARCHAR(255) NOT NULL,
    `readonly` BOOLEAN NOT NULL,
    `prevent_deletion_by_source` BOOLEAN NOT NULL,
    `prevent_deletion_by_target` BOOLEAN NOT NULL,
    `deleted_when_endpoint_is_logically_deleted` BOOLEAN NOT NULL,
    `logical_delete_filter_id` INTEGER DEFAULT NULL,
    PRIMARY KEY (`id`)
);

COMMENT ON TABLE `gen_join_table` IS 'Join Table';
COMMENT ON COLUMN `gen_join_table`.`id` IS 'ID';
COMMENT ON COLUMN `gen_join_table`.`name` IS '名称';
COMMENT ON COLUMN `gen_join_table`.`comment` IS '注释';
COMMENT ON COLUMN `gen_join_table`.`readonly` IS '只读';
COMMENT ON COLUMN `gen_join_table`.`prevent_deletion_by_source` IS '阻止从源删除';
COMMENT ON COLUMN `gen_join_table`.`prevent_deletion_by_target` IS '阻止从目标删除';
COMMENT ON COLUMN `gen_join_table`.`deleted_when_endpoint_is_logically_deleted` IS '在终端逻辑删除时物理删除';
COMMENT ON COLUMN `gen_join_table`.`logical_delete_filter_id` IS '逻辑删除过滤器';

ALTER TABLE `gen_join_table`
    ADD CONSTRAINT `fk_gen_join_table_logical_delete_filter_id`
        FOREIGN KEY (`logical_delete_filter_id`)
            REFERENCES `gen_join_table_logical_delete_filter` (`id`);

ALTER TABLE `gen_join_table_column`
    ADD CONSTRAINT `fk_gen_join_table_column_join_table_id`
        FOREIGN KEY (`join_table_id`)
            REFERENCES `gen_join_table` (`id`);

ALTER TABLE `gen_join_table_filter`
    ADD CONSTRAINT `fk_gen_join_table_filter_join_table_id`
        FOREIGN KEY (`join_table_id`)
            REFERENCES `gen_join_table` (`id`);

ALTER TABLE `gen_many_to_many_association`
    ADD CONSTRAINT `fk_gen_many_to_many_association_join_table_id`
        FOREIGN KEY (`join_table_id`)
            REFERENCES `gen_join_table` (`id`);

ALTER TABLE `gen_many_to_one_association`
    ADD CONSTRAINT `fk_gen_many_to_one_association_join_table_id`
        FOREIGN KEY (`join_table_id`)
            REFERENCES `gen_join_table` (`id`);

ALTER TABLE `gen_one_to_one_association`
    ADD CONSTRAINT `fk_gen_one_to_one_association_join_table_id`
        FOREIGN KEY (`join_table_id`)
            REFERENCES `gen_join_table` (`id`);

