DROP TABLE IF EXISTS `gen_join_table_column` CASCADE;

CREATE TABLE `gen_join_table_column` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `join_table_id` INTEGER NOT NULL,
    `column_name` VARCHAR(255) NOT NULL,
    `reference_column_name` VARCHAR(255) NOT NULL,
    `comment` VARCHAR(255) NOT NULL,
    `fake` BOOLEAN NOT NULL,
    PRIMARY KEY (`id`)
);

CREATE UNIQUE INDEX `key_of_gen_join_table_column` ON `gen_join_table_column` (`join_table_id`, `column_name`);

COMMENT ON TABLE `gen_join_table_column` IS 'Join Table Join Column';
COMMENT ON COLUMN `gen_join_table_column`.`id` IS 'ID';
COMMENT ON COLUMN `gen_join_table_column`.`join_table_id` IS 'Join Table';
COMMENT ON COLUMN `gen_join_table_column`.`column_name` IS '本地列名称';
COMMENT ON COLUMN `gen_join_table_column`.`reference_column_name` IS '引用列名称';
COMMENT ON COLUMN `gen_join_table_column`.`comment` IS '注释';
COMMENT ON COLUMN `gen_join_table_column`.`fake` IS '是否伪外键';

ALTER TABLE `gen_join_table_column`
    ADD CONSTRAINT `fk_gen_join_table_column_join_table_id`
        FOREIGN KEY (`join_table_id`)
            REFERENCES `gen_join_table` (`id`);

