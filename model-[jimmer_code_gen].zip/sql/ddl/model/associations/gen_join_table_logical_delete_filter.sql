DROP TABLE IF EXISTS `gen_join_table_logical_delete_filter` CASCADE;

CREATE TABLE `gen_join_table_logical_delete_filter` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `column_name` VARCHAR(255) NOT NULL,
    `type` VARCHAR(255) NOT NULL,
    `values` VARCHAR(255) NOT NULL,
    `logical_deleted_annotation` CHARACTER VARYING(500) NOT NULL,
    `nullable` BOOLEAN NOT NULL,
    PRIMARY KEY (`id`)
);

COMMENT ON TABLE `gen_join_table_logical_delete_filter` IS 'Join Table 逻辑删除过滤器';
COMMENT ON COLUMN `gen_join_table_logical_delete_filter`.`id` IS 'ID';
COMMENT ON COLUMN `gen_join_table_logical_delete_filter`.`column_name` IS '列名称';
COMMENT ON COLUMN `gen_join_table_logical_delete_filter`.`type` IS '类型';
COMMENT ON COLUMN `gen_join_table_logical_delete_filter`.`values` IS '值';
COMMENT ON COLUMN `gen_join_table_logical_delete_filter`.`logical_deleted_annotation` IS '逻辑删除注解';
COMMENT ON COLUMN `gen_join_table_logical_delete_filter`.`nullable` IS '可空';

ALTER TABLE `gen_join_table`
    ADD CONSTRAINT `fk_gen_join_table_logical_delete_filter_id`
        FOREIGN KEY (`logical_delete_filter_id`)
            REFERENCES `gen_join_table_logical_delete_filter` (`id`);

