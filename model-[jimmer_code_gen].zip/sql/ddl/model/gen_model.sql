DROP TABLE IF EXISTS `gen_model` CASCADE;

CREATE TABLE `gen_model` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `name` CHARACTER VARYING(500) NOT NULL,
    `author` CHARACTER VARYING(500) NOT NULL,
    `language` CHARACTER VARYING(500) NOT NULL,
    `database_type` CHARACTER VARYING(500) NOT NULL,
    `database_naming_strategy` CHARACTER VARYING(500) NOT NULL,
    `transition` VARCHAR(255) NOT NULL,
    `created_time` TIMESTAMP(0) NOT NULL,
    `modified_time` TIMESTAMP(0) NOT NULL,
    PRIMARY KEY (`id`)
);

COMMENT ON TABLE `gen_model` IS '模型';
COMMENT ON COLUMN `gen_model`.`id` IS 'ID';
COMMENT ON COLUMN `gen_model`.`name` IS '名称';
COMMENT ON COLUMN `gen_model`.`author` IS '作者';
COMMENT ON COLUMN `gen_model`.`language` IS '语言';
COMMENT ON COLUMN `gen_model`.`database_type` IS '数据库类型';
COMMENT ON COLUMN `gen_model`.`database_naming_strategy` IS '数据库命名策略';
COMMENT ON COLUMN `gen_model`.`transition` IS '图偏移';
COMMENT ON COLUMN `gen_model`.`created_time` IS '创建时间';
COMMENT ON COLUMN `gen_model`.`modified_time` IS '修改时间';

ALTER TABLE `gen_model_config`
    ADD CONSTRAINT `fk_gen_model_config_model_id`
        FOREIGN KEY (`model_id`)
            REFERENCES `gen_model` (`id`);

ALTER TABLE `gen_model_group`
    ADD CONSTRAINT `fk_gen_model_group_model_id`
        FOREIGN KEY (`model_id`)
            REFERENCES `gen_model` (`id`)
                ON UPDATE restrict
                ON DELETE restrict;

