DROP TABLE IF EXISTS `gen_entity_key_group` CASCADE;

CREATE TABLE `gen_entity_key_group` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `index_id` INTEGER NOT NULL,
    `name` VARCHAR(255) NOT NULL,
    PRIMARY KEY (`id`)
);

CREATE UNIQUE INDEX `key_of_gen_entity_key_group` ON `gen_entity_key_group` (`index_id`);

COMMENT ON TABLE `gen_entity_key_group` IS '实体业务键组';
COMMENT ON COLUMN `gen_entity_key_group`.`id` IS 'ID';
COMMENT ON COLUMN `gen_entity_key_group`.`index_id` IS '对应索引';
COMMENT ON COLUMN `gen_entity_key_group`.`name` IS '名称';

ALTER TABLE `gen_entity_key_group`
    ADD CONSTRAINT `fk_gen_entity_key_group_index_id`
        FOREIGN KEY (`index_id`)
            REFERENCES `gen_entity_index` (`id`);

