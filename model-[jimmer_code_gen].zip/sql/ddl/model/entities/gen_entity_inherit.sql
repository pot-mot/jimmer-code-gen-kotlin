DROP TABLE IF EXISTS `gen_entity_inherit` CASCADE;

CREATE TABLE `gen_entity_inherit` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `parent_id` INTEGER NOT NULL,
    `child_id` INTEGER NOT NULL,
    PRIMARY KEY (`id`)
);

CREATE UNIQUE INDEX `key_of_gen_entity_inherit` ON `gen_entity_inherit` (`parent_id`, `child_id`);

COMMENT ON TABLE `gen_entity_inherit` IS '实体继承';
COMMENT ON COLUMN `gen_entity_inherit`.`id` IS 'ID';
COMMENT ON COLUMN `gen_entity_inherit`.`parent_id` IS '父级';
COMMENT ON COLUMN `gen_entity_inherit`.`child_id` IS '子级';

ALTER TABLE `gen_entity_inherit`
    ADD CONSTRAINT `fk_gen_entity_inherit_child_id`
        FOREIGN KEY (`child_id`)
            REFERENCES `gen_entity` (`id`);

ALTER TABLE `gen_entity_inherit`
    ADD CONSTRAINT `fk_gen_entity_inherit_parent_id`
        FOREIGN KEY (`parent_id`)
            REFERENCES `gen_entity` (`id`);

