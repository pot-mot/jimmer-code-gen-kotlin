DROP TABLE IF EXISTS `gen_entity` CASCADE;

CREATE TABLE `gen_entity` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `group_id` INTEGER NOT NULL,
    `interface_name` CHARACTER VARYING(500) NOT NULL,
    `mapped_super` BOOLEAN NOT NULL,
    `table_name` CHARACTER VARYING(500) NOT NULL,
    `plural_name` CHARACTER VARYING(500) NOT NULL,
    `author` CHARACTER VARYING(500) NOT NULL,
    `comment` CHARACTER VARYING(500) NOT NULL,
    `sub_package_path` CHARACTER VARYING(500) NOT NULL,
    `other_annotations` CHARACTER VARYING(500) NOT NULL,
    `other_imports` VARCHAR(255) NOT NULL,
    `remark` CHARACTER VARYING(500) NOT NULL,
    `id_property_id` INTEGER DEFAULT NULL,
    `logical_delete_property_id` INTEGER DEFAULT NULL,
    `version_property_id` INTEGER DEFAULT NULL,
    `x` DOUBLE PRECISION NOT NULL,
    `y` DOUBLE PRECISION NOT NULL,
    PRIMARY KEY (`id`)
);

CREATE UNIQUE INDEX `key_of_gen_entity` ON `gen_entity` (`group_id`, `interface_name`);

COMMENT ON TABLE `gen_entity` IS '实体';
COMMENT ON COLUMN `gen_entity`.`id` IS 'ID';
COMMENT ON COLUMN `gen_entity`.`group_id` IS '分组';
COMMENT ON COLUMN `gen_entity`.`interface_name` IS '接口名称';
COMMENT ON COLUMN `gen_entity`.`mapped_super` IS '抽象超类型';
COMMENT ON COLUMN `gen_entity`.`table_name` IS '表名称';
COMMENT ON COLUMN `gen_entity`.`plural_name` IS '复数名称';
COMMENT ON COLUMN `gen_entity`.`author` IS '作者';
COMMENT ON COLUMN `gen_entity`.`comment` IS '注释';
COMMENT ON COLUMN `gen_entity`.`sub_package_path` IS '子包路径';
COMMENT ON COLUMN `gen_entity`.`other_annotations` IS '其他注解';
COMMENT ON COLUMN `gen_entity`.`other_imports` IS '其他导入';
COMMENT ON COLUMN `gen_entity`.`remark` IS '备注';
COMMENT ON COLUMN `gen_entity`.`id_property_id` IS 'ID属性';
COMMENT ON COLUMN `gen_entity`.`logical_delete_property_id` IS '逻辑删除属性';
COMMENT ON COLUMN `gen_entity`.`version_property_id` IS '乐观锁属性';
COMMENT ON COLUMN `gen_entity`.`x` IS 'X坐标';
COMMENT ON COLUMN `gen_entity`.`y` IS 'Y坐标';

ALTER TABLE `gen_entity`
    ADD CONSTRAINT `fk_gen_entity_group_id`
        FOREIGN KEY (`group_id`)
            REFERENCES `gen_model_group` (`id`);

ALTER TABLE `gen_entity`
    ADD CONSTRAINT `fk_gen_entity_id_property_id`
        FOREIGN KEY (`id_property_id`)
            REFERENCES `gen_id_property` (`id`);

ALTER TABLE `gen_entity`
    ADD CONSTRAINT `fk_gen_entity_logical_delete_property_id`
        FOREIGN KEY (`logical_delete_property_id`)
            REFERENCES `gen_logical_delete_property` (`id`);

ALTER TABLE `gen_entity`
    ADD CONSTRAINT `fk_gen_entity_version_property_id`
        FOREIGN KEY (`version_property_id`)
            REFERENCES `gen_version_property` (`id`);

ALTER TABLE `gen_entity_index`
    ADD CONSTRAINT `fk_gen_entity_index_entity_id`
        FOREIGN KEY (`entity_id`)
            REFERENCES `gen_entity` (`id`);

ALTER TABLE `gen_entity_inherit`
    ADD CONSTRAINT `fk_gen_entity_inherit_child_id`
        FOREIGN KEY (`child_id`)
            REFERENCES `gen_entity` (`id`);

ALTER TABLE `gen_entity_inherit`
    ADD CONSTRAINT `fk_gen_entity_inherit_parent_id`
        FOREIGN KEY (`parent_id`)
            REFERENCES `gen_entity` (`id`);

ALTER TABLE `gen_extra_property`
    ADD CONSTRAINT `fk_gen_extra_property_type_entity_id`
        FOREIGN KEY (`type_entity_id`)
            REFERENCES `gen_entity` (`id`);

ALTER TABLE `gen_property`
    ADD CONSTRAINT `fk_gen_property_entity_id`
        FOREIGN KEY (`entity_id`)
            REFERENCES `gen_entity` (`id`);

ALTER TABLE `gen_sort_property`
    ADD CONSTRAINT `fk_gen_sort_property_entity_id`
        FOREIGN KEY (`entity_id`)
            REFERENCES `gen_entity` (`id`);

ALTER TABLE `gen_many_to_many_mapped_property`
    ADD CONSTRAINT `fk_gen_many_to_many_mapped_property_type_entity_id`
        FOREIGN KEY (`type_entity_id`)
            REFERENCES `gen_entity` (`id`);

ALTER TABLE `gen_many_to_many_source_property`
    ADD CONSTRAINT `fk_gen_many_to_many_source_property_type_entity_id`
        FOREIGN KEY (`type_entity_id`)
            REFERENCES `gen_entity` (`id`);

ALTER TABLE `gen_many_to_one_mapped_property`
    ADD CONSTRAINT `fk_gen_many_to_one_mapped_property_type_entity_id`
        FOREIGN KEY (`type_entity_id`)
            REFERENCES `gen_entity` (`id`);

ALTER TABLE `gen_many_to_one_source_property`
    ADD CONSTRAINT `fk_gen_many_to_one_source_property_type_entity_id`
        FOREIGN KEY (`type_entity_id`)
            REFERENCES `gen_entity` (`id`);

ALTER TABLE `gen_one_to_one_mapped_property`
    ADD CONSTRAINT `fk_gen_one_to_one_mapped_property_type_entity_id`
        FOREIGN KEY (`type_entity_id`)
            REFERENCES `gen_entity` (`id`);

ALTER TABLE `gen_one_to_one_source_property`
    ADD CONSTRAINT `fk_gen_one_to_one_source_property_type_entity_id`
        FOREIGN KEY (`type_entity_id`)
            REFERENCES `gen_entity` (`id`);

