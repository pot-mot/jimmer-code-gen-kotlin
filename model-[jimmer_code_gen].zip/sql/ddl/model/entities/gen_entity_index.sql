DROP TABLE IF EXISTS `gen_entity_index` CASCADE;

CREATE TABLE `gen_entity_index` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `entity_id` INTEGER NOT NULL,
    `name` CHARACTER VARYING(500) NOT NULL,
    `unique_index` BOOLEAN NOT NULL,
    `remark` CHARACTER VARYING(500) NOT NULL,
    PRIMARY KEY (`id`)
);

CREATE UNIQUE INDEX `key_of_gen_entity_index` ON `gen_entity_index` (`entity_id`, `name`);

COMMENT ON TABLE `gen_entity_index` IS '实体索引';
COMMENT ON COLUMN `gen_entity_index`.`id` IS 'ID';
COMMENT ON COLUMN `gen_entity_index`.`entity_id` IS '归属表';
COMMENT ON COLUMN `gen_entity_index`.`name` IS '名称';
COMMENT ON COLUMN `gen_entity_index`.`unique_index` IS '是否是唯一索引';
COMMENT ON COLUMN `gen_entity_index`.`remark` IS '备注';

ALTER TABLE `gen_entity_index`
    ADD CONSTRAINT `fk_gen_entity_index_entity_id`
        FOREIGN KEY (`entity_id`)
            REFERENCES `gen_entity` (`id`);

DROP TABLE IF EXISTS `gen_entity_index_gen_property_mapping` CASCADE;

CREATE TABLE `gen_entity_index_gen_property_mapping` (
    `gen_entity_index_id` INTEGER NOT NULL,
    `gen_property_id` INTEGER NOT NULL
);

ALTER TABLE `gen_entity_index_gen_property_mapping` ADD CONSTRAINT `pk_gen_entity_index_gen_property_mapping` PRIMARY KEY (`gen_entity_index_id`,`gen_property_id`);

ALTER TABLE `gen_entity_index_gen_property_mapping`
    ADD CONSTRAINT `gen_entity_index_gen_property_mapping_S`
        FOREIGN KEY (`gen_entity_index_id`)
            REFERENCES `gen_entity_index` (`id`);

ALTER TABLE `gen_entity_index_gen_property_mapping`
    ADD CONSTRAINT `gen_entity_index_gen_property_mapping_T`
        FOREIGN KEY (`gen_property_id`)
            REFERENCES `gen_property` (`id`);

COMMENT ON TABLE `gen_entity_index_gen_property_mapping` IS '实体索引与属性的映射关系表';

ALTER TABLE `gen_entity_key_group`
    ADD CONSTRAINT `fk_gen_entity_key_group_index_id`
        FOREIGN KEY (`index_id`)
            REFERENCES `gen_entity_index` (`id`);

