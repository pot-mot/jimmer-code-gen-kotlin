DROP TABLE IF EXISTS `gen_entity_graph_data` CASCADE;

CREATE TABLE `gen_entity_graph_data` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `x` DOUBLE PRECISION NOT NULL,
    `y` DOUBLE PRECISION NOT NULL,
    PRIMARY KEY (`id`)
);

COMMENT ON TABLE `gen_entity_graph_data` IS '实体图数据';
COMMENT ON COLUMN `gen_entity_graph_data`.`id` IS 'ID';
COMMENT ON COLUMN `gen_entity_graph_data`.`x` IS 'X坐标';
COMMENT ON COLUMN `gen_entity_graph_data`.`y` IS 'Y坐标';

ALTER TABLE `gen_entity`
    ADD CONSTRAINT `fk_gen_entity_graph_data_id`
        FOREIGN KEY (`graph_data_id`)
            REFERENCES `gen_entity_graph_data` (`id`);

