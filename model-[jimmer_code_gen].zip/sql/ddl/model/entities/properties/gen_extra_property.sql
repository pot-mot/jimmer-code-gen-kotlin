DROP TABLE IF EXISTS `gen_extra_property` CASCADE;

CREATE TABLE `gen_extra_property` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `property_id` INTEGER NOT NULL,
    `entity_id` INTEGER NOT NULL,
    `type` CHARACTER VARYING(500) DEFAULT NULL,
    `body` CHARACTER VARYING(500) DEFAULT NULL,
    `type_embeddable_id` INTEGER DEFAULT NULL,
    `type_entity_id` INTEGER DEFAULT NULL,
    `type_enum_id` INTEGER DEFAULT NULL,
    PRIMARY KEY (`id`)
);

CREATE UNIQUE INDEX `key_of_gen_extra_property` ON `gen_extra_property` (`property_id`);

COMMENT ON TABLE `gen_extra_property` IS '额外属性';
COMMENT ON COLUMN `gen_extra_property`.`id` IS 'ID';
COMMENT ON COLUMN `gen_extra_property`.`property_id` IS '属性';
COMMENT ON COLUMN `gen_extra_property`.`entity_id` IS '实体';
COMMENT ON COLUMN `gen_extra_property`.`type` IS '类型';
COMMENT ON COLUMN `gen_extra_property`.`body` IS '属性方法体';
COMMENT ON COLUMN `gen_extra_property`.`type_embeddable_id` IS '类型对应嵌入';
COMMENT ON COLUMN `gen_extra_property`.`type_entity_id` IS '类型对应实体';
COMMENT ON COLUMN `gen_extra_property`.`type_enum_id` IS '类型对应枚举';

ALTER TABLE `gen_extra_property`
    ADD CONSTRAINT `fk_gen_extra_property_entity_id`
        FOREIGN KEY (`entity_id`)
            REFERENCES `gen_entity` (`id`);

ALTER TABLE `gen_extra_property`
    ADD CONSTRAINT `fk_gen_extra_property_property_id`
        FOREIGN KEY (`property_id`)
            REFERENCES `gen_property` (`id`);

ALTER TABLE `gen_extra_property`
    ADD CONSTRAINT `fk_gen_extra_property_type_embeddable_id`
        FOREIGN KEY (`type_embeddable_id`)
            REFERENCES `gen_embeddable` (`id`);

ALTER TABLE `gen_extra_property`
    ADD CONSTRAINT `fk_gen_extra_property_may_type_entity_id`
        FOREIGN KEY (`type_entity_id`)
            REFERENCES `gen_entity` (`id`);

ALTER TABLE `gen_extra_property`
    ADD CONSTRAINT `fk_gen_extra_property_type_enum_id`
        FOREIGN KEY (`type_enum_id`)
            REFERENCES `gen_enum` (`id`);

