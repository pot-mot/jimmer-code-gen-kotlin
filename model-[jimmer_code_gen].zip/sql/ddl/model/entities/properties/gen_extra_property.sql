DROP TABLE IF EXISTS `gen_extra_property` CASCADE;

CREATE TABLE `gen_extra_property` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `property_id` INTEGER NOT NULL,
    `type` VARCHAR(255) NOT NULL,
    `type_entity_id` INTEGER DEFAULT NULL,
    `type_enum_id` INTEGER DEFAULT NULL,
    `body` CHARACTER VARYING(500) DEFAULT NULL,
    PRIMARY KEY (`id`)
);

CREATE UNIQUE INDEX `key_of_gen_extra_property` ON `gen_extra_property` (`property_id`);

COMMENT ON TABLE `gen_extra_property` IS '额外属性';
COMMENT ON COLUMN `gen_extra_property`.`id` IS 'ID';
COMMENT ON COLUMN `gen_extra_property`.`property_id` IS '属性';
COMMENT ON COLUMN `gen_extra_property`.`type` IS '类型';
COMMENT ON COLUMN `gen_extra_property`.`type_entity_id` IS '类型对应实体';
COMMENT ON COLUMN `gen_extra_property`.`type_enum_id` IS '类型对应枚举';
COMMENT ON COLUMN `gen_extra_property`.`body` IS '属性方法体';

ALTER TABLE `gen_extra_property`
    ADD CONSTRAINT `fk_gen_extra_property_property_id`
        FOREIGN KEY (`property_id`)
            REFERENCES `gen_property` (`id`);

ALTER TABLE `gen_extra_property`
    ADD CONSTRAINT `fk_gen_extra_property_type_entity_id`
        FOREIGN KEY (`type_entity_id`)
            REFERENCES `gen_entity` (`id`);

ALTER TABLE `gen_extra_property`
    ADD CONSTRAINT `fk_gen_extra_property_type_enum_id`
        FOREIGN KEY (`type_enum_id`)
            REFERENCES `gen_enum` (`id`);

