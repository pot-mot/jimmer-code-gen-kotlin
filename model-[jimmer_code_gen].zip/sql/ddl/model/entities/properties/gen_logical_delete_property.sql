DROP TABLE IF EXISTS `gen_logical_delete_property` CASCADE;

CREATE TABLE `gen_logical_delete_property` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `property_id` INTEGER NOT NULL,
    `logical_deleted_annotation` CHARACTER VARYING(500) NOT NULL,
    PRIMARY KEY (`id`)
);

CREATE UNIQUE INDEX `key_of_gen_logical_delete_property` ON `gen_logical_delete_property` (`property_id`);

COMMENT ON TABLE `gen_logical_delete_property` IS '逻辑删除属性';
COMMENT ON COLUMN `gen_logical_delete_property`.`id` IS 'ID';
COMMENT ON COLUMN `gen_logical_delete_property`.`property_id` IS '属性';
COMMENT ON COLUMN `gen_logical_delete_property`.`logical_deleted_annotation` IS '逻辑删除注解';

ALTER TABLE `gen_logical_delete_property`
    ADD CONSTRAINT `fk_gen_logical_delete_property_property_id`
        FOREIGN KEY (`property_id`)
            REFERENCES `gen_property` (`id`);

ALTER TABLE `gen_entity`
    ADD CONSTRAINT `fk_gen_entity_logical_delete_property_id`
        FOREIGN KEY (`logical_delete_property_id`)
            REFERENCES `gen_logical_delete_property` (`id`);

