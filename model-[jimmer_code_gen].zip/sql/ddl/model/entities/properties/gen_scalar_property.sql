DROP TABLE IF EXISTS `gen_scalar_property` CASCADE;

CREATE TABLE `gen_scalar_property` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `property_id` INTEGER NOT NULL,
    `entity_id` INTEGER NOT NULL,
    `type` CHARACTER VARYING(500) DEFAULT NULL,
    `column_name` VARCHAR(255) NOT NULL,
    `default_value` CHARACTER VARYING(500) DEFAULT NULL,
    `jdbc_type_code` INTEGER NOT NULL,
    `raw_type` CHARACTER VARYING(500) NOT NULL,
    `type_is_not_null` BOOLEAN NOT NULL,
    `data_size` INTEGER DEFAULT NULL,
    `numeric_precision` INTEGER DEFAULT NULL,
    `column_default_exp` CHARACTER VARYING(500) DEFAULT NULL,
    `type_embeddable_id` INTEGER DEFAULT NULL,
    `type_enum_id` INTEGER DEFAULT NULL,
    PRIMARY KEY (`id`)
);

CREATE UNIQUE INDEX `key_of_gen_scalar_property` ON `gen_scalar_property` (`property_id`);
CREATE UNIQUE INDEX `key_of_gen_common_property` ON `gen_scalar_property` (`property_id`);

COMMENT ON TABLE `gen_scalar_property` IS '标量属性';
COMMENT ON COLUMN `gen_scalar_property`.`id` IS 'ID';
COMMENT ON COLUMN `gen_scalar_property`.`property_id` IS '属性';
COMMENT ON COLUMN `gen_scalar_property`.`entity_id` IS '实体';
COMMENT ON COLUMN `gen_scalar_property`.`type` IS '类型';
COMMENT ON COLUMN `gen_scalar_property`.`column_name` IS '列名称';
COMMENT ON COLUMN `gen_scalar_property`.`default_value` IS '默认值';
COMMENT ON COLUMN `gen_scalar_property`.`jdbc_type_code` IS 'JdbcType 码值';
COMMENT ON COLUMN `gen_scalar_property`.`raw_type` IS '字面类型';
COMMENT ON COLUMN `gen_scalar_property`.`type_is_not_null` IS '类型是否非空';
COMMENT ON COLUMN `gen_scalar_property`.`data_size` IS '长度';
COMMENT ON COLUMN `gen_scalar_property`.`numeric_precision` IS '精度';
COMMENT ON COLUMN `gen_scalar_property`.`column_default_exp` IS '列默认表达式';
COMMENT ON COLUMN `gen_scalar_property`.`type_embeddable_id` IS '类型对应嵌入';
COMMENT ON COLUMN `gen_scalar_property`.`type_enum_id` IS '类型对应枚举';

ALTER TABLE `gen_scalar_property`
    ADD CONSTRAINT `fk_gen_scalar_property_entity_id`
        FOREIGN KEY (`entity_id`)
            REFERENCES `gen_entity` (`id`);

ALTER TABLE `gen_scalar_property`
    ADD CONSTRAINT `fk_gen_scalar_property_property_id`
        FOREIGN KEY (`property_id`)
            REFERENCES `gen_property` (`id`);

ALTER TABLE `gen_scalar_property`
    ADD CONSTRAINT `fk_gen_scalar_property_type_embeddable_id`
        FOREIGN KEY (`type_embeddable_id`)
            REFERENCES `gen_embeddable` (`id`);

ALTER TABLE `gen_scalar_property`
    ADD CONSTRAINT `fk_gen_scalar_property_type_enum_id`
        FOREIGN KEY (`type_enum_id`)
            REFERENCES `gen_enum` (`id`);

