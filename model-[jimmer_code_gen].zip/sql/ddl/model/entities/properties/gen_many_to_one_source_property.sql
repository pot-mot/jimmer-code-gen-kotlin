DROP TABLE IF EXISTS `gen_many_to_one_source_property` CASCADE;

CREATE TABLE `gen_many_to_one_source_property` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `property_id` INTEGER NOT NULL,
    `column_name` VARCHAR(255) NOT NULL,
    `id_view_name` VARCHAR(255) NOT NULL,
    `type_is_not_null` BOOLEAN NOT NULL,
    `type_entity_id` INTEGER NOT NULL,
    PRIMARY KEY (`id`)
);

CREATE UNIQUE INDEX `key_of_gen_many_to_one_source_property` ON `gen_many_to_one_source_property` (`property_id`);

COMMENT ON TABLE `gen_many_to_one_source_property` IS '多对一源属性（对单）';
COMMENT ON COLUMN `gen_many_to_one_source_property`.`id` IS 'ID';
COMMENT ON COLUMN `gen_many_to_one_source_property`.`property_id` IS '属性';
COMMENT ON COLUMN `gen_many_to_one_source_property`.`column_name` IS '列名称';
COMMENT ON COLUMN `gen_many_to_one_source_property`.`id_view_name` IS 'ID视图名';
COMMENT ON COLUMN `gen_many_to_one_source_property`.`type_is_not_null` IS '类型是否非空';
COMMENT ON COLUMN `gen_many_to_one_source_property`.`type_entity_id` IS '类型对应实体';

ALTER TABLE `gen_many_to_one_source_property`
    ADD CONSTRAINT `fk_gen_many_to_one_source_property_property_id`
        FOREIGN KEY (`property_id`)
            REFERENCES `gen_property` (`id`);

ALTER TABLE `gen_many_to_one_source_property`
    ADD CONSTRAINT `fk_gen_many_to_one_source_property_type_entity_id`
        FOREIGN KEY (`type_entity_id`)
            REFERENCES `gen_entity` (`id`);

ALTER TABLE `gen_many_to_one_association`
    ADD CONSTRAINT `fk_gen_many_to_one_association_source_property_id`
        FOREIGN KEY (`source_property_id`)
            REFERENCES `gen_many_to_one_source_property` (`id`);

ALTER TABLE `gen_many_to_one_mapped_property`
    ADD CONSTRAINT `fk_gen_many_to_one_mapped_property_mapped_by_id`
        FOREIGN KEY (`mapped_by_id`)
            REFERENCES `gen_many_to_one_source_property` (`id`);

