DROP TABLE IF EXISTS `gen_property` CASCADE;

CREATE TABLE `gen_property` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `entity_id` INTEGER NOT NULL,
    `name` CHARACTER VARYING(500) NOT NULL,
    `comment` CHARACTER VARYING(500) NOT NULL,
    `extra_annotations` CHARACTER VARYING(500) DEFAULT NULL,
    `extra_imports` VARCHAR(255) DEFAULT NULL,
    `extra_validations` VARCHAR(255) DEFAULT NULL,
    `remark` CHARACTER VARYING(500) NOT NULL,
    `order_key` INTEGER NOT NULL,
    `raw_type` CHARACTER VARYING(500) DEFAULT NULL,
    `type_enum_id` INTEGER DEFAULT NULL,
    `type_embeddable_id` INTEGER DEFAULT NULL,
    `column_info_id` INTEGER DEFAULT NULL,
    PRIMARY KEY (`id`)
);

CREATE UNIQUE INDEX `key_of_gen_property` ON `gen_property` (`entity_id`, `name`);

COMMENT ON TABLE `gen_property` IS '属性';
COMMENT ON COLUMN `gen_property`.`id` IS 'ID';
COMMENT ON COLUMN `gen_property`.`entity_id` IS '实体';
COMMENT ON COLUMN `gen_property`.`name` IS '名称';
COMMENT ON COLUMN `gen_property`.`comment` IS '注释';
COMMENT ON COLUMN `gen_property`.`extra_annotations` IS '其他注解';
COMMENT ON COLUMN `gen_property`.`extra_imports` IS '其他导入';
COMMENT ON COLUMN `gen_property`.`extra_validations` IS '其他验证器';
COMMENT ON COLUMN `gen_property`.`remark` IS '备注';
COMMENT ON COLUMN `gen_property`.`order_key` IS '排序键';
COMMENT ON COLUMN `gen_property`.`raw_type` IS '字面类型';
COMMENT ON COLUMN `gen_property`.`type_enum_id` IS '类型对应枚举';
COMMENT ON COLUMN `gen_property`.`type_embeddable_id` IS '类型对应嵌入';
COMMENT ON COLUMN `gen_property`.`column_info_id` IS '列信息';

ALTER TABLE `gen_property`
    ADD CONSTRAINT `fk_gen_property_entity_id`
        FOREIGN KEY (`entity_id`)
            REFERENCES `gen_entity` (`id`);

ALTER TABLE `gen_property`
    ADD CONSTRAINT `fk_gen_property_column_info_id`
        FOREIGN KEY (`column_info_id`)
            REFERENCES `gen_column_info` (`id`);

ALTER TABLE `gen_property`
    ADD CONSTRAINT `fk_gen_property_type_embeddable_id`
        FOREIGN KEY (`type_embeddable_id`)
            REFERENCES `gen_embeddable_type` (`id`);

ALTER TABLE `gen_property`
    ADD CONSTRAINT `fk_gen_property_type_enum_id`
        FOREIGN KEY (`type_enum_id`)
            REFERENCES `gen_enum` (`id`);

ALTER TABLE `gen_extra_property`
    ADD CONSTRAINT `fk_gen_extra_property_property_id`
        FOREIGN KEY (`property_id`)
            REFERENCES `gen_property` (`id`);

ALTER TABLE `gen_id_property`
    ADD CONSTRAINT `fk_gen_id_property_property_id`
        FOREIGN KEY (`property_id`)
            REFERENCES `gen_property` (`id`);

ALTER TABLE `gen_logical_delete_property`
    ADD CONSTRAINT `fk_gen_logical_delete_property_property_id`
        FOREIGN KEY (`property_id`)
            REFERENCES `gen_property` (`id`);

ALTER TABLE `gen_many_to_many_mapped_property`
    ADD CONSTRAINT `fk_gen_many_to_many_mapped_property_property_id`
        FOREIGN KEY (`property_id`)
            REFERENCES `gen_property` (`id`);

ALTER TABLE `gen_many_to_many_source_property`
    ADD CONSTRAINT `fk_gen_many_to_many_source_property_property_id`
        FOREIGN KEY (`property_id`)
            REFERENCES `gen_property` (`id`);

ALTER TABLE `gen_many_to_one_mapped_property`
    ADD CONSTRAINT `fk_gen_many_to_one_mapped_property_property_id`
        FOREIGN KEY (`property_id`)
            REFERENCES `gen_property` (`id`);

ALTER TABLE `gen_many_to_one_source_property`
    ADD CONSTRAINT `fk_gen_many_to_one_source_property_property_id`
        FOREIGN KEY (`property_id`)
            REFERENCES `gen_property` (`id`);

ALTER TABLE `gen_one_to_one_mapped_property`
    ADD CONSTRAINT `fk_gen_one_to_one_mapped_property_property_id`
        FOREIGN KEY (`property_id`)
            REFERENCES `gen_property` (`id`);

ALTER TABLE `gen_one_to_one_source_property`
    ADD CONSTRAINT `fk_gen_one_to_one_source_property_property_id`
        FOREIGN KEY (`property_id`)
            REFERENCES `gen_property` (`id`);

ALTER TABLE `gen_sort_property`
    ADD CONSTRAINT `fk_gen_sort_property_property_id`
        FOREIGN KEY (`property_id`)
            REFERENCES `gen_property` (`id`);

ALTER TABLE `gen_version_property`
    ADD CONSTRAINT `fk_gen_version_property_property_id`
        FOREIGN KEY (`property_id`)
            REFERENCES `gen_property` (`id`);

DROP TABLE IF EXISTS `gen_entity_index_gen_property_mapping` CASCADE;

CREATE TABLE `gen_entity_index_gen_property_mapping` (
    `gen_entity_index_id` INTEGER NOT NULL,
    `gen_property_id` INTEGER NOT NULL
);

ALTER TABLE `gen_entity_index_gen_property_mapping` ADD CONSTRAINT `pk_gen_entity_index_gen_property_mapping` PRIMARY KEY (`gen_entity_index_id`,`gen_property_id`);

ALTER TABLE `gen_entity_index_gen_property_mapping`
    ADD CONSTRAINT `gen_entity_index_gen_property_mapping_S`
        FOREIGN KEY (`gen_entity_index_id`)
            REFERENCES `gen_entity_index` (`id`);

ALTER TABLE `gen_entity_index_gen_property_mapping`
    ADD CONSTRAINT `gen_entity_index_gen_property_mapping_T`
        FOREIGN KEY (`gen_property_id`)
            REFERENCES `gen_property` (`id`);

COMMENT ON TABLE `gen_entity_index_gen_property_mapping` IS '实体索引与属性的映射关系表';

