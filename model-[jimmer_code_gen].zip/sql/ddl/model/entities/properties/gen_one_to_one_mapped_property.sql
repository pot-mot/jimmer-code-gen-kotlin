DROP TABLE IF EXISTS `gen_one_to_one_mapped_property` CASCADE;

CREATE TABLE `gen_one_to_one_mapped_property` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `property_id` INTEGER NOT NULL,
    `mapped_by_id` INTEGER NOT NULL,
    `id_view_name` VARCHAR(255) NOT NULL,
    `type_entity_id` INTEGER NOT NULL,
    PRIMARY KEY (`id`)
);

CREATE UNIQUE INDEX `key_of_gen_one_to_one_mapped_property` ON `gen_one_to_one_mapped_property` (`property_id`);
CREATE UNIQUE INDEX `key_of_gen_one_to_one_mapped_property_mapped_by` ON `gen_one_to_one_mapped_property` (`mapped_by_id`);

COMMENT ON TABLE `gen_one_to_one_mapped_property` IS '一对一映射属性';
COMMENT ON COLUMN `gen_one_to_one_mapped_property`.`id` IS 'ID';
COMMENT ON COLUMN `gen_one_to_one_mapped_property`.`property_id` IS '属性';
COMMENT ON COLUMN `gen_one_to_one_mapped_property`.`mapped_by_id` IS '对应源属性';
COMMENT ON COLUMN `gen_one_to_one_mapped_property`.`id_view_name` IS 'ID视图名';
COMMENT ON COLUMN `gen_one_to_one_mapped_property`.`type_entity_id` IS '类型对应实体';

ALTER TABLE `gen_one_to_one_mapped_property`
    ADD CONSTRAINT `fk_gen_one_to_one_mapped_property_mapped_by_id`
        FOREIGN KEY (`mapped_by_id`)
            REFERENCES `gen_one_to_one_source_property` (`id`);

ALTER TABLE `gen_one_to_one_mapped_property`
    ADD CONSTRAINT `fk_gen_one_to_one_mapped_property_property_id`
        FOREIGN KEY (`property_id`)
            REFERENCES `gen_property` (`id`);

ALTER TABLE `gen_one_to_one_mapped_property`
    ADD CONSTRAINT `fk_gen_one_to_one_mapped_property_type_entity_id`
        FOREIGN KEY (`type_entity_id`)
            REFERENCES `gen_entity` (`id`);

ALTER TABLE `gen_one_to_one_association`
    ADD CONSTRAINT `fk_gen_one_to_one_association_mapped_property_id`
        FOREIGN KEY (`mapped_property_id`)
            REFERENCES `gen_one_to_one_mapped_property` (`id`);

