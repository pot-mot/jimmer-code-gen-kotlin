DROP TABLE IF EXISTS `gen_column_property` CASCADE;

CREATE TABLE `gen_column_property` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `property_id` INTEGER NOT NULL,
    `entity_id` INTEGER NOT NULL,
    `type` VARCHAR(255) NOT NULL,
    `column_name` VARCHAR(255) NOT NULL,
    `jdbc_type_code` INTEGER NOT NULL,
    `raw_type` CHARACTER VARYING(500) NOT NULL,
    `type_is_not_null` BOOLEAN NOT NULL,
    `data_size` INTEGER DEFAULT NULL,
    `numeric_precision` INTEGER DEFAULT NULL,
    `column_default_exp` CHARACTER VARYING(500) DEFAULT NULL,
    PRIMARY KEY (`id`)
);

CREATE UNIQUE INDEX `key_of_gen_column_property` ON `gen_column_property` (`property_id`);

COMMENT ON TABLE `gen_column_property` IS '列属性';
COMMENT ON COLUMN `gen_column_property`.`id` IS 'ID';
COMMENT ON COLUMN `gen_column_property`.`property_id` IS '属性';
COMMENT ON COLUMN `gen_column_property`.`entity_id` IS '实体';
COMMENT ON COLUMN `gen_column_property`.`type` IS '类型';
COMMENT ON COLUMN `gen_column_property`.`column_name` IS '列名';
COMMENT ON COLUMN `gen_column_property`.`jdbc_type_code` IS 'JdbcType 码值';
COMMENT ON COLUMN `gen_column_property`.`raw_type` IS '字面类型';
COMMENT ON COLUMN `gen_column_property`.`type_is_not_null` IS '类型是否非空';
COMMENT ON COLUMN `gen_column_property`.`data_size` IS '长度';
COMMENT ON COLUMN `gen_column_property`.`numeric_precision` IS '精度';
COMMENT ON COLUMN `gen_column_property`.`column_default_exp` IS '列默认表达式';

ALTER TABLE `gen_column_property`
    ADD CONSTRAINT `fk_gen_column_property_entity_id`
        FOREIGN KEY (`entity_id`)
            REFERENCES `gen_entity` (`id`);

ALTER TABLE `gen_column_property`
    ADD CONSTRAINT `fk_gen_column_property_property_id`
        FOREIGN KEY (`property_id`)
            REFERENCES `gen_property` (`id`);

