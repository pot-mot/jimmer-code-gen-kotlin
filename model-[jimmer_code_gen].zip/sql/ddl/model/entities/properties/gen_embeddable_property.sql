DROP TABLE IF EXISTS `gen_embeddable_property` CASCADE;

CREATE TABLE `gen_embeddable_property` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `property_id` INTEGER NOT NULL,
    `entity_id` INTEGER NOT NULL,
    `type_embeddable_id` INTEGER NOT NULL,
    PRIMARY KEY (`id`)
);

CREATE UNIQUE INDEX `key_of_gen_embeddable_property` ON `gen_embeddable_property` (`property_id`);

COMMENT ON TABLE `gen_embeddable_property` IS '复合属性';
COMMENT ON COLUMN `gen_embeddable_property`.`id` IS 'ID';
COMMENT ON COLUMN `gen_embeddable_property`.`property_id` IS '属性';
COMMENT ON COLUMN `gen_embeddable_property`.`entity_id` IS '实体';
COMMENT ON COLUMN `gen_embeddable_property`.`type_embeddable_id` IS '复合类型';

ALTER TABLE `gen_embeddable_property`
    ADD CONSTRAINT `fk_gen_embeddable_property_entity_id`
        FOREIGN KEY (`entity_id`)
            REFERENCES `gen_entity` (`id`);

ALTER TABLE `gen_embeddable_property`
    ADD CONSTRAINT `fk_gen_embeddable_property_property_id`
        FOREIGN KEY (`property_id`)
            REFERENCES `gen_property` (`id`);

ALTER TABLE `gen_embeddable_property`
    ADD CONSTRAINT `fk_gen_embeddable_property_type_embeddable_id`
        FOREIGN KEY (`type_embeddable_id`)
            REFERENCES `gen_embeddable_type` (`id`);

ALTER TABLE `gen_embeddable_property_override`
    ADD CONSTRAINT `fk_gen_embeddable_property_override_embeddable_property_id`
        FOREIGN KEY (`embeddable_property_id`)
            REFERENCES `gen_embeddable_property` (`id`);

