DROP TABLE IF EXISTS `gen_enum_column_property` CASCADE;

CREATE TABLE `gen_enum_column_property` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `property_id` INTEGER NOT NULL,
    `entity_id` INTEGER NOT NULL,
    `type_enum_id` INTEGER NOT NULL,
    `column_name` VARCHAR(255) NOT NULL,
    PRIMARY KEY (`id`)
);

CREATE UNIQUE INDEX `key_of_gen_enum_column_property` ON `gen_enum_column_property` (`property_id`);

COMMENT ON TABLE `gen_enum_column_property` IS '枚举列属性';
COMMENT ON COLUMN `gen_enum_column_property`.`id` IS 'ID';
COMMENT ON COLUMN `gen_enum_column_property`.`property_id` IS '属性';
COMMENT ON COLUMN `gen_enum_column_property`.`entity_id` IS '实体';
COMMENT ON COLUMN `gen_enum_column_property`.`type_enum_id` IS '类型对应枚举';
COMMENT ON COLUMN `gen_enum_column_property`.`column_name` IS '列名';

ALTER TABLE `gen_enum_column_property`
    ADD CONSTRAINT `fk_gen_enum_column_property_entity_id`
        FOREIGN KEY (`entity_id`)
            REFERENCES `gen_entity` (`id`);

ALTER TABLE `gen_enum_column_property`
    ADD CONSTRAINT `fk_gen_enum_column_property_property_id`
        FOREIGN KEY (`property_id`)
            REFERENCES `gen_property` (`id`);

ALTER TABLE `gen_enum_column_property`
    ADD CONSTRAINT `fk_gen_enum_column_property_type_enum_id`
        FOREIGN KEY (`type_enum_id`)
            REFERENCES `gen_enum` (`id`);

