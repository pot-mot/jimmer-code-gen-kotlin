DROP TABLE IF EXISTS `gen_sort_property` CASCADE;

CREATE TABLE `gen_sort_property` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `property_id` INTEGER NOT NULL,
    `entity_id` INTEGER NOT NULL,
    `order_direction` VARCHAR(255) NOT NULL,
    PRIMARY KEY (`id`)
);

CREATE UNIQUE INDEX `key_of_gen_sort_property` ON `gen_sort_property` (`property_id`);

COMMENT ON TABLE `gen_sort_property` IS '排序属性';
COMMENT ON COLUMN `gen_sort_property`.`id` IS 'ID';
COMMENT ON COLUMN `gen_sort_property`.`property_id` IS '属性';
COMMENT ON COLUMN `gen_sort_property`.`entity_id` IS '实体';
COMMENT ON COLUMN `gen_sort_property`.`order_direction` IS '排序方向';

ALTER TABLE `gen_sort_property`
    ADD CONSTRAINT `fk_gen_sort_property_entity_id`
        FOREIGN KEY (`entity_id`)
            REFERENCES `gen_entity` (`id`);

ALTER TABLE `gen_sort_property`
    ADD CONSTRAINT `fk_gen_sort_property_property_id`
        FOREIGN KEY (`property_id`)
            REFERENCES `gen_property` (`id`);

