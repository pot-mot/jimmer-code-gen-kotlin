DROP TABLE IF EXISTS `gen_version_property` CASCADE;

CREATE TABLE `gen_version_property` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `property_id` INTEGER NOT NULL,
    `column_name` VARCHAR(255) NOT NULL,
    PRIMARY KEY (`id`)
);

CREATE UNIQUE INDEX `key_of_gen_version_property` ON `gen_version_property` (`property_id`);

COMMENT ON TABLE `gen_version_property` IS '乐观锁属性';
COMMENT ON COLUMN `gen_version_property`.`id` IS 'ID';
COMMENT ON COLUMN `gen_version_property`.`property_id` IS '属性';
COMMENT ON COLUMN `gen_version_property`.`column_name` IS '列名称';

ALTER TABLE `gen_version_property`
    ADD CONSTRAINT `fk_gen_version_property_property_id`
        FOREIGN KEY (`property_id`)
            REFERENCES `gen_property` (`id`);

ALTER TABLE `gen_entity`
    ADD CONSTRAINT `fk_gen_entity_version_property_id`
        FOREIGN KEY (`version_property_id`)
            REFERENCES `gen_version_property` (`id`);

