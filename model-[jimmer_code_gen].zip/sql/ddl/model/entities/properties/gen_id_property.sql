DROP TABLE IF EXISTS `gen_id_property` CASCADE;

CREATE TABLE `gen_id_property` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `property_id` INTEGER NOT NULL,
    `column_name` VARCHAR(255) NOT NULL,
    `type` CHARACTER VARYING(500) NOT NULL,
    `generated_id_annotation` CHARACTER VARYING(500) DEFAULT NULL,
    `jdbc_type_code` INTEGER NOT NULL,
    `raw_type` CHARACTER VARYING(500) NOT NULL,
    `type_is_not_null` BOOLEAN NOT NULL,
    `data_size` INTEGER DEFAULT NULL,
    `numeric_precision` INTEGER DEFAULT NULL,
    `column_default_exp` CHARACTER VARYING(500) DEFAULT NULL,
    PRIMARY KEY (`id`)
);

CREATE UNIQUE INDEX `key_of_gen_id_property` ON `gen_id_property` (`property_id`);

COMMENT ON TABLE `gen_id_property` IS 'ID属性';
COMMENT ON COLUMN `gen_id_property`.`id` IS 'ID';
COMMENT ON COLUMN `gen_id_property`.`property_id` IS '属性';
COMMENT ON COLUMN `gen_id_property`.`column_name` IS '列名称';
COMMENT ON COLUMN `gen_id_property`.`type` IS '类型';
COMMENT ON COLUMN `gen_id_property`.`generated_id_annotation` IS '生成 ID 注解';
COMMENT ON COLUMN `gen_id_property`.`jdbc_type_code` IS 'JdbcType 码值';
COMMENT ON COLUMN `gen_id_property`.`raw_type` IS '字面类型';
COMMENT ON COLUMN `gen_id_property`.`type_is_not_null` IS '类型是否非空';
COMMENT ON COLUMN `gen_id_property`.`data_size` IS '长度';
COMMENT ON COLUMN `gen_id_property`.`numeric_precision` IS '精度';
COMMENT ON COLUMN `gen_id_property`.`column_default_exp` IS '列默认表达式';

ALTER TABLE `gen_id_property`
    ADD CONSTRAINT `fk_gen_id_property_property_id`
        FOREIGN KEY (`property_id`)
            REFERENCES `gen_property` (`id`);

ALTER TABLE `gen_entity`
    ADD CONSTRAINT `fk_gen_entity_id_property_id`
        FOREIGN KEY (`id_property_id`)
            REFERENCES `gen_id_property` (`id`);

