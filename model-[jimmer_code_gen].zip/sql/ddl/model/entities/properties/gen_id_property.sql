DROP TABLE IF EXISTS `gen_id_property` CASCADE;

CREATE TABLE `gen_id_property` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `property_id` INTEGER NOT NULL,
    `generated_id_annotation` CHARACTER VARYING(500) DEFAULT NULL,
    PRIMARY KEY (`id`)
);

CREATE UNIQUE INDEX `key_of_gen_id_property` ON `gen_id_property` (`property_id`);

COMMENT ON TABLE `gen_id_property` IS 'ID属性';
COMMENT ON COLUMN `gen_id_property`.`id` IS 'ID';
COMMENT ON COLUMN `gen_id_property`.`property_id` IS '属性';
COMMENT ON COLUMN `gen_id_property`.`generated_id_annotation` IS '生成 ID 注解';

ALTER TABLE `gen_id_property`
    ADD CONSTRAINT `fk_gen_id_property_property_id`
        FOREIGN KEY (`property_id`)
            REFERENCES `gen_property` (`id`);

ALTER TABLE `gen_entity`
    ADD CONSTRAINT `fk_gen_entity_id_property_id`
        FOREIGN KEY (`id_property_id`)
            REFERENCES `gen_id_property` (`id`);

