DROP TABLE IF EXISTS `gen_type_pair` CASCADE;

CREATE TABLE `gen_type_pair` (
    `id` BIGINT NOT NULL AUTO_INCREMENT,
    `database_type` CHARACTER VARYING(500) DEFAULT NULL,
    `jdbc_type_code` INTEGER NOT NULL,
    `raw_type` CHARACTER VARYING(500) NOT NULL,
    `default_data_size` INTEGER DEFAULT NULL,
    `default_numeric_precision` INTEGER DEFAULT NULL,
    `language` CHARACTER VARYING(500) DEFAULT NULL,
    `property_type` CHARACTER VARYING(500) NOT NULL,
    `order_key` INTEGER NOT NULL,
    `remark` CHARACTER VARYING(500) NOT NULL,
    PRIMARY KEY (`id`)
);

COMMENT ON TABLE `gen_type_pair` IS '类型对';
COMMENT ON COLUMN `gen_type_pair`.`id` IS 'ID';
COMMENT ON COLUMN `gen_type_pair`.`database_type` IS '数据源类型';
COMMENT ON COLUMN `gen_type_pair`.`jdbc_type_code` IS 'JdbcType 码值';
COMMENT ON COLUMN `gen_type_pair`.`raw_type` IS '字面类型';
COMMENT ON COLUMN `gen_type_pair`.`default_data_size` IS '默认长度';
COMMENT ON COLUMN `gen_type_pair`.`default_numeric_precision` IS '默认精度';
COMMENT ON COLUMN `gen_type_pair`.`language` IS '语言';
COMMENT ON COLUMN `gen_type_pair`.`property_type` IS '属性类型';
COMMENT ON COLUMN `gen_type_pair`.`order_key` IS '排序键';
COMMENT ON COLUMN `gen_type_pair`.`remark` IS '备注';

