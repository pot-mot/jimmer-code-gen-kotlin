DROP TABLE IF EXISTS `gen_type_pair` CASCADE;

CREATE TABLE `gen_type_pair` (
    `id` BIGINT NOT NULL AUTO_INCREMENT,
    `database_type` CHARACTER VARYING(500) NOT NULL,
    `column_type` CHARACTER VARYING(500) NOT NULL,
    `language` CHARACTER VARYING(500) NOT NULL,
    `property_type` CHARACTER VARYING(500) NOT NULL,
    `order_key` INTEGER NOT NULL,
    `remark` CHARACTER VARYING(500) NOT NULL,
    PRIMARY KEY (`id`)
);

COMMENT ON TABLE `gen_type_pair` IS '类型对';
COMMENT ON COLUMN `gen_type_pair`.`id` IS 'ID';
COMMENT ON COLUMN `gen_type_pair`.`database_type` IS '数据源类型';
COMMENT ON COLUMN `gen_type_pair`.`column_type` IS '列类型';
COMMENT ON COLUMN `gen_type_pair`.`language` IS '语言';
COMMENT ON COLUMN `gen_type_pair`.`property_type` IS '属性类型';
COMMENT ON COLUMN `gen_type_pair`.`order_key` IS '排序键';
COMMENT ON COLUMN `gen_type_pair`.`remark` IS '备注';

