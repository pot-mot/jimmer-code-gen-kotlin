DROP TABLE IF EXISTS `gen_embeddable_property` CASCADE;

CREATE TABLE `gen_embeddable_property` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `embeddable_id` INTEGER NOT NULL,
    `name` CHARACTER VARYING(500) NOT NULL,
    `comment` CHARACTER VARYING(500) NOT NULL,
    `type` CHARACTER VARYING(500) NOT NULL,
    `extra_annotations` CHARACTER VARYING(500) DEFAULT NULL,
    `extra_imports` VARCHAR(255) DEFAULT NULL,
    `extra_validations` VARCHAR(255) DEFAULT NULL,
    `remark` CHARACTER VARYING(500) NOT NULL,
    `jdbc_type_code` INTEGER NOT NULL,
    `raw_type` CHARACTER VARYING(500) NOT NULL,
    `type_is_not_null` BOOLEAN NOT NULL,
    `data_size` INTEGER DEFAULT NULL,
    `numeric_precision` INTEGER DEFAULT NULL,
    `column_default_exp` CHARACTER VARYING(500) DEFAULT NULL,
    PRIMARY KEY (`id`)
);

CREATE UNIQUE INDEX `key_of_gen_embeddable_property` ON `gen_embeddable_property` (`embeddable_id`, `name`);

COMMENT ON TABLE `gen_embeddable_property` IS '嵌入类型属性';
COMMENT ON COLUMN `gen_embeddable_property`.`id` IS 'ID';
COMMENT ON COLUMN `gen_embeddable_property`.`embeddable_id` IS '嵌入类型';
COMMENT ON COLUMN `gen_embeddable_property`.`name` IS '名称';
COMMENT ON COLUMN `gen_embeddable_property`.`comment` IS '注释';
COMMENT ON COLUMN `gen_embeddable_property`.`type` IS '类型';
COMMENT ON COLUMN `gen_embeddable_property`.`extra_annotations` IS '其他注解';
COMMENT ON COLUMN `gen_embeddable_property`.`extra_imports` IS '其他导入';
COMMENT ON COLUMN `gen_embeddable_property`.`extra_validations` IS '其他验证器';
COMMENT ON COLUMN `gen_embeddable_property`.`remark` IS '备注';
COMMENT ON COLUMN `gen_embeddable_property`.`jdbc_type_code` IS 'JdbcType 码值';
COMMENT ON COLUMN `gen_embeddable_property`.`raw_type` IS '字面类型';
COMMENT ON COLUMN `gen_embeddable_property`.`type_is_not_null` IS '类型是否非空';
COMMENT ON COLUMN `gen_embeddable_property`.`data_size` IS '长度';
COMMENT ON COLUMN `gen_embeddable_property`.`numeric_precision` IS '精度';
COMMENT ON COLUMN `gen_embeddable_property`.`column_default_exp` IS '列默认表达式';

ALTER TABLE `gen_embeddable_property`
    ADD CONSTRAINT `fk_gen_embeddable_property_embeddable_type_id`
        FOREIGN KEY (`embeddable_id`)
            REFERENCES `gen_embeddable` (`id`);

