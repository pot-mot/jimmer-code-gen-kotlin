DROP TABLE IF EXISTS `gen_embeddable_deep_property` CASCADE;

CREATE TABLE `gen_embeddable_deep_property` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `embeddable_id` INTEGER NOT NULL,
    `name` CHARACTER VARYING(500) NOT NULL,
    `comment` CHARACTER VARYING(500) NOT NULL,
    `type_embeddable_id` INTEGER NOT NULL,
    `extra_annotations` CHARACTER VARYING(500) DEFAULT NULL,
    `extra_imports` VARCHAR(255) DEFAULT NULL,
    `extra_validations` VARCHAR(255) DEFAULT NULL,
    `remark` CHARACTER VARYING(500) NOT NULL,
    PRIMARY KEY (`id`)
);

CREATE UNIQUE INDEX `key_of_gen_embeddable_deep_property` ON `gen_embeddable_deep_property` (`embeddable_id`, `name`);

COMMENT ON TABLE `gen_embeddable_deep_property` IS '嵌入类型深层属性';
COMMENT ON COLUMN `gen_embeddable_deep_property`.`id` IS 'ID';
COMMENT ON COLUMN `gen_embeddable_deep_property`.`embeddable_id` IS '嵌入类型';
COMMENT ON COLUMN `gen_embeddable_deep_property`.`name` IS '名称';
COMMENT ON COLUMN `gen_embeddable_deep_property`.`comment` IS '注释';
COMMENT ON COLUMN `gen_embeddable_deep_property`.`type_embeddable_id` IS '类型对应嵌入类型';
COMMENT ON COLUMN `gen_embeddable_deep_property`.`extra_annotations` IS '其他注解';
COMMENT ON COLUMN `gen_embeddable_deep_property`.`extra_imports` IS '其他导入';
COMMENT ON COLUMN `gen_embeddable_deep_property`.`extra_validations` IS '其他验证器';
COMMENT ON COLUMN `gen_embeddable_deep_property`.`remark` IS '备注';

ALTER TABLE `gen_embeddable_deep_property`
    ADD CONSTRAINT `fk_gen_embeddable_deep_property_embeddable_id`
        FOREIGN KEY (`embeddable_id`)
            REFERENCES `gen_embeddable` (`id`);

ALTER TABLE `gen_embeddable_deep_property`
    ADD CONSTRAINT `fk_gen_embeddable_deep_property_type_embeddable_id`
        FOREIGN KEY (`type_embeddable_id`)
            REFERENCES `gen_embeddable` (`id`);

