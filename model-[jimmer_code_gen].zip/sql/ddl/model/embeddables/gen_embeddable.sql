DROP TABLE IF EXISTS `gen_embeddable` CASCADE;

CREATE TABLE `gen_embeddable` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `group_id` INTEGER NOT NULL,
    `name` VARCHAR(255) NOT NULL,
    `sub_package_path` CHARACTER VARYING(500) NOT NULL,
    `comment` VARCHAR(255) NOT NULL,
    PRIMARY KEY (`id`)
);

CREATE UNIQUE INDEX `key_of_gen_embeddable` ON `gen_embeddable` (`group_id`, `name`);

COMMENT ON TABLE `gen_embeddable` IS '嵌入类型';
COMMENT ON COLUMN `gen_embeddable`.`id` IS 'ID';
COMMENT ON COLUMN `gen_embeddable`.`group_id` IS '分组';
COMMENT ON COLUMN `gen_embeddable`.`name` IS '名称';
COMMENT ON COLUMN `gen_embeddable`.`sub_package_path` IS '子包路径';
COMMENT ON COLUMN `gen_embeddable`.`comment` IS '注释';

ALTER TABLE `gen_embeddable`
    ADD CONSTRAINT `fk_gen_embeddable_group_id`
        FOREIGN KEY (`group_id`)
            REFERENCES `gen_model_group` (`id`);

ALTER TABLE `gen_embeddable_deep_property`
    ADD CONSTRAINT `fk_gen_embeddable_deep_property_embeddable_id`
        FOREIGN KEY (`embeddable_id`)
            REFERENCES `gen_embeddable` (`id`);

ALTER TABLE `gen_embeddable_deep_property`
    ADD CONSTRAINT `fk_gen_embeddable_deep_property_type_embeddable_id`
        FOREIGN KEY (`type_embeddable_id`)
            REFERENCES `gen_embeddable` (`id`);

ALTER TABLE `gen_embeddable_property`
    ADD CONSTRAINT `fk_gen_embeddable_property_embeddable_type_id`
        FOREIGN KEY (`embeddable_id`)
            REFERENCES `gen_embeddable` (`id`);

ALTER TABLE `gen_extra_property`
    ADD CONSTRAINT `fk_gen_extra_property_type_embeddable_id`
        FOREIGN KEY (`type_embeddable_id`)
            REFERENCES `gen_embeddable` (`id`);

ALTER TABLE `gen_scalar_property`
    ADD CONSTRAINT `fk_gen_scalar_property_type_embeddable_id`
        FOREIGN KEY (`type_embeddable_id`)
            REFERENCES `gen_embeddable` (`id`);

