DROP TABLE IF EXISTS `gen_embeddable_type_property` CASCADE;

CREATE TABLE `gen_embeddable_type_property` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `embeddable_id` INTEGER NOT NULL,
    `name` CHARACTER VARYING(500) NOT NULL,
    `comment` CHARACTER VARYING(500) NOT NULL,
    `extra_annotations` CHARACTER VARYING(500) DEFAULT NULL,
    `extra_imports` VARCHAR(255) DEFAULT NULL,
    `extra_validations` VARCHAR(255) DEFAULT NULL,
    `remark` CHARACTER VARYING(500) NOT NULL,
    `order_key` INTEGER NOT NULL,
    `raw_type` CHARACTER VARYING(500) DEFAULT NULL,
    `type_enum_id` INTEGER DEFAULT NULL,
    `type_embeddable_id` INTEGER DEFAULT NULL,
    `column_info_id` INTEGER DEFAULT NULL,
    PRIMARY KEY (`id`)
);

CREATE UNIQUE INDEX `key_of_gen_embeddable_type_property` ON `gen_embeddable_type_property` (`embeddable_id`, `name`);

COMMENT ON TABLE `gen_embeddable_type_property` IS '复合类型属性';
COMMENT ON COLUMN `gen_embeddable_type_property`.`id` IS 'ID';
COMMENT ON COLUMN `gen_embeddable_type_property`.`embeddable_id` IS '嵌入类型';
COMMENT ON COLUMN `gen_embeddable_type_property`.`name` IS '名称';
COMMENT ON COLUMN `gen_embeddable_type_property`.`comment` IS '注释';
COMMENT ON COLUMN `gen_embeddable_type_property`.`extra_annotations` IS '其他注解';
COMMENT ON COLUMN `gen_embeddable_type_property`.`extra_imports` IS '其他导入';
COMMENT ON COLUMN `gen_embeddable_type_property`.`extra_validations` IS '其他验证器';
COMMENT ON COLUMN `gen_embeddable_type_property`.`remark` IS '备注';
COMMENT ON COLUMN `gen_embeddable_type_property`.`order_key` IS '排序键';
COMMENT ON COLUMN `gen_embeddable_type_property`.`raw_type` IS '字面类型';
COMMENT ON COLUMN `gen_embeddable_type_property`.`type_enum_id` IS '类型对应枚举';
COMMENT ON COLUMN `gen_embeddable_type_property`.`type_embeddable_id` IS '类型对应嵌入';
COMMENT ON COLUMN `gen_embeddable_type_property`.`column_info_id` IS '列信息';

ALTER TABLE `gen_embeddable_type_property`
    ADD CONSTRAINT `fk_gen_embeddable_type_property_embeddable_type_id`
        FOREIGN KEY (`embeddable_id`)
            REFERENCES `gen_embeddable_type` (`id`);

ALTER TABLE `gen_embeddable_type_property`
    ADD CONSTRAINT `fk_gen_embeddable_type_property_column_info_id`
        FOREIGN KEY (`column_info_id`)
            REFERENCES `gen_column_info` (`id`);

ALTER TABLE `gen_embeddable_type_property`
    ADD CONSTRAINT `fk_gen_embeddable_type_property_type_embeddable_id`
        FOREIGN KEY (`type_embeddable_id`)
            REFERENCES `gen_embeddable_type` (`id`);

ALTER TABLE `gen_embeddable_type_property`
    ADD CONSTRAINT `fk_gen_embeddable_type_property_type_enum_id`
        FOREIGN KEY (`type_enum_id`)
            REFERENCES `gen_enum` (`id`);

