DROP TABLE IF EXISTS `gen_deep_embeddable_property_override` CASCADE;

CREATE TABLE `gen_deep_embeddable_property_override` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `deep_property_id` INTEGER NOT NULL,
    `override_property_id` INTEGER NOT NULL,
    `column_name` VARCHAR(255) NOT NULL,
    PRIMARY KEY (`id`)
);

CREATE UNIQUE INDEX `key_of_gen_deep_embeddable_property_override` ON `gen_deep_embeddable_property_override` (`deep_property_id`, `override_property_id`);

COMMENT ON TABLE `gen_deep_embeddable_property_override` IS '深层复合属性列覆盖';
COMMENT ON COLUMN `gen_deep_embeddable_property_override`.`id` IS 'ID';
COMMENT ON COLUMN `gen_deep_embeddable_property_override`.`deep_property_id` IS '深层属性';
COMMENT ON COLUMN `gen_deep_embeddable_property_override`.`override_property_id` IS '覆盖属性';
COMMENT ON COLUMN `gen_deep_embeddable_property_override`.`column_name` IS '覆盖后列名';

ALTER TABLE `gen_deep_embeddable_property_override`
    ADD CONSTRAINT `fk_gen_deep_embeddable_property_override_deep_embeddable_property_id`
        FOREIGN KEY (`deep_property_id`)
            REFERENCES `gen_embeddable_type_deep_property` (`id`);

ALTER TABLE `gen_deep_embeddable_property_override`
    ADD CONSTRAINT `fk_gen_deep_embeddable_property_override_property_id`
        FOREIGN KEY (`override_property_id`)
            REFERENCES `gen_embeddable_type_property` (`id`);

