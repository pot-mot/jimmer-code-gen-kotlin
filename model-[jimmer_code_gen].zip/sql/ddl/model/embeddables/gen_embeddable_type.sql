DROP TABLE IF EXISTS `gen_embeddable_type` CASCADE;

CREATE TABLE `gen_embeddable_type` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `group_id` INTEGER NOT NULL,
    `name` VARCHAR(255) NOT NULL,
    `sub_package_path` CHARACTER VARYING(500) NOT NULL,
    `comment` VARCHAR(255) NOT NULL,
    PRIMARY KEY (`id`)
);

CREATE UNIQUE INDEX `key_of_gen_embeddable_type` ON `gen_embeddable_type` (`group_id`, `name`);

COMMENT ON TABLE `gen_embeddable_type` IS '复合类型';
COMMENT ON COLUMN `gen_embeddable_type`.`id` IS 'ID';
COMMENT ON COLUMN `gen_embeddable_type`.`group_id` IS '分组';
COMMENT ON COLUMN `gen_embeddable_type`.`name` IS '名称';
COMMENT ON COLUMN `gen_embeddable_type`.`sub_package_path` IS '子包路径';
COMMENT ON COLUMN `gen_embeddable_type`.`comment` IS '注释';

ALTER TABLE `gen_embeddable_type`
    ADD CONSTRAINT `fk_gen_embeddable_type_group_id`
        FOREIGN KEY (`group_id`)
            REFERENCES `gen_model_group` (`id`);

ALTER TABLE `gen_embeddable_property`
    ADD CONSTRAINT `fk_gen_embeddable_property_type_embeddable_id`
        FOREIGN KEY (`type_embeddable_id`)
            REFERENCES `gen_embeddable_type` (`id`);

ALTER TABLE `gen_embeddable_type_deep_property`
    ADD CONSTRAINT `fk_gen_embeddable_type_deep_property_embeddable_id`
        FOREIGN KEY (`embeddable_id`)
            REFERENCES `gen_embeddable_type` (`id`);

ALTER TABLE `gen_embeddable_type_deep_property`
    ADD CONSTRAINT `fk_gen_embeddable_type_deep_property_type_embeddable_id`
        FOREIGN KEY (`type_embeddable_id`)
            REFERENCES `gen_embeddable_type` (`id`);

ALTER TABLE `gen_embeddable_type_property`
    ADD CONSTRAINT `fk_gen_embeddable_type_property_embeddable_type_id`
        FOREIGN KEY (`embeddable_id`)
            REFERENCES `gen_embeddable_type` (`id`);

