DROP TABLE IF EXISTS `gen_model_config` CASCADE;

CREATE TABLE `gen_model_config` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `model_id` INTEGER NOT NULL,
    `base_package_path` CHARACTER VARYING(500) NOT NULL,
    `base_table_path` CHARACTER VARYING(500) NOT NULL,
    `default_dissociate_action` CHARACTER VARYING(500) NOT NULL,
    `default_use_real_fk` BOOLEAN NOT NULL,
    `default_id_type` INTEGER NOT NULL,
    `default_generated_id_annotation` CHARACTER VARYING(500) NOT NULL,
    `default_logical_deleted_annotation` CHARACTER VARYING(500) NOT NULL,
    `generate_table_annotation` BOOLEAN NOT NULL,
    `generate_column_annotation` BOOLEAN NOT NULL,
    `table_to_entity_removed_name_prefixes` CHARACTER VARYING(500) NOT NULL,
    `table_to_entity_removed_name_suffixes` CHARACTER VARYING(500) NOT NULL,
    `table_to_entity_removed_comment_prefixes` CHARACTER VARYING(500) NOT NULL,
    `table_to_entity_removed_comment_suffixes` CHARACTER VARYING(500) NOT NULL,
    `column_to_property_removed_name_prefixes` CHARACTER VARYING(500) NOT NULL,
    `column_to_property_removed_name_suffixes` CHARACTER VARYING(500) NOT NULL,
    `column_to_property_removed_comment_prefixes` CHARACTER VARYING(500) NOT NULL,
    `column_to_property_removed_comment_suffixes` CHARACTER VARYING(500) NOT NULL,
    `remark` CHARACTER VARYING(500) NOT NULL,
    PRIMARY KEY (`id`)
);

CREATE UNIQUE INDEX `key_of_gen_model_config` ON `gen_model_config` (`model_id`);

COMMENT ON TABLE `gen_model_config` IS '模型配置';
COMMENT ON COLUMN `gen_model_config`.`id` IS 'ID';
COMMENT ON COLUMN `gen_model_config`.`model_id` IS '模型';
COMMENT ON COLUMN `gen_model_config`.`base_package_path` IS '基础包路径';
COMMENT ON COLUMN `gen_model_config`.`base_table_path` IS '基础表路径';
COMMENT ON COLUMN `gen_model_config`.`default_dissociate_action` IS '默认脱钩行为';
COMMENT ON COLUMN `gen_model_config`.`default_use_real_fk` IS '默认使用真实外键';
COMMENT ON COLUMN `gen_model_config`.`default_id_type` IS '默认ID类型';
COMMENT ON COLUMN `gen_model_config`.`default_generated_id_annotation` IS '默认ID生成注解';
COMMENT ON COLUMN `gen_model_config`.`default_logical_deleted_annotation` IS '默认逻辑删除注解';
COMMENT ON COLUMN `gen_model_config`.`generate_table_annotation` IS '生成 Table 注解';
COMMENT ON COLUMN `gen_model_config`.`generate_column_annotation` IS '生成 Column 注解';
COMMENT ON COLUMN `gen_model_config`.`table_to_entity_removed_name_prefixes` IS '表转换实体时移除的表名前缀';
COMMENT ON COLUMN `gen_model_config`.`table_to_entity_removed_name_suffixes` IS '表转换实体时移除的表名后缀';
COMMENT ON COLUMN `gen_model_config`.`table_to_entity_removed_comment_prefixes` IS '表转换实体时移除的表注释前缀';
COMMENT ON COLUMN `gen_model_config`.`table_to_entity_removed_comment_suffixes` IS '表转换实体时移除的表注释后缀';
COMMENT ON COLUMN `gen_model_config`.`column_to_property_removed_name_prefixes` IS '列转换属性时移除的列名前缀';
COMMENT ON COLUMN `gen_model_config`.`column_to_property_removed_name_suffixes` IS '转换属性时移除的列名后缀';
COMMENT ON COLUMN `gen_model_config`.`column_to_property_removed_comment_prefixes` IS '转换属性时移除的列注释前缀';
COMMENT ON COLUMN `gen_model_config`.`column_to_property_removed_comment_suffixes` IS '转换属性时移除的列注释后缀';
COMMENT ON COLUMN `gen_model_config`.`remark` IS '备注';

ALTER TABLE `gen_model_config`
    ADD CONSTRAINT `fk_gen_model_config_model_id`
        FOREIGN KEY (`model_id`)
            REFERENCES `gen_model` (`id`);

