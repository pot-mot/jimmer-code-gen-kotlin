DROP TABLE IF EXISTS `gen_model_group` CASCADE;

CREATE TABLE `gen_model_group` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `model_id` INTEGER NOT NULL,
    `name` CHARACTER VARYING(500) NOT NULL,
    `comment` CHARACTER VARYING(500) NOT NULL,
    `package_path` CHARACTER VARYING(500) NOT NULL,
    `table_path` CHARACTER VARYING(500) NOT NULL,
    `color` CHARACTER VARYING(1000000000) NOT NULL,
    `order_key` INTEGER NOT NULL,
    PRIMARY KEY (`id`)
);

CREATE UNIQUE INDEX `key_of_gen_model_group` ON `gen_model_group` (`model_id`, `name`);

COMMENT ON TABLE `gen_model_group` IS '模型分组';
COMMENT ON COLUMN `gen_model_group`.`id` IS 'ID';
COMMENT ON COLUMN `gen_model_group`.`model_id` IS '模型';
COMMENT ON COLUMN `gen_model_group`.`name` IS '名称';
COMMENT ON COLUMN `gen_model_group`.`comment` IS '注释';
COMMENT ON COLUMN `gen_model_group`.`package_path` IS '包路径';
COMMENT ON COLUMN `gen_model_group`.`table_path` IS '表路径';
COMMENT ON COLUMN `gen_model_group`.`color` IS '颜色';
COMMENT ON COLUMN `gen_model_group`.`order_key` IS '排序键';

ALTER TABLE `gen_model_group`
    ADD CONSTRAINT `fk_gen_model_group_model_id`
        FOREIGN KEY (`model_id`)
            REFERENCES `gen_model` (`id`)
                ON UPDATE restrict
                ON DELETE restrict;

ALTER TABLE `gen_embeddable_type`
    ADD CONSTRAINT `fk_gen_embeddable_type_group_id`
        FOREIGN KEY (`group_id`)
            REFERENCES `gen_model_group` (`id`);

ALTER TABLE `gen_entity`
    ADD CONSTRAINT `fk_gen_entity_group_id`
        FOREIGN KEY (`group_id`)
            REFERENCES `gen_model_group` (`id`);

ALTER TABLE `gen_enum`
    ADD CONSTRAINT `fk_gen_enum_group_id`
        FOREIGN KEY (`group_id`)
            REFERENCES `gen_model_group` (`id`)
                ON UPDATE restrict
                ON DELETE restrict;

