DROP TABLE IF EXISTS `gen_enum_item` CASCADE;

CREATE TABLE `gen_enum_item` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `enum_id` INTEGER NOT NULL,
    `name` CHARACTER VARYING(500) NOT NULL,
    `mapped_value` CHARACTER VARYING(500) NOT NULL,
    `comment` CHARACTER VARYING(500) NOT NULL,
    `default_item` BOOLEAN NOT NULL,
    `remark` CHARACTER VARYING(500) NOT NULL,
    `order_key` INTEGER NOT NULL,
    PRIMARY KEY (`id`)
);

CREATE INDEX `fk_enum_item_enum_INDEX_A` ON `gen_enum_item` (`enum_id`);
CREATE INDEX `idx_enum_item_enum` ON `gen_enum_item` (`enum_id`);
CREATE UNIQUE INDEX `key_of_gen_enum_item` ON `gen_enum_item` (`enum_id`, `name`);

COMMENT ON TABLE `gen_enum_item` IS '枚举元素';
COMMENT ON COLUMN `gen_enum_item`.`id` IS 'ID';
COMMENT ON COLUMN `gen_enum_item`.`enum_id` IS '枚举';
COMMENT ON COLUMN `gen_enum_item`.`name` IS '名称';
COMMENT ON COLUMN `gen_enum_item`.`mapped_value` IS '值';
COMMENT ON COLUMN `gen_enum_item`.`comment` IS '注释';
COMMENT ON COLUMN `gen_enum_item`.`default_item` IS '是否默认';
COMMENT ON COLUMN `gen_enum_item`.`remark` IS '备注';
COMMENT ON COLUMN `gen_enum_item`.`order_key` IS '排序键';

ALTER TABLE `gen_enum_item`
    ADD CONSTRAINT `fk_enum_item_enum`
        FOREIGN KEY (`enum_id`)
            REFERENCES `gen_enum` (`id`)
                ON UPDATE restrict
                ON DELETE restrict;

