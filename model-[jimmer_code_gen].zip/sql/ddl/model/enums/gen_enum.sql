DROP TABLE IF EXISTS `gen_enum` CASCADE;

CREATE TABLE `gen_enum` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `group_id` INTEGER NOT NULL,
    `name` CHARACTER VARYING(500) NOT NULL,
    `comment` CHARACTER VARYING(500) NOT NULL,
    `enum_type` CHARACTER VARYING(500) NOT NULL,
    `sub_package_path` CHARACTER VARYING(500) NOT NULL,
    `remark` CHARACTER VARYING(500) NOT NULL,
    PRIMARY KEY (`id`)
);

CREATE UNIQUE INDEX `key_of_gen_enum` ON `gen_enum` (`group_id`, `name`);

COMMENT ON TABLE `gen_enum` IS '枚举';
COMMENT ON COLUMN `gen_enum`.`id` IS 'ID';
COMMENT ON COLUMN `gen_enum`.`group_id` IS '分组';
COMMENT ON COLUMN `gen_enum`.`name` IS '枚举名';
COMMENT ON COLUMN `gen_enum`.`comment` IS '枚举注释';
COMMENT ON COLUMN `gen_enum`.`enum_type` IS '枚举类型';
COMMENT ON COLUMN `gen_enum`.`sub_package_path` IS '子包路径';
COMMENT ON COLUMN `gen_enum`.`remark` IS '备注';

ALTER TABLE `gen_enum`
    ADD CONSTRAINT `fk_gen_enum_group_id`
        FOREIGN KEY (`group_id`)
            REFERENCES `gen_model_group` (`id`)
                ON UPDATE restrict
                ON DELETE restrict;

ALTER TABLE `gen_enum_item`
    ADD CONSTRAINT `fk_enum_item_enum`
        FOREIGN KEY (`enum_id`)
            REFERENCES `gen_enum` (`id`)
                ON UPDATE restrict
                ON DELETE restrict;

ALTER TABLE `gen_extra_property`
    ADD CONSTRAINT `fk_gen_extra_property_type_enum_id`
        FOREIGN KEY (`type_enum_id`)
            REFERENCES `gen_enum` (`id`);

ALTER TABLE `gen_logical_delete_property`
    ADD CONSTRAINT `fk_gen_logical_delete_property_type_enum_id`
        FOREIGN KEY (`type_enum_id`)
            REFERENCES `gen_enum` (`id`);

ALTER TABLE `gen_scalar_property`
    ADD CONSTRAINT `fk_gen_scalar_property_type_enum_id`
        FOREIGN KEY (`type_enum_id`)
            REFERENCES `gen_enum` (`id`);

