
DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'group__model_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'group__model_manager'
);

DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:menu')
);

DELETE FROM sys_permission
WHERE name IN ('model:menu');

DELETE FROM sys_role
WHERE name = 'group__model_manager';

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('group__model_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'group__model_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:menu', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__model_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:menu');



DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'group__entities_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'group__entities_manager'
);

DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('entities:menu')
);

DELETE FROM sys_permission
WHERE name IN ('entities:menu');

DELETE FROM sys_role
WHERE name = 'group__entities_manager';

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('group__entities_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'group__entities_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('entities:menu', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__entities_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('entities:menu');



DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'group__enums_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'group__enums_manager'
);

DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('enums:menu')
);

DELETE FROM sys_permission
WHERE name IN ('enums:menu');

DELETE FROM sys_role
WHERE name = 'group__enums_manager';

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('group__enums_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'group__enums_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('enums:menu', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__enums_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('enums:menu');



DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'group__database_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'group__database_manager'
);

DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('database:menu')
);

DELETE FROM sys_permission
WHERE name IN ('database:menu');

DELETE FROM sys_role
WHERE name = 'group__database_manager';

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('group__database_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'group__database_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:menu', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__database_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('database:menu');



DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'group__associations_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'group__associations_manager'
);

DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('associations:menu')
);

DELETE FROM sys_permission
WHERE name IN ('associations:menu');

DELETE FROM sys_role
WHERE name = 'group__associations_manager';

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('group__associations_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'group__associations_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('associations:menu', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__associations_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('associations:menu');



DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'group__properties_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'group__properties_manager'
);

DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('properties:menu')
);

DELETE FROM sys_permission
WHERE name IN ('properties:menu');

DELETE FROM sys_role
WHERE name = 'group__properties_manager';

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('group__properties_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'group__properties_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('properties:menu', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__properties_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('properties:menu');



DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'group__embeddables_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'group__embeddables_manager'
);

DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('embeddables:menu')
);

DELETE FROM sys_permission
WHERE name IN ('embeddables:menu');

DELETE FROM sys_role
WHERE name = 'group__embeddables_manager';

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('group__embeddables_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'group__embeddables_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('embeddables:menu', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__embeddables_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('embeddables:menu');


DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'dbDataSource_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'dbDataSource_manager'
);

DELETE FROM sys_role
WHERE name = 'dbDataSource_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('database:dbDataSource:get', 'database:dbDataSource:list', 'database:dbDataSource:select', 'database:dbDataSource:menu', 'database:dbDataSource:insert', 'database:dbDataSource:update', 'database:dbDataSource:delete')
);

DELETE FROM sys_permission
WHERE name IN ('database:dbDataSource:get', 'database:dbDataSource:list', 'database:dbDataSource:select', 'database:dbDataSource:menu', 'database:dbDataSource:insert', 'database:dbDataSource:update', 'database:dbDataSource:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('dbDataSource_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'dbDataSource_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbDataSource:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbDataSource:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbDataSource:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbDataSource:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbDataSource:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbDataSource:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbDataSource:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'dbDataSource_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('database:dbDataSource:get', 'database:dbDataSource:list', 'database:dbDataSource:select', 'database:dbDataSource:menu', 'database:dbDataSource:insert', 'database:dbDataSource:update', 'database:dbDataSource:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__database_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('database:dbDataSource:get', 'database:dbDataSource:list', 'database:dbDataSource:select', 'database:dbDataSource:menu', 'database:dbDataSource:insert', 'database:dbDataSource:update', 'database:dbDataSource:delete');
DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'dbForeignKey_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'dbForeignKey_manager'
);

DELETE FROM sys_role
WHERE name = 'dbForeignKey_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('database:dbForeignKey:get', 'database:dbForeignKey:list', 'database:dbForeignKey:select', 'database:dbForeignKey:menu', 'database:dbForeignKey:insert', 'database:dbForeignKey:update', 'database:dbForeignKey:delete')
);

DELETE FROM sys_permission
WHERE name IN ('database:dbForeignKey:get', 'database:dbForeignKey:list', 'database:dbForeignKey:select', 'database:dbForeignKey:menu', 'database:dbForeignKey:insert', 'database:dbForeignKey:update', 'database:dbForeignKey:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('dbForeignKey_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'dbForeignKey_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbForeignKey:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbForeignKey:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbForeignKey:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbForeignKey:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbForeignKey:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbForeignKey:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbForeignKey:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'dbForeignKey_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('database:dbForeignKey:get', 'database:dbForeignKey:list', 'database:dbForeignKey:select', 'database:dbForeignKey:menu', 'database:dbForeignKey:insert', 'database:dbForeignKey:update', 'database:dbForeignKey:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__database_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('database:dbForeignKey:get', 'database:dbForeignKey:list', 'database:dbForeignKey:select', 'database:dbForeignKey:menu', 'database:dbForeignKey:insert', 'database:dbForeignKey:update', 'database:dbForeignKey:delete');
DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'dbForeignKeyColumnReference_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'dbForeignKeyColumnReference_manager'
);

DELETE FROM sys_role
WHERE name = 'dbForeignKeyColumnReference_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('database:dbForeignKeyColumnReference:get', 'database:dbForeignKeyColumnReference:list', 'database:dbForeignKeyColumnReference:select', 'database:dbForeignKeyColumnReference:menu', 'database:dbForeignKeyColumnReference:insert', 'database:dbForeignKeyColumnReference:update', 'database:dbForeignKeyColumnReference:delete')
);

DELETE FROM sys_permission
WHERE name IN ('database:dbForeignKeyColumnReference:get', 'database:dbForeignKeyColumnReference:list', 'database:dbForeignKeyColumnReference:select', 'database:dbForeignKeyColumnReference:menu', 'database:dbForeignKeyColumnReference:insert', 'database:dbForeignKeyColumnReference:update', 'database:dbForeignKeyColumnReference:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('dbForeignKeyColumnReference_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'dbForeignKeyColumnReference_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbForeignKeyColumnReference:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbForeignKeyColumnReference:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbForeignKeyColumnReference:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbForeignKeyColumnReference:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbForeignKeyColumnReference:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbForeignKeyColumnReference:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbForeignKeyColumnReference:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'dbForeignKeyColumnReference_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('database:dbForeignKeyColumnReference:get', 'database:dbForeignKeyColumnReference:list', 'database:dbForeignKeyColumnReference:select', 'database:dbForeignKeyColumnReference:menu', 'database:dbForeignKeyColumnReference:insert', 'database:dbForeignKeyColumnReference:update', 'database:dbForeignKeyColumnReference:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__database_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('database:dbForeignKeyColumnReference:get', 'database:dbForeignKeyColumnReference:list', 'database:dbForeignKeyColumnReference:select', 'database:dbForeignKeyColumnReference:menu', 'database:dbForeignKeyColumnReference:insert', 'database:dbForeignKeyColumnReference:update', 'database:dbForeignKeyColumnReference:delete');
DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'dbPrimaryKey_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'dbPrimaryKey_manager'
);

DELETE FROM sys_role
WHERE name = 'dbPrimaryKey_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('database:dbPrimaryKey:get', 'database:dbPrimaryKey:list', 'database:dbPrimaryKey:select', 'database:dbPrimaryKey:menu', 'database:dbPrimaryKey:insert', 'database:dbPrimaryKey:update', 'database:dbPrimaryKey:delete')
);

DELETE FROM sys_permission
WHERE name IN ('database:dbPrimaryKey:get', 'database:dbPrimaryKey:list', 'database:dbPrimaryKey:select', 'database:dbPrimaryKey:menu', 'database:dbPrimaryKey:insert', 'database:dbPrimaryKey:update', 'database:dbPrimaryKey:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('dbPrimaryKey_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'dbPrimaryKey_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbPrimaryKey:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbPrimaryKey:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbPrimaryKey:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbPrimaryKey:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbPrimaryKey:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbPrimaryKey:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbPrimaryKey:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'dbPrimaryKey_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('database:dbPrimaryKey:get', 'database:dbPrimaryKey:list', 'database:dbPrimaryKey:select', 'database:dbPrimaryKey:menu', 'database:dbPrimaryKey:insert', 'database:dbPrimaryKey:update', 'database:dbPrimaryKey:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__database_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('database:dbPrimaryKey:get', 'database:dbPrimaryKey:list', 'database:dbPrimaryKey:select', 'database:dbPrimaryKey:menu', 'database:dbPrimaryKey:insert', 'database:dbPrimaryKey:update', 'database:dbPrimaryKey:delete');
DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'dbSchema_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'dbSchema_manager'
);

DELETE FROM sys_role
WHERE name = 'dbSchema_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('database:dbSchema:get', 'database:dbSchema:list', 'database:dbSchema:select', 'database:dbSchema:menu', 'database:dbSchema:insert', 'database:dbSchema:update', 'database:dbSchema:delete')
);

DELETE FROM sys_permission
WHERE name IN ('database:dbSchema:get', 'database:dbSchema:list', 'database:dbSchema:select', 'database:dbSchema:menu', 'database:dbSchema:insert', 'database:dbSchema:update', 'database:dbSchema:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('dbSchema_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'dbSchema_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbSchema:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbSchema:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbSchema:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbSchema:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbSchema:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbSchema:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbSchema:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'dbSchema_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('database:dbSchema:get', 'database:dbSchema:list', 'database:dbSchema:select', 'database:dbSchema:menu', 'database:dbSchema:insert', 'database:dbSchema:update', 'database:dbSchema:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__database_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('database:dbSchema:get', 'database:dbSchema:list', 'database:dbSchema:select', 'database:dbSchema:menu', 'database:dbSchema:insert', 'database:dbSchema:update', 'database:dbSchema:delete');
DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'dbTable_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'dbTable_manager'
);

DELETE FROM sys_role
WHERE name = 'dbTable_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('database:dbTable:get', 'database:dbTable:list', 'database:dbTable:select', 'database:dbTable:menu', 'database:dbTable:insert', 'database:dbTable:update', 'database:dbTable:delete')
);

DELETE FROM sys_permission
WHERE name IN ('database:dbTable:get', 'database:dbTable:list', 'database:dbTable:select', 'database:dbTable:menu', 'database:dbTable:insert', 'database:dbTable:update', 'database:dbTable:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('dbTable_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'dbTable_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbTable:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbTable:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbTable:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbTable:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbTable:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbTable:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbTable:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'dbTable_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('database:dbTable:get', 'database:dbTable:list', 'database:dbTable:select', 'database:dbTable:menu', 'database:dbTable:insert', 'database:dbTable:update', 'database:dbTable:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__database_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('database:dbTable:get', 'database:dbTable:list', 'database:dbTable:select', 'database:dbTable:menu', 'database:dbTable:insert', 'database:dbTable:update', 'database:dbTable:delete');
DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'dbTableColumn_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'dbTableColumn_manager'
);

DELETE FROM sys_role
WHERE name = 'dbTableColumn_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('database:dbTableColumn:get', 'database:dbTableColumn:list', 'database:dbTableColumn:select', 'database:dbTableColumn:menu', 'database:dbTableColumn:insert', 'database:dbTableColumn:update', 'database:dbTableColumn:delete')
);

DELETE FROM sys_permission
WHERE name IN ('database:dbTableColumn:get', 'database:dbTableColumn:list', 'database:dbTableColumn:select', 'database:dbTableColumn:menu', 'database:dbTableColumn:insert', 'database:dbTableColumn:update', 'database:dbTableColumn:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('dbTableColumn_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'dbTableColumn_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbTableColumn:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbTableColumn:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbTableColumn:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbTableColumn:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbTableColumn:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbTableColumn:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbTableColumn:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'dbTableColumn_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('database:dbTableColumn:get', 'database:dbTableColumn:list', 'database:dbTableColumn:select', 'database:dbTableColumn:menu', 'database:dbTableColumn:insert', 'database:dbTableColumn:update', 'database:dbTableColumn:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__database_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('database:dbTableColumn:get', 'database:dbTableColumn:list', 'database:dbTableColumn:select', 'database:dbTableColumn:menu', 'database:dbTableColumn:insert', 'database:dbTableColumn:update', 'database:dbTableColumn:delete');
DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'dbTableIndex_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'dbTableIndex_manager'
);

DELETE FROM sys_role
WHERE name = 'dbTableIndex_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('database:dbTableIndex:get', 'database:dbTableIndex:list', 'database:dbTableIndex:select', 'database:dbTableIndex:menu', 'database:dbTableIndex:insert', 'database:dbTableIndex:update', 'database:dbTableIndex:delete')
);

DELETE FROM sys_permission
WHERE name IN ('database:dbTableIndex:get', 'database:dbTableIndex:list', 'database:dbTableIndex:select', 'database:dbTableIndex:menu', 'database:dbTableIndex:insert', 'database:dbTableIndex:update', 'database:dbTableIndex:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('dbTableIndex_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'dbTableIndex_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbTableIndex:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbTableIndex:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbTableIndex:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbTableIndex:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbTableIndex:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbTableIndex:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbTableIndex:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'dbTableIndex_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('database:dbTableIndex:get', 'database:dbTableIndex:list', 'database:dbTableIndex:select', 'database:dbTableIndex:menu', 'database:dbTableIndex:insert', 'database:dbTableIndex:update', 'database:dbTableIndex:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__database_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('database:dbTableIndex:get', 'database:dbTableIndex:list', 'database:dbTableIndex:select', 'database:dbTableIndex:menu', 'database:dbTableIndex:insert', 'database:dbTableIndex:update', 'database:dbTableIndex:delete');
DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genJoinTable_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genJoinTable_manager'
);

DELETE FROM sys_role
WHERE name = 'genJoinTable_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:associations:genJoinTable:get', 'model:associations:genJoinTable:list', 'model:associations:genJoinTable:select', 'model:associations:genJoinTable:menu', 'model:associations:genJoinTable:insert', 'model:associations:genJoinTable:update', 'model:associations:genJoinTable:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:associations:genJoinTable:get', 'model:associations:genJoinTable:list', 'model:associations:genJoinTable:select', 'model:associations:genJoinTable:menu', 'model:associations:genJoinTable:insert', 'model:associations:genJoinTable:update', 'model:associations:genJoinTable:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genJoinTable_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genJoinTable_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTable:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTable:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTable:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTable:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTable:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTable:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTable:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genJoinTable_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:associations:genJoinTable:get', 'model:associations:genJoinTable:list', 'model:associations:genJoinTable:select', 'model:associations:genJoinTable:menu', 'model:associations:genJoinTable:insert', 'model:associations:genJoinTable:update', 'model:associations:genJoinTable:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__associations_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:associations:genJoinTable:get', 'model:associations:genJoinTable:list', 'model:associations:genJoinTable:select', 'model:associations:genJoinTable:menu', 'model:associations:genJoinTable:insert', 'model:associations:genJoinTable:update', 'model:associations:genJoinTable:delete');
DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genJoinTableColumn_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genJoinTableColumn_manager'
);

DELETE FROM sys_role
WHERE name = 'genJoinTableColumn_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:associations:genJoinTableColumn:get', 'model:associations:genJoinTableColumn:list', 'model:associations:genJoinTableColumn:select', 'model:associations:genJoinTableColumn:menu', 'model:associations:genJoinTableColumn:insert', 'model:associations:genJoinTableColumn:update', 'model:associations:genJoinTableColumn:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:associations:genJoinTableColumn:get', 'model:associations:genJoinTableColumn:list', 'model:associations:genJoinTableColumn:select', 'model:associations:genJoinTableColumn:menu', 'model:associations:genJoinTableColumn:insert', 'model:associations:genJoinTableColumn:update', 'model:associations:genJoinTableColumn:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genJoinTableColumn_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genJoinTableColumn_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTableColumn:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTableColumn:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTableColumn:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTableColumn:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTableColumn:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTableColumn:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTableColumn:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genJoinTableColumn_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:associations:genJoinTableColumn:get', 'model:associations:genJoinTableColumn:list', 'model:associations:genJoinTableColumn:select', 'model:associations:genJoinTableColumn:menu', 'model:associations:genJoinTableColumn:insert', 'model:associations:genJoinTableColumn:update', 'model:associations:genJoinTableColumn:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__associations_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:associations:genJoinTableColumn:get', 'model:associations:genJoinTableColumn:list', 'model:associations:genJoinTableColumn:select', 'model:associations:genJoinTableColumn:menu', 'model:associations:genJoinTableColumn:insert', 'model:associations:genJoinTableColumn:update', 'model:associations:genJoinTableColumn:delete');
DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genJoinTableFilter_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genJoinTableFilter_manager'
);

DELETE FROM sys_role
WHERE name = 'genJoinTableFilter_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:associations:genJoinTableFilter:get', 'model:associations:genJoinTableFilter:list', 'model:associations:genJoinTableFilter:select', 'model:associations:genJoinTableFilter:menu', 'model:associations:genJoinTableFilter:insert', 'model:associations:genJoinTableFilter:update', 'model:associations:genJoinTableFilter:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:associations:genJoinTableFilter:get', 'model:associations:genJoinTableFilter:list', 'model:associations:genJoinTableFilter:select', 'model:associations:genJoinTableFilter:menu', 'model:associations:genJoinTableFilter:insert', 'model:associations:genJoinTableFilter:update', 'model:associations:genJoinTableFilter:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genJoinTableFilter_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genJoinTableFilter_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTableFilter:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTableFilter:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTableFilter:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTableFilter:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTableFilter:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTableFilter:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTableFilter:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genJoinTableFilter_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:associations:genJoinTableFilter:get', 'model:associations:genJoinTableFilter:list', 'model:associations:genJoinTableFilter:select', 'model:associations:genJoinTableFilter:menu', 'model:associations:genJoinTableFilter:insert', 'model:associations:genJoinTableFilter:update', 'model:associations:genJoinTableFilter:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__associations_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:associations:genJoinTableFilter:get', 'model:associations:genJoinTableFilter:list', 'model:associations:genJoinTableFilter:select', 'model:associations:genJoinTableFilter:menu', 'model:associations:genJoinTableFilter:insert', 'model:associations:genJoinTableFilter:update', 'model:associations:genJoinTableFilter:delete');
DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genJoinTableLogicalDeleteFilter_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genJoinTableLogicalDeleteFilter_manager'
);

DELETE FROM sys_role
WHERE name = 'genJoinTableLogicalDeleteFilter_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:associations:genJoinTableLogicalDeleteFilter:get', 'model:associations:genJoinTableLogicalDeleteFilter:list', 'model:associations:genJoinTableLogicalDeleteFilter:select', 'model:associations:genJoinTableLogicalDeleteFilter:menu', 'model:associations:genJoinTableLogicalDeleteFilter:insert', 'model:associations:genJoinTableLogicalDeleteFilter:update', 'model:associations:genJoinTableLogicalDeleteFilter:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:associations:genJoinTableLogicalDeleteFilter:get', 'model:associations:genJoinTableLogicalDeleteFilter:list', 'model:associations:genJoinTableLogicalDeleteFilter:select', 'model:associations:genJoinTableLogicalDeleteFilter:menu', 'model:associations:genJoinTableLogicalDeleteFilter:insert', 'model:associations:genJoinTableLogicalDeleteFilter:update', 'model:associations:genJoinTableLogicalDeleteFilter:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genJoinTableLogicalDeleteFilter_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genJoinTableLogicalDeleteFilter_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTableLogicalDeleteFilter:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTableLogicalDeleteFilter:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTableLogicalDeleteFilter:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTableLogicalDeleteFilter:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTableLogicalDeleteFilter:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTableLogicalDeleteFilter:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTableLogicalDeleteFilter:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genJoinTableLogicalDeleteFilter_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:associations:genJoinTableLogicalDeleteFilter:get', 'model:associations:genJoinTableLogicalDeleteFilter:list', 'model:associations:genJoinTableLogicalDeleteFilter:select', 'model:associations:genJoinTableLogicalDeleteFilter:menu', 'model:associations:genJoinTableLogicalDeleteFilter:insert', 'model:associations:genJoinTableLogicalDeleteFilter:update', 'model:associations:genJoinTableLogicalDeleteFilter:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__associations_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:associations:genJoinTableLogicalDeleteFilter:get', 'model:associations:genJoinTableLogicalDeleteFilter:list', 'model:associations:genJoinTableLogicalDeleteFilter:select', 'model:associations:genJoinTableLogicalDeleteFilter:menu', 'model:associations:genJoinTableLogicalDeleteFilter:insert', 'model:associations:genJoinTableLogicalDeleteFilter:update', 'model:associations:genJoinTableLogicalDeleteFilter:delete');
DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genManyToManyAssociation_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genManyToManyAssociation_manager'
);

DELETE FROM sys_role
WHERE name = 'genManyToManyAssociation_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:associations:genManyToManyAssociation:get', 'model:associations:genManyToManyAssociation:list', 'model:associations:genManyToManyAssociation:select', 'model:associations:genManyToManyAssociation:menu', 'model:associations:genManyToManyAssociation:insert', 'model:associations:genManyToManyAssociation:update', 'model:associations:genManyToManyAssociation:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:associations:genManyToManyAssociation:get', 'model:associations:genManyToManyAssociation:list', 'model:associations:genManyToManyAssociation:select', 'model:associations:genManyToManyAssociation:menu', 'model:associations:genManyToManyAssociation:insert', 'model:associations:genManyToManyAssociation:update', 'model:associations:genManyToManyAssociation:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genManyToManyAssociation_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genManyToManyAssociation_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genManyToManyAssociation:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genManyToManyAssociation:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genManyToManyAssociation:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genManyToManyAssociation:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genManyToManyAssociation:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genManyToManyAssociation:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genManyToManyAssociation:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genManyToManyAssociation_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:associations:genManyToManyAssociation:get', 'model:associations:genManyToManyAssociation:list', 'model:associations:genManyToManyAssociation:select', 'model:associations:genManyToManyAssociation:menu', 'model:associations:genManyToManyAssociation:insert', 'model:associations:genManyToManyAssociation:update', 'model:associations:genManyToManyAssociation:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__associations_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:associations:genManyToManyAssociation:get', 'model:associations:genManyToManyAssociation:list', 'model:associations:genManyToManyAssociation:select', 'model:associations:genManyToManyAssociation:menu', 'model:associations:genManyToManyAssociation:insert', 'model:associations:genManyToManyAssociation:update', 'model:associations:genManyToManyAssociation:delete');
DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genManyToOneAssociation_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genManyToOneAssociation_manager'
);

DELETE FROM sys_role
WHERE name = 'genManyToOneAssociation_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:associations:genManyToOneAssociation:get', 'model:associations:genManyToOneAssociation:list', 'model:associations:genManyToOneAssociation:select', 'model:associations:genManyToOneAssociation:menu', 'model:associations:genManyToOneAssociation:insert', 'model:associations:genManyToOneAssociation:update', 'model:associations:genManyToOneAssociation:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:associations:genManyToOneAssociation:get', 'model:associations:genManyToOneAssociation:list', 'model:associations:genManyToOneAssociation:select', 'model:associations:genManyToOneAssociation:menu', 'model:associations:genManyToOneAssociation:insert', 'model:associations:genManyToOneAssociation:update', 'model:associations:genManyToOneAssociation:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genManyToOneAssociation_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genManyToOneAssociation_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genManyToOneAssociation:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genManyToOneAssociation:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genManyToOneAssociation:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genManyToOneAssociation:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genManyToOneAssociation:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genManyToOneAssociation:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genManyToOneAssociation:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genManyToOneAssociation_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:associations:genManyToOneAssociation:get', 'model:associations:genManyToOneAssociation:list', 'model:associations:genManyToOneAssociation:select', 'model:associations:genManyToOneAssociation:menu', 'model:associations:genManyToOneAssociation:insert', 'model:associations:genManyToOneAssociation:update', 'model:associations:genManyToOneAssociation:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__associations_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:associations:genManyToOneAssociation:get', 'model:associations:genManyToOneAssociation:list', 'model:associations:genManyToOneAssociation:select', 'model:associations:genManyToOneAssociation:menu', 'model:associations:genManyToOneAssociation:insert', 'model:associations:genManyToOneAssociation:update', 'model:associations:genManyToOneAssociation:delete');
DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genOneToOneAssociation_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genOneToOneAssociation_manager'
);

DELETE FROM sys_role
WHERE name = 'genOneToOneAssociation_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:associations:genOneToOneAssociation:get', 'model:associations:genOneToOneAssociation:list', 'model:associations:genOneToOneAssociation:select', 'model:associations:genOneToOneAssociation:menu', 'model:associations:genOneToOneAssociation:insert', 'model:associations:genOneToOneAssociation:update', 'model:associations:genOneToOneAssociation:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:associations:genOneToOneAssociation:get', 'model:associations:genOneToOneAssociation:list', 'model:associations:genOneToOneAssociation:select', 'model:associations:genOneToOneAssociation:menu', 'model:associations:genOneToOneAssociation:insert', 'model:associations:genOneToOneAssociation:update', 'model:associations:genOneToOneAssociation:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genOneToOneAssociation_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genOneToOneAssociation_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genOneToOneAssociation:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genOneToOneAssociation:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genOneToOneAssociation:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genOneToOneAssociation:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genOneToOneAssociation:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genOneToOneAssociation:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genOneToOneAssociation:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genOneToOneAssociation_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:associations:genOneToOneAssociation:get', 'model:associations:genOneToOneAssociation:list', 'model:associations:genOneToOneAssociation:select', 'model:associations:genOneToOneAssociation:menu', 'model:associations:genOneToOneAssociation:insert', 'model:associations:genOneToOneAssociation:update', 'model:associations:genOneToOneAssociation:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__associations_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:associations:genOneToOneAssociation:get', 'model:associations:genOneToOneAssociation:list', 'model:associations:genOneToOneAssociation:select', 'model:associations:genOneToOneAssociation:menu', 'model:associations:genOneToOneAssociation:insert', 'model:associations:genOneToOneAssociation:update', 'model:associations:genOneToOneAssociation:delete');
DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genDeepEmbeddablePropertyOverride_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genDeepEmbeddablePropertyOverride_manager'
);

DELETE FROM sys_role
WHERE name = 'genDeepEmbeddablePropertyOverride_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:embeddables:genDeepEmbeddablePropertyOverride:get', 'model:embeddables:genDeepEmbeddablePropertyOverride:list', 'model:embeddables:genDeepEmbeddablePropertyOverride:select', 'model:embeddables:genDeepEmbeddablePropertyOverride:menu', 'model:embeddables:genDeepEmbeddablePropertyOverride:insert', 'model:embeddables:genDeepEmbeddablePropertyOverride:update', 'model:embeddables:genDeepEmbeddablePropertyOverride:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:embeddables:genDeepEmbeddablePropertyOverride:get', 'model:embeddables:genDeepEmbeddablePropertyOverride:list', 'model:embeddables:genDeepEmbeddablePropertyOverride:select', 'model:embeddables:genDeepEmbeddablePropertyOverride:menu', 'model:embeddables:genDeepEmbeddablePropertyOverride:insert', 'model:embeddables:genDeepEmbeddablePropertyOverride:update', 'model:embeddables:genDeepEmbeddablePropertyOverride:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genDeepEmbeddablePropertyOverride_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genDeepEmbeddablePropertyOverride_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genDeepEmbeddablePropertyOverride:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genDeepEmbeddablePropertyOverride:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genDeepEmbeddablePropertyOverride:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genDeepEmbeddablePropertyOverride:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genDeepEmbeddablePropertyOverride:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genDeepEmbeddablePropertyOverride:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genDeepEmbeddablePropertyOverride:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genDeepEmbeddablePropertyOverride_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:embeddables:genDeepEmbeddablePropertyOverride:get', 'model:embeddables:genDeepEmbeddablePropertyOverride:list', 'model:embeddables:genDeepEmbeddablePropertyOverride:select', 'model:embeddables:genDeepEmbeddablePropertyOverride:menu', 'model:embeddables:genDeepEmbeddablePropertyOverride:insert', 'model:embeddables:genDeepEmbeddablePropertyOverride:update', 'model:embeddables:genDeepEmbeddablePropertyOverride:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__embeddables_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:embeddables:genDeepEmbeddablePropertyOverride:get', 'model:embeddables:genDeepEmbeddablePropertyOverride:list', 'model:embeddables:genDeepEmbeddablePropertyOverride:select', 'model:embeddables:genDeepEmbeddablePropertyOverride:menu', 'model:embeddables:genDeepEmbeddablePropertyOverride:insert', 'model:embeddables:genDeepEmbeddablePropertyOverride:update', 'model:embeddables:genDeepEmbeddablePropertyOverride:delete');
DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEmbeddableType_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEmbeddableType_manager'
);

DELETE FROM sys_role
WHERE name = 'genEmbeddableType_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:embeddables:genEmbeddableType:get', 'model:embeddables:genEmbeddableType:list', 'model:embeddables:genEmbeddableType:select', 'model:embeddables:genEmbeddableType:menu', 'model:embeddables:genEmbeddableType:insert', 'model:embeddables:genEmbeddableType:update', 'model:embeddables:genEmbeddableType:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:embeddables:genEmbeddableType:get', 'model:embeddables:genEmbeddableType:list', 'model:embeddables:genEmbeddableType:select', 'model:embeddables:genEmbeddableType:menu', 'model:embeddables:genEmbeddableType:insert', 'model:embeddables:genEmbeddableType:update', 'model:embeddables:genEmbeddableType:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genEmbeddableType_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genEmbeddableType_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableType:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableType:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableType:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableType:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableType:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableType:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableType:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genEmbeddableType_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:embeddables:genEmbeddableType:get', 'model:embeddables:genEmbeddableType:list', 'model:embeddables:genEmbeddableType:select', 'model:embeddables:genEmbeddableType:menu', 'model:embeddables:genEmbeddableType:insert', 'model:embeddables:genEmbeddableType:update', 'model:embeddables:genEmbeddableType:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__embeddables_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:embeddables:genEmbeddableType:get', 'model:embeddables:genEmbeddableType:list', 'model:embeddables:genEmbeddableType:select', 'model:embeddables:genEmbeddableType:menu', 'model:embeddables:genEmbeddableType:insert', 'model:embeddables:genEmbeddableType:update', 'model:embeddables:genEmbeddableType:delete');
DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEmbeddableTypeDeepProperty_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEmbeddableTypeDeepProperty_manager'
);

DELETE FROM sys_role
WHERE name = 'genEmbeddableTypeDeepProperty_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:embeddables:genEmbeddableTypeDeepProperty:get', 'model:embeddables:genEmbeddableTypeDeepProperty:list', 'model:embeddables:genEmbeddableTypeDeepProperty:select', 'model:embeddables:genEmbeddableTypeDeepProperty:menu', 'model:embeddables:genEmbeddableTypeDeepProperty:insert', 'model:embeddables:genEmbeddableTypeDeepProperty:update', 'model:embeddables:genEmbeddableTypeDeepProperty:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:embeddables:genEmbeddableTypeDeepProperty:get', 'model:embeddables:genEmbeddableTypeDeepProperty:list', 'model:embeddables:genEmbeddableTypeDeepProperty:select', 'model:embeddables:genEmbeddableTypeDeepProperty:menu', 'model:embeddables:genEmbeddableTypeDeepProperty:insert', 'model:embeddables:genEmbeddableTypeDeepProperty:update', 'model:embeddables:genEmbeddableTypeDeepProperty:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genEmbeddableTypeDeepProperty_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genEmbeddableTypeDeepProperty_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableTypeDeepProperty:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableTypeDeepProperty:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableTypeDeepProperty:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableTypeDeepProperty:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableTypeDeepProperty:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableTypeDeepProperty:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableTypeDeepProperty:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genEmbeddableTypeDeepProperty_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:embeddables:genEmbeddableTypeDeepProperty:get', 'model:embeddables:genEmbeddableTypeDeepProperty:list', 'model:embeddables:genEmbeddableTypeDeepProperty:select', 'model:embeddables:genEmbeddableTypeDeepProperty:menu', 'model:embeddables:genEmbeddableTypeDeepProperty:insert', 'model:embeddables:genEmbeddableTypeDeepProperty:update', 'model:embeddables:genEmbeddableTypeDeepProperty:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__embeddables_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:embeddables:genEmbeddableTypeDeepProperty:get', 'model:embeddables:genEmbeddableTypeDeepProperty:list', 'model:embeddables:genEmbeddableTypeDeepProperty:select', 'model:embeddables:genEmbeddableTypeDeepProperty:menu', 'model:embeddables:genEmbeddableTypeDeepProperty:insert', 'model:embeddables:genEmbeddableTypeDeepProperty:update', 'model:embeddables:genEmbeddableTypeDeepProperty:delete');
DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEmbeddableTypeProperty_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEmbeddableTypeProperty_manager'
);

DELETE FROM sys_role
WHERE name = 'genEmbeddableTypeProperty_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:embeddables:genEmbeddableTypeProperty:get', 'model:embeddables:genEmbeddableTypeProperty:list', 'model:embeddables:genEmbeddableTypeProperty:select', 'model:embeddables:genEmbeddableTypeProperty:menu', 'model:embeddables:genEmbeddableTypeProperty:insert', 'model:embeddables:genEmbeddableTypeProperty:update', 'model:embeddables:genEmbeddableTypeProperty:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:embeddables:genEmbeddableTypeProperty:get', 'model:embeddables:genEmbeddableTypeProperty:list', 'model:embeddables:genEmbeddableTypeProperty:select', 'model:embeddables:genEmbeddableTypeProperty:menu', 'model:embeddables:genEmbeddableTypeProperty:insert', 'model:embeddables:genEmbeddableTypeProperty:update', 'model:embeddables:genEmbeddableTypeProperty:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genEmbeddableTypeProperty_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genEmbeddableTypeProperty_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableTypeProperty:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableTypeProperty:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableTypeProperty:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableTypeProperty:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableTypeProperty:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableTypeProperty:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableTypeProperty:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genEmbeddableTypeProperty_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:embeddables:genEmbeddableTypeProperty:get', 'model:embeddables:genEmbeddableTypeProperty:list', 'model:embeddables:genEmbeddableTypeProperty:select', 'model:embeddables:genEmbeddableTypeProperty:menu', 'model:embeddables:genEmbeddableTypeProperty:insert', 'model:embeddables:genEmbeddableTypeProperty:update', 'model:embeddables:genEmbeddableTypeProperty:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__embeddables_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:embeddables:genEmbeddableTypeProperty:get', 'model:embeddables:genEmbeddableTypeProperty:list', 'model:embeddables:genEmbeddableTypeProperty:select', 'model:embeddables:genEmbeddableTypeProperty:menu', 'model:embeddables:genEmbeddableTypeProperty:insert', 'model:embeddables:genEmbeddableTypeProperty:update', 'model:embeddables:genEmbeddableTypeProperty:delete');
DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEntity_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEntity_manager'
);

DELETE FROM sys_role
WHERE name = 'genEntity_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:entities:genEntity:get', 'model:entities:genEntity:list', 'model:entities:genEntity:select', 'model:entities:genEntity:menu', 'model:entities:genEntity:insert', 'model:entities:genEntity:update', 'model:entities:genEntity:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:entities:genEntity:get', 'model:entities:genEntity:list', 'model:entities:genEntity:select', 'model:entities:genEntity:menu', 'model:entities:genEntity:insert', 'model:entities:genEntity:update', 'model:entities:genEntity:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genEntity_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genEntity_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntity:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntity:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntity:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntity:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntity:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntity:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntity:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genEntity_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:genEntity:get', 'model:entities:genEntity:list', 'model:entities:genEntity:select', 'model:entities:genEntity:menu', 'model:entities:genEntity:insert', 'model:entities:genEntity:update', 'model:entities:genEntity:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__entities_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:genEntity:get', 'model:entities:genEntity:list', 'model:entities:genEntity:select', 'model:entities:genEntity:menu', 'model:entities:genEntity:insert', 'model:entities:genEntity:update', 'model:entities:genEntity:delete');
DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEntityIndex_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEntityIndex_manager'
);

DELETE FROM sys_role
WHERE name = 'genEntityIndex_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:entities:genEntityIndex:get', 'model:entities:genEntityIndex:list', 'model:entities:genEntityIndex:select', 'model:entities:genEntityIndex:menu', 'model:entities:genEntityIndex:insert', 'model:entities:genEntityIndex:update', 'model:entities:genEntityIndex:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:entities:genEntityIndex:get', 'model:entities:genEntityIndex:list', 'model:entities:genEntityIndex:select', 'model:entities:genEntityIndex:menu', 'model:entities:genEntityIndex:insert', 'model:entities:genEntityIndex:update', 'model:entities:genEntityIndex:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genEntityIndex_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genEntityIndex_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntityIndex:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntityIndex:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntityIndex:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntityIndex:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntityIndex:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntityIndex:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntityIndex:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genEntityIndex_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:genEntityIndex:get', 'model:entities:genEntityIndex:list', 'model:entities:genEntityIndex:select', 'model:entities:genEntityIndex:menu', 'model:entities:genEntityIndex:insert', 'model:entities:genEntityIndex:update', 'model:entities:genEntityIndex:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__entities_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:genEntityIndex:get', 'model:entities:genEntityIndex:list', 'model:entities:genEntityIndex:select', 'model:entities:genEntityIndex:menu', 'model:entities:genEntityIndex:insert', 'model:entities:genEntityIndex:update', 'model:entities:genEntityIndex:delete');
DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEntityInherit_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEntityInherit_manager'
);

DELETE FROM sys_role
WHERE name = 'genEntityInherit_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:entities:genEntityInherit:get', 'model:entities:genEntityInherit:list', 'model:entities:genEntityInherit:select', 'model:entities:genEntityInherit:menu', 'model:entities:genEntityInherit:insert', 'model:entities:genEntityInherit:update', 'model:entities:genEntityInherit:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:entities:genEntityInherit:get', 'model:entities:genEntityInherit:list', 'model:entities:genEntityInherit:select', 'model:entities:genEntityInherit:menu', 'model:entities:genEntityInherit:insert', 'model:entities:genEntityInherit:update', 'model:entities:genEntityInherit:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genEntityInherit_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genEntityInherit_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntityInherit:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntityInherit:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntityInherit:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntityInherit:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntityInherit:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntityInherit:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntityInherit:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genEntityInherit_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:genEntityInherit:get', 'model:entities:genEntityInherit:list', 'model:entities:genEntityInherit:select', 'model:entities:genEntityInherit:menu', 'model:entities:genEntityInherit:insert', 'model:entities:genEntityInherit:update', 'model:entities:genEntityInherit:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__entities_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:genEntityInherit:get', 'model:entities:genEntityInherit:list', 'model:entities:genEntityInherit:select', 'model:entities:genEntityInherit:menu', 'model:entities:genEntityInherit:insert', 'model:entities:genEntityInherit:update', 'model:entities:genEntityInherit:delete');
DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEntityKeyGroup_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEntityKeyGroup_manager'
);

DELETE FROM sys_role
WHERE name = 'genEntityKeyGroup_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:entities:genEntityKeyGroup:get', 'model:entities:genEntityKeyGroup:list', 'model:entities:genEntityKeyGroup:select', 'model:entities:genEntityKeyGroup:menu', 'model:entities:genEntityKeyGroup:insert', 'model:entities:genEntityKeyGroup:update', 'model:entities:genEntityKeyGroup:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:entities:genEntityKeyGroup:get', 'model:entities:genEntityKeyGroup:list', 'model:entities:genEntityKeyGroup:select', 'model:entities:genEntityKeyGroup:menu', 'model:entities:genEntityKeyGroup:insert', 'model:entities:genEntityKeyGroup:update', 'model:entities:genEntityKeyGroup:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genEntityKeyGroup_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genEntityKeyGroup_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntityKeyGroup:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntityKeyGroup:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntityKeyGroup:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntityKeyGroup:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntityKeyGroup:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntityKeyGroup:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntityKeyGroup:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genEntityKeyGroup_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:genEntityKeyGroup:get', 'model:entities:genEntityKeyGroup:list', 'model:entities:genEntityKeyGroup:select', 'model:entities:genEntityKeyGroup:menu', 'model:entities:genEntityKeyGroup:insert', 'model:entities:genEntityKeyGroup:update', 'model:entities:genEntityKeyGroup:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__entities_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:genEntityKeyGroup:get', 'model:entities:genEntityKeyGroup:list', 'model:entities:genEntityKeyGroup:select', 'model:entities:genEntityKeyGroup:menu', 'model:entities:genEntityKeyGroup:insert', 'model:entities:genEntityKeyGroup:update', 'model:entities:genEntityKeyGroup:delete');
DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genColumnProperty_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genColumnProperty_manager'
);

DELETE FROM sys_role
WHERE name = 'genColumnProperty_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:entities:properties:genColumnProperty:get', 'model:entities:properties:genColumnProperty:list', 'model:entities:properties:genColumnProperty:select', 'model:entities:properties:genColumnProperty:menu', 'model:entities:properties:genColumnProperty:insert', 'model:entities:properties:genColumnProperty:update', 'model:entities:properties:genColumnProperty:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:entities:properties:genColumnProperty:get', 'model:entities:properties:genColumnProperty:list', 'model:entities:properties:genColumnProperty:select', 'model:entities:properties:genColumnProperty:menu', 'model:entities:properties:genColumnProperty:insert', 'model:entities:properties:genColumnProperty:update', 'model:entities:properties:genColumnProperty:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genColumnProperty_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genColumnProperty_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genColumnProperty:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genColumnProperty:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genColumnProperty:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genColumnProperty:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genColumnProperty:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genColumnProperty:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genColumnProperty:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genColumnProperty_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genColumnProperty:get', 'model:entities:properties:genColumnProperty:list', 'model:entities:properties:genColumnProperty:select', 'model:entities:properties:genColumnProperty:menu', 'model:entities:properties:genColumnProperty:insert', 'model:entities:properties:genColumnProperty:update', 'model:entities:properties:genColumnProperty:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__properties_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genColumnProperty:get', 'model:entities:properties:genColumnProperty:list', 'model:entities:properties:genColumnProperty:select', 'model:entities:properties:genColumnProperty:menu', 'model:entities:properties:genColumnProperty:insert', 'model:entities:properties:genColumnProperty:update', 'model:entities:properties:genColumnProperty:delete');
DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEmbeddableProperty_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEmbeddableProperty_manager'
);

DELETE FROM sys_role
WHERE name = 'genEmbeddableProperty_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:entities:properties:genEmbeddableProperty:get', 'model:entities:properties:genEmbeddableProperty:list', 'model:entities:properties:genEmbeddableProperty:select', 'model:entities:properties:genEmbeddableProperty:menu', 'model:entities:properties:genEmbeddableProperty:insert', 'model:entities:properties:genEmbeddableProperty:update', 'model:entities:properties:genEmbeddableProperty:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:entities:properties:genEmbeddableProperty:get', 'model:entities:properties:genEmbeddableProperty:list', 'model:entities:properties:genEmbeddableProperty:select', 'model:entities:properties:genEmbeddableProperty:menu', 'model:entities:properties:genEmbeddableProperty:insert', 'model:entities:properties:genEmbeddableProperty:update', 'model:entities:properties:genEmbeddableProperty:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genEmbeddableProperty_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genEmbeddableProperty_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genEmbeddableProperty:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genEmbeddableProperty:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genEmbeddableProperty:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genEmbeddableProperty:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genEmbeddableProperty:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genEmbeddableProperty:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genEmbeddableProperty:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genEmbeddableProperty_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genEmbeddableProperty:get', 'model:entities:properties:genEmbeddableProperty:list', 'model:entities:properties:genEmbeddableProperty:select', 'model:entities:properties:genEmbeddableProperty:menu', 'model:entities:properties:genEmbeddableProperty:insert', 'model:entities:properties:genEmbeddableProperty:update', 'model:entities:properties:genEmbeddableProperty:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__properties_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genEmbeddableProperty:get', 'model:entities:properties:genEmbeddableProperty:list', 'model:entities:properties:genEmbeddableProperty:select', 'model:entities:properties:genEmbeddableProperty:menu', 'model:entities:properties:genEmbeddableProperty:insert', 'model:entities:properties:genEmbeddableProperty:update', 'model:entities:properties:genEmbeddableProperty:delete');
DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEmbeddablePropertyOverride_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEmbeddablePropertyOverride_manager'
);

DELETE FROM sys_role
WHERE name = 'genEmbeddablePropertyOverride_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:entities:properties:genEmbeddablePropertyOverride:get', 'model:entities:properties:genEmbeddablePropertyOverride:list', 'model:entities:properties:genEmbeddablePropertyOverride:select', 'model:entities:properties:genEmbeddablePropertyOverride:menu', 'model:entities:properties:genEmbeddablePropertyOverride:insert', 'model:entities:properties:genEmbeddablePropertyOverride:update', 'model:entities:properties:genEmbeddablePropertyOverride:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:entities:properties:genEmbeddablePropertyOverride:get', 'model:entities:properties:genEmbeddablePropertyOverride:list', 'model:entities:properties:genEmbeddablePropertyOverride:select', 'model:entities:properties:genEmbeddablePropertyOverride:menu', 'model:entities:properties:genEmbeddablePropertyOverride:insert', 'model:entities:properties:genEmbeddablePropertyOverride:update', 'model:entities:properties:genEmbeddablePropertyOverride:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genEmbeddablePropertyOverride_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genEmbeddablePropertyOverride_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genEmbeddablePropertyOverride:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genEmbeddablePropertyOverride:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genEmbeddablePropertyOverride:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genEmbeddablePropertyOverride:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genEmbeddablePropertyOverride:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genEmbeddablePropertyOverride:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genEmbeddablePropertyOverride:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genEmbeddablePropertyOverride_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genEmbeddablePropertyOverride:get', 'model:entities:properties:genEmbeddablePropertyOverride:list', 'model:entities:properties:genEmbeddablePropertyOverride:select', 'model:entities:properties:genEmbeddablePropertyOverride:menu', 'model:entities:properties:genEmbeddablePropertyOverride:insert', 'model:entities:properties:genEmbeddablePropertyOverride:update', 'model:entities:properties:genEmbeddablePropertyOverride:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__properties_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genEmbeddablePropertyOverride:get', 'model:entities:properties:genEmbeddablePropertyOverride:list', 'model:entities:properties:genEmbeddablePropertyOverride:select', 'model:entities:properties:genEmbeddablePropertyOverride:menu', 'model:entities:properties:genEmbeddablePropertyOverride:insert', 'model:entities:properties:genEmbeddablePropertyOverride:update', 'model:entities:properties:genEmbeddablePropertyOverride:delete');
DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEnumColumnProperty_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEnumColumnProperty_manager'
);

DELETE FROM sys_role
WHERE name = 'genEnumColumnProperty_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:entities:properties:genEnumColumnProperty:get', 'model:entities:properties:genEnumColumnProperty:list', 'model:entities:properties:genEnumColumnProperty:select', 'model:entities:properties:genEnumColumnProperty:menu', 'model:entities:properties:genEnumColumnProperty:insert', 'model:entities:properties:genEnumColumnProperty:update', 'model:entities:properties:genEnumColumnProperty:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:entities:properties:genEnumColumnProperty:get', 'model:entities:properties:genEnumColumnProperty:list', 'model:entities:properties:genEnumColumnProperty:select', 'model:entities:properties:genEnumColumnProperty:menu', 'model:entities:properties:genEnumColumnProperty:insert', 'model:entities:properties:genEnumColumnProperty:update', 'model:entities:properties:genEnumColumnProperty:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genEnumColumnProperty_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genEnumColumnProperty_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genEnumColumnProperty:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genEnumColumnProperty:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genEnumColumnProperty:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genEnumColumnProperty:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genEnumColumnProperty:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genEnumColumnProperty:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genEnumColumnProperty:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genEnumColumnProperty_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genEnumColumnProperty:get', 'model:entities:properties:genEnumColumnProperty:list', 'model:entities:properties:genEnumColumnProperty:select', 'model:entities:properties:genEnumColumnProperty:menu', 'model:entities:properties:genEnumColumnProperty:insert', 'model:entities:properties:genEnumColumnProperty:update', 'model:entities:properties:genEnumColumnProperty:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__properties_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genEnumColumnProperty:get', 'model:entities:properties:genEnumColumnProperty:list', 'model:entities:properties:genEnumColumnProperty:select', 'model:entities:properties:genEnumColumnProperty:menu', 'model:entities:properties:genEnumColumnProperty:insert', 'model:entities:properties:genEnumColumnProperty:update', 'model:entities:properties:genEnumColumnProperty:delete');
DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genExtraProperty_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genExtraProperty_manager'
);

DELETE FROM sys_role
WHERE name = 'genExtraProperty_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:entities:properties:genExtraProperty:get', 'model:entities:properties:genExtraProperty:list', 'model:entities:properties:genExtraProperty:select', 'model:entities:properties:genExtraProperty:menu', 'model:entities:properties:genExtraProperty:insert', 'model:entities:properties:genExtraProperty:update', 'model:entities:properties:genExtraProperty:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:entities:properties:genExtraProperty:get', 'model:entities:properties:genExtraProperty:list', 'model:entities:properties:genExtraProperty:select', 'model:entities:properties:genExtraProperty:menu', 'model:entities:properties:genExtraProperty:insert', 'model:entities:properties:genExtraProperty:update', 'model:entities:properties:genExtraProperty:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genExtraProperty_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genExtraProperty_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genExtraProperty:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genExtraProperty:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genExtraProperty:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genExtraProperty:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genExtraProperty:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genExtraProperty:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genExtraProperty:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genExtraProperty_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genExtraProperty:get', 'model:entities:properties:genExtraProperty:list', 'model:entities:properties:genExtraProperty:select', 'model:entities:properties:genExtraProperty:menu', 'model:entities:properties:genExtraProperty:insert', 'model:entities:properties:genExtraProperty:update', 'model:entities:properties:genExtraProperty:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__properties_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genExtraProperty:get', 'model:entities:properties:genExtraProperty:list', 'model:entities:properties:genExtraProperty:select', 'model:entities:properties:genExtraProperty:menu', 'model:entities:properties:genExtraProperty:insert', 'model:entities:properties:genExtraProperty:update', 'model:entities:properties:genExtraProperty:delete');
DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genIdProperty_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genIdProperty_manager'
);

DELETE FROM sys_role
WHERE name = 'genIdProperty_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:entities:properties:genIdProperty:get', 'model:entities:properties:genIdProperty:list', 'model:entities:properties:genIdProperty:select', 'model:entities:properties:genIdProperty:menu', 'model:entities:properties:genIdProperty:insert', 'model:entities:properties:genIdProperty:update', 'model:entities:properties:genIdProperty:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:entities:properties:genIdProperty:get', 'model:entities:properties:genIdProperty:list', 'model:entities:properties:genIdProperty:select', 'model:entities:properties:genIdProperty:menu', 'model:entities:properties:genIdProperty:insert', 'model:entities:properties:genIdProperty:update', 'model:entities:properties:genIdProperty:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genIdProperty_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genIdProperty_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genIdProperty:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genIdProperty:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genIdProperty:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genIdProperty:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genIdProperty:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genIdProperty:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genIdProperty:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genIdProperty_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genIdProperty:get', 'model:entities:properties:genIdProperty:list', 'model:entities:properties:genIdProperty:select', 'model:entities:properties:genIdProperty:menu', 'model:entities:properties:genIdProperty:insert', 'model:entities:properties:genIdProperty:update', 'model:entities:properties:genIdProperty:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__properties_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genIdProperty:get', 'model:entities:properties:genIdProperty:list', 'model:entities:properties:genIdProperty:select', 'model:entities:properties:genIdProperty:menu', 'model:entities:properties:genIdProperty:insert', 'model:entities:properties:genIdProperty:update', 'model:entities:properties:genIdProperty:delete');
DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genLogicalDeleteProperty_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genLogicalDeleteProperty_manager'
);

DELETE FROM sys_role
WHERE name = 'genLogicalDeleteProperty_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:entities:properties:genLogicalDeleteProperty:get', 'model:entities:properties:genLogicalDeleteProperty:list', 'model:entities:properties:genLogicalDeleteProperty:select', 'model:entities:properties:genLogicalDeleteProperty:menu', 'model:entities:properties:genLogicalDeleteProperty:insert', 'model:entities:properties:genLogicalDeleteProperty:update', 'model:entities:properties:genLogicalDeleteProperty:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:entities:properties:genLogicalDeleteProperty:get', 'model:entities:properties:genLogicalDeleteProperty:list', 'model:entities:properties:genLogicalDeleteProperty:select', 'model:entities:properties:genLogicalDeleteProperty:menu', 'model:entities:properties:genLogicalDeleteProperty:insert', 'model:entities:properties:genLogicalDeleteProperty:update', 'model:entities:properties:genLogicalDeleteProperty:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genLogicalDeleteProperty_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genLogicalDeleteProperty_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genLogicalDeleteProperty:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genLogicalDeleteProperty:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genLogicalDeleteProperty:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genLogicalDeleteProperty:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genLogicalDeleteProperty:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genLogicalDeleteProperty:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genLogicalDeleteProperty:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genLogicalDeleteProperty_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genLogicalDeleteProperty:get', 'model:entities:properties:genLogicalDeleteProperty:list', 'model:entities:properties:genLogicalDeleteProperty:select', 'model:entities:properties:genLogicalDeleteProperty:menu', 'model:entities:properties:genLogicalDeleteProperty:insert', 'model:entities:properties:genLogicalDeleteProperty:update', 'model:entities:properties:genLogicalDeleteProperty:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__properties_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genLogicalDeleteProperty:get', 'model:entities:properties:genLogicalDeleteProperty:list', 'model:entities:properties:genLogicalDeleteProperty:select', 'model:entities:properties:genLogicalDeleteProperty:menu', 'model:entities:properties:genLogicalDeleteProperty:insert', 'model:entities:properties:genLogicalDeleteProperty:update', 'model:entities:properties:genLogicalDeleteProperty:delete');
DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genManyToManyMappedProperty_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genManyToManyMappedProperty_manager'
);

DELETE FROM sys_role
WHERE name = 'genManyToManyMappedProperty_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:entities:properties:genManyToManyMappedProperty:get', 'model:entities:properties:genManyToManyMappedProperty:list', 'model:entities:properties:genManyToManyMappedProperty:select', 'model:entities:properties:genManyToManyMappedProperty:menu', 'model:entities:properties:genManyToManyMappedProperty:insert', 'model:entities:properties:genManyToManyMappedProperty:update', 'model:entities:properties:genManyToManyMappedProperty:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:entities:properties:genManyToManyMappedProperty:get', 'model:entities:properties:genManyToManyMappedProperty:list', 'model:entities:properties:genManyToManyMappedProperty:select', 'model:entities:properties:genManyToManyMappedProperty:menu', 'model:entities:properties:genManyToManyMappedProperty:insert', 'model:entities:properties:genManyToManyMappedProperty:update', 'model:entities:properties:genManyToManyMappedProperty:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genManyToManyMappedProperty_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genManyToManyMappedProperty_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToManyMappedProperty:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToManyMappedProperty:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToManyMappedProperty:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToManyMappedProperty:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToManyMappedProperty:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToManyMappedProperty:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToManyMappedProperty:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genManyToManyMappedProperty_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genManyToManyMappedProperty:get', 'model:entities:properties:genManyToManyMappedProperty:list', 'model:entities:properties:genManyToManyMappedProperty:select', 'model:entities:properties:genManyToManyMappedProperty:menu', 'model:entities:properties:genManyToManyMappedProperty:insert', 'model:entities:properties:genManyToManyMappedProperty:update', 'model:entities:properties:genManyToManyMappedProperty:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__properties_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genManyToManyMappedProperty:get', 'model:entities:properties:genManyToManyMappedProperty:list', 'model:entities:properties:genManyToManyMappedProperty:select', 'model:entities:properties:genManyToManyMappedProperty:menu', 'model:entities:properties:genManyToManyMappedProperty:insert', 'model:entities:properties:genManyToManyMappedProperty:update', 'model:entities:properties:genManyToManyMappedProperty:delete');
DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genManyToManySourceProperty_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genManyToManySourceProperty_manager'
);

DELETE FROM sys_role
WHERE name = 'genManyToManySourceProperty_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:entities:properties:genManyToManySourceProperty:get', 'model:entities:properties:genManyToManySourceProperty:list', 'model:entities:properties:genManyToManySourceProperty:select', 'model:entities:properties:genManyToManySourceProperty:menu', 'model:entities:properties:genManyToManySourceProperty:insert', 'model:entities:properties:genManyToManySourceProperty:update', 'model:entities:properties:genManyToManySourceProperty:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:entities:properties:genManyToManySourceProperty:get', 'model:entities:properties:genManyToManySourceProperty:list', 'model:entities:properties:genManyToManySourceProperty:select', 'model:entities:properties:genManyToManySourceProperty:menu', 'model:entities:properties:genManyToManySourceProperty:insert', 'model:entities:properties:genManyToManySourceProperty:update', 'model:entities:properties:genManyToManySourceProperty:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genManyToManySourceProperty_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genManyToManySourceProperty_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToManySourceProperty:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToManySourceProperty:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToManySourceProperty:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToManySourceProperty:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToManySourceProperty:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToManySourceProperty:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToManySourceProperty:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genManyToManySourceProperty_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genManyToManySourceProperty:get', 'model:entities:properties:genManyToManySourceProperty:list', 'model:entities:properties:genManyToManySourceProperty:select', 'model:entities:properties:genManyToManySourceProperty:menu', 'model:entities:properties:genManyToManySourceProperty:insert', 'model:entities:properties:genManyToManySourceProperty:update', 'model:entities:properties:genManyToManySourceProperty:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__properties_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genManyToManySourceProperty:get', 'model:entities:properties:genManyToManySourceProperty:list', 'model:entities:properties:genManyToManySourceProperty:select', 'model:entities:properties:genManyToManySourceProperty:menu', 'model:entities:properties:genManyToManySourceProperty:insert', 'model:entities:properties:genManyToManySourceProperty:update', 'model:entities:properties:genManyToManySourceProperty:delete');
DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genManyToOneMappedProperty_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genManyToOneMappedProperty_manager'
);

DELETE FROM sys_role
WHERE name = 'genManyToOneMappedProperty_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:entities:properties:genManyToOneMappedProperty:get', 'model:entities:properties:genManyToOneMappedProperty:list', 'model:entities:properties:genManyToOneMappedProperty:select', 'model:entities:properties:genManyToOneMappedProperty:menu', 'model:entities:properties:genManyToOneMappedProperty:insert', 'model:entities:properties:genManyToOneMappedProperty:update', 'model:entities:properties:genManyToOneMappedProperty:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:entities:properties:genManyToOneMappedProperty:get', 'model:entities:properties:genManyToOneMappedProperty:list', 'model:entities:properties:genManyToOneMappedProperty:select', 'model:entities:properties:genManyToOneMappedProperty:menu', 'model:entities:properties:genManyToOneMappedProperty:insert', 'model:entities:properties:genManyToOneMappedProperty:update', 'model:entities:properties:genManyToOneMappedProperty:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genManyToOneMappedProperty_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genManyToOneMappedProperty_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToOneMappedProperty:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToOneMappedProperty:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToOneMappedProperty:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToOneMappedProperty:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToOneMappedProperty:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToOneMappedProperty:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToOneMappedProperty:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genManyToOneMappedProperty_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genManyToOneMappedProperty:get', 'model:entities:properties:genManyToOneMappedProperty:list', 'model:entities:properties:genManyToOneMappedProperty:select', 'model:entities:properties:genManyToOneMappedProperty:menu', 'model:entities:properties:genManyToOneMappedProperty:insert', 'model:entities:properties:genManyToOneMappedProperty:update', 'model:entities:properties:genManyToOneMappedProperty:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__properties_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genManyToOneMappedProperty:get', 'model:entities:properties:genManyToOneMappedProperty:list', 'model:entities:properties:genManyToOneMappedProperty:select', 'model:entities:properties:genManyToOneMappedProperty:menu', 'model:entities:properties:genManyToOneMappedProperty:insert', 'model:entities:properties:genManyToOneMappedProperty:update', 'model:entities:properties:genManyToOneMappedProperty:delete');
DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genManyToOneSourceProperty_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genManyToOneSourceProperty_manager'
);

DELETE FROM sys_role
WHERE name = 'genManyToOneSourceProperty_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:entities:properties:genManyToOneSourceProperty:get', 'model:entities:properties:genManyToOneSourceProperty:list', 'model:entities:properties:genManyToOneSourceProperty:select', 'model:entities:properties:genManyToOneSourceProperty:menu', 'model:entities:properties:genManyToOneSourceProperty:insert', 'model:entities:properties:genManyToOneSourceProperty:update', 'model:entities:properties:genManyToOneSourceProperty:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:entities:properties:genManyToOneSourceProperty:get', 'model:entities:properties:genManyToOneSourceProperty:list', 'model:entities:properties:genManyToOneSourceProperty:select', 'model:entities:properties:genManyToOneSourceProperty:menu', 'model:entities:properties:genManyToOneSourceProperty:insert', 'model:entities:properties:genManyToOneSourceProperty:update', 'model:entities:properties:genManyToOneSourceProperty:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genManyToOneSourceProperty_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genManyToOneSourceProperty_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToOneSourceProperty:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToOneSourceProperty:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToOneSourceProperty:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToOneSourceProperty:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToOneSourceProperty:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToOneSourceProperty:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToOneSourceProperty:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genManyToOneSourceProperty_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genManyToOneSourceProperty:get', 'model:entities:properties:genManyToOneSourceProperty:list', 'model:entities:properties:genManyToOneSourceProperty:select', 'model:entities:properties:genManyToOneSourceProperty:menu', 'model:entities:properties:genManyToOneSourceProperty:insert', 'model:entities:properties:genManyToOneSourceProperty:update', 'model:entities:properties:genManyToOneSourceProperty:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__properties_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genManyToOneSourceProperty:get', 'model:entities:properties:genManyToOneSourceProperty:list', 'model:entities:properties:genManyToOneSourceProperty:select', 'model:entities:properties:genManyToOneSourceProperty:menu', 'model:entities:properties:genManyToOneSourceProperty:insert', 'model:entities:properties:genManyToOneSourceProperty:update', 'model:entities:properties:genManyToOneSourceProperty:delete');
DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genOneToOneMappedProperty_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genOneToOneMappedProperty_manager'
);

DELETE FROM sys_role
WHERE name = 'genOneToOneMappedProperty_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:entities:properties:genOneToOneMappedProperty:get', 'model:entities:properties:genOneToOneMappedProperty:list', 'model:entities:properties:genOneToOneMappedProperty:select', 'model:entities:properties:genOneToOneMappedProperty:menu', 'model:entities:properties:genOneToOneMappedProperty:insert', 'model:entities:properties:genOneToOneMappedProperty:update', 'model:entities:properties:genOneToOneMappedProperty:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:entities:properties:genOneToOneMappedProperty:get', 'model:entities:properties:genOneToOneMappedProperty:list', 'model:entities:properties:genOneToOneMappedProperty:select', 'model:entities:properties:genOneToOneMappedProperty:menu', 'model:entities:properties:genOneToOneMappedProperty:insert', 'model:entities:properties:genOneToOneMappedProperty:update', 'model:entities:properties:genOneToOneMappedProperty:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genOneToOneMappedProperty_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genOneToOneMappedProperty_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genOneToOneMappedProperty:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genOneToOneMappedProperty:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genOneToOneMappedProperty:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genOneToOneMappedProperty:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genOneToOneMappedProperty:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genOneToOneMappedProperty:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genOneToOneMappedProperty:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genOneToOneMappedProperty_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genOneToOneMappedProperty:get', 'model:entities:properties:genOneToOneMappedProperty:list', 'model:entities:properties:genOneToOneMappedProperty:select', 'model:entities:properties:genOneToOneMappedProperty:menu', 'model:entities:properties:genOneToOneMappedProperty:insert', 'model:entities:properties:genOneToOneMappedProperty:update', 'model:entities:properties:genOneToOneMappedProperty:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__properties_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genOneToOneMappedProperty:get', 'model:entities:properties:genOneToOneMappedProperty:list', 'model:entities:properties:genOneToOneMappedProperty:select', 'model:entities:properties:genOneToOneMappedProperty:menu', 'model:entities:properties:genOneToOneMappedProperty:insert', 'model:entities:properties:genOneToOneMappedProperty:update', 'model:entities:properties:genOneToOneMappedProperty:delete');
DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genOneToOneSourceProperty_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genOneToOneSourceProperty_manager'
);

DELETE FROM sys_role
WHERE name = 'genOneToOneSourceProperty_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:entities:properties:genOneToOneSourceProperty:get', 'model:entities:properties:genOneToOneSourceProperty:list', 'model:entities:properties:genOneToOneSourceProperty:select', 'model:entities:properties:genOneToOneSourceProperty:menu', 'model:entities:properties:genOneToOneSourceProperty:insert', 'model:entities:properties:genOneToOneSourceProperty:update', 'model:entities:properties:genOneToOneSourceProperty:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:entities:properties:genOneToOneSourceProperty:get', 'model:entities:properties:genOneToOneSourceProperty:list', 'model:entities:properties:genOneToOneSourceProperty:select', 'model:entities:properties:genOneToOneSourceProperty:menu', 'model:entities:properties:genOneToOneSourceProperty:insert', 'model:entities:properties:genOneToOneSourceProperty:update', 'model:entities:properties:genOneToOneSourceProperty:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genOneToOneSourceProperty_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genOneToOneSourceProperty_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genOneToOneSourceProperty:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genOneToOneSourceProperty:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genOneToOneSourceProperty:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genOneToOneSourceProperty:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genOneToOneSourceProperty:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genOneToOneSourceProperty:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genOneToOneSourceProperty:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genOneToOneSourceProperty_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genOneToOneSourceProperty:get', 'model:entities:properties:genOneToOneSourceProperty:list', 'model:entities:properties:genOneToOneSourceProperty:select', 'model:entities:properties:genOneToOneSourceProperty:menu', 'model:entities:properties:genOneToOneSourceProperty:insert', 'model:entities:properties:genOneToOneSourceProperty:update', 'model:entities:properties:genOneToOneSourceProperty:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__properties_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genOneToOneSourceProperty:get', 'model:entities:properties:genOneToOneSourceProperty:list', 'model:entities:properties:genOneToOneSourceProperty:select', 'model:entities:properties:genOneToOneSourceProperty:menu', 'model:entities:properties:genOneToOneSourceProperty:insert', 'model:entities:properties:genOneToOneSourceProperty:update', 'model:entities:properties:genOneToOneSourceProperty:delete');
DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genProperty_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genProperty_manager'
);

DELETE FROM sys_role
WHERE name = 'genProperty_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:entities:properties:genProperty:get', 'model:entities:properties:genProperty:list', 'model:entities:properties:genProperty:select', 'model:entities:properties:genProperty:menu', 'model:entities:properties:genProperty:insert', 'model:entities:properties:genProperty:update', 'model:entities:properties:genProperty:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:entities:properties:genProperty:get', 'model:entities:properties:genProperty:list', 'model:entities:properties:genProperty:select', 'model:entities:properties:genProperty:menu', 'model:entities:properties:genProperty:insert', 'model:entities:properties:genProperty:update', 'model:entities:properties:genProperty:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genProperty_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genProperty_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genProperty:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genProperty:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genProperty:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genProperty:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genProperty:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genProperty:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genProperty:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genProperty_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genProperty:get', 'model:entities:properties:genProperty:list', 'model:entities:properties:genProperty:select', 'model:entities:properties:genProperty:menu', 'model:entities:properties:genProperty:insert', 'model:entities:properties:genProperty:update', 'model:entities:properties:genProperty:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__properties_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genProperty:get', 'model:entities:properties:genProperty:list', 'model:entities:properties:genProperty:select', 'model:entities:properties:genProperty:menu', 'model:entities:properties:genProperty:insert', 'model:entities:properties:genProperty:update', 'model:entities:properties:genProperty:delete');
DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genSortProperty_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genSortProperty_manager'
);

DELETE FROM sys_role
WHERE name = 'genSortProperty_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:entities:properties:genSortProperty:get', 'model:entities:properties:genSortProperty:list', 'model:entities:properties:genSortProperty:select', 'model:entities:properties:genSortProperty:menu', 'model:entities:properties:genSortProperty:insert', 'model:entities:properties:genSortProperty:update', 'model:entities:properties:genSortProperty:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:entities:properties:genSortProperty:get', 'model:entities:properties:genSortProperty:list', 'model:entities:properties:genSortProperty:select', 'model:entities:properties:genSortProperty:menu', 'model:entities:properties:genSortProperty:insert', 'model:entities:properties:genSortProperty:update', 'model:entities:properties:genSortProperty:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genSortProperty_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genSortProperty_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genSortProperty:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genSortProperty:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genSortProperty:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genSortProperty:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genSortProperty:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genSortProperty:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genSortProperty:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genSortProperty_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genSortProperty:get', 'model:entities:properties:genSortProperty:list', 'model:entities:properties:genSortProperty:select', 'model:entities:properties:genSortProperty:menu', 'model:entities:properties:genSortProperty:insert', 'model:entities:properties:genSortProperty:update', 'model:entities:properties:genSortProperty:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__properties_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genSortProperty:get', 'model:entities:properties:genSortProperty:list', 'model:entities:properties:genSortProperty:select', 'model:entities:properties:genSortProperty:menu', 'model:entities:properties:genSortProperty:insert', 'model:entities:properties:genSortProperty:update', 'model:entities:properties:genSortProperty:delete');
DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genVersionProperty_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genVersionProperty_manager'
);

DELETE FROM sys_role
WHERE name = 'genVersionProperty_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:entities:properties:genVersionProperty:get', 'model:entities:properties:genVersionProperty:list', 'model:entities:properties:genVersionProperty:select', 'model:entities:properties:genVersionProperty:menu', 'model:entities:properties:genVersionProperty:insert', 'model:entities:properties:genVersionProperty:update', 'model:entities:properties:genVersionProperty:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:entities:properties:genVersionProperty:get', 'model:entities:properties:genVersionProperty:list', 'model:entities:properties:genVersionProperty:select', 'model:entities:properties:genVersionProperty:menu', 'model:entities:properties:genVersionProperty:insert', 'model:entities:properties:genVersionProperty:update', 'model:entities:properties:genVersionProperty:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genVersionProperty_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genVersionProperty_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genVersionProperty:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genVersionProperty:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genVersionProperty:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genVersionProperty:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genVersionProperty:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genVersionProperty:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genVersionProperty:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genVersionProperty_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genVersionProperty:get', 'model:entities:properties:genVersionProperty:list', 'model:entities:properties:genVersionProperty:select', 'model:entities:properties:genVersionProperty:menu', 'model:entities:properties:genVersionProperty:insert', 'model:entities:properties:genVersionProperty:update', 'model:entities:properties:genVersionProperty:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__properties_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genVersionProperty:get', 'model:entities:properties:genVersionProperty:list', 'model:entities:properties:genVersionProperty:select', 'model:entities:properties:genVersionProperty:menu', 'model:entities:properties:genVersionProperty:insert', 'model:entities:properties:genVersionProperty:update', 'model:entities:properties:genVersionProperty:delete');
DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEnum_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEnum_manager'
);

DELETE FROM sys_role
WHERE name = 'genEnum_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:enums:genEnum:get', 'model:enums:genEnum:list', 'model:enums:genEnum:select', 'model:enums:genEnum:menu', 'model:enums:genEnum:insert', 'model:enums:genEnum:update', 'model:enums:genEnum:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:enums:genEnum:get', 'model:enums:genEnum:list', 'model:enums:genEnum:select', 'model:enums:genEnum:menu', 'model:enums:genEnum:insert', 'model:enums:genEnum:update', 'model:enums:genEnum:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genEnum_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genEnum_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:enums:genEnum:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:enums:genEnum:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:enums:genEnum:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:enums:genEnum:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:enums:genEnum:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:enums:genEnum:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:enums:genEnum:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genEnum_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:enums:genEnum:get', 'model:enums:genEnum:list', 'model:enums:genEnum:select', 'model:enums:genEnum:menu', 'model:enums:genEnum:insert', 'model:enums:genEnum:update', 'model:enums:genEnum:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__enums_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:enums:genEnum:get', 'model:enums:genEnum:list', 'model:enums:genEnum:select', 'model:enums:genEnum:menu', 'model:enums:genEnum:insert', 'model:enums:genEnum:update', 'model:enums:genEnum:delete');
DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEnumItem_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEnumItem_manager'
);

DELETE FROM sys_role
WHERE name = 'genEnumItem_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:enums:genEnumItem:get', 'model:enums:genEnumItem:list', 'model:enums:genEnumItem:select', 'model:enums:genEnumItem:menu', 'model:enums:genEnumItem:insert', 'model:enums:genEnumItem:update', 'model:enums:genEnumItem:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:enums:genEnumItem:get', 'model:enums:genEnumItem:list', 'model:enums:genEnumItem:select', 'model:enums:genEnumItem:menu', 'model:enums:genEnumItem:insert', 'model:enums:genEnumItem:update', 'model:enums:genEnumItem:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genEnumItem_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genEnumItem_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:enums:genEnumItem:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:enums:genEnumItem:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:enums:genEnumItem:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:enums:genEnumItem:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:enums:genEnumItem:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:enums:genEnumItem:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:enums:genEnumItem:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genEnumItem_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:enums:genEnumItem:get', 'model:enums:genEnumItem:list', 'model:enums:genEnumItem:select', 'model:enums:genEnumItem:menu', 'model:enums:genEnumItem:insert', 'model:enums:genEnumItem:update', 'model:enums:genEnumItem:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__enums_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:enums:genEnumItem:get', 'model:enums:genEnumItem:list', 'model:enums:genEnumItem:select', 'model:enums:genEnumItem:menu', 'model:enums:genEnumItem:insert', 'model:enums:genEnumItem:update', 'model:enums:genEnumItem:delete');
DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genModel_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genModel_manager'
);

DELETE FROM sys_role
WHERE name = 'genModel_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:genModel:get', 'model:genModel:list', 'model:genModel:select', 'model:genModel:menu', 'model:genModel:insert', 'model:genModel:update', 'model:genModel:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:genModel:get', 'model:genModel:list', 'model:genModel:select', 'model:genModel:menu', 'model:genModel:insert', 'model:genModel:update', 'model:genModel:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genModel_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genModel_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genModel:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genModel:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genModel:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genModel:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genModel:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genModel:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genModel:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genModel_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:genModel:get', 'model:genModel:list', 'model:genModel:select', 'model:genModel:menu', 'model:genModel:insert', 'model:genModel:update', 'model:genModel:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__model_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:genModel:get', 'model:genModel:list', 'model:genModel:select', 'model:genModel:menu', 'model:genModel:insert', 'model:genModel:update', 'model:genModel:delete');
DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genModelConfig_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genModelConfig_manager'
);

DELETE FROM sys_role
WHERE name = 'genModelConfig_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:genModelConfig:get', 'model:genModelConfig:list', 'model:genModelConfig:select', 'model:genModelConfig:menu', 'model:genModelConfig:insert', 'model:genModelConfig:update', 'model:genModelConfig:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:genModelConfig:get', 'model:genModelConfig:list', 'model:genModelConfig:select', 'model:genModelConfig:menu', 'model:genModelConfig:insert', 'model:genModelConfig:update', 'model:genModelConfig:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genModelConfig_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genModelConfig_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genModelConfig:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genModelConfig:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genModelConfig:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genModelConfig:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genModelConfig:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genModelConfig:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genModelConfig:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genModelConfig_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:genModelConfig:get', 'model:genModelConfig:list', 'model:genModelConfig:select', 'model:genModelConfig:menu', 'model:genModelConfig:insert', 'model:genModelConfig:update', 'model:genModelConfig:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__model_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:genModelConfig:get', 'model:genModelConfig:list', 'model:genModelConfig:select', 'model:genModelConfig:menu', 'model:genModelConfig:insert', 'model:genModelConfig:update', 'model:genModelConfig:delete');
DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genModelGroup_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genModelGroup_manager'
);

DELETE FROM sys_role
WHERE name = 'genModelGroup_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:genModelGroup:get', 'model:genModelGroup:list', 'model:genModelGroup:select', 'model:genModelGroup:menu', 'model:genModelGroup:insert', 'model:genModelGroup:update', 'model:genModelGroup:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:genModelGroup:get', 'model:genModelGroup:list', 'model:genModelGroup:select', 'model:genModelGroup:menu', 'model:genModelGroup:insert', 'model:genModelGroup:update', 'model:genModelGroup:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genModelGroup_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genModelGroup_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genModelGroup:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genModelGroup:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genModelGroup:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genModelGroup:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genModelGroup:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genModelGroup:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genModelGroup:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genModelGroup_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:genModelGroup:get', 'model:genModelGroup:list', 'model:genModelGroup:select', 'model:genModelGroup:menu', 'model:genModelGroup:insert', 'model:genModelGroup:update', 'model:genModelGroup:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__model_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:genModelGroup:get', 'model:genModelGroup:list', 'model:genModelGroup:select', 'model:genModelGroup:menu', 'model:genModelGroup:insert', 'model:genModelGroup:update', 'model:genModelGroup:delete');
DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genTypePair_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genTypePair_manager'
);

DELETE FROM sys_role
WHERE name = 'genTypePair_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:genTypePair:get', 'model:genTypePair:list', 'model:genTypePair:select', 'model:genTypePair:menu', 'model:genTypePair:insert', 'model:genTypePair:update', 'model:genTypePair:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:genTypePair:get', 'model:genTypePair:list', 'model:genTypePair:select', 'model:genTypePair:menu', 'model:genTypePair:insert', 'model:genTypePair:update', 'model:genTypePair:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genTypePair_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genTypePair_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genTypePair:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genTypePair:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genTypePair:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genTypePair:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genTypePair:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genTypePair:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genTypePair:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genTypePair_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:genTypePair:get', 'model:genTypePair:list', 'model:genTypePair:select', 'model:genTypePair:menu', 'model:genTypePair:insert', 'model:genTypePair:update', 'model:genTypePair:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__model_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:genTypePair:get', 'model:genTypePair:list', 'model:genTypePair:select', 'model:genTypePair:menu', 'model:genTypePair:insert', 'model:genTypePair:update', 'model:genTypePair:delete');