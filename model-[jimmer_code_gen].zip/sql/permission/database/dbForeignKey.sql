DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'dbForeignKey_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'dbForeignKey_manager'
);

DELETE FROM sys_role
WHERE name = 'dbForeignKey_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('database:dbForeignKey:get', 'database:dbForeignKey:list', 'database:dbForeignKey:select', 'database:dbForeignKey:menu', 'database:dbForeignKey:insert', 'database:dbForeignKey:update', 'database:dbForeignKey:delete')
);

DELETE FROM sys_permission
WHERE name IN ('database:dbForeignKey:get', 'database:dbForeignKey:list', 'database:dbForeignKey:select', 'database:dbForeignKey:menu', 'database:dbForeignKey:insert', 'database:dbForeignKey:update', 'database:dbForeignKey:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('dbForeignKey_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'dbForeignKey_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbForeignKey:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbForeignKey:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbForeignKey:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbForeignKey:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbForeignKey:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbForeignKey:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbForeignKey:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'dbForeignKey_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('database:dbForeignKey:get', 'database:dbForeignKey:list', 'database:dbForeignKey:select', 'database:dbForeignKey:menu', 'database:dbForeignKey:insert', 'database:dbForeignKey:update', 'database:dbForeignKey:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__database_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('database:dbForeignKey:get', 'database:dbForeignKey:list', 'database:dbForeignKey:select', 'database:dbForeignKey:menu', 'database:dbForeignKey:insert', 'database:dbForeignKey:update', 'database:dbForeignKey:delete');