DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'dbTable_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'dbTable_manager'
);

DELETE FROM sys_role
WHERE name = 'dbTable_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('database:dbTable:get', 'database:dbTable:list', 'database:dbTable:select', 'database:dbTable:menu', 'database:dbTable:insert', 'database:dbTable:update', 'database:dbTable:delete')
);

DELETE FROM sys_permission
WHERE name IN ('database:dbTable:get', 'database:dbTable:list', 'database:dbTable:select', 'database:dbTable:menu', 'database:dbTable:insert', 'database:dbTable:update', 'database:dbTable:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('dbTable_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'dbTable_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbTable:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbTable:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbTable:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbTable:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbTable:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbTable:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbTable:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'dbTable_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('database:dbTable:get', 'database:dbTable:list', 'database:dbTable:select', 'database:dbTable:menu', 'database:dbTable:insert', 'database:dbTable:update', 'database:dbTable:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__database_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('database:dbTable:get', 'database:dbTable:list', 'database:dbTable:select', 'database:dbTable:menu', 'database:dbTable:insert', 'database:dbTable:update', 'database:dbTable:delete');