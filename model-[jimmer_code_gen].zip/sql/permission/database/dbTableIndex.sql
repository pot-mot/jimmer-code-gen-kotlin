DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'dbTableIndex_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'dbTableIndex_manager'
);

DELETE FROM sys_role
WHERE name = 'dbTableIndex_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('database:dbTableIndex:get', 'database:dbTableIndex:list', 'database:dbTableIndex:select', 'database:dbTableIndex:menu', 'database:dbTableIndex:insert', 'database:dbTableIndex:update', 'database:dbTableIndex:delete')
);

DELETE FROM sys_permission
WHERE name IN ('database:dbTableIndex:get', 'database:dbTableIndex:list', 'database:dbTableIndex:select', 'database:dbTableIndex:menu', 'database:dbTableIndex:insert', 'database:dbTableIndex:update', 'database:dbTableIndex:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('dbTableIndex_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'dbTableIndex_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbTableIndex:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbTableIndex:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbTableIndex:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbTableIndex:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbTableIndex:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbTableIndex:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbTableIndex:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'dbTableIndex_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('database:dbTableIndex:get', 'database:dbTableIndex:list', 'database:dbTableIndex:select', 'database:dbTableIndex:menu', 'database:dbTableIndex:insert', 'database:dbTableIndex:update', 'database:dbTableIndex:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__database_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('database:dbTableIndex:get', 'database:dbTableIndex:list', 'database:dbTableIndex:select', 'database:dbTableIndex:menu', 'database:dbTableIndex:insert', 'database:dbTableIndex:update', 'database:dbTableIndex:delete');