DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'dbPrimaryKey_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'dbPrimaryKey_manager'
);

DELETE FROM sys_role
WHERE name = 'dbPrimaryKey_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('database:dbPrimaryKey:get', 'database:dbPrimaryKey:list', 'database:dbPrimaryKey:select', 'database:dbPrimaryKey:menu', 'database:dbPrimaryKey:insert', 'database:dbPrimaryKey:update', 'database:dbPrimaryKey:delete')
);

DELETE FROM sys_permission
WHERE name IN ('database:dbPrimaryKey:get', 'database:dbPrimaryKey:list', 'database:dbPrimaryKey:select', 'database:dbPrimaryKey:menu', 'database:dbPrimaryKey:insert', 'database:dbPrimaryKey:update', 'database:dbPrimaryKey:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('dbPrimaryKey_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'dbPrimaryKey_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbPrimaryKey:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbPrimaryKey:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbPrimaryKey:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbPrimaryKey:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbPrimaryKey:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbPrimaryKey:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbPrimaryKey:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'dbPrimaryKey_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('database:dbPrimaryKey:get', 'database:dbPrimaryKey:list', 'database:dbPrimaryKey:select', 'database:dbPrimaryKey:menu', 'database:dbPrimaryKey:insert', 'database:dbPrimaryKey:update', 'database:dbPrimaryKey:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__database_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('database:dbPrimaryKey:get', 'database:dbPrimaryKey:list', 'database:dbPrimaryKey:select', 'database:dbPrimaryKey:menu', 'database:dbPrimaryKey:insert', 'database:dbPrimaryKey:update', 'database:dbPrimaryKey:delete');