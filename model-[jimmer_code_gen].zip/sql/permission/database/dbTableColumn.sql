DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'dbTableColumn_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'dbTableColumn_manager'
);

DELETE FROM sys_role
WHERE name = 'dbTableColumn_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('database:dbTableColumn:get', 'database:dbTableColumn:list', 'database:dbTableColumn:select', 'database:dbTableColumn:menu', 'database:dbTableColumn:insert', 'database:dbTableColumn:update', 'database:dbTableColumn:delete')
);

DELETE FROM sys_permission
WHERE name IN ('database:dbTableColumn:get', 'database:dbTableColumn:list', 'database:dbTableColumn:select', 'database:dbTableColumn:menu', 'database:dbTableColumn:insert', 'database:dbTableColumn:update', 'database:dbTableColumn:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('dbTableColumn_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'dbTableColumn_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbTableColumn:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbTableColumn:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbTableColumn:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbTableColumn:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbTableColumn:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbTableColumn:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbTableColumn:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'dbTableColumn_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('database:dbTableColumn:get', 'database:dbTableColumn:list', 'database:dbTableColumn:select', 'database:dbTableColumn:menu', 'database:dbTableColumn:insert', 'database:dbTableColumn:update', 'database:dbTableColumn:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__database_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('database:dbTableColumn:get', 'database:dbTableColumn:list', 'database:dbTableColumn:select', 'database:dbTableColumn:menu', 'database:dbTableColumn:insert', 'database:dbTableColumn:update', 'database:dbTableColumn:delete');