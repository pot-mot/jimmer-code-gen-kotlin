DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'dbSchema_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'dbSchema_manager'
);

DELETE FROM sys_role
WHERE name = 'dbSchema_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('database:dbSchema:get', 'database:dbSchema:list', 'database:dbSchema:select', 'database:dbSchema:menu', 'database:dbSchema:insert', 'database:dbSchema:update', 'database:dbSchema:delete')
);

DELETE FROM sys_permission
WHERE name IN ('database:dbSchema:get', 'database:dbSchema:list', 'database:dbSchema:select', 'database:dbSchema:menu', 'database:dbSchema:insert', 'database:dbSchema:update', 'database:dbSchema:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('dbSchema_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'dbSchema_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbSchema:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbSchema:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbSchema:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbSchema:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbSchema:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbSchema:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbSchema:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'dbSchema_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('database:dbSchema:get', 'database:dbSchema:list', 'database:dbSchema:select', 'database:dbSchema:menu', 'database:dbSchema:insert', 'database:dbSchema:update', 'database:dbSchema:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__database_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('database:dbSchema:get', 'database:dbSchema:list', 'database:dbSchema:select', 'database:dbSchema:menu', 'database:dbSchema:insert', 'database:dbSchema:update', 'database:dbSchema:delete');