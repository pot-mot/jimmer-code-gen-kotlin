DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'dbDataSource_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'dbDataSource_manager'
);

DELETE FROM sys_role
WHERE name = 'dbDataSource_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('database:dbDataSource:get', 'database:dbDataSource:list', 'database:dbDataSource:select', 'database:dbDataSource:menu', 'database:dbDataSource:insert', 'database:dbDataSource:update', 'database:dbDataSource:delete')
);

DELETE FROM sys_permission
WHERE name IN ('database:dbDataSource:get', 'database:dbDataSource:list', 'database:dbDataSource:select', 'database:dbDataSource:menu', 'database:dbDataSource:insert', 'database:dbDataSource:update', 'database:dbDataSource:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('dbDataSource_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'dbDataSource_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbDataSource:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbDataSource:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbDataSource:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbDataSource:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbDataSource:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbDataSource:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('database:dbDataSource:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'dbDataSource_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('database:dbDataSource:get', 'database:dbDataSource:list', 'database:dbDataSource:select', 'database:dbDataSource:menu', 'database:dbDataSource:insert', 'database:dbDataSource:update', 'database:dbDataSource:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__database_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('database:dbDataSource:get', 'database:dbDataSource:list', 'database:dbDataSource:select', 'database:dbDataSource:menu', 'database:dbDataSource:insert', 'database:dbDataSource:update', 'database:dbDataSource:delete');