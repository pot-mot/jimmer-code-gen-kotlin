DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEnum_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEnum_manager'
);

DELETE FROM sys_role
WHERE name = 'genEnum_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:enums:genEnum:get', 'model:enums:genEnum:list', 'model:enums:genEnum:select', 'model:enums:genEnum:menu', 'model:enums:genEnum:insert', 'model:enums:genEnum:update', 'model:enums:genEnum:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:enums:genEnum:get', 'model:enums:genEnum:list', 'model:enums:genEnum:select', 'model:enums:genEnum:menu', 'model:enums:genEnum:insert', 'model:enums:genEnum:update', 'model:enums:genEnum:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genEnum_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genEnum_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:enums:genEnum:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:enums:genEnum:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:enums:genEnum:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:enums:genEnum:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:enums:genEnum:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:enums:genEnum:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:enums:genEnum:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genEnum_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:enums:genEnum:get', 'model:enums:genEnum:list', 'model:enums:genEnum:select', 'model:enums:genEnum:menu', 'model:enums:genEnum:insert', 'model:enums:genEnum:update', 'model:enums:genEnum:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__enums_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:enums:genEnum:get', 'model:enums:genEnum:list', 'model:enums:genEnum:select', 'model:enums:genEnum:menu', 'model:enums:genEnum:insert', 'model:enums:genEnum:update', 'model:enums:genEnum:delete');