
DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'group__enums_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'group__enums_manager'
);

DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('enums:menu')
);

DELETE FROM sys_permission
WHERE name IN ('enums:menu');

DELETE FROM sys_role
WHERE name = 'group__enums_manager';

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('group__enums_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'group__enums_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('enums:menu', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__enums_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('enums:menu');

