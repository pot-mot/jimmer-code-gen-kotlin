DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEnumItem_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEnumItem_manager'
);

DELETE FROM sys_role
WHERE name = 'genEnumItem_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:enums:genEnumItem:get', 'model:enums:genEnumItem:list', 'model:enums:genEnumItem:select', 'model:enums:genEnumItem:menu', 'model:enums:genEnumItem:insert', 'model:enums:genEnumItem:update', 'model:enums:genEnumItem:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:enums:genEnumItem:get', 'model:enums:genEnumItem:list', 'model:enums:genEnumItem:select', 'model:enums:genEnumItem:menu', 'model:enums:genEnumItem:insert', 'model:enums:genEnumItem:update', 'model:enums:genEnumItem:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genEnumItem_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genEnumItem_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:enums:genEnumItem:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:enums:genEnumItem:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:enums:genEnumItem:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:enums:genEnumItem:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:enums:genEnumItem:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:enums:genEnumItem:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:enums:genEnumItem:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genEnumItem_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:enums:genEnumItem:get', 'model:enums:genEnumItem:list', 'model:enums:genEnumItem:select', 'model:enums:genEnumItem:menu', 'model:enums:genEnumItem:insert', 'model:enums:genEnumItem:update', 'model:enums:genEnumItem:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__enums_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:enums:genEnumItem:get', 'model:enums:genEnumItem:list', 'model:enums:genEnumItem:select', 'model:enums:genEnumItem:menu', 'model:enums:genEnumItem:insert', 'model:enums:genEnumItem:update', 'model:enums:genEnumItem:delete');