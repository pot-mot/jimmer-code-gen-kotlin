DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genModelGroup_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genModelGroup_manager'
);

DELETE FROM sys_role
WHERE name = 'genModelGroup_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:genModelGroup:get', 'model:genModelGroup:list', 'model:genModelGroup:select', 'model:genModelGroup:menu', 'model:genModelGroup:insert', 'model:genModelGroup:update', 'model:genModelGroup:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:genModelGroup:get', 'model:genModelGroup:list', 'model:genModelGroup:select', 'model:genModelGroup:menu', 'model:genModelGroup:insert', 'model:genModelGroup:update', 'model:genModelGroup:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genModelGroup_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genModelGroup_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genModelGroup:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genModelGroup:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genModelGroup:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genModelGroup:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genModelGroup:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genModelGroup:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genModelGroup:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genModelGroup_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:genModelGroup:get', 'model:genModelGroup:list', 'model:genModelGroup:select', 'model:genModelGroup:menu', 'model:genModelGroup:insert', 'model:genModelGroup:update', 'model:genModelGroup:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__model_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:genModelGroup:get', 'model:genModelGroup:list', 'model:genModelGroup:select', 'model:genModelGroup:menu', 'model:genModelGroup:insert', 'model:genModelGroup:update', 'model:genModelGroup:delete');