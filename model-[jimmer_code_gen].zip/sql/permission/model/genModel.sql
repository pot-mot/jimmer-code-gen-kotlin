DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genModel_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genModel_manager'
);

DELETE FROM sys_role
WHERE name = 'genModel_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:genModel:get', 'model:genModel:list', 'model:genModel:select', 'model:genModel:menu', 'model:genModel:insert', 'model:genModel:update', 'model:genModel:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:genModel:get', 'model:genModel:list', 'model:genModel:select', 'model:genModel:menu', 'model:genModel:insert', 'model:genModel:update', 'model:genModel:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genModel_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genModel_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genModel:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genModel:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genModel:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genModel:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genModel:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genModel:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genModel:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genModel_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:genModel:get', 'model:genModel:list', 'model:genModel:select', 'model:genModel:menu', 'model:genModel:insert', 'model:genModel:update', 'model:genModel:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__model_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:genModel:get', 'model:genModel:list', 'model:genModel:select', 'model:genModel:menu', 'model:genModel:insert', 'model:genModel:update', 'model:genModel:delete');