DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genColumnInfo_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genColumnInfo_manager'
);

DELETE FROM sys_role
WHERE name = 'genColumnInfo_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:genColumnInfo:get', 'model:genColumnInfo:list', 'model:genColumnInfo:select', 'model:genColumnInfo:menu', 'model:genColumnInfo:insert', 'model:genColumnInfo:update', 'model:genColumnInfo:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:genColumnInfo:get', 'model:genColumnInfo:list', 'model:genColumnInfo:select', 'model:genColumnInfo:menu', 'model:genColumnInfo:insert', 'model:genColumnInfo:update', 'model:genColumnInfo:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genColumnInfo_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genColumnInfo_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genColumnInfo:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genColumnInfo:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genColumnInfo:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genColumnInfo:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genColumnInfo:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genColumnInfo:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genColumnInfo:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genColumnInfo_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:genColumnInfo:get', 'model:genColumnInfo:list', 'model:genColumnInfo:select', 'model:genColumnInfo:menu', 'model:genColumnInfo:insert', 'model:genColumnInfo:update', 'model:genColumnInfo:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__model_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:genColumnInfo:get', 'model:genColumnInfo:list', 'model:genColumnInfo:select', 'model:genColumnInfo:menu', 'model:genColumnInfo:insert', 'model:genColumnInfo:update', 'model:genColumnInfo:delete');