DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEmbeddable_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEmbeddable_manager'
);

DELETE FROM sys_role
WHERE name = 'genEmbeddable_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:embeddables:genEmbeddable:get', 'model:embeddables:genEmbeddable:list', 'model:embeddables:genEmbeddable:select', 'model:embeddables:genEmbeddable:menu', 'model:embeddables:genEmbeddable:insert', 'model:embeddables:genEmbeddable:update', 'model:embeddables:genEmbeddable:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:embeddables:genEmbeddable:get', 'model:embeddables:genEmbeddable:list', 'model:embeddables:genEmbeddable:select', 'model:embeddables:genEmbeddable:menu', 'model:embeddables:genEmbeddable:insert', 'model:embeddables:genEmbeddable:update', 'model:embeddables:genEmbeddable:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genEmbeddable_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genEmbeddable_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddable:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddable:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddable:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddable:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddable:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddable:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddable:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genEmbeddable_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:embeddables:genEmbeddable:get', 'model:embeddables:genEmbeddable:list', 'model:embeddables:genEmbeddable:select', 'model:embeddables:genEmbeddable:menu', 'model:embeddables:genEmbeddable:insert', 'model:embeddables:genEmbeddable:update', 'model:embeddables:genEmbeddable:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__embeddables_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:embeddables:genEmbeddable:get', 'model:embeddables:genEmbeddable:list', 'model:embeddables:genEmbeddable:select', 'model:embeddables:genEmbeddable:menu', 'model:embeddables:genEmbeddable:insert', 'model:embeddables:genEmbeddable:update', 'model:embeddables:genEmbeddable:delete');