DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEmbeddableTypeDeepProperty_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEmbeddableTypeDeepProperty_manager'
);

DELETE FROM sys_role
WHERE name = 'genEmbeddableTypeDeepProperty_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:embeddables:genEmbeddableTypeDeepProperty:get', 'model:embeddables:genEmbeddableTypeDeepProperty:list', 'model:embeddables:genEmbeddableTypeDeepProperty:select', 'model:embeddables:genEmbeddableTypeDeepProperty:menu', 'model:embeddables:genEmbeddableTypeDeepProperty:insert', 'model:embeddables:genEmbeddableTypeDeepProperty:update', 'model:embeddables:genEmbeddableTypeDeepProperty:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:embeddables:genEmbeddableTypeDeepProperty:get', 'model:embeddables:genEmbeddableTypeDeepProperty:list', 'model:embeddables:genEmbeddableTypeDeepProperty:select', 'model:embeddables:genEmbeddableTypeDeepProperty:menu', 'model:embeddables:genEmbeddableTypeDeepProperty:insert', 'model:embeddables:genEmbeddableTypeDeepProperty:update', 'model:embeddables:genEmbeddableTypeDeepProperty:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genEmbeddableTypeDeepProperty_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genEmbeddableTypeDeepProperty_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableTypeDeepProperty:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableTypeDeepProperty:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableTypeDeepProperty:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableTypeDeepProperty:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableTypeDeepProperty:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableTypeDeepProperty:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableTypeDeepProperty:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genEmbeddableTypeDeepProperty_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:embeddables:genEmbeddableTypeDeepProperty:get', 'model:embeddables:genEmbeddableTypeDeepProperty:list', 'model:embeddables:genEmbeddableTypeDeepProperty:select', 'model:embeddables:genEmbeddableTypeDeepProperty:menu', 'model:embeddables:genEmbeddableTypeDeepProperty:insert', 'model:embeddables:genEmbeddableTypeDeepProperty:update', 'model:embeddables:genEmbeddableTypeDeepProperty:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__embeddables_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:embeddables:genEmbeddableTypeDeepProperty:get', 'model:embeddables:genEmbeddableTypeDeepProperty:list', 'model:embeddables:genEmbeddableTypeDeepProperty:select', 'model:embeddables:genEmbeddableTypeDeepProperty:menu', 'model:embeddables:genEmbeddableTypeDeepProperty:insert', 'model:embeddables:genEmbeddableTypeDeepProperty:update', 'model:embeddables:genEmbeddableTypeDeepProperty:delete');