DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEmbeddableDeepProperty_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEmbeddableDeepProperty_manager'
);

DELETE FROM sys_role
WHERE name = 'genEmbeddableDeepProperty_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:embeddables:genEmbeddableDeepProperty:get', 'model:embeddables:genEmbeddableDeepProperty:list', 'model:embeddables:genEmbeddableDeepProperty:select', 'model:embeddables:genEmbeddableDeepProperty:menu', 'model:embeddables:genEmbeddableDeepProperty:insert', 'model:embeddables:genEmbeddableDeepProperty:update', 'model:embeddables:genEmbeddableDeepProperty:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:embeddables:genEmbeddableDeepProperty:get', 'model:embeddables:genEmbeddableDeepProperty:list', 'model:embeddables:genEmbeddableDeepProperty:select', 'model:embeddables:genEmbeddableDeepProperty:menu', 'model:embeddables:genEmbeddableDeepProperty:insert', 'model:embeddables:genEmbeddableDeepProperty:update', 'model:embeddables:genEmbeddableDeepProperty:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genEmbeddableDeepProperty_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genEmbeddableDeepProperty_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableDeepProperty:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableDeepProperty:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableDeepProperty:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableDeepProperty:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableDeepProperty:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableDeepProperty:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableDeepProperty:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genEmbeddableDeepProperty_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:embeddables:genEmbeddableDeepProperty:get', 'model:embeddables:genEmbeddableDeepProperty:list', 'model:embeddables:genEmbeddableDeepProperty:select', 'model:embeddables:genEmbeddableDeepProperty:menu', 'model:embeddables:genEmbeddableDeepProperty:insert', 'model:embeddables:genEmbeddableDeepProperty:update', 'model:embeddables:genEmbeddableDeepProperty:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__embeddables_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:embeddables:genEmbeddableDeepProperty:get', 'model:embeddables:genEmbeddableDeepProperty:list', 'model:embeddables:genEmbeddableDeepProperty:select', 'model:embeddables:genEmbeddableDeepProperty:menu', 'model:embeddables:genEmbeddableDeepProperty:insert', 'model:embeddables:genEmbeddableDeepProperty:update', 'model:embeddables:genEmbeddableDeepProperty:delete');