DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEmbeddableType_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEmbeddableType_manager'
);

DELETE FROM sys_role
WHERE name = 'genEmbeddableType_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:embeddables:genEmbeddableType:get', 'model:embeddables:genEmbeddableType:list', 'model:embeddables:genEmbeddableType:select', 'model:embeddables:genEmbeddableType:menu', 'model:embeddables:genEmbeddableType:insert', 'model:embeddables:genEmbeddableType:update', 'model:embeddables:genEmbeddableType:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:embeddables:genEmbeddableType:get', 'model:embeddables:genEmbeddableType:list', 'model:embeddables:genEmbeddableType:select', 'model:embeddables:genEmbeddableType:menu', 'model:embeddables:genEmbeddableType:insert', 'model:embeddables:genEmbeddableType:update', 'model:embeddables:genEmbeddableType:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genEmbeddableType_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genEmbeddableType_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableType:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableType:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableType:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableType:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableType:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableType:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableType:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genEmbeddableType_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:embeddables:genEmbeddableType:get', 'model:embeddables:genEmbeddableType:list', 'model:embeddables:genEmbeddableType:select', 'model:embeddables:genEmbeddableType:menu', 'model:embeddables:genEmbeddableType:insert', 'model:embeddables:genEmbeddableType:update', 'model:embeddables:genEmbeddableType:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__embeddables_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:embeddables:genEmbeddableType:get', 'model:embeddables:genEmbeddableType:list', 'model:embeddables:genEmbeddableType:select', 'model:embeddables:genEmbeddableType:menu', 'model:embeddables:genEmbeddableType:insert', 'model:embeddables:genEmbeddableType:update', 'model:embeddables:genEmbeddableType:delete');