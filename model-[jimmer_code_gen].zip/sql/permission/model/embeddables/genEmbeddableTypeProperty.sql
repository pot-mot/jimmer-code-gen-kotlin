DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEmbeddableTypeProperty_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEmbeddableTypeProperty_manager'
);

DELETE FROM sys_role
WHERE name = 'genEmbeddableTypeProperty_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:embeddables:genEmbeddableTypeProperty:get', 'model:embeddables:genEmbeddableTypeProperty:list', 'model:embeddables:genEmbeddableTypeProperty:select', 'model:embeddables:genEmbeddableTypeProperty:menu', 'model:embeddables:genEmbeddableTypeProperty:insert', 'model:embeddables:genEmbeddableTypeProperty:update', 'model:embeddables:genEmbeddableTypeProperty:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:embeddables:genEmbeddableTypeProperty:get', 'model:embeddables:genEmbeddableTypeProperty:list', 'model:embeddables:genEmbeddableTypeProperty:select', 'model:embeddables:genEmbeddableTypeProperty:menu', 'model:embeddables:genEmbeddableTypeProperty:insert', 'model:embeddables:genEmbeddableTypeProperty:update', 'model:embeddables:genEmbeddableTypeProperty:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genEmbeddableTypeProperty_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genEmbeddableTypeProperty_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableTypeProperty:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableTypeProperty:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableTypeProperty:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableTypeProperty:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableTypeProperty:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableTypeProperty:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableTypeProperty:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genEmbeddableTypeProperty_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:embeddables:genEmbeddableTypeProperty:get', 'model:embeddables:genEmbeddableTypeProperty:list', 'model:embeddables:genEmbeddableTypeProperty:select', 'model:embeddables:genEmbeddableTypeProperty:menu', 'model:embeddables:genEmbeddableTypeProperty:insert', 'model:embeddables:genEmbeddableTypeProperty:update', 'model:embeddables:genEmbeddableTypeProperty:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__embeddables_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:embeddables:genEmbeddableTypeProperty:get', 'model:embeddables:genEmbeddableTypeProperty:list', 'model:embeddables:genEmbeddableTypeProperty:select', 'model:embeddables:genEmbeddableTypeProperty:menu', 'model:embeddables:genEmbeddableTypeProperty:insert', 'model:embeddables:genEmbeddableTypeProperty:update', 'model:embeddables:genEmbeddableTypeProperty:delete');