DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEmbeddableProperty_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEmbeddableProperty_manager'
);

DELETE FROM sys_role
WHERE name = 'genEmbeddableProperty_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:embeddables:genEmbeddableProperty:get', 'model:embeddables:genEmbeddableProperty:list', 'model:embeddables:genEmbeddableProperty:select', 'model:embeddables:genEmbeddableProperty:menu', 'model:embeddables:genEmbeddableProperty:insert', 'model:embeddables:genEmbeddableProperty:update', 'model:embeddables:genEmbeddableProperty:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:embeddables:genEmbeddableProperty:get', 'model:embeddables:genEmbeddableProperty:list', 'model:embeddables:genEmbeddableProperty:select', 'model:embeddables:genEmbeddableProperty:menu', 'model:embeddables:genEmbeddableProperty:insert', 'model:embeddables:genEmbeddableProperty:update', 'model:embeddables:genEmbeddableProperty:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genEmbeddableProperty_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genEmbeddableProperty_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableProperty:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableProperty:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableProperty:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableProperty:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableProperty:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableProperty:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genEmbeddableProperty:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genEmbeddableProperty_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:embeddables:genEmbeddableProperty:get', 'model:embeddables:genEmbeddableProperty:list', 'model:embeddables:genEmbeddableProperty:select', 'model:embeddables:genEmbeddableProperty:menu', 'model:embeddables:genEmbeddableProperty:insert', 'model:embeddables:genEmbeddableProperty:update', 'model:embeddables:genEmbeddableProperty:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__embeddables_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:embeddables:genEmbeddableProperty:get', 'model:embeddables:genEmbeddableProperty:list', 'model:embeddables:genEmbeddableProperty:select', 'model:embeddables:genEmbeddableProperty:menu', 'model:embeddables:genEmbeddableProperty:insert', 'model:embeddables:genEmbeddableProperty:update', 'model:embeddables:genEmbeddableProperty:delete');