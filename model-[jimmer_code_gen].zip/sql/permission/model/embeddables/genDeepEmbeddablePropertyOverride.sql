DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genDeepEmbeddablePropertyOverride_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genDeepEmbeddablePropertyOverride_manager'
);

DELETE FROM sys_role
WHERE name = 'genDeepEmbeddablePropertyOverride_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:embeddables:genDeepEmbeddablePropertyOverride:get', 'model:embeddables:genDeepEmbeddablePropertyOverride:list', 'model:embeddables:genDeepEmbeddablePropertyOverride:select', 'model:embeddables:genDeepEmbeddablePropertyOverride:menu', 'model:embeddables:genDeepEmbeddablePropertyOverride:insert', 'model:embeddables:genDeepEmbeddablePropertyOverride:update', 'model:embeddables:genDeepEmbeddablePropertyOverride:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:embeddables:genDeepEmbeddablePropertyOverride:get', 'model:embeddables:genDeepEmbeddablePropertyOverride:list', 'model:embeddables:genDeepEmbeddablePropertyOverride:select', 'model:embeddables:genDeepEmbeddablePropertyOverride:menu', 'model:embeddables:genDeepEmbeddablePropertyOverride:insert', 'model:embeddables:genDeepEmbeddablePropertyOverride:update', 'model:embeddables:genDeepEmbeddablePropertyOverride:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genDeepEmbeddablePropertyOverride_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genDeepEmbeddablePropertyOverride_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genDeepEmbeddablePropertyOverride:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genDeepEmbeddablePropertyOverride:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genDeepEmbeddablePropertyOverride:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genDeepEmbeddablePropertyOverride:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genDeepEmbeddablePropertyOverride:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genDeepEmbeddablePropertyOverride:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:embeddables:genDeepEmbeddablePropertyOverride:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genDeepEmbeddablePropertyOverride_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:embeddables:genDeepEmbeddablePropertyOverride:get', 'model:embeddables:genDeepEmbeddablePropertyOverride:list', 'model:embeddables:genDeepEmbeddablePropertyOverride:select', 'model:embeddables:genDeepEmbeddablePropertyOverride:menu', 'model:embeddables:genDeepEmbeddablePropertyOverride:insert', 'model:embeddables:genDeepEmbeddablePropertyOverride:update', 'model:embeddables:genDeepEmbeddablePropertyOverride:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__embeddables_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:embeddables:genDeepEmbeddablePropertyOverride:get', 'model:embeddables:genDeepEmbeddablePropertyOverride:list', 'model:embeddables:genDeepEmbeddablePropertyOverride:select', 'model:embeddables:genDeepEmbeddablePropertyOverride:menu', 'model:embeddables:genDeepEmbeddablePropertyOverride:insert', 'model:embeddables:genDeepEmbeddablePropertyOverride:update', 'model:embeddables:genDeepEmbeddablePropertyOverride:delete');