DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genManyToOneAssociation_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genManyToOneAssociation_manager'
);

DELETE FROM sys_role
WHERE name = 'genManyToOneAssociation_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:associations:genManyToOneAssociation:get', 'model:associations:genManyToOneAssociation:list', 'model:associations:genManyToOneAssociation:select', 'model:associations:genManyToOneAssociation:menu', 'model:associations:genManyToOneAssociation:insert', 'model:associations:genManyToOneAssociation:update', 'model:associations:genManyToOneAssociation:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:associations:genManyToOneAssociation:get', 'model:associations:genManyToOneAssociation:list', 'model:associations:genManyToOneAssociation:select', 'model:associations:genManyToOneAssociation:menu', 'model:associations:genManyToOneAssociation:insert', 'model:associations:genManyToOneAssociation:update', 'model:associations:genManyToOneAssociation:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genManyToOneAssociation_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genManyToOneAssociation_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genManyToOneAssociation:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genManyToOneAssociation:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genManyToOneAssociation:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genManyToOneAssociation:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genManyToOneAssociation:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genManyToOneAssociation:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genManyToOneAssociation:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genManyToOneAssociation_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:associations:genManyToOneAssociation:get', 'model:associations:genManyToOneAssociation:list', 'model:associations:genManyToOneAssociation:select', 'model:associations:genManyToOneAssociation:menu', 'model:associations:genManyToOneAssociation:insert', 'model:associations:genManyToOneAssociation:update', 'model:associations:genManyToOneAssociation:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__associations_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:associations:genManyToOneAssociation:get', 'model:associations:genManyToOneAssociation:list', 'model:associations:genManyToOneAssociation:select', 'model:associations:genManyToOneAssociation:menu', 'model:associations:genManyToOneAssociation:insert', 'model:associations:genManyToOneAssociation:update', 'model:associations:genManyToOneAssociation:delete');