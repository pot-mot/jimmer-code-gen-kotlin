DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genJoinTableFilter_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genJoinTableFilter_manager'
);

DELETE FROM sys_role
WHERE name = 'genJoinTableFilter_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:associations:genJoinTableFilter:get', 'model:associations:genJoinTableFilter:list', 'model:associations:genJoinTableFilter:select', 'model:associations:genJoinTableFilter:menu', 'model:associations:genJoinTableFilter:insert', 'model:associations:genJoinTableFilter:update', 'model:associations:genJoinTableFilter:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:associations:genJoinTableFilter:get', 'model:associations:genJoinTableFilter:list', 'model:associations:genJoinTableFilter:select', 'model:associations:genJoinTableFilter:menu', 'model:associations:genJoinTableFilter:insert', 'model:associations:genJoinTableFilter:update', 'model:associations:genJoinTableFilter:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genJoinTableFilter_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genJoinTableFilter_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTableFilter:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTableFilter:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTableFilter:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTableFilter:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTableFilter:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTableFilter:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTableFilter:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genJoinTableFilter_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:associations:genJoinTableFilter:get', 'model:associations:genJoinTableFilter:list', 'model:associations:genJoinTableFilter:select', 'model:associations:genJoinTableFilter:menu', 'model:associations:genJoinTableFilter:insert', 'model:associations:genJoinTableFilter:update', 'model:associations:genJoinTableFilter:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__associations_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:associations:genJoinTableFilter:get', 'model:associations:genJoinTableFilter:list', 'model:associations:genJoinTableFilter:select', 'model:associations:genJoinTableFilter:menu', 'model:associations:genJoinTableFilter:insert', 'model:associations:genJoinTableFilter:update', 'model:associations:genJoinTableFilter:delete');