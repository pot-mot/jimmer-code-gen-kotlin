DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genJoinTableColumn_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genJoinTableColumn_manager'
);

DELETE FROM sys_role
WHERE name = 'genJoinTableColumn_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:associations:genJoinTableColumn:get', 'model:associations:genJoinTableColumn:list', 'model:associations:genJoinTableColumn:select', 'model:associations:genJoinTableColumn:menu', 'model:associations:genJoinTableColumn:insert', 'model:associations:genJoinTableColumn:update', 'model:associations:genJoinTableColumn:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:associations:genJoinTableColumn:get', 'model:associations:genJoinTableColumn:list', 'model:associations:genJoinTableColumn:select', 'model:associations:genJoinTableColumn:menu', 'model:associations:genJoinTableColumn:insert', 'model:associations:genJoinTableColumn:update', 'model:associations:genJoinTableColumn:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genJoinTableColumn_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genJoinTableColumn_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTableColumn:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTableColumn:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTableColumn:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTableColumn:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTableColumn:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTableColumn:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTableColumn:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genJoinTableColumn_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:associations:genJoinTableColumn:get', 'model:associations:genJoinTableColumn:list', 'model:associations:genJoinTableColumn:select', 'model:associations:genJoinTableColumn:menu', 'model:associations:genJoinTableColumn:insert', 'model:associations:genJoinTableColumn:update', 'model:associations:genJoinTableColumn:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__associations_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:associations:genJoinTableColumn:get', 'model:associations:genJoinTableColumn:list', 'model:associations:genJoinTableColumn:select', 'model:associations:genJoinTableColumn:menu', 'model:associations:genJoinTableColumn:insert', 'model:associations:genJoinTableColumn:update', 'model:associations:genJoinTableColumn:delete');