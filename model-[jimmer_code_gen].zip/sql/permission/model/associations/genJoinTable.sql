DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genJoinTable_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genJoinTable_manager'
);

DELETE FROM sys_role
WHERE name = 'genJoinTable_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:associations:genJoinTable:get', 'model:associations:genJoinTable:list', 'model:associations:genJoinTable:select', 'model:associations:genJoinTable:menu', 'model:associations:genJoinTable:insert', 'model:associations:genJoinTable:update', 'model:associations:genJoinTable:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:associations:genJoinTable:get', 'model:associations:genJoinTable:list', 'model:associations:genJoinTable:select', 'model:associations:genJoinTable:menu', 'model:associations:genJoinTable:insert', 'model:associations:genJoinTable:update', 'model:associations:genJoinTable:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genJoinTable_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genJoinTable_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTable:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTable:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTable:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTable:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTable:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTable:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTable:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genJoinTable_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:associations:genJoinTable:get', 'model:associations:genJoinTable:list', 'model:associations:genJoinTable:select', 'model:associations:genJoinTable:menu', 'model:associations:genJoinTable:insert', 'model:associations:genJoinTable:update', 'model:associations:genJoinTable:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__associations_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:associations:genJoinTable:get', 'model:associations:genJoinTable:list', 'model:associations:genJoinTable:select', 'model:associations:genJoinTable:menu', 'model:associations:genJoinTable:insert', 'model:associations:genJoinTable:update', 'model:associations:genJoinTable:delete');