DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genManyToManyAssociation_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genManyToManyAssociation_manager'
);

DELETE FROM sys_role
WHERE name = 'genManyToManyAssociation_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:associations:genManyToManyAssociation:get', 'model:associations:genManyToManyAssociation:list', 'model:associations:genManyToManyAssociation:select', 'model:associations:genManyToManyAssociation:menu', 'model:associations:genManyToManyAssociation:insert', 'model:associations:genManyToManyAssociation:update', 'model:associations:genManyToManyAssociation:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:associations:genManyToManyAssociation:get', 'model:associations:genManyToManyAssociation:list', 'model:associations:genManyToManyAssociation:select', 'model:associations:genManyToManyAssociation:menu', 'model:associations:genManyToManyAssociation:insert', 'model:associations:genManyToManyAssociation:update', 'model:associations:genManyToManyAssociation:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genManyToManyAssociation_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genManyToManyAssociation_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genManyToManyAssociation:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genManyToManyAssociation:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genManyToManyAssociation:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genManyToManyAssociation:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genManyToManyAssociation:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genManyToManyAssociation:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genManyToManyAssociation:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genManyToManyAssociation_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:associations:genManyToManyAssociation:get', 'model:associations:genManyToManyAssociation:list', 'model:associations:genManyToManyAssociation:select', 'model:associations:genManyToManyAssociation:menu', 'model:associations:genManyToManyAssociation:insert', 'model:associations:genManyToManyAssociation:update', 'model:associations:genManyToManyAssociation:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__associations_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:associations:genManyToManyAssociation:get', 'model:associations:genManyToManyAssociation:list', 'model:associations:genManyToManyAssociation:select', 'model:associations:genManyToManyAssociation:menu', 'model:associations:genManyToManyAssociation:insert', 'model:associations:genManyToManyAssociation:update', 'model:associations:genManyToManyAssociation:delete');