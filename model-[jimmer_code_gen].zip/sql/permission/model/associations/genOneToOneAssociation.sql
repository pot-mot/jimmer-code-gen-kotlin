DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genOneToOneAssociation_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genOneToOneAssociation_manager'
);

DELETE FROM sys_role
WHERE name = 'genOneToOneAssociation_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:associations:genOneToOneAssociation:get', 'model:associations:genOneToOneAssociation:list', 'model:associations:genOneToOneAssociation:select', 'model:associations:genOneToOneAssociation:menu', 'model:associations:genOneToOneAssociation:insert', 'model:associations:genOneToOneAssociation:update', 'model:associations:genOneToOneAssociation:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:associations:genOneToOneAssociation:get', 'model:associations:genOneToOneAssociation:list', 'model:associations:genOneToOneAssociation:select', 'model:associations:genOneToOneAssociation:menu', 'model:associations:genOneToOneAssociation:insert', 'model:associations:genOneToOneAssociation:update', 'model:associations:genOneToOneAssociation:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genOneToOneAssociation_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genOneToOneAssociation_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genOneToOneAssociation:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genOneToOneAssociation:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genOneToOneAssociation:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genOneToOneAssociation:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genOneToOneAssociation:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genOneToOneAssociation:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genOneToOneAssociation:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genOneToOneAssociation_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:associations:genOneToOneAssociation:get', 'model:associations:genOneToOneAssociation:list', 'model:associations:genOneToOneAssociation:select', 'model:associations:genOneToOneAssociation:menu', 'model:associations:genOneToOneAssociation:insert', 'model:associations:genOneToOneAssociation:update', 'model:associations:genOneToOneAssociation:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__associations_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:associations:genOneToOneAssociation:get', 'model:associations:genOneToOneAssociation:list', 'model:associations:genOneToOneAssociation:select', 'model:associations:genOneToOneAssociation:menu', 'model:associations:genOneToOneAssociation:insert', 'model:associations:genOneToOneAssociation:update', 'model:associations:genOneToOneAssociation:delete');