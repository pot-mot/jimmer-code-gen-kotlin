DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genJoinTableLogicalDeleteFilter_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genJoinTableLogicalDeleteFilter_manager'
);

DELETE FROM sys_role
WHERE name = 'genJoinTableLogicalDeleteFilter_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:associations:genJoinTableLogicalDeleteFilter:get', 'model:associations:genJoinTableLogicalDeleteFilter:list', 'model:associations:genJoinTableLogicalDeleteFilter:select', 'model:associations:genJoinTableLogicalDeleteFilter:menu', 'model:associations:genJoinTableLogicalDeleteFilter:insert', 'model:associations:genJoinTableLogicalDeleteFilter:update', 'model:associations:genJoinTableLogicalDeleteFilter:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:associations:genJoinTableLogicalDeleteFilter:get', 'model:associations:genJoinTableLogicalDeleteFilter:list', 'model:associations:genJoinTableLogicalDeleteFilter:select', 'model:associations:genJoinTableLogicalDeleteFilter:menu', 'model:associations:genJoinTableLogicalDeleteFilter:insert', 'model:associations:genJoinTableLogicalDeleteFilter:update', 'model:associations:genJoinTableLogicalDeleteFilter:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genJoinTableLogicalDeleteFilter_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genJoinTableLogicalDeleteFilter_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTableLogicalDeleteFilter:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTableLogicalDeleteFilter:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTableLogicalDeleteFilter:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTableLogicalDeleteFilter:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTableLogicalDeleteFilter:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTableLogicalDeleteFilter:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:associations:genJoinTableLogicalDeleteFilter:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genJoinTableLogicalDeleteFilter_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:associations:genJoinTableLogicalDeleteFilter:get', 'model:associations:genJoinTableLogicalDeleteFilter:list', 'model:associations:genJoinTableLogicalDeleteFilter:select', 'model:associations:genJoinTableLogicalDeleteFilter:menu', 'model:associations:genJoinTableLogicalDeleteFilter:insert', 'model:associations:genJoinTableLogicalDeleteFilter:update', 'model:associations:genJoinTableLogicalDeleteFilter:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__associations_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:associations:genJoinTableLogicalDeleteFilter:get', 'model:associations:genJoinTableLogicalDeleteFilter:list', 'model:associations:genJoinTableLogicalDeleteFilter:select', 'model:associations:genJoinTableLogicalDeleteFilter:menu', 'model:associations:genJoinTableLogicalDeleteFilter:insert', 'model:associations:genJoinTableLogicalDeleteFilter:update', 'model:associations:genJoinTableLogicalDeleteFilter:delete');