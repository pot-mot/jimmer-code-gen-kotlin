DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEntity_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEntity_manager'
);

DELETE FROM sys_role
WHERE name = 'genEntity_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:entities:genEntity:get', 'model:entities:genEntity:list', 'model:entities:genEntity:select', 'model:entities:genEntity:menu', 'model:entities:genEntity:insert', 'model:entities:genEntity:update', 'model:entities:genEntity:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:entities:genEntity:get', 'model:entities:genEntity:list', 'model:entities:genEntity:select', 'model:entities:genEntity:menu', 'model:entities:genEntity:insert', 'model:entities:genEntity:update', 'model:entities:genEntity:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genEntity_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genEntity_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntity:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntity:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntity:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntity:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntity:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntity:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntity:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genEntity_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:genEntity:get', 'model:entities:genEntity:list', 'model:entities:genEntity:select', 'model:entities:genEntity:menu', 'model:entities:genEntity:insert', 'model:entities:genEntity:update', 'model:entities:genEntity:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__entities_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:genEntity:get', 'model:entities:genEntity:list', 'model:entities:genEntity:select', 'model:entities:genEntity:menu', 'model:entities:genEntity:insert', 'model:entities:genEntity:update', 'model:entities:genEntity:delete');