DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEmbeddableProperty_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEmbeddableProperty_manager'
);

DELETE FROM sys_role
WHERE name = 'genEmbeddableProperty_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:entities:properties:genEmbeddableProperty:get', 'model:entities:properties:genEmbeddableProperty:list', 'model:entities:properties:genEmbeddableProperty:select', 'model:entities:properties:genEmbeddableProperty:menu', 'model:entities:properties:genEmbeddableProperty:insert', 'model:entities:properties:genEmbeddableProperty:update', 'model:entities:properties:genEmbeddableProperty:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:entities:properties:genEmbeddableProperty:get', 'model:entities:properties:genEmbeddableProperty:list', 'model:entities:properties:genEmbeddableProperty:select', 'model:entities:properties:genEmbeddableProperty:menu', 'model:entities:properties:genEmbeddableProperty:insert', 'model:entities:properties:genEmbeddableProperty:update', 'model:entities:properties:genEmbeddableProperty:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genEmbeddableProperty_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genEmbeddableProperty_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genEmbeddableProperty:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genEmbeddableProperty:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genEmbeddableProperty:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genEmbeddableProperty:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genEmbeddableProperty:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genEmbeddableProperty:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genEmbeddableProperty:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genEmbeddableProperty_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genEmbeddableProperty:get', 'model:entities:properties:genEmbeddableProperty:list', 'model:entities:properties:genEmbeddableProperty:select', 'model:entities:properties:genEmbeddableProperty:menu', 'model:entities:properties:genEmbeddableProperty:insert', 'model:entities:properties:genEmbeddableProperty:update', 'model:entities:properties:genEmbeddableProperty:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__properties_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genEmbeddableProperty:get', 'model:entities:properties:genEmbeddableProperty:list', 'model:entities:properties:genEmbeddableProperty:select', 'model:entities:properties:genEmbeddableProperty:menu', 'model:entities:properties:genEmbeddableProperty:insert', 'model:entities:properties:genEmbeddableProperty:update', 'model:entities:properties:genEmbeddableProperty:delete');