DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genProperty_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genProperty_manager'
);

DELETE FROM sys_role
WHERE name = 'genProperty_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:entities:properties:genProperty:get', 'model:entities:properties:genProperty:list', 'model:entities:properties:genProperty:select', 'model:entities:properties:genProperty:menu', 'model:entities:properties:genProperty:insert', 'model:entities:properties:genProperty:update', 'model:entities:properties:genProperty:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:entities:properties:genProperty:get', 'model:entities:properties:genProperty:list', 'model:entities:properties:genProperty:select', 'model:entities:properties:genProperty:menu', 'model:entities:properties:genProperty:insert', 'model:entities:properties:genProperty:update', 'model:entities:properties:genProperty:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genProperty_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genProperty_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genProperty:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genProperty:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genProperty:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genProperty:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genProperty:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genProperty:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genProperty:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genProperty_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genProperty:get', 'model:entities:properties:genProperty:list', 'model:entities:properties:genProperty:select', 'model:entities:properties:genProperty:menu', 'model:entities:properties:genProperty:insert', 'model:entities:properties:genProperty:update', 'model:entities:properties:genProperty:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__properties_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genProperty:get', 'model:entities:properties:genProperty:list', 'model:entities:properties:genProperty:select', 'model:entities:properties:genProperty:menu', 'model:entities:properties:genProperty:insert', 'model:entities:properties:genProperty:update', 'model:entities:properties:genProperty:delete');