DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genSortProperty_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genSortProperty_manager'
);

DELETE FROM sys_role
WHERE name = 'genSortProperty_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:entities:properties:genSortProperty:get', 'model:entities:properties:genSortProperty:list', 'model:entities:properties:genSortProperty:select', 'model:entities:properties:genSortProperty:menu', 'model:entities:properties:genSortProperty:insert', 'model:entities:properties:genSortProperty:update', 'model:entities:properties:genSortProperty:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:entities:properties:genSortProperty:get', 'model:entities:properties:genSortProperty:list', 'model:entities:properties:genSortProperty:select', 'model:entities:properties:genSortProperty:menu', 'model:entities:properties:genSortProperty:insert', 'model:entities:properties:genSortProperty:update', 'model:entities:properties:genSortProperty:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genSortProperty_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genSortProperty_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genSortProperty:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genSortProperty:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genSortProperty:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genSortProperty:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genSortProperty:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genSortProperty:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genSortProperty:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genSortProperty_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genSortProperty:get', 'model:entities:properties:genSortProperty:list', 'model:entities:properties:genSortProperty:select', 'model:entities:properties:genSortProperty:menu', 'model:entities:properties:genSortProperty:insert', 'model:entities:properties:genSortProperty:update', 'model:entities:properties:genSortProperty:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__properties_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genSortProperty:get', 'model:entities:properties:genSortProperty:list', 'model:entities:properties:genSortProperty:select', 'model:entities:properties:genSortProperty:menu', 'model:entities:properties:genSortProperty:insert', 'model:entities:properties:genSortProperty:update', 'model:entities:properties:genSortProperty:delete');