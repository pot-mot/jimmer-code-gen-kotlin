DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genManyToManyMappedProperty_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genManyToManyMappedProperty_manager'
);

DELETE FROM sys_role
WHERE name = 'genManyToManyMappedProperty_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:entities:properties:genManyToManyMappedProperty:get', 'model:entities:properties:genManyToManyMappedProperty:list', 'model:entities:properties:genManyToManyMappedProperty:select', 'model:entities:properties:genManyToManyMappedProperty:menu', 'model:entities:properties:genManyToManyMappedProperty:insert', 'model:entities:properties:genManyToManyMappedProperty:update', 'model:entities:properties:genManyToManyMappedProperty:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:entities:properties:genManyToManyMappedProperty:get', 'model:entities:properties:genManyToManyMappedProperty:list', 'model:entities:properties:genManyToManyMappedProperty:select', 'model:entities:properties:genManyToManyMappedProperty:menu', 'model:entities:properties:genManyToManyMappedProperty:insert', 'model:entities:properties:genManyToManyMappedProperty:update', 'model:entities:properties:genManyToManyMappedProperty:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genManyToManyMappedProperty_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genManyToManyMappedProperty_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToManyMappedProperty:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToManyMappedProperty:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToManyMappedProperty:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToManyMappedProperty:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToManyMappedProperty:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToManyMappedProperty:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToManyMappedProperty:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genManyToManyMappedProperty_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genManyToManyMappedProperty:get', 'model:entities:properties:genManyToManyMappedProperty:list', 'model:entities:properties:genManyToManyMappedProperty:select', 'model:entities:properties:genManyToManyMappedProperty:menu', 'model:entities:properties:genManyToManyMappedProperty:insert', 'model:entities:properties:genManyToManyMappedProperty:update', 'model:entities:properties:genManyToManyMappedProperty:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__properties_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genManyToManyMappedProperty:get', 'model:entities:properties:genManyToManyMappedProperty:list', 'model:entities:properties:genManyToManyMappedProperty:select', 'model:entities:properties:genManyToManyMappedProperty:menu', 'model:entities:properties:genManyToManyMappedProperty:insert', 'model:entities:properties:genManyToManyMappedProperty:update', 'model:entities:properties:genManyToManyMappedProperty:delete');