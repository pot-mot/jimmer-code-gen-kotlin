DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEmbeddablePropertyOverride_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEmbeddablePropertyOverride_manager'
);

DELETE FROM sys_role
WHERE name = 'genEmbeddablePropertyOverride_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:entities:properties:genEmbeddablePropertyOverride:get', 'model:entities:properties:genEmbeddablePropertyOverride:list', 'model:entities:properties:genEmbeddablePropertyOverride:select', 'model:entities:properties:genEmbeddablePropertyOverride:menu', 'model:entities:properties:genEmbeddablePropertyOverride:insert', 'model:entities:properties:genEmbeddablePropertyOverride:update', 'model:entities:properties:genEmbeddablePropertyOverride:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:entities:properties:genEmbeddablePropertyOverride:get', 'model:entities:properties:genEmbeddablePropertyOverride:list', 'model:entities:properties:genEmbeddablePropertyOverride:select', 'model:entities:properties:genEmbeddablePropertyOverride:menu', 'model:entities:properties:genEmbeddablePropertyOverride:insert', 'model:entities:properties:genEmbeddablePropertyOverride:update', 'model:entities:properties:genEmbeddablePropertyOverride:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genEmbeddablePropertyOverride_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genEmbeddablePropertyOverride_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genEmbeddablePropertyOverride:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genEmbeddablePropertyOverride:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genEmbeddablePropertyOverride:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genEmbeddablePropertyOverride:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genEmbeddablePropertyOverride:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genEmbeddablePropertyOverride:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genEmbeddablePropertyOverride:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genEmbeddablePropertyOverride_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genEmbeddablePropertyOverride:get', 'model:entities:properties:genEmbeddablePropertyOverride:list', 'model:entities:properties:genEmbeddablePropertyOverride:select', 'model:entities:properties:genEmbeddablePropertyOverride:menu', 'model:entities:properties:genEmbeddablePropertyOverride:insert', 'model:entities:properties:genEmbeddablePropertyOverride:update', 'model:entities:properties:genEmbeddablePropertyOverride:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__properties_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genEmbeddablePropertyOverride:get', 'model:entities:properties:genEmbeddablePropertyOverride:list', 'model:entities:properties:genEmbeddablePropertyOverride:select', 'model:entities:properties:genEmbeddablePropertyOverride:menu', 'model:entities:properties:genEmbeddablePropertyOverride:insert', 'model:entities:properties:genEmbeddablePropertyOverride:update', 'model:entities:properties:genEmbeddablePropertyOverride:delete');