DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genColumnProperty_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genColumnProperty_manager'
);

DELETE FROM sys_role
WHERE name = 'genColumnProperty_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:entities:properties:genColumnProperty:get', 'model:entities:properties:genColumnProperty:list', 'model:entities:properties:genColumnProperty:select', 'model:entities:properties:genColumnProperty:menu', 'model:entities:properties:genColumnProperty:insert', 'model:entities:properties:genColumnProperty:update', 'model:entities:properties:genColumnProperty:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:entities:properties:genColumnProperty:get', 'model:entities:properties:genColumnProperty:list', 'model:entities:properties:genColumnProperty:select', 'model:entities:properties:genColumnProperty:menu', 'model:entities:properties:genColumnProperty:insert', 'model:entities:properties:genColumnProperty:update', 'model:entities:properties:genColumnProperty:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genColumnProperty_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genColumnProperty_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genColumnProperty:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genColumnProperty:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genColumnProperty:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genColumnProperty:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genColumnProperty:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genColumnProperty:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genColumnProperty:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genColumnProperty_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genColumnProperty:get', 'model:entities:properties:genColumnProperty:list', 'model:entities:properties:genColumnProperty:select', 'model:entities:properties:genColumnProperty:menu', 'model:entities:properties:genColumnProperty:insert', 'model:entities:properties:genColumnProperty:update', 'model:entities:properties:genColumnProperty:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__properties_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genColumnProperty:get', 'model:entities:properties:genColumnProperty:list', 'model:entities:properties:genColumnProperty:select', 'model:entities:properties:genColumnProperty:menu', 'model:entities:properties:genColumnProperty:insert', 'model:entities:properties:genColumnProperty:update', 'model:entities:properties:genColumnProperty:delete');