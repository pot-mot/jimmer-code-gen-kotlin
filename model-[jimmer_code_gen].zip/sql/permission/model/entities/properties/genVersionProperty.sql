DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genVersionProperty_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genVersionProperty_manager'
);

DELETE FROM sys_role
WHERE name = 'genVersionProperty_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:entities:properties:genVersionProperty:get', 'model:entities:properties:genVersionProperty:list', 'model:entities:properties:genVersionProperty:select', 'model:entities:properties:genVersionProperty:menu', 'model:entities:properties:genVersionProperty:insert', 'model:entities:properties:genVersionProperty:update', 'model:entities:properties:genVersionProperty:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:entities:properties:genVersionProperty:get', 'model:entities:properties:genVersionProperty:list', 'model:entities:properties:genVersionProperty:select', 'model:entities:properties:genVersionProperty:menu', 'model:entities:properties:genVersionProperty:insert', 'model:entities:properties:genVersionProperty:update', 'model:entities:properties:genVersionProperty:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genVersionProperty_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genVersionProperty_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genVersionProperty:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genVersionProperty:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genVersionProperty:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genVersionProperty:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genVersionProperty:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genVersionProperty:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genVersionProperty:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genVersionProperty_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genVersionProperty:get', 'model:entities:properties:genVersionProperty:list', 'model:entities:properties:genVersionProperty:select', 'model:entities:properties:genVersionProperty:menu', 'model:entities:properties:genVersionProperty:insert', 'model:entities:properties:genVersionProperty:update', 'model:entities:properties:genVersionProperty:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__properties_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genVersionProperty:get', 'model:entities:properties:genVersionProperty:list', 'model:entities:properties:genVersionProperty:select', 'model:entities:properties:genVersionProperty:menu', 'model:entities:properties:genVersionProperty:insert', 'model:entities:properties:genVersionProperty:update', 'model:entities:properties:genVersionProperty:delete');