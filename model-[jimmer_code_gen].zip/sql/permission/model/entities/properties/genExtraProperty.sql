DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genExtraProperty_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genExtraProperty_manager'
);

DELETE FROM sys_role
WHERE name = 'genExtraProperty_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:entities:properties:genExtraProperty:get', 'model:entities:properties:genExtraProperty:list', 'model:entities:properties:genExtraProperty:select', 'model:entities:properties:genExtraProperty:menu', 'model:entities:properties:genExtraProperty:insert', 'model:entities:properties:genExtraProperty:update', 'model:entities:properties:genExtraProperty:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:entities:properties:genExtraProperty:get', 'model:entities:properties:genExtraProperty:list', 'model:entities:properties:genExtraProperty:select', 'model:entities:properties:genExtraProperty:menu', 'model:entities:properties:genExtraProperty:insert', 'model:entities:properties:genExtraProperty:update', 'model:entities:properties:genExtraProperty:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genExtraProperty_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genExtraProperty_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genExtraProperty:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genExtraProperty:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genExtraProperty:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genExtraProperty:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genExtraProperty:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genExtraProperty:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genExtraProperty:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genExtraProperty_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genExtraProperty:get', 'model:entities:properties:genExtraProperty:list', 'model:entities:properties:genExtraProperty:select', 'model:entities:properties:genExtraProperty:menu', 'model:entities:properties:genExtraProperty:insert', 'model:entities:properties:genExtraProperty:update', 'model:entities:properties:genExtraProperty:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__properties_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genExtraProperty:get', 'model:entities:properties:genExtraProperty:list', 'model:entities:properties:genExtraProperty:select', 'model:entities:properties:genExtraProperty:menu', 'model:entities:properties:genExtraProperty:insert', 'model:entities:properties:genExtraProperty:update', 'model:entities:properties:genExtraProperty:delete');