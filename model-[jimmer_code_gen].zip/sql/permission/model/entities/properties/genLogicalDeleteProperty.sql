DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genLogicalDeleteProperty_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genLogicalDeleteProperty_manager'
);

DELETE FROM sys_role
WHERE name = 'genLogicalDeleteProperty_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:entities:properties:genLogicalDeleteProperty:get', 'model:entities:properties:genLogicalDeleteProperty:list', 'model:entities:properties:genLogicalDeleteProperty:select', 'model:entities:properties:genLogicalDeleteProperty:menu', 'model:entities:properties:genLogicalDeleteProperty:insert', 'model:entities:properties:genLogicalDeleteProperty:update', 'model:entities:properties:genLogicalDeleteProperty:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:entities:properties:genLogicalDeleteProperty:get', 'model:entities:properties:genLogicalDeleteProperty:list', 'model:entities:properties:genLogicalDeleteProperty:select', 'model:entities:properties:genLogicalDeleteProperty:menu', 'model:entities:properties:genLogicalDeleteProperty:insert', 'model:entities:properties:genLogicalDeleteProperty:update', 'model:entities:properties:genLogicalDeleteProperty:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genLogicalDeleteProperty_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genLogicalDeleteProperty_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genLogicalDeleteProperty:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genLogicalDeleteProperty:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genLogicalDeleteProperty:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genLogicalDeleteProperty:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genLogicalDeleteProperty:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genLogicalDeleteProperty:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genLogicalDeleteProperty:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genLogicalDeleteProperty_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genLogicalDeleteProperty:get', 'model:entities:properties:genLogicalDeleteProperty:list', 'model:entities:properties:genLogicalDeleteProperty:select', 'model:entities:properties:genLogicalDeleteProperty:menu', 'model:entities:properties:genLogicalDeleteProperty:insert', 'model:entities:properties:genLogicalDeleteProperty:update', 'model:entities:properties:genLogicalDeleteProperty:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__properties_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genLogicalDeleteProperty:get', 'model:entities:properties:genLogicalDeleteProperty:list', 'model:entities:properties:genLogicalDeleteProperty:select', 'model:entities:properties:genLogicalDeleteProperty:menu', 'model:entities:properties:genLogicalDeleteProperty:insert', 'model:entities:properties:genLogicalDeleteProperty:update', 'model:entities:properties:genLogicalDeleteProperty:delete');