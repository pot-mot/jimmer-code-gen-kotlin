DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genManyToManySourceProperty_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genManyToManySourceProperty_manager'
);

DELETE FROM sys_role
WHERE name = 'genManyToManySourceProperty_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:entities:properties:genManyToManySourceProperty:get', 'model:entities:properties:genManyToManySourceProperty:list', 'model:entities:properties:genManyToManySourceProperty:select', 'model:entities:properties:genManyToManySourceProperty:menu', 'model:entities:properties:genManyToManySourceProperty:insert', 'model:entities:properties:genManyToManySourceProperty:update', 'model:entities:properties:genManyToManySourceProperty:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:entities:properties:genManyToManySourceProperty:get', 'model:entities:properties:genManyToManySourceProperty:list', 'model:entities:properties:genManyToManySourceProperty:select', 'model:entities:properties:genManyToManySourceProperty:menu', 'model:entities:properties:genManyToManySourceProperty:insert', 'model:entities:properties:genManyToManySourceProperty:update', 'model:entities:properties:genManyToManySourceProperty:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genManyToManySourceProperty_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genManyToManySourceProperty_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToManySourceProperty:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToManySourceProperty:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToManySourceProperty:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToManySourceProperty:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToManySourceProperty:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToManySourceProperty:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToManySourceProperty:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genManyToManySourceProperty_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genManyToManySourceProperty:get', 'model:entities:properties:genManyToManySourceProperty:list', 'model:entities:properties:genManyToManySourceProperty:select', 'model:entities:properties:genManyToManySourceProperty:menu', 'model:entities:properties:genManyToManySourceProperty:insert', 'model:entities:properties:genManyToManySourceProperty:update', 'model:entities:properties:genManyToManySourceProperty:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__properties_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genManyToManySourceProperty:get', 'model:entities:properties:genManyToManySourceProperty:list', 'model:entities:properties:genManyToManySourceProperty:select', 'model:entities:properties:genManyToManySourceProperty:menu', 'model:entities:properties:genManyToManySourceProperty:insert', 'model:entities:properties:genManyToManySourceProperty:update', 'model:entities:properties:genManyToManySourceProperty:delete');