DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genOneToOneSourceProperty_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genOneToOneSourceProperty_manager'
);

DELETE FROM sys_role
WHERE name = 'genOneToOneSourceProperty_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:entities:properties:genOneToOneSourceProperty:get', 'model:entities:properties:genOneToOneSourceProperty:list', 'model:entities:properties:genOneToOneSourceProperty:select', 'model:entities:properties:genOneToOneSourceProperty:menu', 'model:entities:properties:genOneToOneSourceProperty:insert', 'model:entities:properties:genOneToOneSourceProperty:update', 'model:entities:properties:genOneToOneSourceProperty:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:entities:properties:genOneToOneSourceProperty:get', 'model:entities:properties:genOneToOneSourceProperty:list', 'model:entities:properties:genOneToOneSourceProperty:select', 'model:entities:properties:genOneToOneSourceProperty:menu', 'model:entities:properties:genOneToOneSourceProperty:insert', 'model:entities:properties:genOneToOneSourceProperty:update', 'model:entities:properties:genOneToOneSourceProperty:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genOneToOneSourceProperty_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genOneToOneSourceProperty_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genOneToOneSourceProperty:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genOneToOneSourceProperty:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genOneToOneSourceProperty:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genOneToOneSourceProperty:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genOneToOneSourceProperty:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genOneToOneSourceProperty:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genOneToOneSourceProperty:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genOneToOneSourceProperty_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genOneToOneSourceProperty:get', 'model:entities:properties:genOneToOneSourceProperty:list', 'model:entities:properties:genOneToOneSourceProperty:select', 'model:entities:properties:genOneToOneSourceProperty:menu', 'model:entities:properties:genOneToOneSourceProperty:insert', 'model:entities:properties:genOneToOneSourceProperty:update', 'model:entities:properties:genOneToOneSourceProperty:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__properties_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genOneToOneSourceProperty:get', 'model:entities:properties:genOneToOneSourceProperty:list', 'model:entities:properties:genOneToOneSourceProperty:select', 'model:entities:properties:genOneToOneSourceProperty:menu', 'model:entities:properties:genOneToOneSourceProperty:insert', 'model:entities:properties:genOneToOneSourceProperty:update', 'model:entities:properties:genOneToOneSourceProperty:delete');