DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genManyToOneSourceProperty_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genManyToOneSourceProperty_manager'
);

DELETE FROM sys_role
WHERE name = 'genManyToOneSourceProperty_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:entities:properties:genManyToOneSourceProperty:get', 'model:entities:properties:genManyToOneSourceProperty:list', 'model:entities:properties:genManyToOneSourceProperty:select', 'model:entities:properties:genManyToOneSourceProperty:menu', 'model:entities:properties:genManyToOneSourceProperty:insert', 'model:entities:properties:genManyToOneSourceProperty:update', 'model:entities:properties:genManyToOneSourceProperty:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:entities:properties:genManyToOneSourceProperty:get', 'model:entities:properties:genManyToOneSourceProperty:list', 'model:entities:properties:genManyToOneSourceProperty:select', 'model:entities:properties:genManyToOneSourceProperty:menu', 'model:entities:properties:genManyToOneSourceProperty:insert', 'model:entities:properties:genManyToOneSourceProperty:update', 'model:entities:properties:genManyToOneSourceProperty:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genManyToOneSourceProperty_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genManyToOneSourceProperty_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToOneSourceProperty:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToOneSourceProperty:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToOneSourceProperty:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToOneSourceProperty:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToOneSourceProperty:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToOneSourceProperty:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToOneSourceProperty:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genManyToOneSourceProperty_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genManyToOneSourceProperty:get', 'model:entities:properties:genManyToOneSourceProperty:list', 'model:entities:properties:genManyToOneSourceProperty:select', 'model:entities:properties:genManyToOneSourceProperty:menu', 'model:entities:properties:genManyToOneSourceProperty:insert', 'model:entities:properties:genManyToOneSourceProperty:update', 'model:entities:properties:genManyToOneSourceProperty:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__properties_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genManyToOneSourceProperty:get', 'model:entities:properties:genManyToOneSourceProperty:list', 'model:entities:properties:genManyToOneSourceProperty:select', 'model:entities:properties:genManyToOneSourceProperty:menu', 'model:entities:properties:genManyToOneSourceProperty:insert', 'model:entities:properties:genManyToOneSourceProperty:update', 'model:entities:properties:genManyToOneSourceProperty:delete');