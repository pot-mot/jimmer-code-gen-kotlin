DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genIdProperty_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genIdProperty_manager'
);

DELETE FROM sys_role
WHERE name = 'genIdProperty_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:entities:properties:genIdProperty:get', 'model:entities:properties:genIdProperty:list', 'model:entities:properties:genIdProperty:select', 'model:entities:properties:genIdProperty:menu', 'model:entities:properties:genIdProperty:insert', 'model:entities:properties:genIdProperty:update', 'model:entities:properties:genIdProperty:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:entities:properties:genIdProperty:get', 'model:entities:properties:genIdProperty:list', 'model:entities:properties:genIdProperty:select', 'model:entities:properties:genIdProperty:menu', 'model:entities:properties:genIdProperty:insert', 'model:entities:properties:genIdProperty:update', 'model:entities:properties:genIdProperty:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genIdProperty_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genIdProperty_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genIdProperty:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genIdProperty:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genIdProperty:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genIdProperty:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genIdProperty:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genIdProperty:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genIdProperty:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genIdProperty_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genIdProperty:get', 'model:entities:properties:genIdProperty:list', 'model:entities:properties:genIdProperty:select', 'model:entities:properties:genIdProperty:menu', 'model:entities:properties:genIdProperty:insert', 'model:entities:properties:genIdProperty:update', 'model:entities:properties:genIdProperty:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__properties_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genIdProperty:get', 'model:entities:properties:genIdProperty:list', 'model:entities:properties:genIdProperty:select', 'model:entities:properties:genIdProperty:menu', 'model:entities:properties:genIdProperty:insert', 'model:entities:properties:genIdProperty:update', 'model:entities:properties:genIdProperty:delete');