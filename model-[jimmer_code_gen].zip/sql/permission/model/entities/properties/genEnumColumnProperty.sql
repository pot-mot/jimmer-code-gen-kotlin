DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEnumColumnProperty_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEnumColumnProperty_manager'
);

DELETE FROM sys_role
WHERE name = 'genEnumColumnProperty_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:entities:properties:genEnumColumnProperty:get', 'model:entities:properties:genEnumColumnProperty:list', 'model:entities:properties:genEnumColumnProperty:select', 'model:entities:properties:genEnumColumnProperty:menu', 'model:entities:properties:genEnumColumnProperty:insert', 'model:entities:properties:genEnumColumnProperty:update', 'model:entities:properties:genEnumColumnProperty:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:entities:properties:genEnumColumnProperty:get', 'model:entities:properties:genEnumColumnProperty:list', 'model:entities:properties:genEnumColumnProperty:select', 'model:entities:properties:genEnumColumnProperty:menu', 'model:entities:properties:genEnumColumnProperty:insert', 'model:entities:properties:genEnumColumnProperty:update', 'model:entities:properties:genEnumColumnProperty:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genEnumColumnProperty_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genEnumColumnProperty_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genEnumColumnProperty:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genEnumColumnProperty:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genEnumColumnProperty:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genEnumColumnProperty:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genEnumColumnProperty:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genEnumColumnProperty:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genEnumColumnProperty:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genEnumColumnProperty_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genEnumColumnProperty:get', 'model:entities:properties:genEnumColumnProperty:list', 'model:entities:properties:genEnumColumnProperty:select', 'model:entities:properties:genEnumColumnProperty:menu', 'model:entities:properties:genEnumColumnProperty:insert', 'model:entities:properties:genEnumColumnProperty:update', 'model:entities:properties:genEnumColumnProperty:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__properties_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genEnumColumnProperty:get', 'model:entities:properties:genEnumColumnProperty:list', 'model:entities:properties:genEnumColumnProperty:select', 'model:entities:properties:genEnumColumnProperty:menu', 'model:entities:properties:genEnumColumnProperty:insert', 'model:entities:properties:genEnumColumnProperty:update', 'model:entities:properties:genEnumColumnProperty:delete');