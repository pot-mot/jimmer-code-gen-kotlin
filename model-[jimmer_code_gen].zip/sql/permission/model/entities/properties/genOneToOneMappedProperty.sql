DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genOneToOneMappedProperty_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genOneToOneMappedProperty_manager'
);

DELETE FROM sys_role
WHERE name = 'genOneToOneMappedProperty_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:entities:properties:genOneToOneMappedProperty:get', 'model:entities:properties:genOneToOneMappedProperty:list', 'model:entities:properties:genOneToOneMappedProperty:select', 'model:entities:properties:genOneToOneMappedProperty:menu', 'model:entities:properties:genOneToOneMappedProperty:insert', 'model:entities:properties:genOneToOneMappedProperty:update', 'model:entities:properties:genOneToOneMappedProperty:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:entities:properties:genOneToOneMappedProperty:get', 'model:entities:properties:genOneToOneMappedProperty:list', 'model:entities:properties:genOneToOneMappedProperty:select', 'model:entities:properties:genOneToOneMappedProperty:menu', 'model:entities:properties:genOneToOneMappedProperty:insert', 'model:entities:properties:genOneToOneMappedProperty:update', 'model:entities:properties:genOneToOneMappedProperty:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genOneToOneMappedProperty_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genOneToOneMappedProperty_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genOneToOneMappedProperty:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genOneToOneMappedProperty:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genOneToOneMappedProperty:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genOneToOneMappedProperty:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genOneToOneMappedProperty:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genOneToOneMappedProperty:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genOneToOneMappedProperty:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genOneToOneMappedProperty_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genOneToOneMappedProperty:get', 'model:entities:properties:genOneToOneMappedProperty:list', 'model:entities:properties:genOneToOneMappedProperty:select', 'model:entities:properties:genOneToOneMappedProperty:menu', 'model:entities:properties:genOneToOneMappedProperty:insert', 'model:entities:properties:genOneToOneMappedProperty:update', 'model:entities:properties:genOneToOneMappedProperty:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__properties_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genOneToOneMappedProperty:get', 'model:entities:properties:genOneToOneMappedProperty:list', 'model:entities:properties:genOneToOneMappedProperty:select', 'model:entities:properties:genOneToOneMappedProperty:menu', 'model:entities:properties:genOneToOneMappedProperty:insert', 'model:entities:properties:genOneToOneMappedProperty:update', 'model:entities:properties:genOneToOneMappedProperty:delete');