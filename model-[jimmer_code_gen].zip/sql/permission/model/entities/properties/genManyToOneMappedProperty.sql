DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genManyToOneMappedProperty_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genManyToOneMappedProperty_manager'
);

DELETE FROM sys_role
WHERE name = 'genManyToOneMappedProperty_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:entities:properties:genManyToOneMappedProperty:get', 'model:entities:properties:genManyToOneMappedProperty:list', 'model:entities:properties:genManyToOneMappedProperty:select', 'model:entities:properties:genManyToOneMappedProperty:menu', 'model:entities:properties:genManyToOneMappedProperty:insert', 'model:entities:properties:genManyToOneMappedProperty:update', 'model:entities:properties:genManyToOneMappedProperty:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:entities:properties:genManyToOneMappedProperty:get', 'model:entities:properties:genManyToOneMappedProperty:list', 'model:entities:properties:genManyToOneMappedProperty:select', 'model:entities:properties:genManyToOneMappedProperty:menu', 'model:entities:properties:genManyToOneMappedProperty:insert', 'model:entities:properties:genManyToOneMappedProperty:update', 'model:entities:properties:genManyToOneMappedProperty:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genManyToOneMappedProperty_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genManyToOneMappedProperty_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToOneMappedProperty:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToOneMappedProperty:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToOneMappedProperty:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToOneMappedProperty:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToOneMappedProperty:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToOneMappedProperty:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:properties:genManyToOneMappedProperty:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genManyToOneMappedProperty_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genManyToOneMappedProperty:get', 'model:entities:properties:genManyToOneMappedProperty:list', 'model:entities:properties:genManyToOneMappedProperty:select', 'model:entities:properties:genManyToOneMappedProperty:menu', 'model:entities:properties:genManyToOneMappedProperty:insert', 'model:entities:properties:genManyToOneMappedProperty:update', 'model:entities:properties:genManyToOneMappedProperty:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__properties_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:properties:genManyToOneMappedProperty:get', 'model:entities:properties:genManyToOneMappedProperty:list', 'model:entities:properties:genManyToOneMappedProperty:select', 'model:entities:properties:genManyToOneMappedProperty:menu', 'model:entities:properties:genManyToOneMappedProperty:insert', 'model:entities:properties:genManyToOneMappedProperty:update', 'model:entities:properties:genManyToOneMappedProperty:delete');