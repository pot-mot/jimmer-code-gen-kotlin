DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEntityIndex_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEntityIndex_manager'
);

DELETE FROM sys_role
WHERE name = 'genEntityIndex_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:entities:genEntityIndex:get', 'model:entities:genEntityIndex:list', 'model:entities:genEntityIndex:select', 'model:entities:genEntityIndex:menu', 'model:entities:genEntityIndex:insert', 'model:entities:genEntityIndex:update', 'model:entities:genEntityIndex:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:entities:genEntityIndex:get', 'model:entities:genEntityIndex:list', 'model:entities:genEntityIndex:select', 'model:entities:genEntityIndex:menu', 'model:entities:genEntityIndex:insert', 'model:entities:genEntityIndex:update', 'model:entities:genEntityIndex:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genEntityIndex_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genEntityIndex_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntityIndex:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntityIndex:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntityIndex:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntityIndex:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntityIndex:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntityIndex:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntityIndex:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genEntityIndex_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:genEntityIndex:get', 'model:entities:genEntityIndex:list', 'model:entities:genEntityIndex:select', 'model:entities:genEntityIndex:menu', 'model:entities:genEntityIndex:insert', 'model:entities:genEntityIndex:update', 'model:entities:genEntityIndex:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__entities_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:genEntityIndex:get', 'model:entities:genEntityIndex:list', 'model:entities:genEntityIndex:select', 'model:entities:genEntityIndex:menu', 'model:entities:genEntityIndex:insert', 'model:entities:genEntityIndex:update', 'model:entities:genEntityIndex:delete');