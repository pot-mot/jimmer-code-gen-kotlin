DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEntityInherit_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEntityInherit_manager'
);

DELETE FROM sys_role
WHERE name = 'genEntityInherit_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:entities:genEntityInherit:get', 'model:entities:genEntityInherit:list', 'model:entities:genEntityInherit:select', 'model:entities:genEntityInherit:menu', 'model:entities:genEntityInherit:insert', 'model:entities:genEntityInherit:update', 'model:entities:genEntityInherit:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:entities:genEntityInherit:get', 'model:entities:genEntityInherit:list', 'model:entities:genEntityInherit:select', 'model:entities:genEntityInherit:menu', 'model:entities:genEntityInherit:insert', 'model:entities:genEntityInherit:update', 'model:entities:genEntityInherit:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genEntityInherit_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genEntityInherit_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntityInherit:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntityInherit:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntityInherit:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntityInherit:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntityInherit:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntityInherit:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntityInherit:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genEntityInherit_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:genEntityInherit:get', 'model:entities:genEntityInherit:list', 'model:entities:genEntityInherit:select', 'model:entities:genEntityInherit:menu', 'model:entities:genEntityInherit:insert', 'model:entities:genEntityInherit:update', 'model:entities:genEntityInherit:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__entities_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:genEntityInherit:get', 'model:entities:genEntityInherit:list', 'model:entities:genEntityInherit:select', 'model:entities:genEntityInherit:menu', 'model:entities:genEntityInherit:insert', 'model:entities:genEntityInherit:update', 'model:entities:genEntityInherit:delete');