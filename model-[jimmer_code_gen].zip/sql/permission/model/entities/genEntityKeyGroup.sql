DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEntityKeyGroup_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEntityKeyGroup_manager'
);

DELETE FROM sys_role
WHERE name = 'genEntityKeyGroup_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:entities:genEntityKeyGroup:get', 'model:entities:genEntityKeyGroup:list', 'model:entities:genEntityKeyGroup:select', 'model:entities:genEntityKeyGroup:menu', 'model:entities:genEntityKeyGroup:insert', 'model:entities:genEntityKeyGroup:update', 'model:entities:genEntityKeyGroup:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:entities:genEntityKeyGroup:get', 'model:entities:genEntityKeyGroup:list', 'model:entities:genEntityKeyGroup:select', 'model:entities:genEntityKeyGroup:menu', 'model:entities:genEntityKeyGroup:insert', 'model:entities:genEntityKeyGroup:update', 'model:entities:genEntityKeyGroup:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genEntityKeyGroup_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genEntityKeyGroup_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntityKeyGroup:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntityKeyGroup:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntityKeyGroup:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntityKeyGroup:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntityKeyGroup:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntityKeyGroup:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntityKeyGroup:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genEntityKeyGroup_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:genEntityKeyGroup:get', 'model:entities:genEntityKeyGroup:list', 'model:entities:genEntityKeyGroup:select', 'model:entities:genEntityKeyGroup:menu', 'model:entities:genEntityKeyGroup:insert', 'model:entities:genEntityKeyGroup:update', 'model:entities:genEntityKeyGroup:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__entities_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:genEntityKeyGroup:get', 'model:entities:genEntityKeyGroup:list', 'model:entities:genEntityKeyGroup:select', 'model:entities:genEntityKeyGroup:menu', 'model:entities:genEntityKeyGroup:insert', 'model:entities:genEntityKeyGroup:update', 'model:entities:genEntityKeyGroup:delete');