DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEntityGraphData_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genEntityGraphData_manager'
);

DELETE FROM sys_role
WHERE name = 'genEntityGraphData_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:entities:genEntityGraphData:get', 'model:entities:genEntityGraphData:list', 'model:entities:genEntityGraphData:select', 'model:entities:genEntityGraphData:menu', 'model:entities:genEntityGraphData:insert', 'model:entities:genEntityGraphData:update', 'model:entities:genEntityGraphData:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:entities:genEntityGraphData:get', 'model:entities:genEntityGraphData:list', 'model:entities:genEntityGraphData:select', 'model:entities:genEntityGraphData:menu', 'model:entities:genEntityGraphData:insert', 'model:entities:genEntityGraphData:update', 'model:entities:genEntityGraphData:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genEntityGraphData_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genEntityGraphData_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntityGraphData:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntityGraphData:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntityGraphData:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntityGraphData:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntityGraphData:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntityGraphData:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:entities:genEntityGraphData:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genEntityGraphData_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:genEntityGraphData:get', 'model:entities:genEntityGraphData:list', 'model:entities:genEntityGraphData:select', 'model:entities:genEntityGraphData:menu', 'model:entities:genEntityGraphData:insert', 'model:entities:genEntityGraphData:update', 'model:entities:genEntityGraphData:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__entities_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:entities:genEntityGraphData:get', 'model:entities:genEntityGraphData:list', 'model:entities:genEntityGraphData:select', 'model:entities:genEntityGraphData:menu', 'model:entities:genEntityGraphData:insert', 'model:entities:genEntityGraphData:update', 'model:entities:genEntityGraphData:delete');