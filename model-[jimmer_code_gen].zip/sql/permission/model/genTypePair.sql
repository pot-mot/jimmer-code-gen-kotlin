DELETE FROM sys_user_sys_role_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genTypePair_manager'
);

DELETE FROM sys_role_sys_permission_mapping WHERE role_id IN (
    SELECT id FROM sys_role
    WHERE name = 'genTypePair_manager'
);

DELETE FROM sys_role
WHERE name = 'genTypePair_manager';


DELETE FROM sys_menu_sys_permission_mapping WHERE permission_id IN (
    SELECT id FROM sys_permission
    WHERE name IN ('model:genTypePair:get', 'model:genTypePair:list', 'model:genTypePair:select', 'model:genTypePair:menu', 'model:genTypePair:insert', 'model:genTypePair:update', 'model:genTypePair:delete')
);

DELETE FROM sys_permission
WHERE name IN ('model:genTypePair:get', 'model:genTypePair:list', 'model:genTypePair:select', 'model:genTypePair:menu', 'model:genTypePair:insert', 'model:genTypePair:update', 'model:genTypePair:delete');

INSERT INTO sys_role (name, created_time, modified_time)
VALUES ('genTypePair_manager', now(), now());

INSERT INTO sys_user_sys_role_mapping (role_id, user_id)
VALUES ((SELECT id FROM sys_role WHERE name = 'genTypePair_manager' LIMIT 1), 1);

INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genTypePair:get', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genTypePair:list', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genTypePair:select', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genTypePair:menu', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genTypePair:insert', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genTypePair:update', now(), now());
INSERT INTO sys_permission (name, created_time, modified_time)
VALUES ('model:genTypePair:delete', now(), now());

INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'genTypePair_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:genTypePair:get', 'model:genTypePair:list', 'model:genTypePair:select', 'model:genTypePair:menu', 'model:genTypePair:insert', 'model:genTypePair:update', 'model:genTypePair:delete');


INSERT INTO sys_role_sys_permission_mapping (role_id, permission_id)
SELECT (SELECT id FROM sys_role WHERE name = 'group__model_manager' LIMIT 1), id FROM sys_permission 
WHERE sys_permission.name IN ('model:genTypePair:get', 'model:genTypePair:list', 'model:genTypePair:select', 'model:genTypePair:menu', 'model:genTypePair:insert', 'model:genTypePair:update', 'model:genTypePair:delete');