DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'DbSchemaPage'
);

DELETE FROM sys_menu WHERE name = 'DbSchemaPage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'database' LIMIT 1) target), 'DbSchemaPage', '/DbSchemaPage', 'List', '数据架构', 'pages/database/DbSchemaPage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'database:dbSchema:menu' AND sys_menu.name = 'DbSchemaPage';
