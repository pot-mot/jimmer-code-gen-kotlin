DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'database'
);

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE parent_id IN (
        SELECT id FROM sys_menu WHERE name = 'database'
    )
);

DELETE FROM sys_menu WHERE parent_id IN (
    SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'database') target
);

DELETE FROM sys_menu WHERE name = 'database';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES (NULL, 'database', '/database', 'List', '数据库', NULL, 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'database:menu' AND sys_menu.name = 'database';
