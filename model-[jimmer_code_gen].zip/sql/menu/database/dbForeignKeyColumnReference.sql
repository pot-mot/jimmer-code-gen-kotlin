DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'DbForeignKeyColumnReferencePage'
);

DELETE FROM sys_menu WHERE name = 'DbForeignKeyColumnReferencePage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'database' LIMIT 1) target), 'DbForeignKeyColumnReferencePage', '/DbForeignKeyColumnReferencePage', 'List', '外键列引用', 'pages/database/DbForeignKeyColumnReferencePage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'database:dbForeignKeyColumnReference:menu' AND sys_menu.name = 'DbForeignKeyColumnReferencePage';
