DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'DbForeignKeyPage'
);

DELETE FROM sys_menu WHERE name = 'DbForeignKeyPage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'database' LIMIT 1) target), 'DbForeignKeyPage', '/DbForeignKeyPage', 'List', '外键', 'pages/database/DbForeignKeyPage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'database:dbForeignKey:menu' AND sys_menu.name = 'DbForeignKeyPage';
