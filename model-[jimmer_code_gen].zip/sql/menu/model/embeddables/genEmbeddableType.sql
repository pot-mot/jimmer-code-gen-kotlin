DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'GenEmbeddableTypePage'
);

DELETE FROM sys_menu WHERE name = 'GenEmbeddableTypePage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'embeddables' LIMIT 1) target), 'GenEmbeddableTypePage', '/GenEmbeddableTypePage', 'List', '复合类型', 'pages/model/embeddables/GenEmbeddableTypePage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'model:embeddables:genEmbeddableType:menu' AND sys_menu.name = 'GenEmbeddableTypePage';
