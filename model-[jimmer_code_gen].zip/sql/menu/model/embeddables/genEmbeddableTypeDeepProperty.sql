DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'GenEmbeddableTypeDeepPropertyPage'
);

DELETE FROM sys_menu WHERE name = 'GenEmbeddableTypeDeepPropertyPage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'embeddables' LIMIT 1) target), 'GenEmbeddableTypeDeepPropertyPage', '/GenEmbeddableTypeDeepPropertyPage', 'List', '深层复合属性', 'pages/model/embeddables/GenEmbeddableTypeDeepPropertyPage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'model:embeddables:genEmbeddableTypeDeepProperty:menu' AND sys_menu.name = 'GenEmbeddableTypeDeepPropertyPage';
