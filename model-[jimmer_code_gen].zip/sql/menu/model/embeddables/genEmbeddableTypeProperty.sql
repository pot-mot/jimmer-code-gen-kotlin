DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'GenEmbeddableTypePropertyPage'
);

DELETE FROM sys_menu WHERE name = 'GenEmbeddableTypePropertyPage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'embeddables' LIMIT 1) target), 'GenEmbeddableTypePropertyPage', '/GenEmbeddableTypePropertyPage', 'List', '复合类型属性', 'pages/model/embeddables/GenEmbeddableTypePropertyPage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'model:embeddables:genEmbeddableTypeProperty:menu' AND sys_menu.name = 'GenEmbeddableTypePropertyPage';
