DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'GenEnumItemPage'
);

DELETE FROM sys_menu WHERE name = 'GenEnumItemPage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'enums' LIMIT 1) target), 'GenEnumItemPage', '/GenEnumItemPage', 'List', '枚举元素', 'pages/model/enums/GenEnumItemPage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'model:enums:genEnumItem:menu' AND sys_menu.name = 'GenEnumItemPage';
