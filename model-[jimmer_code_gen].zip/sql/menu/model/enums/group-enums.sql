DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'enums'
);

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE parent_id IN (
        SELECT id FROM sys_menu WHERE name = 'enums'
    )
);

DELETE FROM sys_menu WHERE parent_id IN (
    SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'enums') target
);

DELETE FROM sys_menu WHERE name = 'enums';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES (NULL, 'enums', '/enums', 'List', '枚举', NULL, 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'enums:menu' AND sys_menu.name = 'enums';
