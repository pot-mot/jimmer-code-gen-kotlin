DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'GenColumnPropertyPage'
);

DELETE FROM sys_menu WHERE name = 'GenColumnPropertyPage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'properties' LIMIT 1) target), 'GenColumnPropertyPage', '/GenColumnPropertyPage', 'List', '列属性', 'pages/model/entities/properties/GenColumnPropertyPage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'model:entities:properties:genColumnProperty:menu' AND sys_menu.name = 'GenColumnPropertyPage';
