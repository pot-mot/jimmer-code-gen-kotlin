DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'GenOneToOneMappedPropertyPage'
);

DELETE FROM sys_menu WHERE name = 'GenOneToOneMappedPropertyPage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'properties' LIMIT 1) target), 'GenOneToOneMappedPropertyPage', '/GenOneToOneMappedPropertyPage', 'List', '一对一映射属性', 'pages/model/entities/properties/GenOneToOneMappedPropertyPage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'model:entities:properties:genOneToOneMappedProperty:menu' AND sys_menu.name = 'GenOneToOneMappedPropertyPage';
