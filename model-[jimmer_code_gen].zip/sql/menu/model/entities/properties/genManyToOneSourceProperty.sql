DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'GenManyToOneSourcePropertyPage'
);

DELETE FROM sys_menu WHERE name = 'GenManyToOneSourcePropertyPage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'properties' LIMIT 1) target), 'GenManyToOneSourcePropertyPage', '/GenManyToOneSourcePropertyPage', 'List', '多对一源属性（对单）', 'pages/model/entities/properties/GenManyToOneSourcePropertyPage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'model:entities:properties:genManyToOneSourceProperty:menu' AND sys_menu.name = 'GenManyToOneSourcePropertyPage';
