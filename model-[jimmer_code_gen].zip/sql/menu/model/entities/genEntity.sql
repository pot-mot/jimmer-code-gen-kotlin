DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'GenEntityPage'
);

DELETE FROM sys_menu WHERE name = 'GenEntityPage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'entities' LIMIT 1) target), 'GenEntityPage', '/GenEntityPage', 'List', '实体', 'pages/model/entities/GenEntityPage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'model:entities:genEntity:menu' AND sys_menu.name = 'GenEntityPage';
