DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'associations'
);

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE parent_id IN (
        SELECT id FROM sys_menu WHERE name = 'associations'
    )
);

DELETE FROM sys_menu WHERE parent_id IN (
    SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'associations') target
);

DELETE FROM sys_menu WHERE name = 'associations';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES (NULL, 'associations', '/associations', 'List', '关联', NULL, 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'associations:menu' AND sys_menu.name = 'associations';
