DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'GenManyToOneAssociationPage'
);

DELETE FROM sys_menu WHERE name = 'GenManyToOneAssociationPage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'associations' LIMIT 1) target), 'GenManyToOneAssociationPage', '/GenManyToOneAssociationPage', 'List', '多对一关联', 'pages/model/associations/GenManyToOneAssociationPage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'model:associations:genManyToOneAssociation:menu' AND sys_menu.name = 'GenManyToOneAssociationPage';
