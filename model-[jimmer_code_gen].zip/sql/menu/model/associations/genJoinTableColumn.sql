DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'GenJoinTableColumnPage'
);

DELETE FROM sys_menu WHERE name = 'GenJoinTableColumnPage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'associations' LIMIT 1) target), 'GenJoinTableColumnPage', '/GenJoinTableColumnPage', 'List', 'Join Table Join Column', 'pages/model/associations/GenJoinTableColumnPage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'model:associations:genJoinTableColumn:menu' AND sys_menu.name = 'GenJoinTableColumnPage';
