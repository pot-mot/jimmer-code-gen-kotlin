DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'GenJoinTableFilterPage'
);

DELETE FROM sys_menu WHERE name = 'GenJoinTableFilterPage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'associations' LIMIT 1) target), 'GenJoinTableFilterPage', '/GenJoinTableFilterPage', 'List', 'Join Table 过滤器', 'pages/model/associations/GenJoinTableFilterPage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'model:associations:genJoinTableFilter:menu' AND sys_menu.name = 'GenJoinTableFilterPage';
