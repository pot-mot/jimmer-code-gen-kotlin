DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'GenTypePairPage'
);

DELETE FROM sys_menu WHERE name = 'GenTypePairPage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'model' LIMIT 1) target), 'GenTypePairPage', '/GenTypePairPage', 'List', '类型对', 'pages/model/GenTypePairPage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'model:genTypePair:menu' AND sys_menu.name = 'GenTypePairPage';
