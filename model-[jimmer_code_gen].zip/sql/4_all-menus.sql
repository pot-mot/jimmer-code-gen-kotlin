DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'model'
);

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE parent_id IN (
        SELECT id FROM sys_menu WHERE name = 'model'
    )
);

DELETE FROM sys_menu WHERE parent_id IN (
    SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'model') target
);

DELETE FROM sys_menu WHERE name = 'model';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES (NULL, 'model', '/model', 'List', '模型', NULL, 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'model:menu' AND sys_menu.name = 'model';

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'entities'
);

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE parent_id IN (
        SELECT id FROM sys_menu WHERE name = 'entities'
    )
);

DELETE FROM sys_menu WHERE parent_id IN (
    SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'entities') target
);

DELETE FROM sys_menu WHERE name = 'entities';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES (NULL, 'entities', '/entities', 'List', '实体', NULL, 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'entities:menu' AND sys_menu.name = 'entities';

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'enums'
);

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE parent_id IN (
        SELECT id FROM sys_menu WHERE name = 'enums'
    )
);

DELETE FROM sys_menu WHERE parent_id IN (
    SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'enums') target
);

DELETE FROM sys_menu WHERE name = 'enums';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES (NULL, 'enums', '/enums', 'List', '枚举', NULL, 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'enums:menu' AND sys_menu.name = 'enums';

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'database'
);

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE parent_id IN (
        SELECT id FROM sys_menu WHERE name = 'database'
    )
);

DELETE FROM sys_menu WHERE parent_id IN (
    SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'database') target
);

DELETE FROM sys_menu WHERE name = 'database';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES (NULL, 'database', '/database', 'List', '数据库', NULL, 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'database:menu' AND sys_menu.name = 'database';

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'associations'
);

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE parent_id IN (
        SELECT id FROM sys_menu WHERE name = 'associations'
    )
);

DELETE FROM sys_menu WHERE parent_id IN (
    SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'associations') target
);

DELETE FROM sys_menu WHERE name = 'associations';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES (NULL, 'associations', '/associations', 'List', '关联', NULL, 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'associations:menu' AND sys_menu.name = 'associations';

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'properties'
);

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE parent_id IN (
        SELECT id FROM sys_menu WHERE name = 'properties'
    )
);

DELETE FROM sys_menu WHERE parent_id IN (
    SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'properties') target
);

DELETE FROM sys_menu WHERE name = 'properties';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES (NULL, 'properties', '/properties', 'List', '属性', NULL, 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'properties:menu' AND sys_menu.name = 'properties';

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'embeddables'
);

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE parent_id IN (
        SELECT id FROM sys_menu WHERE name = 'embeddables'
    )
);

DELETE FROM sys_menu WHERE parent_id IN (
    SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'embeddables') target
);

DELETE FROM sys_menu WHERE name = 'embeddables';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES (NULL, 'embeddables', '/embeddables', 'List', '内嵌复合类型', NULL, 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'embeddables:menu' AND sys_menu.name = 'embeddables';

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'DbDataSourcePage'
);

DELETE FROM sys_menu WHERE name = 'DbDataSourcePage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'database' LIMIT 1) target), 'DbDataSourcePage', '/DbDataSourcePage', 'List', '数据源', 'pages/database/DbDataSourcePage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'database:dbDataSource:menu' AND sys_menu.name = 'DbDataSourcePage';

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'DbForeignKeyPage'
);

DELETE FROM sys_menu WHERE name = 'DbForeignKeyPage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'database' LIMIT 1) target), 'DbForeignKeyPage', '/DbForeignKeyPage', 'List', '外键', 'pages/database/DbForeignKeyPage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'database:dbForeignKey:menu' AND sys_menu.name = 'DbForeignKeyPage';

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'DbForeignKeyColumnReferencePage'
);

DELETE FROM sys_menu WHERE name = 'DbForeignKeyColumnReferencePage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'database' LIMIT 1) target), 'DbForeignKeyColumnReferencePage', '/DbForeignKeyColumnReferencePage', 'List', '外键列引用', 'pages/database/DbForeignKeyColumnReferencePage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'database:dbForeignKeyColumnReference:menu' AND sys_menu.name = 'DbForeignKeyColumnReferencePage';

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'DbPrimaryKeyPage'
);

DELETE FROM sys_menu WHERE name = 'DbPrimaryKeyPage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'database' LIMIT 1) target), 'DbPrimaryKeyPage', '/DbPrimaryKeyPage', 'List', '主键', 'pages/database/DbPrimaryKeyPage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'database:dbPrimaryKey:menu' AND sys_menu.name = 'DbPrimaryKeyPage';

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'DbSchemaPage'
);

DELETE FROM sys_menu WHERE name = 'DbSchemaPage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'database' LIMIT 1) target), 'DbSchemaPage', '/DbSchemaPage', 'List', '数据架构', 'pages/database/DbSchemaPage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'database:dbSchema:menu' AND sys_menu.name = 'DbSchemaPage';

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'DbTablePage'
);

DELETE FROM sys_menu WHERE name = 'DbTablePage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'database' LIMIT 1) target), 'DbTablePage', '/DbTablePage', 'List', '', 'pages/database/DbTablePage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'database:dbTable:menu' AND sys_menu.name = 'DbTablePage';

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'DbTableColumnPage'
);

DELETE FROM sys_menu WHERE name = 'DbTableColumnPage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'database' LIMIT 1) target), 'DbTableColumnPage', '/DbTableColumnPage', 'List', '列', 'pages/database/DbTableColumnPage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'database:dbTableColumn:menu' AND sys_menu.name = 'DbTableColumnPage';

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'DbTableIndexPage'
);

DELETE FROM sys_menu WHERE name = 'DbTableIndexPage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'database' LIMIT 1) target), 'DbTableIndexPage', '/DbTableIndexPage', 'List', '表索引', 'pages/database/DbTableIndexPage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'database:dbTableIndex:menu' AND sys_menu.name = 'DbTableIndexPage';

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'GenJoinTablePage'
);

DELETE FROM sys_menu WHERE name = 'GenJoinTablePage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'associations' LIMIT 1) target), 'GenJoinTablePage', '/GenJoinTablePage', 'List', 'Join Table', 'pages/model/associations/GenJoinTablePage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'model:associations:genJoinTable:menu' AND sys_menu.name = 'GenJoinTablePage';

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'GenJoinTableColumnPage'
);

DELETE FROM sys_menu WHERE name = 'GenJoinTableColumnPage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'associations' LIMIT 1) target), 'GenJoinTableColumnPage', '/GenJoinTableColumnPage', 'List', 'Join Table Join Column', 'pages/model/associations/GenJoinTableColumnPage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'model:associations:genJoinTableColumn:menu' AND sys_menu.name = 'GenJoinTableColumnPage';

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'GenJoinTableFilterPage'
);

DELETE FROM sys_menu WHERE name = 'GenJoinTableFilterPage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'associations' LIMIT 1) target), 'GenJoinTableFilterPage', '/GenJoinTableFilterPage', 'List', 'Join Table 过滤器', 'pages/model/associations/GenJoinTableFilterPage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'model:associations:genJoinTableFilter:menu' AND sys_menu.name = 'GenJoinTableFilterPage';

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'GenJoinTableLogicalDeleteFilterPage'
);

DELETE FROM sys_menu WHERE name = 'GenJoinTableLogicalDeleteFilterPage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'associations' LIMIT 1) target), 'GenJoinTableLogicalDeleteFilterPage', '/GenJoinTableLogicalDeleteFilterPage', 'List', 'Join Table 逻辑删除过滤器', 'pages/model/associations/GenJoinTableLogicalDeleteFilterPage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'model:associations:genJoinTableLogicalDeleteFilter:menu' AND sys_menu.name = 'GenJoinTableLogicalDeleteFilterPage';

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'GenManyToManyAssociationPage'
);

DELETE FROM sys_menu WHERE name = 'GenManyToManyAssociationPage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'associations' LIMIT 1) target), 'GenManyToManyAssociationPage', '/GenManyToManyAssociationPage', 'List', '多对多关联', 'pages/model/associations/GenManyToManyAssociationPage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'model:associations:genManyToManyAssociation:menu' AND sys_menu.name = 'GenManyToManyAssociationPage';

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'GenManyToOneAssociationPage'
);

DELETE FROM sys_menu WHERE name = 'GenManyToOneAssociationPage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'associations' LIMIT 1) target), 'GenManyToOneAssociationPage', '/GenManyToOneAssociationPage', 'List', '多对一关联', 'pages/model/associations/GenManyToOneAssociationPage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'model:associations:genManyToOneAssociation:menu' AND sys_menu.name = 'GenManyToOneAssociationPage';

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'GenOneToOneAssociationPage'
);

DELETE FROM sys_menu WHERE name = 'GenOneToOneAssociationPage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'associations' LIMIT 1) target), 'GenOneToOneAssociationPage', '/GenOneToOneAssociationPage', 'List', '一对一关联', 'pages/model/associations/GenOneToOneAssociationPage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'model:associations:genOneToOneAssociation:menu' AND sys_menu.name = 'GenOneToOneAssociationPage';

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'GenEmbeddableTypePage'
);

DELETE FROM sys_menu WHERE name = 'GenEmbeddableTypePage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'embeddables' LIMIT 1) target), 'GenEmbeddableTypePage', '/GenEmbeddableTypePage', 'List', '复合类型', 'pages/model/embeddables/GenEmbeddableTypePage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'model:embeddables:genEmbeddableType:menu' AND sys_menu.name = 'GenEmbeddableTypePage';

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'GenEmbeddableTypeDeepPropertyPage'
);

DELETE FROM sys_menu WHERE name = 'GenEmbeddableTypeDeepPropertyPage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'embeddables' LIMIT 1) target), 'GenEmbeddableTypeDeepPropertyPage', '/GenEmbeddableTypeDeepPropertyPage', 'List', '深层复合属性', 'pages/model/embeddables/GenEmbeddableTypeDeepPropertyPage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'model:embeddables:genEmbeddableTypeDeepProperty:menu' AND sys_menu.name = 'GenEmbeddableTypeDeepPropertyPage';

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'GenEmbeddableTypePropertyPage'
);

DELETE FROM sys_menu WHERE name = 'GenEmbeddableTypePropertyPage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'embeddables' LIMIT 1) target), 'GenEmbeddableTypePropertyPage', '/GenEmbeddableTypePropertyPage', 'List', '复合类型属性', 'pages/model/embeddables/GenEmbeddableTypePropertyPage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'model:embeddables:genEmbeddableTypeProperty:menu' AND sys_menu.name = 'GenEmbeddableTypePropertyPage';

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'GenEntityPage'
);

DELETE FROM sys_menu WHERE name = 'GenEntityPage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'entities' LIMIT 1) target), 'GenEntityPage', '/GenEntityPage', 'List', '实体', 'pages/model/entities/GenEntityPage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'model:entities:genEntity:menu' AND sys_menu.name = 'GenEntityPage';

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'GenEntityIndexPage'
);

DELETE FROM sys_menu WHERE name = 'GenEntityIndexPage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'entities' LIMIT 1) target), 'GenEntityIndexPage', '/GenEntityIndexPage', 'List', '实体索引', 'pages/model/entities/GenEntityIndexPage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'model:entities:genEntityIndex:menu' AND sys_menu.name = 'GenEntityIndexPage';

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'GenEntityInheritPage'
);

DELETE FROM sys_menu WHERE name = 'GenEntityInheritPage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'entities' LIMIT 1) target), 'GenEntityInheritPage', '/GenEntityInheritPage', 'List', '实体继承', 'pages/model/entities/GenEntityInheritPage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'model:entities:genEntityInherit:menu' AND sys_menu.name = 'GenEntityInheritPage';

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'GenEntityKeyGroupPage'
);

DELETE FROM sys_menu WHERE name = 'GenEntityKeyGroupPage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'entities' LIMIT 1) target), 'GenEntityKeyGroupPage', '/GenEntityKeyGroupPage', 'List', '实体业务键组', 'pages/model/entities/GenEntityKeyGroupPage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'model:entities:genEntityKeyGroup:menu' AND sys_menu.name = 'GenEntityKeyGroupPage';

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'GenExtraPropertyPage'
);

DELETE FROM sys_menu WHERE name = 'GenExtraPropertyPage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'properties' LIMIT 1) target), 'GenExtraPropertyPage', '/GenExtraPropertyPage', 'List', '额外属性', 'pages/model/entities/properties/GenExtraPropertyPage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'model:entities:properties:genExtraProperty:menu' AND sys_menu.name = 'GenExtraPropertyPage';

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'GenIdPropertyPage'
);

DELETE FROM sys_menu WHERE name = 'GenIdPropertyPage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'properties' LIMIT 1) target), 'GenIdPropertyPage', '/GenIdPropertyPage', 'List', 'ID属性', 'pages/model/entities/properties/GenIdPropertyPage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'model:entities:properties:genIdProperty:menu' AND sys_menu.name = 'GenIdPropertyPage';

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'GenLogicalDeletePropertyPage'
);

DELETE FROM sys_menu WHERE name = 'GenLogicalDeletePropertyPage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'properties' LIMIT 1) target), 'GenLogicalDeletePropertyPage', '/GenLogicalDeletePropertyPage', 'List', '逻辑删除属性', 'pages/model/entities/properties/GenLogicalDeletePropertyPage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'model:entities:properties:genLogicalDeleteProperty:menu' AND sys_menu.name = 'GenLogicalDeletePropertyPage';

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'GenManyToManyMappedPropertyPage'
);

DELETE FROM sys_menu WHERE name = 'GenManyToManyMappedPropertyPage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'properties' LIMIT 1) target), 'GenManyToManyMappedPropertyPage', '/GenManyToManyMappedPropertyPage', 'List', '多对多映射属性', 'pages/model/entities/properties/GenManyToManyMappedPropertyPage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'model:entities:properties:genManyToManyMappedProperty:menu' AND sys_menu.name = 'GenManyToManyMappedPropertyPage';

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'GenManyToManySourcePropertyPage'
);

DELETE FROM sys_menu WHERE name = 'GenManyToManySourcePropertyPage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'properties' LIMIT 1) target), 'GenManyToManySourcePropertyPage', '/GenManyToManySourcePropertyPage', 'List', '多对多源属性', 'pages/model/entities/properties/GenManyToManySourcePropertyPage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'model:entities:properties:genManyToManySourceProperty:menu' AND sys_menu.name = 'GenManyToManySourcePropertyPage';

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'GenManyToOneMappedPropertyPage'
);

DELETE FROM sys_menu WHERE name = 'GenManyToOneMappedPropertyPage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'properties' LIMIT 1) target), 'GenManyToOneMappedPropertyPage', '/GenManyToOneMappedPropertyPage', 'List', '多对一映射属性（对多）', 'pages/model/entities/properties/GenManyToOneMappedPropertyPage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'model:entities:properties:genManyToOneMappedProperty:menu' AND sys_menu.name = 'GenManyToOneMappedPropertyPage';

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'GenManyToOneSourcePropertyPage'
);

DELETE FROM sys_menu WHERE name = 'GenManyToOneSourcePropertyPage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'properties' LIMIT 1) target), 'GenManyToOneSourcePropertyPage', '/GenManyToOneSourcePropertyPage', 'List', '多对一源属性（对单）', 'pages/model/entities/properties/GenManyToOneSourcePropertyPage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'model:entities:properties:genManyToOneSourceProperty:menu' AND sys_menu.name = 'GenManyToOneSourcePropertyPage';

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'GenOneToOneMappedPropertyPage'
);

DELETE FROM sys_menu WHERE name = 'GenOneToOneMappedPropertyPage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'properties' LIMIT 1) target), 'GenOneToOneMappedPropertyPage', '/GenOneToOneMappedPropertyPage', 'List', '一对一映射属性', 'pages/model/entities/properties/GenOneToOneMappedPropertyPage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'model:entities:properties:genOneToOneMappedProperty:menu' AND sys_menu.name = 'GenOneToOneMappedPropertyPage';

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'GenOneToOneSourcePropertyPage'
);

DELETE FROM sys_menu WHERE name = 'GenOneToOneSourcePropertyPage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'properties' LIMIT 1) target), 'GenOneToOneSourcePropertyPage', '/GenOneToOneSourcePropertyPage', 'List', '一对一源属性', 'pages/model/entities/properties/GenOneToOneSourcePropertyPage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'model:entities:properties:genOneToOneSourceProperty:menu' AND sys_menu.name = 'GenOneToOneSourcePropertyPage';

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'GenPropertyPage'
);

DELETE FROM sys_menu WHERE name = 'GenPropertyPage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'properties' LIMIT 1) target), 'GenPropertyPage', '/GenPropertyPage', 'List', '属性', 'pages/model/entities/properties/GenPropertyPage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'model:entities:properties:genProperty:menu' AND sys_menu.name = 'GenPropertyPage';

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'GenSortPropertyPage'
);

DELETE FROM sys_menu WHERE name = 'GenSortPropertyPage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'properties' LIMIT 1) target), 'GenSortPropertyPage', '/GenSortPropertyPage', 'List', '排序属性', 'pages/model/entities/properties/GenSortPropertyPage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'model:entities:properties:genSortProperty:menu' AND sys_menu.name = 'GenSortPropertyPage';

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'GenVersionPropertyPage'
);

DELETE FROM sys_menu WHERE name = 'GenVersionPropertyPage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'properties' LIMIT 1) target), 'GenVersionPropertyPage', '/GenVersionPropertyPage', 'List', '乐观锁属性', 'pages/model/entities/properties/GenVersionPropertyPage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'model:entities:properties:genVersionProperty:menu' AND sys_menu.name = 'GenVersionPropertyPage';

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'GenEnumPage'
);

DELETE FROM sys_menu WHERE name = 'GenEnumPage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'enums' LIMIT 1) target), 'GenEnumPage', '/GenEnumPage', 'List', '枚举', 'pages/model/enums/GenEnumPage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'model:enums:genEnum:menu' AND sys_menu.name = 'GenEnumPage';

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'GenEnumItemPage'
);

DELETE FROM sys_menu WHERE name = 'GenEnumItemPage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'enums' LIMIT 1) target), 'GenEnumItemPage', '/GenEnumItemPage', 'List', '枚举元素', 'pages/model/enums/GenEnumItemPage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'model:enums:genEnumItem:menu' AND sys_menu.name = 'GenEnumItemPage';

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'GenColumnInfoPage'
);

DELETE FROM sys_menu WHERE name = 'GenColumnInfoPage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'model' LIMIT 1) target), 'GenColumnInfoPage', '/GenColumnInfoPage', 'List', '列信息', 'pages/model/GenColumnInfoPage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'model:genColumnInfo:menu' AND sys_menu.name = 'GenColumnInfoPage';

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'GenModelPage'
);

DELETE FROM sys_menu WHERE name = 'GenModelPage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'model' LIMIT 1) target), 'GenModelPage', '/GenModelPage', 'List', '模型', 'pages/model/GenModelPage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'model:genModel:menu' AND sys_menu.name = 'GenModelPage';

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'GenModelConfigPage'
);

DELETE FROM sys_menu WHERE name = 'GenModelConfigPage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'model' LIMIT 1) target), 'GenModelConfigPage', '/GenModelConfigPage', 'List', '模型配置', 'pages/model/GenModelConfigPage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'model:genModelConfig:menu' AND sys_menu.name = 'GenModelConfigPage';

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'GenModelGroupPage'
);

DELETE FROM sys_menu WHERE name = 'GenModelGroupPage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'model' LIMIT 1) target), 'GenModelGroupPage', '/GenModelGroupPage', 'List', '模型分组', 'pages/model/GenModelGroupPage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'model:genModelGroup:menu' AND sys_menu.name = 'GenModelGroupPage';

DELETE FROM sys_menu_sys_permission_mapping WHERE menu_id IN (
    SELECT id FROM sys_menu WHERE name = 'GenTypePairPage'
);

DELETE FROM sys_menu WHERE name = 'GenTypePairPage';

INSERT INTO sys_menu 
(parent_id, name, path, icon, label, component, order_key, created_time, modified_time)
VALUES ((SELECT id FROM (SELECT id FROM sys_menu WHERE name = 'model' LIMIT 1) target), 'GenTypePairPage', '/GenTypePairPage', 'List', '类型对', 'pages/model/GenTypePairPage.vue', 1, now(), now());

INSERT INTO sys_menu_sys_permission_mapping (permission_id, menu_id)
SELECT sys_permission.id, sys_menu.id FROM sys_permission, sys_menu 
WHERE sys_permission.name = 'model:genTypePair:menu' AND sys_menu.name = 'GenTypePairPage';
