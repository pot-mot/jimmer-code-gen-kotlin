<script setup lang="ts">
import type {DbPrimaryKeyListView} from "@/api/__generated/model/static"
import {usePageSizeStore} from "@/stores/pageSizeStore"

withDefaults(defineProps<{
    rows: Array<DbPrimaryKeyListView>,
    idColumn?: boolean | undefined,
    indexColumn?: boolean | undefined,
    multiSelect?: boolean | undefined,
    withOperations?: boolean | undefined
}>(), {
    idColumn: false,
    indexColumn: true,
    multiSelect: true,
    withOperations: true,
})

const emits = defineEmits<{
    (
        event: "selectionChange",
        selection: Array<DbPrimaryKeyListView>
    ): void
}>()

defineSlots<{
    operations(props: {row: DbPrimaryKeyListView, index: number}): any
}>()

const pageSizeStore = usePageSizeStore()

const handleSelectionChange = (
    newSelection: Array<DbPrimaryKeyListView>
): void => {
    emits("selectionChange", newSelection)
}
</script>

<template>
    <el-table
        :data="rows"
        row-key="id"
        border
        stripe
        class="view-table"
        @selection-change="handleSelectionChange"
    >
        <el-table-column
            v-if="idColumn"
            prop="id"
            label="ID"
            :fixed="pageSizeStore.isSmall ? undefined : 'left'"
        />
        <el-table-column
            v-if="indexColumn"
            type="index"
            :fixed="pageSizeStore.isSmall ? undefined : 'left'"
        />
        <el-table-column
            v-if="multiSelect"
            type="selection"
            :width="43"
            :fixed="pageSizeStore.isSmall ? undefined : 'left'"
        />
        <el-table-column
            prop="tableId"
            label="表"
            :min-width="161"
        />
        <el-table-column prop="name" label="名称" :min-width="129"/>
        <el-table-column
            prop="serialName"
            label="对应序列"
            :min-width="129"
        />
        <el-table-column
            prop="autoIncrement"
            label="是否自增"
            :min-width="81"
        >
            <template #default="scope">
                <el-checkbox :modelValue="scope.row.autoIncrement"/>
            </template>
        </el-table-column>
        <el-table-column
            prop="remark"
            label="备注"
            :min-width="129"
        />
        <el-table-column
            v-if="withOperations"
            label="操作"
            :fixed="pageSizeStore.isSmall ? undefined : 'right'"
        >
            <template #default="scope">
                <slot
                    name="operations"
                    :row="scope.row as DbPrimaryKeyListView"
                    :index="scope.$index"
                />
            </template>
        </el-table-column>
    </el-table>
</template>
