import {sendMessage} from "@/utils/message"
import type {DbPrimaryKeyInsertInput} from "@/api/__generated/model/static"

export type DbPrimaryKeyAddData = {
    tableId?: number | undefined
    name: string
    serialName?: string | undefined
    autoIncrement: boolean
    remark: string
}

const getUnmatchedMessageList = (data: DbPrimaryKeyAddData): Array<string> => {
    const messageList: Array<string> = []

    if (data.tableId === undefined) {
        messageList.push("表不可为空")
    }

    return messageList
}

export const validateDbPrimaryKeyAddDataForSubmit = (data: DbPrimaryKeyAddData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertDbPrimaryKeyAddDataAsSubmitType = (data: DbPrimaryKeyAddData): DbPrimaryKeyInsertInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as DbPrimaryKeyInsertInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
