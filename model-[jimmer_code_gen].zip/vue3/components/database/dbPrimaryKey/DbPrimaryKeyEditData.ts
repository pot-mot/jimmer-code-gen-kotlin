import {sendMessage} from "@/utils/message"
import type {DbPrimaryKeyUpdateInput} from "@/api/__generated/model/static"

export type DbPrimaryKeyEditData = {
    id: number
    tableId?: number | undefined
    name: string
    serialName?: string | undefined
    autoIncrement: boolean
    remark: string
}

const getUnmatchedMessageList = (data: DbPrimaryKeyEditData): Array<string> => {
    const messageList: Array<string> = []

    if (data.tableId === undefined) {
        messageList.push("表不可为空")
    }

    return messageList
}

export const validateDbPrimaryKeyEditDataForSubmit = (data: DbPrimaryKeyEditData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertDbPrimaryKeyEditDataAsSubmitType = (data: DbPrimaryKeyEditData): DbPrimaryKeyUpdateInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as DbPrimaryKeyUpdateInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
