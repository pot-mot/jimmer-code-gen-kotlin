import type {DbPrimaryKeyAddData} from "./DbPrimaryKeyAddData"

export const createDefaultDbPrimaryKey = (): DbPrimaryKeyAddData => {
    return {
        tableId: undefined,
        name: "",
        serialName: undefined,
        autoIncrement: false,
        remark: ""
    }
}
