<script setup lang="ts">
import {ref} from "vue"
import type {FormInstance} from "element-plus"
import type {FormExpose} from "@/components/form/FormExpose"
import type {
    DbPrimaryKeyInsertInput,
    DbTableOptionView
} from "@/api/__generated/model/static"
import {
    validateDbPrimaryKeyAddDataForSubmit,
    assertDbPrimaryKeyAddDataAsSubmitType
} from "@/components/database/dbPrimaryKey/DbPrimaryKeyAddData"
import type {DbPrimaryKeyAddData} from "@/components/database/dbPrimaryKey/DbPrimaryKeyAddData"
import {createDefaultDbPrimaryKey} from "@/components/database/dbPrimaryKey/createDefaultDbPrimaryKey"
import {useRules} from "@/rules/database/dbPrimaryKey/DbPrimaryKeyAddFormRules"
import DbTableIdSelect from "@/components/database/dbTable/DbTableIdSelect.vue"
import type {LazyOptions} from "@/utils/lazyOptions"

const props = withDefaults(defineProps<{
    withOperations?: boolean | undefined,
    submitLoading?: boolean | undefined,
    tableIdOptions: LazyOptions<DbTableOptionView>
}>(), {
    withOperations: true,
    submitLoading: false,
})

const emits = defineEmits<{
    (
        event: "submit",
        formData: DbPrimaryKeyInsertInput
    ): void,
    (event: "cancel"): void
}>()

defineSlots<{
    operations(props: {
        handleSubmit: () => Promise<void>,
        handleCancel: () => void
    }): any
}>()

const formData = ref<DbPrimaryKeyAddData>(createDefaultDbPrimaryKey())

const formRef = ref<FormInstance>()
const rules = useRules(formData)

// 校验
const handleValidate = async (
    errorHandler: (errors: any[]) => void = (errors) => {console.error(errors)}
): Promise<boolean> => {
    const errors: any[] = []
    const formValid: boolean = await formRef.value?.validate().catch(e => {
        errors.push(e)
        return false
    }) ?? false

    const typeValidate: boolean = validateDbPrimaryKeyAddDataForSubmit(formData.value)

    errorHandler?.(errors)
    return formValid && typeValidate
}

// 提交
const handleSubmit = async (): Promise<void> => {
    if (props.submitLoading) return

    const validResult = await handleValidate()
    if (validResult) {
        emits("submit", assertDbPrimaryKeyAddDataAsSubmitType(formData.value))
    }
}

// 取消
const handleCancel = (): void => {
    emits("cancel")
}

defineExpose<FormExpose>({
    validate: handleValidate
})
</script>

<template>
    <el-form
        :model="formData"
        ref="formRef"
        :rules="rules"
        label-width="auto"
        @submit.prevent
        class="add-form"
    >
        <el-form-item prop="tableId" label="表">
            <DbTableIdSelect
                v-model="formData.tableId"
                :options="tableIdOptions"
            />
        </el-form-item>
        <el-form-item prop="name" label="名称">
            <el-input
                v-model="formData.name"
                placeholder="请输入名称"
                clearable
            />
        </el-form-item>
        <el-form-item prop="serialName" label="对应序列">
            <el-input
                v-model="formData.serialName"
                placeholder="请输入对应序列"
                clearable
            />
        </el-form-item>
        <el-form-item prop="autoIncrement" label="是否自增">
            <el-switch v-model="formData.autoIncrement"/>
        </el-form-item>
        <el-form-item prop="remark" label="备注">
            <el-input
                v-model="formData.remark"
                placeholder="请输入备注"
                clearable
            />
        </el-form-item>

        <slot
            v-if="withOperations"
            name="operations"
            :handleSubmit="handleSubmit"
            :handleCancel="handleCancel"
        >
            <div class="form-operations">
                <el-button type="warning" @click="handleCancel">
                    取消
                </el-button>
                <el-button
                    type="primary"
                    :loading="submitLoading"
                    @click="handleSubmit"
                >
                    提交
                </el-button>
            </div>
        </slot>
    </el-form>
</template>
