<script setup lang="ts">
import type {DbDataSourceListView} from "@/api/__generated/model/static"
import {usePageSizeStore} from "@/stores/pageSizeStore"
import DatabaseTypeView from "@/components/enums/databaseType/DatabaseTypeView.vue"

withDefaults(defineProps<{
    rows: Array<DbDataSourceListView>,
    idColumn?: boolean | undefined,
    indexColumn?: boolean | undefined,
    multiSelect?: boolean | undefined,
    withOperations?: boolean | undefined
}>(), {
    idColumn: false,
    indexColumn: true,
    multiSelect: true,
    withOperations: true,
})

const emits = defineEmits<{
    (
        event: "selectionChange",
        selection: Array<DbDataSourceListView>
    ): void
}>()

defineSlots<{
    operations(props: {row: DbDataSourceListView, index: number}): any
}>()

const pageSizeStore = usePageSizeStore()

const handleSelectionChange = (
    newSelection: Array<DbDataSourceListView>
): void => {
    emits("selectionChange", newSelection)
}
</script>

<template>
    <el-table
        :data="rows"
        row-key="id"
        border
        stripe
        class="view-table"
        @selection-change="handleSelectionChange"
    >
        <el-table-column
            v-if="idColumn"
            prop="id"
            label="ID"
            :fixed="pageSizeStore.isSmall ? undefined : 'left'"
        />
        <el-table-column
            v-if="indexColumn"
            type="index"
            :fixed="pageSizeStore.isSmall ? undefined : 'left'"
        />
        <el-table-column
            v-if="multiSelect"
            type="selection"
            :width="43"
            :fixed="pageSizeStore.isSmall ? undefined : 'left'"
        />
        <el-table-column
            prop="type"
            label="数据库类型"
            :min-width="129"
        >
            <template #default="scope">
                <DatabaseTypeView :value="scope.row.type"/>
            </template>
        </el-table-column>
        <el-table-column prop="name" label="名称" :min-width="129"/>
        <el-table-column prop="url" label="链接" :min-width="129"/>
        <el-table-column
            prop="username"
            label="用户名"
            :min-width="129"
        />
        <el-table-column
            prop="password"
            label="密码"
            :min-width="129"
        />
        <el-table-column
            prop="remark"
            label="备注"
            :min-width="129"
        />
        <el-table-column
            v-if="withOperations"
            label="操作"
            :fixed="pageSizeStore.isSmall ? undefined : 'right'"
        >
            <template #default="scope">
                <slot
                    name="operations"
                    :row="scope.row as DbDataSourceListView"
                    :index="scope.$index"
                />
            </template>
        </el-table-column>
    </el-table>
</template>
