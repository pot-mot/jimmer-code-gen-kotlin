import {sendMessage} from "@/utils/message"
import type {DbDataSourceInsertInput} from "@/api/__generated/model/static"
import type {DatabaseType} from "@/api/__generated/model/enums"

export type DbDataSourceAddData = {
    type: DatabaseType
    name: string
    url: string
    username: string
    password: string
    remark: string
}

const getUnmatchedMessageList = (data: DbDataSourceAddData): Array<string> => {
    const messageList: Array<string> = []


    return messageList
}

export const validateDbDataSourceAddDataForSubmit = (data: DbDataSourceAddData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertDbDataSourceAddDataAsSubmitType = (data: DbDataSourceAddData): DbDataSourceInsertInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as DbDataSourceInsertInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
