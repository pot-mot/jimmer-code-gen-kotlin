<script setup lang="ts">
import {Search} from "@element-plus/icons-vue"
import type {DbDataSourceSpec} from "@/api/__generated/model/static"
import DatabaseTypeNullableSelect from "@/components/enums/databaseType/DatabaseTypeNullableSelect.vue"

const spec = defineModel<DbDataSourceSpec>({
    required: true
})

const emits = defineEmits<{
    (event: "query", spec: DbDataSourceSpec): void
}>()
</script>

<template>
    <el-form
        :model="spec"
        label-width="auto"
        @submit.prevent
        class="query-form"
    >
        <el-row :gutter="20">
            <el-col :span="8" :xs="24">
                <el-form-item prop="type" label="数据库类型">
                    <DatabaseTypeNullableSelect
                        v-model="spec.type"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="name" label="名称">
                    <el-input
                        v-model="spec.name"
                        placeholder="请输入名称"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="url" label="链接">
                    <el-input
                        v-model="spec.url"
                        placeholder="请输入链接"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="username" label="用户名">
                    <el-input
                        v-model="spec.username"
                        placeholder="请输入用户名"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="password" label="密码">
                    <el-input
                        v-model="spec.password"
                        placeholder="请输入密码"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="remark" label="备注">
                    <el-input
                        v-model="spec.remark"
                        placeholder="请输入备注"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-button
                type="primary"
                :icon="Search"
                class="search-button"
                @click="emits('query', spec)"
            >
                查询
            </el-button>
        </el-row>
    </el-form>
</template>
