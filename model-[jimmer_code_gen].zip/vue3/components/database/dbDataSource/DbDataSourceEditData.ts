import {sendMessage} from "@/utils/message"
import type {DbDataSourceUpdateInput} from "@/api/__generated/model/static"
import type {DatabaseType} from "@/api/__generated/model/enums"

export type DbDataSourceEditData = {
    id: number
    type: DatabaseType
    name: string
    url: string
    username: string
    password: string
    remark: string
}

const getUnmatchedMessageList = (data: DbDataSourceEditData): Array<string> => {
    const messageList: Array<string> = []


    return messageList
}

export const validateDbDataSourceEditDataForSubmit = (data: DbDataSourceEditData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertDbDataSourceEditDataAsSubmitType = (data: DbDataSourceEditData): DbDataSourceUpdateInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as DbDataSourceUpdateInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
