<script setup lang="ts">
import {ref} from "vue"
import type {FormInstance} from "element-plus"
import type {FormExpose} from "@/components/form/FormExpose"
import type {DbDataSourceUpdateInput} from "@/api/__generated/model/static"
import {
    validateDbDataSourceEditDataForSubmit,
    assertDbDataSourceEditDataAsSubmitType
} from "@/components/database/dbDataSource/DbDataSourceEditData"
import type {DbDataSourceEditData} from "@/components/database/dbDataSource/DbDataSourceEditData"
import {useRules} from "@/rules/database/dbDataSource/DbDataSourceEditFormRules"
import DatabaseTypeSelect from "@/components/enums/databaseType/DatabaseTypeSelect.vue"

const formData = defineModel<DbDataSourceEditData>({
    required: true
})

const props = withDefaults(defineProps<{
    withOperations?: boolean | undefined,
    submitLoading?: boolean | undefined
}>(), {
    withOperations: true,
    submitLoading: false,
})

const emits = defineEmits<{
    (
        event: "submit",
        formData: DbDataSourceUpdateInput
    ): void,
    (event: "cancel"): void
}>()

defineSlots<{
    operations(props: {
        handleSubmit: () => Promise<void>,
        handleCancel: () => void
    }): any
}>()

const formRef = ref<FormInstance>()
const rules = useRules(formData)

// 校验
const handleValidate = async (
    errorHandler: (errors: any[]) => void = (errors) => {console.error(errors)}
): Promise<boolean> => {
    const errors: any[] = []
    const formValid: boolean = await formRef.value?.validate().catch(e => {
        errors.push(e)
        return false
    }) ?? false

    const typeValidate: boolean = validateDbDataSourceEditDataForSubmit(formData.value)

    errorHandler?.(errors)
    return formValid && typeValidate
}

// 提交
const handleSubmit = async (): Promise<void> => {
    if (props.submitLoading) return

    const validResult = await handleValidate()
    if (validResult) {
        emits("submit", assertDbDataSourceEditDataAsSubmitType(formData.value))
    }
}

// 取消
const handleCancel = (): void => {
    emits("cancel")
}

defineExpose<FormExpose>({
    validate: handleValidate
})
</script>

<template>
    <el-form
        :model="formData"
        ref="formRef"
        :rules="rules"
        label-width="auto"
        @submit.prevent
        class="edit-form"
    >
        <el-form-item prop="type" label="数据库类型">
            <DatabaseTypeSelect v-model="formData.type"/>
        </el-form-item>
        <el-form-item prop="name" label="名称">
            <el-input
                v-model="formData.name"
                placeholder="请输入名称"
                clearable
            />
        </el-form-item>
        <el-form-item prop="url" label="链接">
            <el-input
                v-model="formData.url"
                placeholder="请输入链接"
                clearable
            />
        </el-form-item>
        <el-form-item prop="username" label="用户名">
            <el-input
                v-model="formData.username"
                placeholder="请输入用户名"
                clearable
            />
        </el-form-item>
        <el-form-item prop="password" label="密码">
            <el-input
                v-model="formData.password"
                placeholder="请输入密码"
                clearable
            />
        </el-form-item>
        <el-form-item prop="remark" label="备注">
            <el-input
                v-model="formData.remark"
                placeholder="请输入备注"
                clearable
            />
        </el-form-item>

        <slot
            v-if="withOperations"
            name="operations"
            :handleSubmit="handleSubmit"
            :handleCancel="handleCancel"
        >
            <div class="form-operations">
                <el-button type="warning" @click="handleCancel">
                    取消
                </el-button>
                <el-button
                    type="primary"
                    :loading="submitLoading"
                    @click="handleSubmit"
                >
                    提交
                </el-button>
            </div>
        </slot>
    </el-form>
</template>
