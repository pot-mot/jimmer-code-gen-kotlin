import type {DbDataSourceAddData} from "./DbDataSourceAddData"

export const createDefaultDbDataSource = (): DbDataSourceAddData => {
    return {
        type: "PostgreSQL",
        name: "",
        url: "",
        username: "",
        password: "",
        remark: ""
    }
}
