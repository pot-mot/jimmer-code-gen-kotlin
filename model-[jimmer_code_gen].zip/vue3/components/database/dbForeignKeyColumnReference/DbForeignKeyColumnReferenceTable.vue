<script setup lang="ts">
import type {DbForeignKeyColumnReferenceListView} from "@/api/__generated/model/static"
import {usePageSizeStore} from "@/stores/pageSizeStore"

withDefaults(defineProps<{
    rows: Array<DbForeignKeyColumnReferenceListView>,
    idColumn?: boolean | undefined,
    indexColumn?: boolean | undefined,
    multiSelect?: boolean | undefined,
    withOperations?: boolean | undefined
}>(), {
    idColumn: false,
    indexColumn: true,
    multiSelect: true,
    withOperations: true,
})

const emits = defineEmits<{
    (
        event: "selectionChange",
        selection: Array<DbForeignKeyColumnReferenceListView>
    ): void
}>()

defineSlots<{
    operations(props: {
        row: DbForeignKeyColumnReferenceListView,
        index: number
    }): any
}>()

const pageSizeStore = usePageSizeStore()

const handleSelectionChange = (
    newSelection: Array<DbForeignKeyColumnReferenceListView>
): void => {
    emits("selectionChange", newSelection)
}
</script>

<template>
    <el-table
        :data="rows"
        row-key="id"
        border
        stripe
        class="view-table"
        @selection-change="handleSelectionChange"
    >
        <el-table-column
            v-if="idColumn"
            prop="id"
            label="ID"
            :fixed="pageSizeStore.isSmall ? undefined : 'left'"
        />
        <el-table-column
            v-if="indexColumn"
            type="index"
            :fixed="pageSizeStore.isSmall ? undefined : 'left'"
        />
        <el-table-column
            v-if="multiSelect"
            type="selection"
            :width="43"
            :fixed="pageSizeStore.isSmall ? undefined : 'left'"
        />
        <el-table-column
            prop="associationId"
            label="关联"
            :min-width="161"
        />
        <el-table-column
            prop="sourceColumnId"
            label="主列"
            :min-width="161"
        />
        <el-table-column
            prop="targetColumnId"
            label="从列"
            :min-width="161"
        />
        <el-table-column
            prop="remark"
            label="备注"
            :min-width="129"
        />
        <el-table-column
            v-if="withOperations"
            label="操作"
            :fixed="pageSizeStore.isSmall ? undefined : 'right'"
        >
            <template #default="scope">
                <slot
                    name="operations"
                    :row="scope.row as DbForeignKeyColumnReferenceListView"
                    :index="scope.$index"
                />
            </template>
        </el-table-column>
    </el-table>
</template>
