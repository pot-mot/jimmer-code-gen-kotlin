import {sendMessage} from "@/utils/message"
import type {DbForeignKeyColumnReferenceInsertInput} from "@/api/__generated/model/static"

export type DbForeignKeyColumnReferenceAddData = {
    associationId?: number | undefined
    sourceColumnId?: number | undefined
    targetColumnId?: number | undefined
    remark: string
}

const getUnmatchedMessageList = (data: DbForeignKeyColumnReferenceAddData): Array<string> => {
    const messageList: Array<string> = []

    if (data.associationId === undefined) {
        messageList.push("关联不可为空")
    }
    if (data.sourceColumnId === undefined) {
        messageList.push("主列不可为空")
    }
    if (data.targetColumnId === undefined) {
        messageList.push("从列不可为空")
    }

    return messageList
}

export const validateDbForeignKeyColumnReferenceAddDataForSubmit = (data: DbForeignKeyColumnReferenceAddData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertDbForeignKeyColumnReferenceAddDataAsSubmitType = (data: DbForeignKeyColumnReferenceAddData): DbForeignKeyColumnReferenceInsertInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as DbForeignKeyColumnReferenceInsertInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
