import {sendMessage} from "@/utils/message"
import type {DbForeignKeyColumnReferenceUpdateInput} from "@/api/__generated/model/static"

export type DbForeignKeyColumnReferenceEditData = {
    id: number
    associationId?: number | undefined
    sourceColumnId?: number | undefined
    targetColumnId?: number | undefined
    remark: string
}

const getUnmatchedMessageList = (data: DbForeignKeyColumnReferenceEditData): Array<string> => {
    const messageList: Array<string> = []

    if (data.associationId === undefined) {
        messageList.push("关联不可为空")
    }
    if (data.sourceColumnId === undefined) {
        messageList.push("主列不可为空")
    }
    if (data.targetColumnId === undefined) {
        messageList.push("从列不可为空")
    }

    return messageList
}

export const validateDbForeignKeyColumnReferenceEditDataForSubmit = (data: DbForeignKeyColumnReferenceEditData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertDbForeignKeyColumnReferenceEditDataAsSubmitType = (data: DbForeignKeyColumnReferenceEditData): DbForeignKeyColumnReferenceUpdateInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as DbForeignKeyColumnReferenceUpdateInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
