<script setup lang="ts">
import {ref} from "vue"
import type {FormInstance} from "element-plus"
import type {FormExpose} from "@/components/form/FormExpose"
import type {
    DbForeignKeyColumnReferenceInsertInput,
    DbForeignKeyOptionView,
    DbTableColumnOptionView
} from "@/api/__generated/model/static"
import {
    validateDbForeignKeyColumnReferenceAddDataForSubmit,
    assertDbForeignKeyColumnReferenceAddDataAsSubmitType
} from "@/components/database/dbForeignKeyColumnReference/DbForeignKeyColumnReferenceAddData"
import type {DbForeignKeyColumnReferenceAddData} from "@/components/database/dbForeignKeyColumnReference/DbForeignKeyColumnReferenceAddData"
import {createDefaultDbForeignKeyColumnReference} from "@/components/database/dbForeignKeyColumnReference/createDefaultDbForeignKeyColumnReference"
import {useRules} from "@/rules/database/dbForeignKeyColumnReference/DbForeignKeyColumnReferenceAddFormRules"
import DbForeignKeyIdSelect from "@/components/database/dbForeignKey/DbForeignKeyIdSelect.vue"
import DbTableColumnIdSelect from "@/components/database/dbTableColumn/DbTableColumnIdSelect.vue"
import type {LazyOptions} from "@/utils/lazyOptions"

const props = withDefaults(defineProps<{
    withOperations?: boolean | undefined,
    submitLoading?: boolean | undefined,
    associationIdOptions: LazyOptions<DbForeignKeyOptionView>,
    sourceColumnIdOptions: LazyOptions<DbTableColumnOptionView>,
    targetColumnIdOptions: LazyOptions<DbTableColumnOptionView>
}>(), {
    withOperations: true,
    submitLoading: false,
})

const emits = defineEmits<{
    (
        event: "submit",
        formData: DbForeignKeyColumnReferenceInsertInput
    ): void,
    (event: "cancel"): void
}>()

defineSlots<{
    operations(props: {
        handleSubmit: () => Promise<void>,
        handleCancel: () => void
    }): any
}>()

const formData = ref<DbForeignKeyColumnReferenceAddData>(createDefaultDbForeignKeyColumnReference())

const formRef = ref<FormInstance>()
const rules = useRules(formData)

// 校验
const handleValidate = async (
    errorHandler: (errors: any[]) => void = (errors) => {console.error(errors)}
): Promise<boolean> => {
    const errors: any[] = []
    const formValid: boolean = await formRef.value?.validate().catch(e => {
        errors.push(e)
        return false
    }) ?? false

    const typeValidate: boolean = validateDbForeignKeyColumnReferenceAddDataForSubmit(formData.value)

    errorHandler?.(errors)
    return formValid && typeValidate
}

// 提交
const handleSubmit = async (): Promise<void> => {
    if (props.submitLoading) return

    const validResult = await handleValidate()
    if (validResult) {
        emits("submit", assertDbForeignKeyColumnReferenceAddDataAsSubmitType(formData.value))
    }
}

// 取消
const handleCancel = (): void => {
    emits("cancel")
}

defineExpose<FormExpose>({
    validate: handleValidate
})
</script>

<template>
    <el-form
        :model="formData"
        ref="formRef"
        :rules="rules"
        label-width="auto"
        @submit.prevent
        class="add-form"
    >
        <el-form-item prop="associationId" label="关联">
            <DbForeignKeyIdSelect
                v-model="formData.associationId"
                :options="associationIdOptions"
            />
        </el-form-item>
        <el-form-item prop="sourceColumnId" label="主列">
            <DbTableColumnIdSelect
                v-model="formData.sourceColumnId"
                :options="sourceColumnIdOptions"
            />
        </el-form-item>
        <el-form-item prop="targetColumnId" label="从列">
            <DbTableColumnIdSelect
                v-model="formData.targetColumnId"
                :options="targetColumnIdOptions"
            />
        </el-form-item>
        <el-form-item prop="remark" label="备注">
            <el-input
                v-model="formData.remark"
                placeholder="请输入备注"
                clearable
            />
        </el-form-item>

        <slot
            v-if="withOperations"
            name="operations"
            :handleSubmit="handleSubmit"
            :handleCancel="handleCancel"
        >
            <div class="form-operations">
                <el-button type="warning" @click="handleCancel">
                    取消
                </el-button>
                <el-button
                    type="primary"
                    :loading="submitLoading"
                    @click="handleSubmit"
                >
                    提交
                </el-button>
            </div>
        </slot>
    </el-form>
</template>
