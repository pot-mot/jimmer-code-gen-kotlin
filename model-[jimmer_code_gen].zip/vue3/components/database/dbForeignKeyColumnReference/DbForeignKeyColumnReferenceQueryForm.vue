<script setup lang="ts">
import {Search} from "@element-plus/icons-vue"
import type {
    DbForeignKeyColumnReferenceSpec,
    DbForeignKeyOptionView,
    DbTableColumnOptionView
} from "@/api/__generated/model/static"
import DbForeignKeyIdSelect from "@/components/database/dbForeignKey/DbForeignKeyIdSelect.vue"
import DbTableColumnIdSelect from "@/components/database/dbTableColumn/DbTableColumnIdSelect.vue"
import type {LazyOptions} from "@/utils/lazyOptions"

const spec = defineModel<DbForeignKeyColumnReferenceSpec>({
    required: true
})

defineProps<{
    associationIdOptions: LazyOptions<DbForeignKeyOptionView>,
    sourceColumnIdOptions: LazyOptions<DbTableColumnOptionView>,
    targetColumnIdOptions: LazyOptions<DbTableColumnOptionView>
}>()

const emits = defineEmits<{
    (
        event: "query",
        spec: DbForeignKeyColumnReferenceSpec
    ): void
}>()
</script>

<template>
    <el-form
        :model="spec"
        label-width="auto"
        @submit.prevent
        class="query-form"
    >
        <el-row :gutter="20">
            <el-col :span="8" :xs="24">
                <el-form-item prop="associationId" label="关联">
                    <DbForeignKeyIdSelect
                        v-model="spec.associationId"
                        :options="associationIdOptions"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="sourceColumnId" label="主列">
                    <DbTableColumnIdSelect
                        v-model="spec.sourceColumnId"
                        :options="sourceColumnIdOptions"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="targetColumnId" label="从列">
                    <DbTableColumnIdSelect
                        v-model="spec.targetColumnId"
                        :options="targetColumnIdOptions"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="remark" label="备注">
                    <el-input
                        v-model="spec.remark"
                        placeholder="请输入备注"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-button
                type="primary"
                :icon="Search"
                class="search-button"
                @click="emits('query', spec)"
            >
                查询
            </el-button>
        </el-row>
    </el-form>
</template>
