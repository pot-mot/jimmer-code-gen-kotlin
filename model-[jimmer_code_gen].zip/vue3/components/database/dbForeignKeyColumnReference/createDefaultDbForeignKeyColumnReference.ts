import type {DbForeignKeyColumnReferenceAddData} from "./DbForeignKeyColumnReferenceAddData"

export const createDefaultDbForeignKeyColumnReference = (): DbForeignKeyColumnReferenceAddData => {
    return {
        associationId: undefined,
        sourceColumnId: undefined,
        targetColumnId: undefined,
        remark: ""
    }
}
