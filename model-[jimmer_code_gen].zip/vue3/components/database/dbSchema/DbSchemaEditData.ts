import {sendMessage} from "@/utils/message"
import type {DbSchemaUpdateInput} from "@/api/__generated/model/static"

export type DbSchemaEditData = {
    id: number
    dataSourceId?: number | undefined
    name: string
    remark: string
}

const getUnmatchedMessageList = (data: DbSchemaEditData): Array<string> => {
    const messageList: Array<string> = []

    if (data.dataSourceId === undefined) {
        messageList.push("数据源不可为空")
    }

    return messageList
}

export const validateDbSchemaEditDataForSubmit = (data: DbSchemaEditData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertDbSchemaEditDataAsSubmitType = (data: DbSchemaEditData): DbSchemaUpdateInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as DbSchemaUpdateInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
