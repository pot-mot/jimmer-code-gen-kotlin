import {sendMessage} from "@/utils/message"
import type {DbSchemaInsertInput} from "@/api/__generated/model/static"

export type DbSchemaAddData = {
    dataSourceId?: number | undefined
    name: string
    remark: string
}

const getUnmatchedMessageList = (data: DbSchemaAddData): Array<string> => {
    const messageList: Array<string> = []

    if (data.dataSourceId === undefined) {
        messageList.push("数据源不可为空")
    }

    return messageList
}

export const validateDbSchemaAddDataForSubmit = (data: DbSchemaAddData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertDbSchemaAddDataAsSubmitType = (data: DbSchemaAddData): DbSchemaInsertInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as DbSchemaInsertInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
