<script setup lang="ts">
import {Search} from "@element-plus/icons-vue"
import type {DbSchemaSpec, DbDataSourceOptionView} from "@/api/__generated/model/static"
import DbDataSourceIdSelect from "@/components/database/dbDataSource/DbDataSourceIdSelect.vue"
import type {LazyOptions} from "@/utils/lazyOptions"

const spec = defineModel<DbSchemaSpec>({
    required: true
})

defineProps<{
    dataSourceIdOptions: LazyOptions<DbDataSourceOptionView>
}>()

const emits = defineEmits<{
    (event: "query", spec: DbSchemaSpec): void
}>()
</script>

<template>
    <el-form
        :model="spec"
        label-width="auto"
        @submit.prevent
        class="query-form"
    >
        <el-row :gutter="20">
            <el-col :span="8" :xs="24">
                <el-form-item prop="dataSourceId" label="数据源">
                    <DbDataSourceIdSelect
                        v-model="spec.dataSourceId"
                        :options="dataSourceIdOptions"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="name" label="名称">
                    <el-input
                        v-model="spec.name"
                        placeholder="请输入名称"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="remark" label="备注">
                    <el-input
                        v-model="spec.remark"
                        placeholder="请输入备注"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-button
                type="primary"
                :icon="Search"
                class="search-button"
                @click="emits('query', spec)"
            >
                查询
            </el-button>
        </el-row>
    </el-form>
</template>
