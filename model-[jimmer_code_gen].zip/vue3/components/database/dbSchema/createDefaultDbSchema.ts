import type {DbSchemaAddData} from "./DbSchemaAddData"

export const createDefaultDbSchema = (): DbSchemaAddData => {
    return {
        dataSourceId: undefined,
        name: "",
        remark: ""
    }
}
