<script setup lang="ts">
import {ref} from "vue"
import type {FormInstance} from "element-plus"
import type {FormExpose} from "@/components/form/FormExpose"
import type {
    DbForeignKeyInsertInput,
    DbTableOptionView
} from "@/api/__generated/model/static"
import {
    validateDbForeignKeyAddDataForSubmit,
    assertDbForeignKeyAddDataAsSubmitType
} from "@/components/database/dbForeignKey/DbForeignKeyAddData"
import type {DbForeignKeyAddData} from "@/components/database/dbForeignKey/DbForeignKeyAddData"
import {createDefaultDbForeignKey} from "@/components/database/dbForeignKey/createDefaultDbForeignKey"
import {useRules} from "@/rules/database/dbForeignKey/DbForeignKeyAddFormRules"
import DbTableIdSelect from "@/components/database/dbTable/DbTableIdSelect.vue"
import type {LazyOptions} from "@/utils/lazyOptions"

const props = withDefaults(defineProps<{
    withOperations?: boolean | undefined,
    submitLoading?: boolean | undefined,
    sourceTableIdOptions: LazyOptions<DbTableOptionView>,
    targetTableIdOptions: LazyOptions<DbTableOptionView>
}>(), {
    withOperations: true,
    submitLoading: false,
})

const emits = defineEmits<{
    (
        event: "submit",
        formData: DbForeignKeyInsertInput
    ): void,
    (event: "cancel"): void
}>()

defineSlots<{
    operations(props: {
        handleSubmit: () => Promise<void>,
        handleCancel: () => void
    }): any
}>()

const formData = ref<DbForeignKeyAddData>(createDefaultDbForeignKey())

const formRef = ref<FormInstance>()
const rules = useRules(formData)

// 校验
const handleValidate = async (
    errorHandler: (errors: any[]) => void = (errors) => {console.error(errors)}
): Promise<boolean> => {
    const errors: any[] = []
    const formValid: boolean = await formRef.value?.validate().catch(e => {
        errors.push(e)
        return false
    }) ?? false

    const typeValidate: boolean = validateDbForeignKeyAddDataForSubmit(formData.value)

    errorHandler?.(errors)
    return formValid && typeValidate
}

// 提交
const handleSubmit = async (): Promise<void> => {
    if (props.submitLoading) return

    const validResult = await handleValidate()
    if (validResult) {
        emits("submit", assertDbForeignKeyAddDataAsSubmitType(formData.value))
    }
}

// 取消
const handleCancel = (): void => {
    emits("cancel")
}

defineExpose<FormExpose>({
    validate: handleValidate
})
</script>

<template>
    <el-form
        :model="formData"
        ref="formRef"
        :rules="rules"
        label-width="auto"
        @submit.prevent
        class="add-form"
    >
        <el-form-item prop="name" label="关联名称">
            <el-input
                v-model="formData.name"
                placeholder="请输入关联名称"
                clearable
            />
        </el-form-item>
        <el-form-item prop="sourceTableId" label="主表">
            <DbTableIdSelect
                v-model="formData.sourceTableId"
                :options="sourceTableIdOptions"
            />
        </el-form-item>
        <el-form-item prop="targetTableId" label="从表">
            <DbTableIdSelect
                v-model="formData.targetTableId"
                :options="targetTableIdOptions"
            />
        </el-form-item>
        <el-form-item prop="type" label="关联类型">
            <el-input
                v-model="formData.type"
                placeholder="请输入关联类型"
                clearable
            />
        </el-form-item>
        <el-form-item prop="updateAction" label="更新行为">
            <el-input
                v-model="formData.updateAction"
                placeholder="请输入更新行为"
                clearable
            />
        </el-form-item>
        <el-form-item prop="deleteAction" label="删除行为">
            <el-input
                v-model="formData.deleteAction"
                placeholder="请输入删除行为"
                clearable
            />
        </el-form-item>
        <el-form-item prop="remark" label="备注">
            <el-input
                v-model="formData.remark"
                placeholder="请输入备注"
                clearable
            />
        </el-form-item>

        <slot
            v-if="withOperations"
            name="operations"
            :handleSubmit="handleSubmit"
            :handleCancel="handleCancel"
        >
            <div class="form-operations">
                <el-button type="warning" @click="handleCancel">
                    取消
                </el-button>
                <el-button
                    type="primary"
                    :loading="submitLoading"
                    @click="handleSubmit"
                >
                    提交
                </el-button>
            </div>
        </slot>
    </el-form>
</template>
