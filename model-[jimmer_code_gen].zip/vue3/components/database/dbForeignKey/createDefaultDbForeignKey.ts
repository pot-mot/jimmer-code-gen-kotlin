import type {DbForeignKeyAddData} from "./DbForeignKeyAddData"

export const createDefaultDbForeignKey = (): DbForeignKeyAddData => {
    return {
        name: "",
        sourceTableId: undefined,
        targetTableId: undefined,
        type: "",
        updateAction: "",
        deleteAction: "",
        remark: ""
    }
}
