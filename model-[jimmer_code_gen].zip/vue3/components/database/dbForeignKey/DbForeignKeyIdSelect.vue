<script setup lang="ts">
import {onBeforeMount, watch} from "vue"
import type {LazyOptions} from "@/utils/lazyOptions"
import type {DbForeignKeyOptionView} from "@/api/__generated/model/static"

const modelValue = defineModel<number | undefined>({
    required: true
})

const props = defineProps<{
    options: LazyOptions<DbForeignKeyOptionView>
}>()

const loadIfNot = async () => {
    if (props.options.state === 'unload') {
        await props.options.load()
    } else if (props.options.data === undefined && props.options.state !== 'loading') {
        await props.options.load()
    }
}

onBeforeMount(async () => {
    if (modelValue.value !== undefined) {
        await loadIfNot()
    }
})

watch(() => [modelValue.value, props.options], () => {
    if (props.options.state !== 'loaded') return []
    if (props.options.data === undefined) return []

    if (!(props.options.data.map(it => it.id) as Array<number | undefined>).includes(modelValue.value)) {
        modelValue.value = undefined
    }
}, {immediate: true})
</script>

<template>
    <el-select
        v-model="modelValue"
        placeholder="请选择外键"
        filterable
        clearable
        :value-on-clear="undefined"
        :loading="options.state === 'loading'"
        @focus.once="loadIfNot"
    >
        <el-option
            v-for="option in options.data"
            :key="option.id"
            :value="option.id"
            :label="`${option.id}`"
        />
    </el-select>
</template>
