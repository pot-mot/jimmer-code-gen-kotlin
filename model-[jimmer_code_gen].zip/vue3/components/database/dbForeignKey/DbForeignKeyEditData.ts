import {sendMessage} from "@/utils/message"
import type {DbForeignKeyUpdateInput} from "@/api/__generated/model/static"

export type DbForeignKeyEditData = {
    id: number
    name: string
    sourceTableId?: number | undefined
    targetTableId?: number | undefined
    type: string
    updateAction: string
    deleteAction: string
    remark: string
}

const getUnmatchedMessageList = (data: DbForeignKeyEditData): Array<string> => {
    const messageList: Array<string> = []

    if (data.sourceTableId === undefined) {
        messageList.push("主表不可为空")
    }
    if (data.targetTableId === undefined) {
        messageList.push("从表不可为空")
    }

    return messageList
}

export const validateDbForeignKeyEditDataForSubmit = (data: DbForeignKeyEditData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertDbForeignKeyEditDataAsSubmitType = (data: DbForeignKeyEditData): DbForeignKeyUpdateInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as DbForeignKeyUpdateInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
