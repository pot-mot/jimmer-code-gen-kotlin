<script setup lang="ts">
import type {DbForeignKeyListView} from "@/api/__generated/model/static"
import {usePageSizeStore} from "@/stores/pageSizeStore"

withDefaults(defineProps<{
    rows: Array<DbForeignKeyListView>,
    idColumn?: boolean | undefined,
    indexColumn?: boolean | undefined,
    multiSelect?: boolean | undefined,
    withOperations?: boolean | undefined
}>(), {
    idColumn: false,
    indexColumn: true,
    multiSelect: true,
    withOperations: true,
})

const emits = defineEmits<{
    (
        event: "selectionChange",
        selection: Array<DbForeignKeyListView>
    ): void
}>()

defineSlots<{
    operations(props: {row: DbForeignKeyListView, index: number}): any
}>()

const pageSizeStore = usePageSizeStore()

const handleSelectionChange = (
    newSelection: Array<DbForeignKeyListView>
): void => {
    emits("selectionChange", newSelection)
}
</script>

<template>
    <el-table
        :data="rows"
        row-key="id"
        border
        stripe
        class="view-table"
        @selection-change="handleSelectionChange"
    >
        <el-table-column
            v-if="idColumn"
            prop="id"
            label="ID"
            :fixed="pageSizeStore.isSmall ? undefined : 'left'"
        />
        <el-table-column
            v-if="indexColumn"
            type="index"
            :fixed="pageSizeStore.isSmall ? undefined : 'left'"
        />
        <el-table-column
            v-if="multiSelect"
            type="selection"
            :width="43"
            :fixed="pageSizeStore.isSmall ? undefined : 'left'"
        />
        <el-table-column
            prop="name"
            label="关联名称"
            :min-width="129"
        />
        <el-table-column
            prop="sourceTableId"
            label="主表"
            :min-width="161"
        />
        <el-table-column
            prop="targetTableId"
            label="从表"
            :min-width="161"
        />
        <el-table-column
            prop="type"
            label="关联类型"
            :min-width="129"
        />
        <el-table-column
            prop="updateAction"
            label="更新行为"
            :min-width="129"
        />
        <el-table-column
            prop="deleteAction"
            label="删除行为"
            :min-width="129"
        />
        <el-table-column
            prop="remark"
            label="备注"
            :min-width="129"
        />
        <el-table-column
            v-if="withOperations"
            label="操作"
            :fixed="pageSizeStore.isSmall ? undefined : 'right'"
        >
            <template #default="scope">
                <slot
                    name="operations"
                    :row="scope.row as DbForeignKeyListView"
                    :index="scope.$index"
                />
            </template>
        </el-table-column>
    </el-table>
</template>
