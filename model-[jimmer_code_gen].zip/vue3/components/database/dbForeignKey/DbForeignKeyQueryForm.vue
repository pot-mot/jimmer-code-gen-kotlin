<script setup lang="ts">
import {Search} from "@element-plus/icons-vue"
import type {DbForeignKeySpec, DbTableOptionView} from "@/api/__generated/model/static"
import DbTableIdSelect from "@/components/database/dbTable/DbTableIdSelect.vue"
import type {LazyOptions} from "@/utils/lazyOptions"

const spec = defineModel<DbForeignKeySpec>({
    required: true
})

defineProps<{
    sourceTableIdOptions: LazyOptions<DbTableOptionView>,
    targetTableIdOptions: LazyOptions<DbTableOptionView>
}>()

const emits = defineEmits<{
    (event: "query", spec: DbForeignKeySpec): void
}>()
</script>

<template>
    <el-form
        :model="spec"
        label-width="auto"
        @submit.prevent
        class="query-form"
    >
        <el-row :gutter="20">
            <el-col :span="8" :xs="24">
                <el-form-item prop="name" label="关联名称">
                    <el-input
                        v-model="spec.name"
                        placeholder="请输入关联名称"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="sourceTableId" label="主表">
                    <DbTableIdSelect
                        v-model="spec.sourceTableId"
                        :options="sourceTableIdOptions"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="targetTableId" label="从表">
                    <DbTableIdSelect
                        v-model="spec.targetTableId"
                        :options="targetTableIdOptions"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="type" label="关联类型">
                    <el-input
                        v-model="spec.type"
                        placeholder="请输入关联类型"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="updateAction" label="更新行为">
                    <el-input
                        v-model="spec.updateAction"
                        placeholder="请输入更新行为"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="deleteAction" label="删除行为">
                    <el-input
                        v-model="spec.deleteAction"
                        placeholder="请输入删除行为"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="remark" label="备注">
                    <el-input
                        v-model="spec.remark"
                        placeholder="请输入备注"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-button
                type="primary"
                :icon="Search"
                class="search-button"
                @click="emits('query', spec)"
            >
                查询
            </el-button>
        </el-row>
    </el-form>
</template>
