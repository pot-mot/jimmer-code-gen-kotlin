import {sendMessage} from "@/utils/message"
import type {DbTableIndexUpdateInput} from "@/api/__generated/model/static"

export type DbTableIndexEditData = {
    id: number
    tableId?: number | undefined
    name: string
    uniqueIndex: boolean
    remark: string
}

const getUnmatchedMessageList = (data: DbTableIndexEditData): Array<string> => {
    const messageList: Array<string> = []

    if (data.tableId === undefined) {
        messageList.push("归属表不可为空")
    }

    return messageList
}

export const validateDbTableIndexEditDataForSubmit = (data: DbTableIndexEditData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertDbTableIndexEditDataAsSubmitType = (data: DbTableIndexEditData): DbTableIndexUpdateInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as DbTableIndexUpdateInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
