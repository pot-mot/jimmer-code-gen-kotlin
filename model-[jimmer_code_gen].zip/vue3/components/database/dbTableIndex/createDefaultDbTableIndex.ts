import type {DbTableIndexAddData} from "./DbTableIndexAddData"

export const createDefaultDbTableIndex = (): DbTableIndexAddData => {
    return {
        tableId: undefined,
        name: "",
        uniqueIndex: false,
        remark: ""
    }
}
