import {sendMessage} from "@/utils/message"
import type {DbTableIndexInsertInput} from "@/api/__generated/model/static"

export type DbTableIndexAddData = {
    tableId?: number | undefined
    name: string
    uniqueIndex: boolean
    remark: string
}

const getUnmatchedMessageList = (data: DbTableIndexAddData): Array<string> => {
    const messageList: Array<string> = []

    if (data.tableId === undefined) {
        messageList.push("归属表不可为空")
    }

    return messageList
}

export const validateDbTableIndexAddDataForSubmit = (data: DbTableIndexAddData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertDbTableIndexAddDataAsSubmitType = (data: DbTableIndexAddData): DbTableIndexInsertInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as DbTableIndexInsertInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
