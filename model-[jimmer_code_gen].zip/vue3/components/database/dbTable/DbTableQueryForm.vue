<script setup lang="ts">
import {Search} from "@element-plus/icons-vue"
import type {DbTableSpec, DbSchemaOptionView} from "@/api/__generated/model/static"
import DbSchemaIdSelect from "@/components/database/dbSchema/DbSchemaIdSelect.vue"
import TableTypeNullableSelect from "@/components/enums/tableType/TableTypeNullableSelect.vue"
import type {LazyOptions} from "@/utils/lazyOptions"

const spec = defineModel<DbTableSpec>({
    required: true
})

defineProps<{
    schemaIdOptions: LazyOptions<DbSchemaOptionView>
}>()

const emits = defineEmits<{
    (event: "query", spec: DbTableSpec): void
}>()
</script>

<template>
    <el-form
        :model="spec"
        label-width="auto"
        @submit.prevent
        class="query-form"
    >
        <el-row :gutter="20">
            <el-col :span="8" :xs="24">
                <el-form-item prop="schemaId" label="数据架构">
                    <DbSchemaIdSelect
                        v-model="spec.schemaId"
                        :options="schemaIdOptions"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="name" label="名称">
                    <el-input
                        v-model="spec.name"
                        placeholder="请输入名称"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="comment" label="注释">
                    <el-input
                        v-model="spec.comment"
                        placeholder="请输入注释"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="type" label="类型">
                    <TableTypeNullableSelect
                        v-model="spec.type"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="remark" label="备注">
                    <el-input
                        v-model="spec.remark"
                        placeholder="请输入备注"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-button
                type="primary"
                :icon="Search"
                class="search-button"
                @click="emits('query', spec)"
            >
                查询
            </el-button>
        </el-row>
    </el-form>
</template>
