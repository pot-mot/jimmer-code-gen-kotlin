import type {DbTableAddData} from "./DbTableAddData"

export const createDefaultDbTable = (): DbTableAddData => {
    return {
        schemaId: undefined,
        name: "",
        comment: "",
        type: "TABLE",
        remark: ""
    }
}
