import {sendMessage} from "@/utils/message"
import type {DbTableUpdateInput} from "@/api/__generated/model/static"
import type {TableType} from "@/api/__generated/model/enums"

export type DbTableEditData = {
    id: number
    schemaId?: number | undefined
    name: string
    comment: string
    type: TableType
    remark: string
}

const getUnmatchedMessageList = (data: DbTableEditData): Array<string> => {
    const messageList: Array<string> = []

    if (data.schemaId === undefined) {
        messageList.push("数据架构不可为空")
    }

    return messageList
}

export const validateDbTableEditDataForSubmit = (data: DbTableEditData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertDbTableEditDataAsSubmitType = (data: DbTableEditData): DbTableUpdateInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as DbTableUpdateInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
