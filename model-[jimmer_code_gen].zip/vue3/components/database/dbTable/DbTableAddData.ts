import {sendMessage} from "@/utils/message"
import type {DbTableInsertInput} from "@/api/__generated/model/static"
import type {TableType} from "@/api/__generated/model/enums"

export type DbTableAddData = {
    schemaId?: number | undefined
    name: string
    comment: string
    type: TableType
    remark: string
}

const getUnmatchedMessageList = (data: DbTableAddData): Array<string> => {
    const messageList: Array<string> = []

    if (data.schemaId === undefined) {
        messageList.push("数据架构不可为空")
    }

    return messageList
}

export const validateDbTableAddDataForSubmit = (data: DbTableAddData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertDbTableAddDataAsSubmitType = (data: DbTableAddData): DbTableInsertInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as DbTableInsertInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
