import {sendMessage} from "@/utils/message"
import type {DbTableColumnUpdateInput} from "@/api/__generated/model/static"

export type DbTableColumnEditData = {
    id: number
    tableId?: number | undefined
    name: string
    orderKey: number
    jdbcTypeCode: number
    rawType: string
    typeIsNotNull: boolean
    dataSize?: number | undefined
    numericPrecision?: number | undefined
    defaultValue?: string | undefined
    comment: string
    remark: string
}

const getUnmatchedMessageList = (data: DbTableColumnEditData): Array<string> => {
    const messageList: Array<string> = []

    if (data.tableId === undefined) {
        messageList.push("归属表不可为空")
    }

    return messageList
}

export const validateDbTableColumnEditDataForSubmit = (data: DbTableColumnEditData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertDbTableColumnEditDataAsSubmitType = (data: DbTableColumnEditData): DbTableColumnUpdateInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as DbTableColumnUpdateInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
