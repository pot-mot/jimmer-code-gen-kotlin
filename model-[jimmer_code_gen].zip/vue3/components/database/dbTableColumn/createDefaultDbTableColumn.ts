import type {DbTableColumnAddData} from "./DbTableColumnAddData"

export const createDefaultDbTableColumn = (): DbTableColumnAddData => {
    return {
        tableId: undefined,
        name: "",
        orderKey: 0,
        jdbcTypeCode: 0,
        rawType: "",
        typeIsNotNull: false,
        dataSize: undefined,
        numericPrecision: undefined,
        defaultValue: undefined,
        comment: "",
        remark: ""
    }
}
