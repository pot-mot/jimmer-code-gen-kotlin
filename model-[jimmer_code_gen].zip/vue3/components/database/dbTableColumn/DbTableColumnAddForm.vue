<script setup lang="ts">
import {ref} from "vue"
import type {FormInstance} from "element-plus"
import type {FormExpose} from "@/components/form/FormExpose"
import type {
    DbTableColumnInsertInput,
    DbTableOptionView
} from "@/api/__generated/model/static"
import {
    validateDbTableColumnAddDataForSubmit,
    assertDbTableColumnAddDataAsSubmitType
} from "@/components/database/dbTableColumn/DbTableColumnAddData"
import type {DbTableColumnAddData} from "@/components/database/dbTableColumn/DbTableColumnAddData"
import {createDefaultDbTableColumn} from "@/components/database/dbTableColumn/createDefaultDbTableColumn"
import {useRules} from "@/rules/database/dbTableColumn/DbTableColumnAddFormRules"
import DbTableIdSelect from "@/components/database/dbTable/DbTableIdSelect.vue"
import type {LazyOptions} from "@/utils/lazyOptions"

const props = withDefaults(defineProps<{
    withOperations?: boolean | undefined,
    submitLoading?: boolean | undefined,
    tableIdOptions: LazyOptions<DbTableOptionView>
}>(), {
    withOperations: true,
    submitLoading: false,
})

const emits = defineEmits<{
    (
        event: "submit",
        formData: DbTableColumnInsertInput
    ): void,
    (event: "cancel"): void
}>()

defineSlots<{
    operations(props: {
        handleSubmit: () => Promise<void>,
        handleCancel: () => void
    }): any
}>()

const formData = ref<DbTableColumnAddData>(createDefaultDbTableColumn())

const formRef = ref<FormInstance>()
const rules = useRules(formData)

// 校验
const handleValidate = async (
    errorHandler: (errors: any[]) => void = (errors) => {console.error(errors)}
): Promise<boolean> => {
    const errors: any[] = []
    const formValid: boolean = await formRef.value?.validate().catch(e => {
        errors.push(e)
        return false
    }) ?? false

    const typeValidate: boolean = validateDbTableColumnAddDataForSubmit(formData.value)

    errorHandler?.(errors)
    return formValid && typeValidate
}

// 提交
const handleSubmit = async (): Promise<void> => {
    if (props.submitLoading) return

    const validResult = await handleValidate()
    if (validResult) {
        emits("submit", assertDbTableColumnAddDataAsSubmitType(formData.value))
    }
}

// 取消
const handleCancel = (): void => {
    emits("cancel")
}

defineExpose<FormExpose>({
    validate: handleValidate
})
</script>

<template>
    <el-form
        :model="formData"
        ref="formRef"
        :rules="rules"
        label-width="auto"
        @submit.prevent
        class="add-form"
    >
        <el-form-item prop="tableId" label="归属表">
            <DbTableIdSelect
                v-model="formData.tableId"
                :options="tableIdOptions"
            />
        </el-form-item>
        <el-form-item prop="name" label="名称">
            <el-input
                v-model="formData.name"
                placeholder="请输入名称"
                clearable
            />
        </el-form-item>
        <el-form-item prop="orderKey" label="排序键">
            <el-input-number
                v-model.number="formData.orderKey"
                placeholder="请输入排序键"
                :precision="0"
                :max="2147483647"
            />
        </el-form-item>
        <el-form-item prop="jdbcTypeCode" label="JdbcType 码值">
            <el-input-number
                v-model.number="formData.jdbcTypeCode"
                placeholder="请输入JdbcType 码值"
                :precision="0"
                :min="0"
                :max="2147483647"
                :value-on-clear="'min'"
            />
        </el-form-item>
        <el-form-item prop="rawType" label="字面类型">
            <el-input
                v-model="formData.rawType"
                placeholder="请输入字面类型"
                clearable
            />
        </el-form-item>
        <el-form-item prop="typeIsNotNull" label="类型是否非空">
            <el-switch v-model="formData.typeIsNotNull"/>
        </el-form-item>
        <el-form-item prop="dataSize" label="长度">
            <el-input-number
                v-model.number="formData.dataSize"
                placeholder="请输入长度"
                :precision="0"
                :min="0"
                :max="9223372036854775807"
                :value-on-clear="undefined"
            />
        </el-form-item>
        <el-form-item prop="numericPrecision" label="精度">
            <el-input-number
                v-model.number="formData.numericPrecision"
                placeholder="请输入精度"
                :precision="0"
                :min="0"
                :max="9223372036854775807"
                :value-on-clear="undefined"
            />
        </el-form-item>
        <el-form-item prop="defaultValue" label="列默认值">
            <el-input
                v-model="formData.defaultValue"
                placeholder="请输入列默认值"
                clearable
            />
        </el-form-item>
        <el-form-item prop="comment" label="注释">
            <el-input
                v-model="formData.comment"
                placeholder="请输入注释"
                clearable
            />
        </el-form-item>
        <el-form-item prop="remark" label="备注">
            <el-input
                v-model="formData.remark"
                placeholder="请输入备注"
                clearable
            />
        </el-form-item>

        <slot
            v-if="withOperations"
            name="operations"
            :handleSubmit="handleSubmit"
            :handleCancel="handleCancel"
        >
            <div class="form-operations">
                <el-button type="warning" @click="handleCancel">
                    取消
                </el-button>
                <el-button
                    type="primary"
                    :loading="submitLoading"
                    @click="handleSubmit"
                >
                    提交
                </el-button>
            </div>
        </slot>
    </el-form>
</template>
