<script setup lang="ts">
import type {DbTableColumnListView} from "@/api/__generated/model/static"
import {usePageSizeStore} from "@/stores/pageSizeStore"

withDefaults(defineProps<{
    rows: Array<DbTableColumnListView>,
    idColumn?: boolean | undefined,
    indexColumn?: boolean | undefined,
    multiSelect?: boolean | undefined,
    withOperations?: boolean | undefined
}>(), {
    idColumn: false,
    indexColumn: true,
    multiSelect: true,
    withOperations: true,
})

const emits = defineEmits<{
    (
        event: "selectionChange",
        selection: Array<DbTableColumnListView>
    ): void
}>()

defineSlots<{
    operations(props: {
        row: DbTableColumnListView,
        index: number
    }): any
}>()

const pageSizeStore = usePageSizeStore()

const handleSelectionChange = (
    newSelection: Array<DbTableColumnListView>
): void => {
    emits("selectionChange", newSelection)
}
</script>

<template>
    <el-table
        :data="rows"
        row-key="id"
        border
        stripe
        class="view-table"
        @selection-change="handleSelectionChange"
    >
        <el-table-column
            v-if="idColumn"
            prop="id"
            label="ID"
            :fixed="pageSizeStore.isSmall ? undefined : 'left'"
        />
        <el-table-column
            v-if="indexColumn"
            type="index"
            :fixed="pageSizeStore.isSmall ? undefined : 'left'"
        />
        <el-table-column
            v-if="multiSelect"
            type="selection"
            :width="43"
            :fixed="pageSizeStore.isSmall ? undefined : 'left'"
        />
        <el-table-column
            prop="tableId"
            label="归属表"
            :min-width="161"
        />
        <el-table-column prop="name" label="名称" :min-width="129"/>
        <el-table-column
            prop="orderKey"
            label="排序键"
            :min-width="161"
        />
        <el-table-column
            prop="jdbcTypeCode"
            label="JdbcType 码值"
            :min-width="161"
        />
        <el-table-column
            prop="rawType"
            label="字面类型"
            :min-width="129"
        />
        <el-table-column
            prop="typeIsNotNull"
            label="类型是否非空"
            :min-width="81"
        >
            <template #default="scope">
                <el-checkbox :modelValue="scope.row.typeIsNotNull"/>
            </template>
        </el-table-column>
        <el-table-column
            prop="dataSize"
            label="长度"
            :min-width="161"
        />
        <el-table-column
            prop="numericPrecision"
            label="精度"
            :min-width="161"
        />
        <el-table-column
            prop="defaultValue"
            label="列默认值"
            :min-width="129"
        />
        <el-table-column
            prop="comment"
            label="注释"
            :min-width="129"
        />
        <el-table-column
            prop="remark"
            label="备注"
            :min-width="129"
        />
        <el-table-column
            v-if="withOperations"
            label="操作"
            :fixed="pageSizeStore.isSmall ? undefined : 'right'"
        >
            <template #default="scope">
                <slot
                    name="operations"
                    :row="scope.row as DbTableColumnListView"
                    :index="scope.$index"
                />
            </template>
        </el-table-column>
    </el-table>
</template>
