import {sendMessage} from "@/utils/message"
import type {GenManyToManyAssociationUpdateInput} from "@/api/__generated/model/static"

export type GenManyToManyAssociationEditData = {
    id: number
    sourcePropertyId?: number | undefined
    mappedPropertyId?: number | undefined
    joinTableId?: number | undefined
}

const getUnmatchedMessageList = (data: GenManyToManyAssociationEditData): Array<string> => {
    const messageList: Array<string> = []

    if (data.sourcePropertyId === undefined) {
        messageList.push("源属性不可为空")
    }
    if (data.mappedPropertyId === undefined) {
        messageList.push("目标属性不可为空")
    }
    if (data.joinTableId === undefined) {
        messageList.push("Join Table不可为空")
    }

    return messageList
}

export const validateGenManyToManyAssociationEditDataForSubmit = (data: GenManyToManyAssociationEditData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertGenManyToManyAssociationEditDataAsSubmitType = (data: GenManyToManyAssociationEditData): GenManyToManyAssociationUpdateInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as GenManyToManyAssociationUpdateInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
