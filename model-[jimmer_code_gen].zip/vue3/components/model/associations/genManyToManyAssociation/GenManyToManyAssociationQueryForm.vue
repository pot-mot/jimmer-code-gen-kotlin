<script setup lang="ts">
import {Search} from "@element-plus/icons-vue"
import type {
    GenManyToManyAssociationSpec,
    GenManyToManySourcePropertyOptionView,
    GenManyToManyMappedPropertyOptionView,
    GenJoinTableOptionView
} from "@/api/__generated/model/static"
import GenManyToManySourcePropertyIdSelect from "@/components/model/entities/properties/genManyToManySourceProperty/GenManyToManySourcePropertyIdSelect.vue"
import GenManyToManyMappedPropertyIdSelect from "@/components/model/entities/properties/genManyToManyMappedProperty/GenManyToManyMappedPropertyIdSelect.vue"
import GenJoinTableIdSelect from "@/components/model/associations/genJoinTable/GenJoinTableIdSelect.vue"
import type {LazyOptions} from "@/utils/lazyOptions"

const spec = defineModel<GenManyToManyAssociationSpec>({
    required: true
})

defineProps<{
    sourcePropertyIdOptions: LazyOptions<GenManyToManySourcePropertyOptionView>,
    mappedPropertyIdOptions: LazyOptions<GenManyToManyMappedPropertyOptionView>,
    joinTableIdOptions: LazyOptions<GenJoinTableOptionView>
}>()

const emits = defineEmits<{
    (
        event: "query",
        spec: GenManyToManyAssociationSpec
    ): void
}>()
</script>

<template>
    <el-form
        :model="spec"
        label-width="auto"
        @submit.prevent
        class="query-form"
    >
        <el-row :gutter="20">
            <el-col :span="8" :xs="24">
                <el-form-item prop="sourcePropertyId" label="源属性">
                    <GenManyToManySourcePropertyIdSelect
                        v-model="spec.sourcePropertyId"
                        :options="sourcePropertyIdOptions"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="mappedPropertyId" label="目标属性">
                    <GenManyToManyMappedPropertyIdSelect
                        v-model="spec.mappedPropertyId"
                        :options="mappedPropertyIdOptions"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="joinTableId" label="Join Table">
                    <GenJoinTableIdSelect
                        v-model="spec.joinTableId"
                        :options="joinTableIdOptions"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-button
                type="primary"
                :icon="Search"
                class="search-button"
                @click="emits('query', spec)"
            >
                查询
            </el-button>
        </el-row>
    </el-form>
</template>
