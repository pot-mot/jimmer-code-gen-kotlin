<script setup lang="ts">
import {ref} from "vue"
import type {FormInstance} from "element-plus"
import type {FormExpose} from "@/components/form/FormExpose"
import type {
    GenManyToManyAssociationInsertInput,
    GenManyToManySourcePropertyOptionView,
    GenManyToManyMappedPropertyOptionView,
    GenJoinTableOptionView
} from "@/api/__generated/model/static"
import {
    validateGenManyToManyAssociationAddDataForSubmit,
    assertGenManyToManyAssociationAddDataAsSubmitType
} from "@/components/model/associations/genManyToManyAssociation/GenManyToManyAssociationAddData"
import type {GenManyToManyAssociationAddData} from "@/components/model/associations/genManyToManyAssociation/GenManyToManyAssociationAddData"
import {createDefaultGenManyToManyAssociation} from "@/components/model/associations/genManyToManyAssociation/createDefaultGenManyToManyAssociation"
import {useRules} from "@/rules/model/associations/genManyToManyAssociation/GenManyToManyAssociationAddFormRules"
import GenManyToManySourcePropertyIdSelect from "@/components/model/entities/properties/genManyToManySourceProperty/GenManyToManySourcePropertyIdSelect.vue"
import GenManyToManyMappedPropertyIdSelect from "@/components/model/entities/properties/genManyToManyMappedProperty/GenManyToManyMappedPropertyIdSelect.vue"
import GenJoinTableIdSelect from "@/components/model/associations/genJoinTable/GenJoinTableIdSelect.vue"
import type {LazyOptions} from "@/utils/lazyOptions"

const props = withDefaults(defineProps<{
    withOperations?: boolean | undefined,
    submitLoading?: boolean | undefined,
    sourcePropertyIdOptions: LazyOptions<GenManyToManySourcePropertyOptionView>,
    mappedPropertyIdOptions: LazyOptions<GenManyToManyMappedPropertyOptionView>,
    joinTableIdOptions: LazyOptions<GenJoinTableOptionView>
}>(), {
    withOperations: true,
    submitLoading: false,
})

const emits = defineEmits<{
    (
        event: "submit",
        formData: GenManyToManyAssociationInsertInput
    ): void,
    (event: "cancel"): void
}>()

defineSlots<{
    operations(props: {
        handleSubmit: () => Promise<void>,
        handleCancel: () => void
    }): any
}>()

const formData = ref<GenManyToManyAssociationAddData>(createDefaultGenManyToManyAssociation())

const formRef = ref<FormInstance>()
const rules = useRules(formData)

// 校验
const handleValidate = async (
    errorHandler: (errors: any[]) => void = (errors) => {console.error(errors)}
): Promise<boolean> => {
    const errors: any[] = []
    const formValid: boolean = await formRef.value?.validate().catch(e => {
        errors.push(e)
        return false
    }) ?? false

    const typeValidate: boolean = validateGenManyToManyAssociationAddDataForSubmit(formData.value)

    errorHandler?.(errors)
    return formValid && typeValidate
}

// 提交
const handleSubmit = async (): Promise<void> => {
    if (props.submitLoading) return

    const validResult = await handleValidate()
    if (validResult) {
        emits("submit", assertGenManyToManyAssociationAddDataAsSubmitType(formData.value))
    }
}

// 取消
const handleCancel = (): void => {
    emits("cancel")
}

defineExpose<FormExpose>({
    validate: handleValidate
})
</script>

<template>
    <el-form
        :model="formData"
        ref="formRef"
        :rules="rules"
        label-width="auto"
        @submit.prevent
        class="add-form"
    >
        <el-form-item prop="sourcePropertyId" label="源属性">
            <GenManyToManySourcePropertyIdSelect
                v-model="formData.sourcePropertyId"
                :options="sourcePropertyIdOptions"
            />
        </el-form-item>
        <el-form-item prop="mappedPropertyId" label="目标属性">
            <GenManyToManyMappedPropertyIdSelect
                v-model="formData.mappedPropertyId"
                :options="mappedPropertyIdOptions"
            />
        </el-form-item>
        <el-form-item prop="joinTableId" label="Join Table">
            <GenJoinTableIdSelect
                v-model="formData.joinTableId"
                :options="joinTableIdOptions"
            />
        </el-form-item>

        <slot
            v-if="withOperations"
            name="operations"
            :handleSubmit="handleSubmit"
            :handleCancel="handleCancel"
        >
            <div class="form-operations">
                <el-button type="warning" @click="handleCancel">
                    取消
                </el-button>
                <el-button
                    type="primary"
                    :loading="submitLoading"
                    @click="handleSubmit"
                >
                    提交
                </el-button>
            </div>
        </slot>
    </el-form>
</template>
