import {sendMessage} from "@/utils/message"
import type {GenManyToManyAssociationInsertInput} from "@/api/__generated/model/static"

export type GenManyToManyAssociationAddData = {
    sourcePropertyId?: number | undefined
    mappedPropertyId?: number | undefined
    joinTableId?: number | undefined
}

const getUnmatchedMessageList = (data: GenManyToManyAssociationAddData): Array<string> => {
    const messageList: Array<string> = []

    if (data.sourcePropertyId === undefined) {
        messageList.push("源属性不可为空")
    }
    if (data.mappedPropertyId === undefined) {
        messageList.push("目标属性不可为空")
    }
    if (data.joinTableId === undefined) {
        messageList.push("Join Table不可为空")
    }

    return messageList
}

export const validateGenManyToManyAssociationAddDataForSubmit = (data: GenManyToManyAssociationAddData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertGenManyToManyAssociationAddDataAsSubmitType = (data: GenManyToManyAssociationAddData): GenManyToManyAssociationInsertInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as GenManyToManyAssociationInsertInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
