import type {GenManyToManyAssociationAddData} from "./GenManyToManyAssociationAddData"

export const createDefaultGenManyToManyAssociation = (): GenManyToManyAssociationAddData => {
    return {
        sourcePropertyId: undefined,
        mappedPropertyId: undefined,
        joinTableId: undefined
    }
}
