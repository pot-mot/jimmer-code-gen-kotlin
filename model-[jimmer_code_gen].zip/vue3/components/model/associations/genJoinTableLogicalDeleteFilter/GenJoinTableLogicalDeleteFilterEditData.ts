import {sendMessage} from "@/utils/message"
import type {
    GenJoinTableLogicalDeleteFilterUpdateInput
} from "@/api/__generated/model/static"

export type GenJoinTableLogicalDeleteFilterEditData = {
    id: number
    joinTableId?: number | undefined
    columnName: string
    type: string
    values: string
    logicalDeletedAnnotation: string
    nullable: boolean
}

const getUnmatchedMessageList = (data: GenJoinTableLogicalDeleteFilterEditData): Array<string> => {
    const messageList: Array<string> = []

    if (data.joinTableId === undefined) {
        messageList.push("Join Table不可为空")
    }

    return messageList
}

export const validateGenJoinTableLogicalDeleteFilterEditDataForSubmit = (data: GenJoinTableLogicalDeleteFilterEditData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertGenJoinTableLogicalDeleteFilterEditDataAsSubmitType = (data: GenJoinTableLogicalDeleteFilterEditData): GenJoinTableLogicalDeleteFilterUpdateInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as GenJoinTableLogicalDeleteFilterUpdateInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
