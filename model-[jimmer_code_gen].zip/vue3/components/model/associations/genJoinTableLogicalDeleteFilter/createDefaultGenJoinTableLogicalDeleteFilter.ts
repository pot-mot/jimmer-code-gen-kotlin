import type {GenJoinTableLogicalDeleteFilterAddData} from "./GenJoinTableLogicalDeleteFilterAddData"

export const createDefaultGenJoinTableLogicalDeleteFilter = (): GenJoinTableLogicalDeleteFilterAddData => {
    return {
        joinTableId: undefined,
        columnName: "",
        type: "",
        values: "",
        logicalDeletedAnnotation: "",
        nullable: false
    }
}
