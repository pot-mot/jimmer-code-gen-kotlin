import type {GenJoinTableLogicalDeleteFilterAddData} from "./GenJoinTableLogicalDeleteFilterAddData"

export const createDefaultGenJoinTableLogicalDeleteFilter = (): GenJoinTableLogicalDeleteFilterAddData => {
    return {
        columnName: "",
        type: "",
        values: "",
        logicalDeletedAnnotation: "",
        nullable: false
    }
}
