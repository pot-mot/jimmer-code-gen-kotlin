<script setup lang="ts">
import type {GenJoinTableLogicalDeleteFilterListView} from "@/api/__generated/model/static"
import {usePageSizeStore} from "@/stores/pageSizeStore"

withDefaults(defineProps<{
    rows: Array<GenJoinTableLogicalDeleteFilterListView>,
    idColumn?: boolean | undefined,
    indexColumn?: boolean | undefined,
    multiSelect?: boolean | undefined,
    withOperations?: boolean | undefined
}>(), {
    idColumn: false,
    indexColumn: true,
    multiSelect: true,
    withOperations: true,
})

const emits = defineEmits<{
    (
        event: "selectionChange",
        selection: Array<GenJoinTableLogicalDeleteFilterListView>
    ): void
}>()

defineSlots<{
    operations(props: {
        row: GenJoinTableLogicalDeleteFilterListView,
        index: number
    }): any
}>()

const pageSizeStore = usePageSizeStore()

const handleSelectionChange = (
    newSelection: Array<GenJoinTableLogicalDeleteFilterListView>
): void => {
    emits("selectionChange", newSelection)
}
</script>

<template>
    <el-table
        :data="rows"
        row-key="id"
        border
        stripe
        class="view-table"
        @selection-change="handleSelectionChange"
    >
        <el-table-column
            v-if="idColumn"
            prop="id"
            label="ID"
            :fixed="pageSizeStore.isSmall ? undefined : 'left'"
        />
        <el-table-column
            v-if="indexColumn"
            type="index"
            :fixed="pageSizeStore.isSmall ? undefined : 'left'"
        />
        <el-table-column
            v-if="multiSelect"
            type="selection"
            :width="43"
            :fixed="pageSizeStore.isSmall ? undefined : 'left'"
        />
        <el-table-column
            prop="columnName"
            label="列名称"
            :min-width="129"
        />
        <el-table-column prop="type" label="类型" :min-width="129"/>
        <el-table-column prop="values" label="值" :min-width="129"/>
        <el-table-column
            prop="logicalDeletedAnnotation"
            label="逻辑删除注解"
            :min-width="129"
        />
        <el-table-column
            prop="nullable"
            label="可空"
            :min-width="81"
        >
            <template #default="scope">
                <el-checkbox :modelValue="scope.row.nullable"/>
            </template>
        </el-table-column>
        <el-table-column
            v-if="withOperations"
            label="操作"
            :fixed="pageSizeStore.isSmall ? undefined : 'right'"
        >
            <template #default="scope">
                <slot
                    name="operations"
                    :row="scope.row as GenJoinTableLogicalDeleteFilterListView"
                    :index="scope.$index"
                />
            </template>
        </el-table-column>
    </el-table>
</template>
