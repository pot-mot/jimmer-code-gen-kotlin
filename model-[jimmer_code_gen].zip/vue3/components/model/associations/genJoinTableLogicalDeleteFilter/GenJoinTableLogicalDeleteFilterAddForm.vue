<script setup lang="ts">
import {ref} from "vue"
import type {FormInstance} from "element-plus"
import type {FormExpose} from "@/components/form/FormExpose"
import type {
    GenJoinTableLogicalDeleteFilterInsertInput,
    GenJoinTableOptionView
} from "@/api/__generated/model/static"
import {
    validateGenJoinTableLogicalDeleteFilterAddDataForSubmit,
    assertGenJoinTableLogicalDeleteFilterAddDataAsSubmitType
} from "@/components/model/associations/genJoinTableLogicalDeleteFilter/GenJoinTableLogicalDeleteFilterAddData"
import type {GenJoinTableLogicalDeleteFilterAddData} from "@/components/model/associations/genJoinTableLogicalDeleteFilter/GenJoinTableLogicalDeleteFilterAddData"
import {
    createDefaultGenJoinTableLogicalDeleteFilter
} from "@/components/model/associations/genJoinTableLogicalDeleteFilter/createDefaultGenJoinTableLogicalDeleteFilter"
import {useRules} from "@/rules/model/associations/genJoinTableLogicalDeleteFilter/GenJoinTableLogicalDeleteFilterAddFormRules"
import GenJoinTableIdSelect from "@/components/model/associations/genJoinTable/GenJoinTableIdSelect.vue"
import type {LazyOptions} from "@/utils/lazyOptions"

const props = withDefaults(defineProps<{
    withOperations?: boolean | undefined,
    submitLoading?: boolean | undefined,
    joinTableIdOptions: LazyOptions<GenJoinTableOptionView>
}>(), {
    withOperations: true,
    submitLoading: false,
})

const emits = defineEmits<{
    (
        event: "submit",
        formData: GenJoinTableLogicalDeleteFilterInsertInput
    ): void,
    (event: "cancel"): void
}>()

defineSlots<{
    operations(props: {
        handleSubmit: () => Promise<void>,
        handleCancel: () => void
    }): any
}>()

const formData = ref<GenJoinTableLogicalDeleteFilterAddData>(createDefaultGenJoinTableLogicalDeleteFilter())

const formRef = ref<FormInstance>()
const rules = useRules(formData)

// 校验
const handleValidate = async (
    errorHandler: (errors: any[]) => void = (errors) => {console.error(errors)}
): Promise<boolean> => {
    const errors: any[] = []
    const formValid: boolean = await formRef.value?.validate().catch(e => {
        errors.push(e)
        return false
    }) ?? false

    const typeValidate: boolean = validateGenJoinTableLogicalDeleteFilterAddDataForSubmit(formData.value)

    errorHandler?.(errors)
    return formValid && typeValidate
}

// 提交
const handleSubmit = async (): Promise<void> => {
    if (props.submitLoading) return

    const validResult = await handleValidate()
    if (validResult) {
        emits("submit", assertGenJoinTableLogicalDeleteFilterAddDataAsSubmitType(formData.value))
    }
}

// 取消
const handleCancel = (): void => {
    emits("cancel")
}

defineExpose<FormExpose>({
    validate: handleValidate
})
</script>

<template>
    <el-form
        :model="formData"
        ref="formRef"
        :rules="rules"
        label-width="auto"
        @submit.prevent
        class="add-form"
    >
        <el-form-item prop="joinTableId" label="Join Table">
            <GenJoinTableIdSelect
                v-model="formData.joinTableId"
                :options="joinTableIdOptions"
            />
        </el-form-item>
        <el-form-item prop="columnName" label="列名称">
            <el-input
                v-model="formData.columnName"
                placeholder="请输入列名称"
                clearable
            />
        </el-form-item>
        <el-form-item prop="type" label="类型">
            <el-input
                v-model="formData.type"
                placeholder="请输入类型"
                clearable
            />
        </el-form-item>
        <el-form-item prop="values" label="值">
            <el-input
                v-model="formData.values"
                placeholder="请输入值"
                clearable
            />
        </el-form-item>
        <el-form-item
            prop="logicalDeletedAnnotation"
            label="逻辑删除注解"
        >
            <el-input
                v-model="formData.logicalDeletedAnnotation"
                placeholder="请输入逻辑删除注解"
                clearable
            />
        </el-form-item>
        <el-form-item prop="nullable" label="可空">
            <el-switch v-model="formData.nullable"/>
        </el-form-item>

        <slot
            v-if="withOperations"
            name="operations"
            :handleSubmit="handleSubmit"
            :handleCancel="handleCancel"
        >
            <div class="form-operations">
                <el-button type="warning" @click="handleCancel">
                    取消
                </el-button>
                <el-button
                    type="primary"
                    :loading="submitLoading"
                    @click="handleSubmit"
                >
                    提交
                </el-button>
            </div>
        </slot>
    </el-form>
</template>
