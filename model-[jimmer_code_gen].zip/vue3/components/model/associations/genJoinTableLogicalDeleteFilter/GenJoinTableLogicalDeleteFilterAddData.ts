import {sendMessage} from "@/utils/message"
import type {
    GenJoinTableLogicalDeleteFilterInsertInput
} from "@/api/__generated/model/static"

export type GenJoinTableLogicalDeleteFilterAddData = {
    columnName: string
    type: string
    values: string
    logicalDeletedAnnotation: string
    nullable: boolean
}

const getUnmatchedMessageList = (data: GenJoinTableLogicalDeleteFilterAddData): Array<string> => {
    const messageList: Array<string> = []


    return messageList
}

export const validateGenJoinTableLogicalDeleteFilterAddDataForSubmit = (data: GenJoinTableLogicalDeleteFilterAddData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertGenJoinTableLogicalDeleteFilterAddDataAsSubmitType = (data: GenJoinTableLogicalDeleteFilterAddData): GenJoinTableLogicalDeleteFilterInsertInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as GenJoinTableLogicalDeleteFilterInsertInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
