import {sendMessage} from "@/utils/message"
import type {GenOneToOneAssociationUpdateInput} from "@/api/__generated/model/static"

export type GenOneToOneAssociationEditData = {
    id: number
    sourcePropertyId?: number | undefined
    mappedPropertyId?: number | undefined
    joinTableId?: number | undefined
}

const getUnmatchedMessageList = (data: GenOneToOneAssociationEditData): Array<string> => {
    const messageList: Array<string> = []

    if (data.sourcePropertyId === undefined) {
        messageList.push("源属性不可为空")
    }
    if (data.mappedPropertyId === undefined) {
        messageList.push("目标属性不可为空")
    }

    return messageList
}

export const validateGenOneToOneAssociationEditDataForSubmit = (data: GenOneToOneAssociationEditData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertGenOneToOneAssociationEditDataAsSubmitType = (data: GenOneToOneAssociationEditData): GenOneToOneAssociationUpdateInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as GenOneToOneAssociationUpdateInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
