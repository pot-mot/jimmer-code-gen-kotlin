import {sendMessage} from "@/utils/message"
import type {GenOneToOneAssociationInsertInput} from "@/api/__generated/model/static"

export type GenOneToOneAssociationAddData = {
    sourcePropertyId?: number | undefined
    mappedPropertyId?: number | undefined
    joinTableId?: number | undefined
}

const getUnmatchedMessageList = (data: GenOneToOneAssociationAddData): Array<string> => {
    const messageList: Array<string> = []

    if (data.sourcePropertyId === undefined) {
        messageList.push("源属性不可为空")
    }
    if (data.mappedPropertyId === undefined) {
        messageList.push("目标属性不可为空")
    }

    return messageList
}

export const validateGenOneToOneAssociationAddDataForSubmit = (data: GenOneToOneAssociationAddData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertGenOneToOneAssociationAddDataAsSubmitType = (data: GenOneToOneAssociationAddData): GenOneToOneAssociationInsertInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as GenOneToOneAssociationInsertInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
