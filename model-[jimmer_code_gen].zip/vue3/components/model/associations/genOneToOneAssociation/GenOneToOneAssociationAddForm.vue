<script setup lang="ts">
import {ref} from "vue"
import type {FormInstance} from "element-plus"
import type {FormExpose} from "@/components/form/FormExpose"
import type {
    GenOneToOneAssociationInsertInput,
    GenOneToOneSourcePropertyOptionView,
    GenOneToOneMappedPropertyOptionView,
    GenJoinTableOptionView
} from "@/api/__generated/model/static"
import {
    validateGenOneToOneAssociationAddDataForSubmit,
    assertGenOneToOneAssociationAddDataAsSubmitType
} from "@/components/model/associations/genOneToOneAssociation/GenOneToOneAssociationAddData"
import type {GenOneToOneAssociationAddData} from "@/components/model/associations/genOneToOneAssociation/GenOneToOneAssociationAddData"
import {createDefaultGenOneToOneAssociation} from "@/components/model/associations/genOneToOneAssociation/createDefaultGenOneToOneAssociation"
import {useRules} from "@/rules/model/associations/genOneToOneAssociation/GenOneToOneAssociationAddFormRules"
import GenOneToOneSourcePropertyIdSelect from "@/components/model/entities/properties/genOneToOneSourceProperty/GenOneToOneSourcePropertyIdSelect.vue"
import GenOneToOneMappedPropertyIdSelect from "@/components/model/entities/properties/genOneToOneMappedProperty/GenOneToOneMappedPropertyIdSelect.vue"
import GenJoinTableIdSelect from "@/components/model/associations/genJoinTable/GenJoinTableIdSelect.vue"
import type {LazyOptions} from "@/utils/lazyOptions"

const props = withDefaults(defineProps<{
    withOperations?: boolean | undefined,
    submitLoading?: boolean | undefined,
    sourcePropertyIdOptions: LazyOptions<GenOneToOneSourcePropertyOptionView>,
    mappedPropertyIdOptions: LazyOptions<GenOneToOneMappedPropertyOptionView>,
    joinTableIdOptions: LazyOptions<GenJoinTableOptionView>
}>(), {
    withOperations: true,
    submitLoading: false,
})

const emits = defineEmits<{
    (
        event: "submit",
        formData: GenOneToOneAssociationInsertInput
    ): void,
    (event: "cancel"): void
}>()

defineSlots<{
    operations(props: {
        handleSubmit: () => Promise<void>,
        handleCancel: () => void
    }): any
}>()

const formData = ref<GenOneToOneAssociationAddData>(createDefaultGenOneToOneAssociation())

const formRef = ref<FormInstance>()
const rules = useRules(formData)

// 校验
const handleValidate = async (
    errorHandler: (errors: any[]) => void = (errors) => {console.error(errors)}
): Promise<boolean> => {
    const errors: any[] = []
    const formValid: boolean = await formRef.value?.validate().catch(e => {
        errors.push(e)
        return false
    }) ?? false

    const typeValidate: boolean = validateGenOneToOneAssociationAddDataForSubmit(formData.value)

    errorHandler?.(errors)
    return formValid && typeValidate
}

// 提交
const handleSubmit = async (): Promise<void> => {
    if (props.submitLoading) return

    const validResult = await handleValidate()
    if (validResult) {
        emits("submit", assertGenOneToOneAssociationAddDataAsSubmitType(formData.value))
    }
}

// 取消
const handleCancel = (): void => {
    emits("cancel")
}

defineExpose<FormExpose>({
    validate: handleValidate
})
</script>

<template>
    <el-form
        :model="formData"
        ref="formRef"
        :rules="rules"
        label-width="auto"
        @submit.prevent
        class="add-form"
    >
        <el-form-item prop="sourcePropertyId" label="源属性">
            <GenOneToOneSourcePropertyIdSelect
                v-model="formData.sourcePropertyId"
                :options="sourcePropertyIdOptions"
            />
        </el-form-item>
        <el-form-item prop="mappedPropertyId" label="目标属性">
            <GenOneToOneMappedPropertyIdSelect
                v-model="formData.mappedPropertyId"
                :options="mappedPropertyIdOptions"
            />
        </el-form-item>
        <el-form-item prop="joinTableId" label="Join Table">
            <GenJoinTableIdSelect
                v-model="formData.joinTableId"
                :options="joinTableIdOptions"
            />
        </el-form-item>

        <slot
            v-if="withOperations"
            name="operations"
            :handleSubmit="handleSubmit"
            :handleCancel="handleCancel"
        >
            <div class="form-operations">
                <el-button type="warning" @click="handleCancel">
                    取消
                </el-button>
                <el-button
                    type="primary"
                    :loading="submitLoading"
                    @click="handleSubmit"
                >
                    提交
                </el-button>
            </div>
        </slot>
    </el-form>
</template>
