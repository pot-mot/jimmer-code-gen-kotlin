<script setup lang="ts">
import {Search} from "@element-plus/icons-vue"
import type {
    GenOneToOneAssociationSpec,
    GenOneToOneSourcePropertyOptionView,
    GenOneToOneMappedPropertyOptionView,
    GenJoinTableOptionView
} from "@/api/__generated/model/static"
import GenOneToOneSourcePropertyIdSelect from "@/components/model/entities/properties/genOneToOneSourceProperty/GenOneToOneSourcePropertyIdSelect.vue"
import GenOneToOneMappedPropertyIdSelect from "@/components/model/entities/properties/genOneToOneMappedProperty/GenOneToOneMappedPropertyIdSelect.vue"
import GenJoinTableIdSelect from "@/components/model/associations/genJoinTable/GenJoinTableIdSelect.vue"
import type {LazyOptions} from "@/utils/lazyOptions"

const spec = defineModel<GenOneToOneAssociationSpec>({
    required: true
})

defineProps<{
    sourcePropertyIdOptions: LazyOptions<GenOneToOneSourcePropertyOptionView>,
    mappedPropertyIdOptions: LazyOptions<GenOneToOneMappedPropertyOptionView>,
    joinTableIdOptions: LazyOptions<GenJoinTableOptionView>
}>()

const emits = defineEmits<{
    (
        event: "query",
        spec: GenOneToOneAssociationSpec
    ): void
}>()
</script>

<template>
    <el-form
        :model="spec"
        label-width="auto"
        @submit.prevent
        class="query-form"
    >
        <el-row :gutter="20">
            <el-col :span="8" :xs="24">
                <el-form-item prop="sourcePropertyId" label="源属性">
                    <GenOneToOneSourcePropertyIdSelect
                        v-model="spec.sourcePropertyId"
                        :options="sourcePropertyIdOptions"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="mappedPropertyId" label="目标属性">
                    <GenOneToOneMappedPropertyIdSelect
                        v-model="spec.mappedPropertyId"
                        :options="mappedPropertyIdOptions"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="joinTableId" label="Join Table">
                    <GenJoinTableIdSelect
                        v-model="spec.joinTableId"
                        :options="joinTableIdOptions"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-button
                type="primary"
                :icon="Search"
                class="search-button"
                @click="emits('query', spec)"
            >
                查询
            </el-button>
        </el-row>
    </el-form>
</template>
