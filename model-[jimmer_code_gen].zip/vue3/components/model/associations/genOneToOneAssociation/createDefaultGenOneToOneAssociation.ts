import type {GenOneToOneAssociationAddData} from "./GenOneToOneAssociationAddData"

export const createDefaultGenOneToOneAssociation = (): GenOneToOneAssociationAddData => {
    return {
        sourcePropertyId: undefined,
        mappedPropertyId: undefined,
        joinTableId: undefined
    }
}
