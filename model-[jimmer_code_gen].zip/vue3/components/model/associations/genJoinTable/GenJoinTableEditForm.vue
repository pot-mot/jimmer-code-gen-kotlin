<script setup lang="ts">
import {ref} from "vue"
import type {FormInstance} from "element-plus"
import type {FormExpose} from "@/components/form/FormExpose"
import type {GenJoinTableUpdateInput} from "@/api/__generated/model/static"
import {
    validateGenJoinTableEditDataForSubmit,
    assertGenJoinTableEditDataAsSubmitType
} from "@/components/model/associations/genJoinTable/GenJoinTableEditData"
import type {GenJoinTableEditData} from "@/components/model/associations/genJoinTable/GenJoinTableEditData"
import {useRules} from "@/rules/model/associations/genJoinTable/GenJoinTableEditFormRules"

const formData = defineModel<GenJoinTableEditData>({
    required: true
})

const props = withDefaults(defineProps<{
    withOperations?: boolean | undefined,
    submitLoading?: boolean | undefined
}>(), {
    withOperations: true,
    submitLoading: false,
})

const emits = defineEmits<{
    (
        event: "submit",
        formData: GenJoinTableUpdateInput
    ): void,
    (event: "cancel"): void
}>()

defineSlots<{
    operations(props: {
        handleSubmit: () => Promise<void>,
        handleCancel: () => void
    }): any
}>()

const formRef = ref<FormInstance>()
const rules = useRules(formData)

// 校验
const handleValidate = async (
    errorHandler: (errors: any[]) => void = (errors) => {console.error(errors)}
): Promise<boolean> => {
    const errors: any[] = []
    const formValid: boolean = await formRef.value?.validate().catch(e => {
        errors.push(e)
        return false
    }) ?? false

    const typeValidate: boolean = validateGenJoinTableEditDataForSubmit(formData.value)

    errorHandler?.(errors)
    return formValid && typeValidate
}

// 提交
const handleSubmit = async (): Promise<void> => {
    if (props.submitLoading) return

    const validResult = await handleValidate()
    if (validResult) {
        emits("submit", assertGenJoinTableEditDataAsSubmitType(formData.value))
    }
}

// 取消
const handleCancel = (): void => {
    emits("cancel")
}

defineExpose<FormExpose>({
    validate: handleValidate
})
</script>

<template>
    <el-form
        :model="formData"
        ref="formRef"
        :rules="rules"
        label-width="auto"
        @submit.prevent
        class="edit-form"
    >
        <el-form-item prop="name" label="名称">
            <el-input
                v-model="formData.name"
                placeholder="请输入名称"
                clearable
            />
        </el-form-item>
        <el-form-item prop="comment" label="注释">
            <el-input
                v-model="formData.comment"
                placeholder="请输入注释"
                clearable
            />
        </el-form-item>
        <el-form-item prop="readonly" label="只读">
            <el-switch v-model="formData.readonly"/>
        </el-form-item>
        <el-form-item
            prop="preventDeletionBySource"
            label="阻止从源删除"
        >
            <el-switch
                v-model="formData.preventDeletionBySource"
            />
        </el-form-item>
        <el-form-item
            prop="preventDeletionByTarget"
            label="阻止从目标删除"
        >
            <el-switch
                v-model="formData.preventDeletionByTarget"
            />
        </el-form-item>
        <el-form-item
            prop="deletedWhenEndpointIsLogicallyDeleted"
            label="在终端逻辑删除时物理删除"
        >
            <el-switch
                v-model="formData.deletedWhenEndpointIsLogicallyDeleted"
            />
        </el-form-item>

        <slot
            v-if="withOperations"
            name="operations"
            :handleSubmit="handleSubmit"
            :handleCancel="handleCancel"
        >
            <div class="form-operations">
                <el-button type="warning" @click="handleCancel">
                    取消
                </el-button>
                <el-button
                    type="primary"
                    :loading="submitLoading"
                    @click="handleSubmit"
                >
                    提交
                </el-button>
            </div>
        </slot>
    </el-form>
</template>
