import {sendMessage} from "@/utils/message"
import type {GenJoinTableInsertInput} from "@/api/__generated/model/static"

export type GenJoinTableAddData = {
    name: string
    comment: string
    readonly: boolean
    preventDeletionBySource: boolean
    preventDeletionByTarget: boolean
    deletedWhenEndpointIsLogicallyDeleted: boolean
}

const getUnmatchedMessageList = (data: GenJoinTableAddData): Array<string> => {
    const messageList: Array<string> = []


    return messageList
}

export const validateGenJoinTableAddDataForSubmit = (data: GenJoinTableAddData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertGenJoinTableAddDataAsSubmitType = (data: GenJoinTableAddData): GenJoinTableInsertInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as GenJoinTableInsertInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
