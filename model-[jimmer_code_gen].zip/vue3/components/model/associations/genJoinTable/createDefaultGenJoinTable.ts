import type {GenJoinTableAddData} from "./GenJoinTableAddData"

export const createDefaultGenJoinTable = (): GenJoinTableAddData => {
    return {
        name: "",
        comment: "",
        readonly: false,
        preventDeletionBySource: false,
        preventDeletionByTarget: false,
        deletedWhenEndpointIsLogicallyDeleted: false
    }
}
