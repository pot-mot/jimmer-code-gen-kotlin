<script setup lang="ts">
import type {GenJoinTableListView} from "@/api/__generated/model/static"
import {usePageSizeStore} from "@/stores/pageSizeStore"

withDefaults(defineProps<{
    rows: Array<GenJoinTableListView>,
    idColumn?: boolean | undefined,
    indexColumn?: boolean | undefined,
    multiSelect?: boolean | undefined,
    withOperations?: boolean | undefined
}>(), {
    idColumn: false,
    indexColumn: true,
    multiSelect: true,
    withOperations: true,
})

const emits = defineEmits<{
    (
        event: "selectionChange",
        selection: Array<GenJoinTableListView>
    ): void
}>()

defineSlots<{
    operations(props: {row: GenJoinTableListView, index: number}): any
}>()

const pageSizeStore = usePageSizeStore()

const handleSelectionChange = (
    newSelection: Array<GenJoinTableListView>
): void => {
    emits("selectionChange", newSelection)
}
</script>

<template>
    <el-table
        :data="rows"
        row-key="id"
        border
        stripe
        class="view-table"
        @selection-change="handleSelectionChange"
    >
        <el-table-column
            v-if="idColumn"
            prop="id"
            label="ID"
            :fixed="pageSizeStore.isSmall ? undefined : 'left'"
        />
        <el-table-column
            v-if="indexColumn"
            type="index"
            :fixed="pageSizeStore.isSmall ? undefined : 'left'"
        />
        <el-table-column
            v-if="multiSelect"
            type="selection"
            :width="43"
            :fixed="pageSizeStore.isSmall ? undefined : 'left'"
        />
        <el-table-column prop="name" label="名称" :min-width="129"/>
        <el-table-column
            prop="comment"
            label="注释"
            :min-width="129"
        />
        <el-table-column
            prop="readonly"
            label="只读"
            :min-width="81"
        >
            <template #default="scope">
                <el-checkbox :modelValue="scope.row.readonly"/>
            </template>
        </el-table-column>
        <el-table-column
            prop="preventDeletionBySource"
            label="阻止从源删除"
            :min-width="81"
        >
            <template #default="scope">
                <el-checkbox
                    :modelValue="scope.row.preventDeletionBySource"
                />
            </template>
        </el-table-column>
        <el-table-column
            prop="preventDeletionByTarget"
            label="阻止从目标删除"
            :min-width="81"
        >
            <template #default="scope">
                <el-checkbox
                    :modelValue="scope.row.preventDeletionByTarget"
                />
            </template>
        </el-table-column>
        <el-table-column
            prop="deletedWhenEndpointIsLogicallyDeleted"
            label="在终端逻辑删除时物理删除"
            :min-width="81"
        >
            <template #default="scope">
                <el-checkbox
                    :modelValue="scope.row.deletedWhenEndpointIsLogicallyDeleted"
                />
            </template>
        </el-table-column>
        <el-table-column
            v-if="withOperations"
            label="操作"
            :fixed="pageSizeStore.isSmall ? undefined : 'right'"
        >
            <template #default="scope">
                <slot
                    name="operations"
                    :row="scope.row as GenJoinTableListView"
                    :index="scope.$index"
                />
            </template>
        </el-table-column>
    </el-table>
</template>
