<script setup lang="ts">
import {Search} from "@element-plus/icons-vue"
import type {
    GenJoinTableSpec,
    GenJoinTableLogicalDeleteFilterOptionView
} from "@/api/__generated/model/static"
import GenJoinTableLogicalDeleteFilterIdSelect from "@/components/model/associations/genJoinTableLogicalDeleteFilter/GenJoinTableLogicalDeleteFilterIdSelect.vue"
import type {LazyOptions} from "@/utils/lazyOptions"

const spec = defineModel<GenJoinTableSpec>({
    required: true
})

defineProps<{
    logicalDeleteFilterIdOptions: LazyOptions<GenJoinTableLogicalDeleteFilterOptionView>
}>()

const emits = defineEmits<{
    (event: "query", spec: GenJoinTableSpec): void
}>()
</script>

<template>
    <el-form
        :model="spec"
        label-width="auto"
        @submit.prevent
        class="query-form"
    >
        <el-row :gutter="20">
            <el-col :span="8" :xs="24">
                <el-form-item prop="name" label="名称">
                    <el-input
                        v-model="spec.name"
                        placeholder="请输入名称"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="comment" label="注释">
                    <el-input
                        v-model="spec.comment"
                        placeholder="请输入注释"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="readonly" label="只读">
                    <el-select
                        v-model="spec.readonly"
                        placeholder="请选择只读"
                        clearable
                        :value-on-clear="undefined"
                        @change="emits('query', spec)"
                    >
                        <el-option :value="true" label="是"/>
                        <el-option :value="false" label="否"/>
                    </el-select>
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item
                    prop="preventDeletionBySource"
                    label="阻止从源删除"
                >
                    <el-select
                        v-model="spec.preventDeletionBySource"
                        placeholder="请选择阻止从源删除"
                        clearable
                        :value-on-clear="undefined"
                        @change="emits('query', spec)"
                    >
                        <el-option :value="true" label="是"/>
                        <el-option :value="false" label="否"/>
                    </el-select>
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item
                    prop="preventDeletionByTarget"
                    label="阻止从目标删除"
                >
                    <el-select
                        v-model="spec.preventDeletionByTarget"
                        placeholder="请选择阻止从目标删除"
                        clearable
                        :value-on-clear="undefined"
                        @change="emits('query', spec)"
                    >
                        <el-option :value="true" label="是"/>
                        <el-option :value="false" label="否"/>
                    </el-select>
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item
                    prop="deletedWhenEndpointIsLogicallyDeleted"
                    label="在终端逻辑删除时物理删除"
                >
                    <el-select
                        v-model="spec.deletedWhenEndpointIsLogicallyDeleted"
                        placeholder="请选择在终端逻辑删除时物理删除"
                        clearable
                        :value-on-clear="undefined"
                        @change="emits('query', spec)"
                    >
                        <el-option :value="true" label="是"/>
                        <el-option :value="false" label="否"/>
                    </el-select>
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item
                    prop="logicalDeleteFilterId"
                    label="逻辑删除过滤器"
                >
                    <GenJoinTableLogicalDeleteFilterIdSelect
                        v-model="spec.logicalDeleteFilterId"
                        :options="logicalDeleteFilterIdOptions"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-button
                type="primary"
                :icon="Search"
                class="search-button"
                @click="emits('query', spec)"
            >
                查询
            </el-button>
        </el-row>
    </el-form>
</template>
