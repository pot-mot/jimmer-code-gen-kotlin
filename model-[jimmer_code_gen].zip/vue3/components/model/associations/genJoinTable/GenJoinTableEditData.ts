import {sendMessage} from "@/utils/message"
import type {GenJoinTableUpdateInput} from "@/api/__generated/model/static"

export type GenJoinTableEditData = {
    id: number
    name: string
    comment: string
    readonly: boolean
    preventDeletionBySource: boolean
    preventDeletionByTarget: boolean
    deletedWhenEndpointIsLogicallyDeleted: boolean
    logicalDeleteFilterId?: number | undefined
}

const getUnmatchedMessageList = (data: GenJoinTableEditData): Array<string> => {
    const messageList: Array<string> = []


    return messageList
}

export const validateGenJoinTableEditDataForSubmit = (data: GenJoinTableEditData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertGenJoinTableEditDataAsSubmitType = (data: GenJoinTableEditData): GenJoinTableUpdateInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as GenJoinTableUpdateInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
