import {sendMessage} from "@/utils/message"
import type {GenJoinTableColumnUpdateInput} from "@/api/__generated/model/static"

export type GenJoinTableColumnEditData = {
    id: number
    jdbcTypeCode: number
    rawType: string
    typeIsNotNull: boolean
    dataSize?: number | undefined
    numericPrecision?: number | undefined
    columnDefaultExp?: string | undefined
    joinTableId?: number | undefined
    columnName: string
    referenceColumnName: string
    comment: string
    fake: boolean
}

const getUnmatchedMessageList = (data: GenJoinTableColumnEditData): Array<string> => {
    const messageList: Array<string> = []

    if (data.joinTableId === undefined) {
        messageList.push("Join Table不可为空")
    }

    return messageList
}

export const validateGenJoinTableColumnEditDataForSubmit = (data: GenJoinTableColumnEditData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertGenJoinTableColumnEditDataAsSubmitType = (data: GenJoinTableColumnEditData): GenJoinTableColumnUpdateInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as GenJoinTableColumnUpdateInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
