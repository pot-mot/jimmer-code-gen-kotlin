import {sendMessage} from "@/utils/message"
import type {GenJoinTableColumnInsertInput} from "@/api/__generated/model/static"

export type GenJoinTableColumnAddData = {
    joinTableId?: number | undefined
    columnName: string
    referenceColumnName: string
    comment: string
    fake: boolean
}

const getUnmatchedMessageList = (data: GenJoinTableColumnAddData): Array<string> => {
    const messageList: Array<string> = []

    if (data.joinTableId === undefined) {
        messageList.push("Join Table不可为空")
    }

    return messageList
}

export const validateGenJoinTableColumnAddDataForSubmit = (data: GenJoinTableColumnAddData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertGenJoinTableColumnAddDataAsSubmitType = (data: GenJoinTableColumnAddData): GenJoinTableColumnInsertInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as GenJoinTableColumnInsertInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
