<script setup lang="ts">
import {Search} from "@element-plus/icons-vue"
import type {
    GenJoinTableColumnSpec,
    GenJoinTableOptionView
} from "@/api/__generated/model/static"
import GenJoinTableIdSelect from "@/components/model/associations/genJoinTable/GenJoinTableIdSelect.vue"
import type {LazyOptions} from "@/utils/lazyOptions"

const spec = defineModel<GenJoinTableColumnSpec>({
    required: true
})

defineProps<{
    joinTableIdOptions: LazyOptions<GenJoinTableOptionView>
}>()

const emits = defineEmits<{
    (
        event: "query",
        spec: GenJoinTableColumnSpec
    ): void
}>()
</script>

<template>
    <el-form
        :model="spec"
        label-width="auto"
        @submit.prevent
        class="query-form"
    >
        <el-row :gutter="20">
            <el-col :span="8" :xs="24">
                <el-form-item prop="jdbcTypeCode" label="JdbcType 码值">
                    <el-input-number
                        v-model.number="spec.minJdbcTypeCode"
                        placeholder="最小"
                        :precision="0"
                        :min="0"
                        :max="2147483647"
                        :value-on-clear="undefined"
                        @change="emits('query', spec)"
                    />
                    <el-input-number
                        v-model.number="spec.maxJdbcTypeCode"
                        placeholder="最大"
                        :precision="0"
                        :min="0"
                        :max="2147483647"
                        :value-on-clear="undefined"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="rawType" label="字面类型">
                    <el-input
                        v-model="spec.rawType"
                        placeholder="请输入字面类型"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="typeIsNotNull" label="类型是否非空">
                    <el-select
                        v-model="spec.typeIsNotNull"
                        placeholder="请选择类型是否非空"
                        clearable
                        :value-on-clear="undefined"
                        @change="emits('query', spec)"
                    >
                        <el-option :value="true" label="是"/>
                        <el-option :value="false" label="否"/>
                    </el-select>
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="dataSize" label="长度">
                    <el-input-number
                        v-model.number="spec.minDataSize"
                        placeholder="最小"
                        :precision="0"
                        :max="2147483647"
                        :value-on-clear="undefined"
                        @change="emits('query', spec)"
                    />
                    <el-input-number
                        v-model.number="spec.maxDataSize"
                        placeholder="最大"
                        :precision="0"
                        :max="2147483647"
                        :value-on-clear="undefined"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="numericPrecision" label="精度">
                    <el-input-number
                        v-model.number="spec.minNumericPrecision"
                        placeholder="最小"
                        :precision="0"
                        :max="2147483647"
                        :value-on-clear="undefined"
                        @change="emits('query', spec)"
                    />
                    <el-input-number
                        v-model.number="spec.maxNumericPrecision"
                        placeholder="最大"
                        :precision="0"
                        :max="2147483647"
                        :value-on-clear="undefined"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="columnDefaultExp" label="列默认表达式">
                    <el-input
                        v-model="spec.columnDefaultExp"
                        placeholder="请输入列默认表达式"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="joinTableId" label="Join Table">
                    <GenJoinTableIdSelect
                        v-model="spec.joinTableId"
                        :options="joinTableIdOptions"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="columnName" label="本地列名称">
                    <el-input
                        v-model="spec.columnName"
                        placeholder="请输入本地列名称"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="referenceColumnName" label="引用列名称">
                    <el-input
                        v-model="spec.referenceColumnName"
                        placeholder="请输入引用列名称"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="comment" label="注释">
                    <el-input
                        v-model="spec.comment"
                        placeholder="请输入注释"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="fake" label="是否伪外键">
                    <el-select
                        v-model="spec.fake"
                        placeholder="请选择是否伪外键"
                        clearable
                        :value-on-clear="undefined"
                        @change="emits('query', spec)"
                    >
                        <el-option :value="true" label="是"/>
                        <el-option :value="false" label="否"/>
                    </el-select>
                </el-form-item>
            </el-col>
            <el-button
                type="primary"
                :icon="Search"
                class="search-button"
                @click="emits('query', spec)"
            >
                查询
            </el-button>
        </el-row>
    </el-form>
</template>
