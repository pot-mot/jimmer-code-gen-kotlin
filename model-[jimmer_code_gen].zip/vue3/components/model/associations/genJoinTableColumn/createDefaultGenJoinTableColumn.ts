import type {GenJoinTableColumnAddData} from "./GenJoinTableColumnAddData"

export const createDefaultGenJoinTableColumn = (): GenJoinTableColumnAddData => {
    return {
        joinTableId: undefined,
        columnName: "",
        referenceColumnName: "",
        comment: "",
        fake: false
    }
}
