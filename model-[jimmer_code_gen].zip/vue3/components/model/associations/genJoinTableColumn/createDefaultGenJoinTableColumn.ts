import type {GenJoinTableColumnAddData} from "./GenJoinTableColumnAddData"

export const createDefaultGenJoinTableColumn = (): GenJoinTableColumnAddData => {
    return {
        jdbcTypeCode: 0,
        rawType: "",
        typeIsNotNull: false,
        dataSize: undefined,
        numericPrecision: undefined,
        columnDefaultExp: undefined,
        joinTableId: undefined,
        columnName: "",
        referenceColumnName: "",
        comment: "",
        fake: false
    }
}
