<script setup lang="ts">
import type {GenJoinTableColumnListView} from "@/api/__generated/model/static"
import {usePageSizeStore} from "@/stores/pageSizeStore"

withDefaults(defineProps<{
    rows: Array<GenJoinTableColumnListView>,
    idColumn?: boolean | undefined,
    indexColumn?: boolean | undefined,
    multiSelect?: boolean | undefined,
    withOperations?: boolean | undefined
}>(), {
    idColumn: false,
    indexColumn: true,
    multiSelect: true,
    withOperations: true,
})

const emits = defineEmits<{
    (
        event: "selectionChange",
        selection: Array<GenJoinTableColumnListView>
    ): void
}>()

defineSlots<{
    operations(props: {
        row: GenJoinTableColumnListView,
        index: number
    }): any
}>()

const pageSizeStore = usePageSizeStore()

const handleSelectionChange = (
    newSelection: Array<GenJoinTableColumnListView>
): void => {
    emits("selectionChange", newSelection)
}
</script>

<template>
    <el-table
        :data="rows"
        row-key="id"
        border
        stripe
        class="view-table"
        @selection-change="handleSelectionChange"
    >
        <el-table-column
            v-if="idColumn"
            prop="id"
            label="ID"
            :fixed="pageSizeStore.isSmall ? undefined : 'left'"
        />
        <el-table-column
            v-if="indexColumn"
            type="index"
            :fixed="pageSizeStore.isSmall ? undefined : 'left'"
        />
        <el-table-column
            v-if="multiSelect"
            type="selection"
            :width="43"
            :fixed="pageSizeStore.isSmall ? undefined : 'left'"
        />
        <el-table-column
            prop="joinTableId"
            label="Join Table"
            :min-width="161"
        />
        <el-table-column
            prop="columnName"
            label="本地列名称"
            :min-width="129"
        />
        <el-table-column
            prop="referenceColumnName"
            label="引用列名称"
            :min-width="129"
        />
        <el-table-column
            prop="comment"
            label="注释"
            :min-width="129"
        />
        <el-table-column
            prop="fake"
            label="是否伪外键"
            :min-width="81"
        >
            <template #default="scope">
                <el-checkbox :modelValue="scope.row.fake"/>
            </template>
        </el-table-column>
        <el-table-column
            v-if="withOperations"
            label="操作"
            :fixed="pageSizeStore.isSmall ? undefined : 'right'"
        >
            <template #default="scope">
                <slot
                    name="operations"
                    :row="scope.row as GenJoinTableColumnListView"
                    :index="scope.$index"
                />
            </template>
        </el-table-column>
    </el-table>
</template>
