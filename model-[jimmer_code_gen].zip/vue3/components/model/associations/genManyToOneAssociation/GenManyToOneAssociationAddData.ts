import {sendMessage} from "@/utils/message"
import type {GenManyToOneAssociationInsertInput} from "@/api/__generated/model/static"

export type GenManyToOneAssociationAddData = {
    sourcePropertyId?: number | undefined
    mappedPropertyId?: number | undefined
    joinTableId?: number | undefined
}

const getUnmatchedMessageList = (data: GenManyToOneAssociationAddData): Array<string> => {
    const messageList: Array<string> = []

    if (data.sourcePropertyId === undefined) {
        messageList.push("源属性不可为空")
    }
    if (data.mappedPropertyId === undefined) {
        messageList.push("目标属性不可为空")
    }

    return messageList
}

export const validateGenManyToOneAssociationAddDataForSubmit = (data: GenManyToOneAssociationAddData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertGenManyToOneAssociationAddDataAsSubmitType = (data: GenManyToOneAssociationAddData): GenManyToOneAssociationInsertInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as GenManyToOneAssociationInsertInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
