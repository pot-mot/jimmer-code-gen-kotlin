<script setup lang="ts">
import type {GenManyToOneAssociationListView} from "@/api/__generated/model/static"
import {usePageSizeStore} from "@/stores/pageSizeStore"

withDefaults(defineProps<{
    rows: Array<GenManyToOneAssociationListView>,
    idColumn?: boolean | undefined,
    indexColumn?: boolean | undefined,
    multiSelect?: boolean | undefined,
    withOperations?: boolean | undefined
}>(), {
    idColumn: false,
    indexColumn: true,
    multiSelect: true,
    withOperations: true,
})

const emits = defineEmits<{
    (
        event: "selectionChange",
        selection: Array<GenManyToOneAssociationListView>
    ): void
}>()

defineSlots<{
    operations(props: {
        row: GenManyToOneAssociationListView,
        index: number
    }): any
}>()

const pageSizeStore = usePageSizeStore()

const handleSelectionChange = (
    newSelection: Array<GenManyToOneAssociationListView>
): void => {
    emits("selectionChange", newSelection)
}
</script>

<template>
    <el-table
        :data="rows"
        row-key="id"
        border
        stripe
        class="view-table"
        @selection-change="handleSelectionChange"
    >
        <el-table-column
            v-if="idColumn"
            prop="id"
            label="ID"
            :fixed="pageSizeStore.isSmall ? undefined : 'left'"
        />
        <el-table-column
            v-if="indexColumn"
            type="index"
            :fixed="pageSizeStore.isSmall ? undefined : 'left'"
        />
        <el-table-column
            v-if="multiSelect"
            type="selection"
            :width="43"
            :fixed="pageSizeStore.isSmall ? undefined : 'left'"
        />
        <el-table-column
            prop="sourcePropertyId"
            label="源属性"
            :min-width="161"
        />
        <el-table-column
            prop="mappedPropertyId"
            label="目标属性"
            :min-width="161"
        />
        <el-table-column
            prop="joinTableId"
            label="Join Table"
            :min-width="161"
        />
        <el-table-column
            v-if="withOperations"
            label="操作"
            :fixed="pageSizeStore.isSmall ? undefined : 'right'"
        >
            <template #default="scope">
                <slot
                    name="operations"
                    :row="scope.row as GenManyToOneAssociationListView"
                    :index="scope.$index"
                />
            </template>
        </el-table-column>
    </el-table>
</template>
