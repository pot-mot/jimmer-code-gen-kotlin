<script setup lang="ts">
import {Search} from "@element-plus/icons-vue"
import type {
    GenManyToOneAssociationSpec,
    GenManyToOneSourcePropertyOptionView,
    GenManyToOneMappedPropertyOptionView,
    GenJoinTableOptionView
} from "@/api/__generated/model/static"
import GenManyToOneSourcePropertyIdSelect from "@/components/model/entities/properties/genManyToOneSourceProperty/GenManyToOneSourcePropertyIdSelect.vue"
import GenManyToOneMappedPropertyIdSelect from "@/components/model/entities/properties/genManyToOneMappedProperty/GenManyToOneMappedPropertyIdSelect.vue"
import GenJoinTableIdSelect from "@/components/model/associations/genJoinTable/GenJoinTableIdSelect.vue"
import type {LazyOptions} from "@/utils/lazyOptions"

const spec = defineModel<GenManyToOneAssociationSpec>({
    required: true
})

defineProps<{
    sourcePropertyIdOptions: LazyOptions<GenManyToOneSourcePropertyOptionView>,
    mappedPropertyIdOptions: LazyOptions<GenManyToOneMappedPropertyOptionView>,
    joinTableIdOptions: LazyOptions<GenJoinTableOptionView>
}>()

const emits = defineEmits<{
    (
        event: "query",
        spec: GenManyToOneAssociationSpec
    ): void
}>()
</script>

<template>
    <el-form
        :model="spec"
        label-width="auto"
        @submit.prevent
        class="query-form"
    >
        <el-row :gutter="20">
            <el-col :span="8" :xs="24">
                <el-form-item prop="sourcePropertyId" label="源属性">
                    <GenManyToOneSourcePropertyIdSelect
                        v-model="spec.sourcePropertyId"
                        :options="sourcePropertyIdOptions"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="mappedPropertyId" label="目标属性">
                    <GenManyToOneMappedPropertyIdSelect
                        v-model="spec.mappedPropertyId"
                        :options="mappedPropertyIdOptions"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="joinTableId" label="Join Table">
                    <GenJoinTableIdSelect
                        v-model="spec.joinTableId"
                        :options="joinTableIdOptions"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-button
                type="primary"
                :icon="Search"
                class="search-button"
                @click="emits('query', spec)"
            >
                查询
            </el-button>
        </el-row>
    </el-form>
</template>
