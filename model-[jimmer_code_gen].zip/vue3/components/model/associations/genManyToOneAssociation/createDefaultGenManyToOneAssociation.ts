import type {GenManyToOneAssociationAddData} from "./GenManyToOneAssociationAddData"

export const createDefaultGenManyToOneAssociation = (): GenManyToOneAssociationAddData => {
    return {
        sourcePropertyId: undefined,
        mappedPropertyId: undefined,
        joinTableId: undefined
    }
}
