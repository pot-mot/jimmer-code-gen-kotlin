import {sendMessage} from "@/utils/message"
import type {GenManyToOneAssociationUpdateInput} from "@/api/__generated/model/static"

export type GenManyToOneAssociationEditData = {
    id: number
    sourcePropertyId?: number | undefined
    mappedPropertyId?: number | undefined
    joinTableId?: number | undefined
}

const getUnmatchedMessageList = (data: GenManyToOneAssociationEditData): Array<string> => {
    const messageList: Array<string> = []

    if (data.sourcePropertyId === undefined) {
        messageList.push("源属性不可为空")
    }
    if (data.mappedPropertyId === undefined) {
        messageList.push("目标属性不可为空")
    }

    return messageList
}

export const validateGenManyToOneAssociationEditDataForSubmit = (data: GenManyToOneAssociationEditData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertGenManyToOneAssociationEditDataAsSubmitType = (data: GenManyToOneAssociationEditData): GenManyToOneAssociationUpdateInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as GenManyToOneAssociationUpdateInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
