<script setup lang="ts">
import {ref} from "vue"
import type {FormInstance} from "element-plus"
import type {FormExpose} from "@/components/form/FormExpose"
import type {
    GenJoinTableFilterInsertInput,
    GenJoinTableOptionView
} from "@/api/__generated/model/static"
import {
    validateGenJoinTableFilterAddDataForSubmit,
    assertGenJoinTableFilterAddDataAsSubmitType
} from "@/components/model/associations/genJoinTableFilter/GenJoinTableFilterAddData"
import type {GenJoinTableFilterAddData} from "@/components/model/associations/genJoinTableFilter/GenJoinTableFilterAddData"
import {createDefaultGenJoinTableFilter} from "@/components/model/associations/genJoinTableFilter/createDefaultGenJoinTableFilter"
import {useRules} from "@/rules/model/associations/genJoinTableFilter/GenJoinTableFilterAddFormRules"
import GenJoinTableIdSelect from "@/components/model/associations/genJoinTable/GenJoinTableIdSelect.vue"
import type {LazyOptions} from "@/utils/lazyOptions"

const props = withDefaults(defineProps<{
    withOperations?: boolean | undefined,
    submitLoading?: boolean | undefined,
    joinTableIdOptions: LazyOptions<GenJoinTableOptionView>
}>(), {
    withOperations: true,
    submitLoading: false,
})

const emits = defineEmits<{
    (
        event: "submit",
        formData: GenJoinTableFilterInsertInput
    ): void,
    (event: "cancel"): void
}>()

defineSlots<{
    operations(props: {
        handleSubmit: () => Promise<void>,
        handleCancel: () => void
    }): any
}>()

const formData = ref<GenJoinTableFilterAddData>(createDefaultGenJoinTableFilter())

const formRef = ref<FormInstance>()
const rules = useRules(formData)

// 校验
const handleValidate = async (
    errorHandler: (errors: any[]) => void = (errors) => {console.error(errors)}
): Promise<boolean> => {
    const errors: any[] = []
    const formValid: boolean = await formRef.value?.validate().catch(e => {
        errors.push(e)
        return false
    }) ?? false

    const typeValidate: boolean = validateGenJoinTableFilterAddDataForSubmit(formData.value)

    errorHandler?.(errors)
    return formValid && typeValidate
}

// 提交
const handleSubmit = async (): Promise<void> => {
    if (props.submitLoading) return

    const validResult = await handleValidate()
    if (validResult) {
        emits("submit", assertGenJoinTableFilterAddDataAsSubmitType(formData.value))
    }
}

// 取消
const handleCancel = (): void => {
    emits("cancel")
}

defineExpose<FormExpose>({
    validate: handleValidate
})
</script>

<template>
    <el-form
        :model="formData"
        ref="formRef"
        :rules="rules"
        label-width="auto"
        @submit.prevent
        class="add-form"
    >
        <el-form-item prop="joinTableId" label="Join Table">
            <GenJoinTableIdSelect
                v-model="formData.joinTableId"
                :options="joinTableIdOptions"
            />
        </el-form-item>
        <el-form-item prop="columnName" label="列名称">
            <el-input
                v-model="formData.columnName"
                placeholder="请输入列名称"
                clearable
            />
        </el-form-item>
        <el-form-item prop="type" label="类型">
            <el-input
                v-model="formData.type"
                placeholder="请输入类型"
                clearable
            />
        </el-form-item>
        <el-form-item prop="values" label="值">
            <el-input
                v-model="formData.values"
                placeholder="请输入值"
                clearable
            />
        </el-form-item>

        <slot
            v-if="withOperations"
            name="operations"
            :handleSubmit="handleSubmit"
            :handleCancel="handleCancel"
        >
            <div class="form-operations">
                <el-button type="warning" @click="handleCancel">
                    取消
                </el-button>
                <el-button
                    type="primary"
                    :loading="submitLoading"
                    @click="handleSubmit"
                >
                    提交
                </el-button>
            </div>
        </slot>
    </el-form>
</template>
