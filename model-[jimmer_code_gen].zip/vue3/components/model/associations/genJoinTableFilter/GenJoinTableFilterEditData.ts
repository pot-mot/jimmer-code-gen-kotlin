import {sendMessage} from "@/utils/message"
import type {GenJoinTableFilterUpdateInput} from "@/api/__generated/model/static"

export type GenJoinTableFilterEditData = {
    id: number
    joinTableId?: number | undefined
    columnName: string
    type: string
    values: string
}

const getUnmatchedMessageList = (data: GenJoinTableFilterEditData): Array<string> => {
    const messageList: Array<string> = []

    if (data.joinTableId === undefined) {
        messageList.push("Join Table不可为空")
    }

    return messageList
}

export const validateGenJoinTableFilterEditDataForSubmit = (data: GenJoinTableFilterEditData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertGenJoinTableFilterEditDataAsSubmitType = (data: GenJoinTableFilterEditData): GenJoinTableFilterUpdateInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as GenJoinTableFilterUpdateInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
