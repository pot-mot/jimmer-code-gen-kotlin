import type {GenJoinTableFilterAddData} from "./GenJoinTableFilterAddData"

export const createDefaultGenJoinTableFilter = (): GenJoinTableFilterAddData => {
    return {
        joinTableId: undefined,
        columnName: "",
        type: "",
        values: ""
    }
}
