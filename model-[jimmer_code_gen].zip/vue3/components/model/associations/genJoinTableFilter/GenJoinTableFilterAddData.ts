import {sendMessage} from "@/utils/message"
import type {GenJoinTableFilterInsertInput} from "@/api/__generated/model/static"

export type GenJoinTableFilterAddData = {
    joinTableId?: number | undefined
    columnName: string
    type: string
    values: string
}

const getUnmatchedMessageList = (data: GenJoinTableFilterAddData): Array<string> => {
    const messageList: Array<string> = []

    if (data.joinTableId === undefined) {
        messageList.push("Join Table不可为空")
    }

    return messageList
}

export const validateGenJoinTableFilterAddDataForSubmit = (data: GenJoinTableFilterAddData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertGenJoinTableFilterAddDataAsSubmitType = (data: GenJoinTableFilterAddData): GenJoinTableFilterInsertInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as GenJoinTableFilterInsertInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
