<script setup lang="ts">
import {Search} from "@element-plus/icons-vue"
import type {
    GenJoinTableFilterSpec,
    GenJoinTableOptionView
} from "@/api/__generated/model/static"
import GenJoinTableIdSelect from "@/components/model/associations/genJoinTable/GenJoinTableIdSelect.vue"
import type {LazyOptions} from "@/utils/lazyOptions"

const spec = defineModel<GenJoinTableFilterSpec>({
    required: true
})

defineProps<{
    joinTableIdOptions: LazyOptions<GenJoinTableOptionView>
}>()

const emits = defineEmits<{
    (
        event: "query",
        spec: GenJoinTableFilterSpec
    ): void
}>()
</script>

<template>
    <el-form
        :model="spec"
        label-width="auto"
        @submit.prevent
        class="query-form"
    >
        <el-row :gutter="20">
            <el-col :span="8" :xs="24">
                <el-form-item prop="joinTableId" label="Join Table">
                    <GenJoinTableIdSelect
                        v-model="spec.joinTableId"
                        :options="joinTableIdOptions"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="columnName" label="列名称">
                    <el-input
                        v-model="spec.columnName"
                        placeholder="请输入列名称"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="type" label="类型">
                    <el-input
                        v-model="spec.type"
                        placeholder="请输入类型"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="values" label="值">
                    <el-input
                        v-model="spec.values"
                        placeholder="请输入值"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-button
                type="primary"
                :icon="Search"
                class="search-button"
                @click="emits('query', spec)"
            >
                查询
            </el-button>
        </el-row>
    </el-form>
</template>
