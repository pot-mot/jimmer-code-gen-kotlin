import type {GenEmbeddableAddData} from "./GenEmbeddableAddData"

export const createDefaultGenEmbeddable = (): GenEmbeddableAddData => {
    return {
        groupId: undefined,
        name: "",
        subPackagePath: "",
        comment: ""
    }
}
