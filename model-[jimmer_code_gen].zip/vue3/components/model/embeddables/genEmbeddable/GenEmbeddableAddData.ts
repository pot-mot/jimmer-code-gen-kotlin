import {sendMessage} from "@/utils/message"
import type {GenEmbeddableInsertInput} from "@/api/__generated/model/static"

export type GenEmbeddableAddData = {
    groupId?: number | undefined
    name: string
    subPackagePath: string
    comment: string
}

const getUnmatchedMessageList = (data: GenEmbeddableAddData): Array<string> => {
    const messageList: Array<string> = []

    if (data.groupId === undefined) {
        messageList.push("分组不可为空")
    }

    return messageList
}

export const validateGenEmbeddableAddDataForSubmit = (data: GenEmbeddableAddData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertGenEmbeddableAddDataAsSubmitType = (data: GenEmbeddableAddData): GenEmbeddableInsertInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as GenEmbeddableInsertInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
