import {sendMessage} from "@/utils/message"
import type {GenEmbeddableUpdateInput} from "@/api/__generated/model/static"

export type GenEmbeddableEditData = {
    id: number
    groupId?: number | undefined
    name: string
    subPackagePath: string
    comment: string
}

const getUnmatchedMessageList = (data: GenEmbeddableEditData): Array<string> => {
    const messageList: Array<string> = []

    if (data.groupId === undefined) {
        messageList.push("分组不可为空")
    }

    return messageList
}

export const validateGenEmbeddableEditDataForSubmit = (data: GenEmbeddableEditData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertGenEmbeddableEditDataAsSubmitType = (data: GenEmbeddableEditData): GenEmbeddableUpdateInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as GenEmbeddableUpdateInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
