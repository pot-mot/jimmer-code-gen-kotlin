<script setup lang="ts">
import {ref} from "vue"
import type {FormInstance} from "element-plus"
import type {FormExpose} from "@/components/form/FormExpose"
import type {
    GenDeepEmbeddablePropertyOverrideUpdateInput,
    GenEmbeddableTypeDeepPropertyOptionView,
    GenEmbeddableTypePropertyOptionView
} from "@/api/__generated/model/static"
import {
    validateGenDeepEmbeddablePropertyOverrideEditDataForSubmit,
    assertGenDeepEmbeddablePropertyOverrideEditDataAsSubmitType
} from "@/components/model/embeddables/genDeepEmbeddablePropertyOverride/GenDeepEmbeddablePropertyOverrideEditData"
import type {
    GenDeepEmbeddablePropertyOverrideEditData
} from "@/components/model/embeddables/genDeepEmbeddablePropertyOverride/GenDeepEmbeddablePropertyOverrideEditData"
import {useRules} from "@/rules/model/embeddables/genDeepEmbeddablePropertyOverride/GenDeepEmbeddablePropertyOverrideEditFormRules"
import GenEmbeddableTypeDeepPropertyIdSelect from "@/components/model/embeddables/genEmbeddableTypeDeepProperty/GenEmbeddableTypeDeepPropertyIdSelect.vue"
import GenEmbeddableTypePropertyIdSelect from "@/components/model/embeddables/genEmbeddableTypeProperty/GenEmbeddableTypePropertyIdSelect.vue"
import type {LazyOptions} from "@/utils/lazyOptions"

const formData = defineModel<GenDeepEmbeddablePropertyOverrideEditData>({
    required: true
})

const props = withDefaults(defineProps<{
    withOperations?: boolean | undefined,
    submitLoading?: boolean | undefined,
    deepPropertyIdOptions: LazyOptions<GenEmbeddableTypeDeepPropertyOptionView>,
    overridePropertyIdOptions: LazyOptions<GenEmbeddableTypePropertyOptionView>
}>(), {
    withOperations: true,
    submitLoading: false,
})

const emits = defineEmits<{
    (
        event: "submit",
        formData: GenDeepEmbeddablePropertyOverrideUpdateInput
    ): void,
    (event: "cancel"): void
}>()

defineSlots<{
    operations(props: {
        handleSubmit: () => Promise<void>,
        handleCancel: () => void
    }): any
}>()

const formRef = ref<FormInstance>()
const rules = useRules(formData)

// 校验
const handleValidate = async (
    errorHandler: (errors: any[]) => void = (errors) => {console.error(errors)}
): Promise<boolean> => {
    const errors: any[] = []
    const formValid: boolean = await formRef.value?.validate().catch(e => {
        errors.push(e)
        return false
    }) ?? false

    const typeValidate: boolean = validateGenDeepEmbeddablePropertyOverrideEditDataForSubmit(formData.value)

    errorHandler?.(errors)
    return formValid && typeValidate
}

// 提交
const handleSubmit = async (): Promise<void> => {
    if (props.submitLoading) return

    const validResult = await handleValidate()
    if (validResult) {
        emits("submit", assertGenDeepEmbeddablePropertyOverrideEditDataAsSubmitType(formData.value))
    }
}

// 取消
const handleCancel = (): void => {
    emits("cancel")
}

defineExpose<FormExpose>({
    validate: handleValidate
})
</script>

<template>
    <el-form
        :model="formData"
        ref="formRef"
        :rules="rules"
        label-width="auto"
        @submit.prevent
        class="edit-form"
    >
        <el-form-item prop="deepPropertyId" label="深层属性">
            <GenEmbeddableTypeDeepPropertyIdSelect
                v-model="formData.deepPropertyId"
                :options="deepPropertyIdOptions"
            />
        </el-form-item>
        <el-form-item prop="overridePropertyId" label="覆盖属性">
            <GenEmbeddableTypePropertyIdSelect
                v-model="formData.overridePropertyId"
                :options="overridePropertyIdOptions"
            />
        </el-form-item>
        <el-form-item prop="columnName" label="覆盖后列名">
            <el-input
                v-model="formData.columnName"
                placeholder="请输入覆盖后列名"
                clearable
            />
        </el-form-item>

        <slot
            v-if="withOperations"
            name="operations"
            :handleSubmit="handleSubmit"
            :handleCancel="handleCancel"
        >
            <div class="form-operations">
                <el-button type="warning" @click="handleCancel">
                    取消
                </el-button>
                <el-button
                    type="primary"
                    :loading="submitLoading"
                    @click="handleSubmit"
                >
                    提交
                </el-button>
            </div>
        </slot>
    </el-form>
</template>
