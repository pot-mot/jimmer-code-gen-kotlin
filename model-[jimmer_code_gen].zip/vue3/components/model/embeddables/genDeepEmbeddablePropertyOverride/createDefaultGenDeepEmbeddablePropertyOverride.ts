import type {GenDeepEmbeddablePropertyOverrideAddData} from "./GenDeepEmbeddablePropertyOverrideAddData"

export const createDefaultGenDeepEmbeddablePropertyOverride = (): GenDeepEmbeddablePropertyOverrideAddData => {
    return {
        deepPropertyId: undefined,
        overridePropertyId: undefined,
        columnName: ""
    }
}
