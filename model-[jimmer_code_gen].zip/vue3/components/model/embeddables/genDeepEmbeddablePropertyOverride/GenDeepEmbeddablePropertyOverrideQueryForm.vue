<script setup lang="ts">
import {Search} from "@element-plus/icons-vue"
import type {
    GenDeepEmbeddablePropertyOverrideSpec,
    GenEmbeddableTypeDeepPropertyOptionView,
    GenEmbeddableTypePropertyOptionView
} from "@/api/__generated/model/static"
import GenEmbeddableTypeDeepPropertyIdSelect from "@/components/model/embeddables/genEmbeddableTypeDeepProperty/GenEmbeddableTypeDeepPropertyIdSelect.vue"
import GenEmbeddableTypePropertyIdSelect from "@/components/model/embeddables/genEmbeddableTypeProperty/GenEmbeddableTypePropertyIdSelect.vue"
import type {LazyOptions} from "@/utils/lazyOptions"

const spec = defineModel<GenDeepEmbeddablePropertyOverrideSpec>({
    required: true
})

defineProps<{
    deepPropertyIdOptions: LazyOptions<GenEmbeddableTypeDeepPropertyOptionView>,
    overridePropertyIdOptions: LazyOptions<GenEmbeddableTypePropertyOptionView>
}>()

const emits = defineEmits<{
    (
        event: "query",
        spec: GenDeepEmbeddablePropertyOverrideSpec
    ): void
}>()
</script>

<template>
    <el-form
        :model="spec"
        label-width="auto"
        @submit.prevent
        class="query-form"
    >
        <el-row :gutter="20">
            <el-col :span="8" :xs="24">
                <el-form-item prop="deepPropertyId" label="深层属性">
                    <GenEmbeddableTypeDeepPropertyIdSelect
                        v-model="spec.deepPropertyId"
                        :options="deepPropertyIdOptions"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="overridePropertyId" label="覆盖属性">
                    <GenEmbeddableTypePropertyIdSelect
                        v-model="spec.overridePropertyId"
                        :options="overridePropertyIdOptions"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="columnName" label="覆盖后列名">
                    <el-input
                        v-model="spec.columnName"
                        placeholder="请输入覆盖后列名"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-button
                type="primary"
                :icon="Search"
                class="search-button"
                @click="emits('query', spec)"
            >
                查询
            </el-button>
        </el-row>
    </el-form>
</template>
