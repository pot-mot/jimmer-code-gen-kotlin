import {sendMessage} from "@/utils/message"
import type {
    GenDeepEmbeddablePropertyOverrideUpdateInput
} from "@/api/__generated/model/static"

export type GenDeepEmbeddablePropertyOverrideEditData = {
    id: number
    deepPropertyId?: number | undefined
    overridePropertyId?: number | undefined
    columnName: string
}

const getUnmatchedMessageList = (data: GenDeepEmbeddablePropertyOverrideEditData): Array<string> => {
    const messageList: Array<string> = []

    if (data.deepPropertyId === undefined) {
        messageList.push("深层属性不可为空")
    }
    if (data.overridePropertyId === undefined) {
        messageList.push("覆盖属性不可为空")
    }

    return messageList
}

export const validateGenDeepEmbeddablePropertyOverrideEditDataForSubmit = (data: GenDeepEmbeddablePropertyOverrideEditData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertGenDeepEmbeddablePropertyOverrideEditDataAsSubmitType = (data: GenDeepEmbeddablePropertyOverrideEditData): GenDeepEmbeddablePropertyOverrideUpdateInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as GenDeepEmbeddablePropertyOverrideUpdateInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
