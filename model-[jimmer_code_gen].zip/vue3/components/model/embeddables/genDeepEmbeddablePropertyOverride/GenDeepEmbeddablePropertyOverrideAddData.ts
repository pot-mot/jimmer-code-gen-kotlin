import {sendMessage} from "@/utils/message"
import type {
    GenDeepEmbeddablePropertyOverrideInsertInput
} from "@/api/__generated/model/static"

export type GenDeepEmbeddablePropertyOverrideAddData = {
    deepPropertyId?: number | undefined
    overridePropertyId?: number | undefined
    columnName: string
}

const getUnmatchedMessageList = (data: GenDeepEmbeddablePropertyOverrideAddData): Array<string> => {
    const messageList: Array<string> = []

    if (data.deepPropertyId === undefined) {
        messageList.push("深层属性不可为空")
    }
    if (data.overridePropertyId === undefined) {
        messageList.push("覆盖属性不可为空")
    }

    return messageList
}

export const validateGenDeepEmbeddablePropertyOverrideAddDataForSubmit = (data: GenDeepEmbeddablePropertyOverrideAddData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertGenDeepEmbeddablePropertyOverrideAddDataAsSubmitType = (data: GenDeepEmbeddablePropertyOverrideAddData): GenDeepEmbeddablePropertyOverrideInsertInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as GenDeepEmbeddablePropertyOverrideInsertInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
