import {sendMessage} from "@/utils/message"
import type {GenEmbeddableTypeInsertInput} from "@/api/__generated/model/static"

export type GenEmbeddableTypeAddData = {
    groupId?: number | undefined
    name: string
    subPackagePath: string
    comment: string
}

const getUnmatchedMessageList = (data: GenEmbeddableTypeAddData): Array<string> => {
    const messageList: Array<string> = []

    if (data.groupId === undefined) {
        messageList.push("分组不可为空")
    }

    return messageList
}

export const validateGenEmbeddableTypeAddDataForSubmit = (data: GenEmbeddableTypeAddData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertGenEmbeddableTypeAddDataAsSubmitType = (data: GenEmbeddableTypeAddData): GenEmbeddableTypeInsertInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as GenEmbeddableTypeInsertInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
