import type {GenEmbeddableTypeAddData} from "./GenEmbeddableTypeAddData"

export const createDefaultGenEmbeddableType = (): GenEmbeddableTypeAddData => {
    return {
        groupId: undefined,
        name: "",
        subPackagePath: "",
        comment: ""
    }
}
