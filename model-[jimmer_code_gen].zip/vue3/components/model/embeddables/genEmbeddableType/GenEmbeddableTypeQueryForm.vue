<script setup lang="ts">
import {Search} from "@element-plus/icons-vue"
import type {
    GenEmbeddableTypeSpec,
    GenModelGroupOptionView
} from "@/api/__generated/model/static"
import GenModelGroupIdSelect from "@/components/model/genModelGroup/GenModelGroupIdSelect.vue"
import type {LazyOptions} from "@/utils/lazyOptions"

const spec = defineModel<GenEmbeddableTypeSpec>({
    required: true
})

defineProps<{
    groupIdOptions: LazyOptions<GenModelGroupOptionView>
}>()

const emits = defineEmits<{
    (
        event: "query",
        spec: GenEmbeddableTypeSpec
    ): void
}>()
</script>

<template>
    <el-form
        :model="spec"
        label-width="auto"
        @submit.prevent
        class="query-form"
    >
        <el-row :gutter="20">
            <el-col :span="8" :xs="24">
                <el-form-item prop="groupId" label="分组">
                    <GenModelGroupIdSelect
                        v-model="spec.groupId"
                        :options="groupIdOptions"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="name" label="名称">
                    <el-input
                        v-model="spec.name"
                        placeholder="请输入名称"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="subPackagePath" label="子包路径">
                    <el-input
                        v-model="spec.subPackagePath"
                        placeholder="请输入子包路径"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="comment" label="注释">
                    <el-input
                        v-model="spec.comment"
                        placeholder="请输入注释"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-button
                type="primary"
                :icon="Search"
                class="search-button"
                @click="emits('query', spec)"
            >
                查询
            </el-button>
        </el-row>
    </el-form>
</template>
