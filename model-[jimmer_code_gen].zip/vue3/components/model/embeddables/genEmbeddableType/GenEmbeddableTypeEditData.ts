import {sendMessage} from "@/utils/message"
import type {GenEmbeddableTypeUpdateInput} from "@/api/__generated/model/static"

export type GenEmbeddableTypeEditData = {
    id: number
    groupId?: number | undefined
    name: string
    subPackagePath: string
    comment: string
}

const getUnmatchedMessageList = (data: GenEmbeddableTypeEditData): Array<string> => {
    const messageList: Array<string> = []

    if (data.groupId === undefined) {
        messageList.push("分组不可为空")
    }

    return messageList
}

export const validateGenEmbeddableTypeEditDataForSubmit = (data: GenEmbeddableTypeEditData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertGenEmbeddableTypeEditDataAsSubmitType = (data: GenEmbeddableTypeEditData): GenEmbeddableTypeUpdateInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as GenEmbeddableTypeUpdateInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
