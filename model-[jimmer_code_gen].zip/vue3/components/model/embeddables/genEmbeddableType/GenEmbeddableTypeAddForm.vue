<script setup lang="ts">
import {ref} from "vue"
import type {FormInstance} from "element-plus"
import type {FormExpose} from "@/components/form/FormExpose"
import type {
    GenEmbeddableTypeInsertInput,
    GenModelGroupOptionView
} from "@/api/__generated/model/static"
import {
    validateGenEmbeddableTypeAddDataForSubmit,
    assertGenEmbeddableTypeAddDataAsSubmitType
} from "@/components/model/embeddables/genEmbeddableType/GenEmbeddableTypeAddData"
import type {GenEmbeddableTypeAddData} from "@/components/model/embeddables/genEmbeddableType/GenEmbeddableTypeAddData"
import {createDefaultGenEmbeddableType} from "@/components/model/embeddables/genEmbeddableType/createDefaultGenEmbeddableType"
import {useRules} from "@/rules/model/embeddables/genEmbeddableType/GenEmbeddableTypeAddFormRules"
import GenModelGroupIdSelect from "@/components/model/genModelGroup/GenModelGroupIdSelect.vue"
import type {LazyOptions} from "@/utils/lazyOptions"

const props = withDefaults(defineProps<{
    withOperations?: boolean | undefined,
    submitLoading?: boolean | undefined,
    groupIdOptions: LazyOptions<GenModelGroupOptionView>
}>(), {
    withOperations: true,
    submitLoading: false,
})

const emits = defineEmits<{
    (
        event: "submit",
        formData: GenEmbeddableTypeInsertInput
    ): void,
    (event: "cancel"): void
}>()

defineSlots<{
    operations(props: {
        handleSubmit: () => Promise<void>,
        handleCancel: () => void
    }): any
}>()

const formData = ref<GenEmbeddableTypeAddData>(createDefaultGenEmbeddableType())

const formRef = ref<FormInstance>()
const rules = useRules(formData)

// 校验
const handleValidate = async (
    errorHandler: (errors: any[]) => void = (errors) => {console.error(errors)}
): Promise<boolean> => {
    const errors: any[] = []
    const formValid: boolean = await formRef.value?.validate().catch(e => {
        errors.push(e)
        return false
    }) ?? false

    const typeValidate: boolean = validateGenEmbeddableTypeAddDataForSubmit(formData.value)

    errorHandler?.(errors)
    return formValid && typeValidate
}

// 提交
const handleSubmit = async (): Promise<void> => {
    if (props.submitLoading) return

    const validResult = await handleValidate()
    if (validResult) {
        emits("submit", assertGenEmbeddableTypeAddDataAsSubmitType(formData.value))
    }
}

// 取消
const handleCancel = (): void => {
    emits("cancel")
}

defineExpose<FormExpose>({
    validate: handleValidate
})
</script>

<template>
    <el-form
        :model="formData"
        ref="formRef"
        :rules="rules"
        label-width="auto"
        @submit.prevent
        class="add-form"
    >
        <el-form-item prop="groupId" label="分组">
            <GenModelGroupIdSelect
                v-model="formData.groupId"
                :options="groupIdOptions"
            />
        </el-form-item>
        <el-form-item prop="name" label="名称">
            <el-input
                v-model="formData.name"
                placeholder="请输入名称"
                clearable
            />
        </el-form-item>
        <el-form-item prop="subPackagePath" label="子包路径">
            <el-input
                v-model="formData.subPackagePath"
                placeholder="请输入子包路径"
                clearable
            />
        </el-form-item>
        <el-form-item prop="comment" label="注释">
            <el-input
                v-model="formData.comment"
                placeholder="请输入注释"
                clearable
            />
        </el-form-item>

        <slot
            v-if="withOperations"
            name="operations"
            :handleSubmit="handleSubmit"
            :handleCancel="handleCancel"
        >
            <div class="form-operations">
                <el-button type="warning" @click="handleCancel">
                    取消
                </el-button>
                <el-button
                    type="primary"
                    :loading="submitLoading"
                    @click="handleSubmit"
                >
                    提交
                </el-button>
            </div>
        </slot>
    </el-form>
</template>
