import {sendMessage} from "@/utils/message"
import type {GenEmbeddableTypeDeepPropertyInsertInput} from "@/api/__generated/model/static"

export type GenEmbeddableTypeDeepPropertyAddData = {
    embeddableId?: number | undefined
    name: string
    comment: string
    typeEmbeddableId?: number | undefined
    overrideColumnNames: string
    extraAnnotations?: string | undefined
    extraImports?: string | undefined
    extraValidations?: string | undefined
    remark: string
    orderKey: number
}

const getUnmatchedMessageList = (data: GenEmbeddableTypeDeepPropertyAddData): Array<string> => {
    const messageList: Array<string> = []

    if (data.embeddableId === undefined) {
        messageList.push("嵌入类型不可为空")
    }
    if (data.typeEmbeddableId === undefined) {
        messageList.push("类型对应嵌入类型不可为空")
    }

    return messageList
}

export const validateGenEmbeddableTypeDeepPropertyAddDataForSubmit = (data: GenEmbeddableTypeDeepPropertyAddData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertGenEmbeddableTypeDeepPropertyAddDataAsSubmitType = (data: GenEmbeddableTypeDeepPropertyAddData): GenEmbeddableTypeDeepPropertyInsertInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as GenEmbeddableTypeDeepPropertyInsertInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
