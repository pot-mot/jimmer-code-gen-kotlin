import {sendMessage} from "@/utils/message"
import type {GenEmbeddableTypeDeepPropertyUpdateInput} from "@/api/__generated/model/static"

export type GenEmbeddableTypeDeepPropertyEditData = {
    id: number
    embeddableId?: number | undefined
    name: string
    comment: string
    typeEmbeddableId?: number | undefined
    extraAnnotations?: string | undefined
    extraImports?: string | undefined
    extraValidations?: string | undefined
    remark: string
    orderKey: number
}

const getUnmatchedMessageList = (data: GenEmbeddableTypeDeepPropertyEditData): Array<string> => {
    const messageList: Array<string> = []

    if (data.embeddableId === undefined) {
        messageList.push("嵌入类型不可为空")
    }
    if (data.typeEmbeddableId === undefined) {
        messageList.push("类型对应嵌入类型不可为空")
    }

    return messageList
}

export const validateGenEmbeddableTypeDeepPropertyEditDataForSubmit = (data: GenEmbeddableTypeDeepPropertyEditData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertGenEmbeddableTypeDeepPropertyEditDataAsSubmitType = (data: GenEmbeddableTypeDeepPropertyEditData): GenEmbeddableTypeDeepPropertyUpdateInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as GenEmbeddableTypeDeepPropertyUpdateInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
