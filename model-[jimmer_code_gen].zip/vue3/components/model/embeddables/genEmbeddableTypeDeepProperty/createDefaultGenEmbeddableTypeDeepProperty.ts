import type {GenEmbeddableTypeDeepPropertyAddData} from "./GenEmbeddableTypeDeepPropertyAddData"

export const createDefaultGenEmbeddableTypeDeepProperty = (): GenEmbeddableTypeDeepPropertyAddData => {
    return {
        embeddableId: undefined,
        name: "",
        comment: "",
        typeEmbeddableId: undefined,
        overrideColumnNames: "",
        extraAnnotations: undefined,
        extraImports: undefined,
        extraValidations: undefined,
        remark: "",
        orderKey: 0
    }
}
