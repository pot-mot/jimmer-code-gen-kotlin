<script setup lang="ts">
import {ref} from "vue"
import type {FormInstance} from "element-plus"
import type {FormExpose} from "@/components/form/FormExpose"
import type {
    GenEmbeddableTypeDeepPropertyInsertInput,
    GenEmbeddableTypeOptionView
} from "@/api/__generated/model/static"
import {
    validateGenEmbeddableTypeDeepPropertyAddDataForSubmit,
    assertGenEmbeddableTypeDeepPropertyAddDataAsSubmitType
} from "@/components/model/embeddables/genEmbeddableTypeDeepProperty/GenEmbeddableTypeDeepPropertyAddData"
import type {GenEmbeddableTypeDeepPropertyAddData} from "@/components/model/embeddables/genEmbeddableTypeDeepProperty/GenEmbeddableTypeDeepPropertyAddData"
import {
    createDefaultGenEmbeddableTypeDeepProperty
} from "@/components/model/embeddables/genEmbeddableTypeDeepProperty/createDefaultGenEmbeddableTypeDeepProperty"
import {useRules} from "@/rules/model/embeddables/genEmbeddableTypeDeepProperty/GenEmbeddableTypeDeepPropertyAddFormRules"
import GenEmbeddableTypeIdSelect from "@/components/model/embeddables/genEmbeddableType/GenEmbeddableTypeIdSelect.vue"
import type {LazyOptions} from "@/utils/lazyOptions"

const props = withDefaults(defineProps<{
    withOperations?: boolean | undefined,
    submitLoading?: boolean | undefined,
    embeddableIdOptions: LazyOptions<GenEmbeddableTypeOptionView>,
    typeEmbeddableIdOptions: LazyOptions<GenEmbeddableTypeOptionView>
}>(), {
    withOperations: true,
    submitLoading: false,
})

const emits = defineEmits<{
    (
        event: "submit",
        formData: GenEmbeddableTypeDeepPropertyInsertInput
    ): void,
    (event: "cancel"): void
}>()

defineSlots<{
    operations(props: {
        handleSubmit: () => Promise<void>,
        handleCancel: () => void
    }): any
}>()

const formData = ref<GenEmbeddableTypeDeepPropertyAddData>(createDefaultGenEmbeddableTypeDeepProperty())

const formRef = ref<FormInstance>()
const rules = useRules(formData)

// 校验
const handleValidate = async (
    errorHandler: (errors: any[]) => void = (errors) => {console.error(errors)}
): Promise<boolean> => {
    const errors: any[] = []
    const formValid: boolean = await formRef.value?.validate().catch(e => {
        errors.push(e)
        return false
    }) ?? false

    const typeValidate: boolean = validateGenEmbeddableTypeDeepPropertyAddDataForSubmit(formData.value)

    errorHandler?.(errors)
    return formValid && typeValidate
}

// 提交
const handleSubmit = async (): Promise<void> => {
    if (props.submitLoading) return

    const validResult = await handleValidate()
    if (validResult) {
        emits("submit", assertGenEmbeddableTypeDeepPropertyAddDataAsSubmitType(formData.value))
    }
}

// 取消
const handleCancel = (): void => {
    emits("cancel")
}

defineExpose<FormExpose>({
    validate: handleValidate
})
</script>

<template>
    <el-form
        :model="formData"
        ref="formRef"
        :rules="rules"
        label-width="auto"
        @submit.prevent
        class="add-form"
    >
        <el-form-item prop="embeddableId" label="嵌入类型">
            <GenEmbeddableTypeIdSelect
                v-model="formData.embeddableId"
                :options="embeddableIdOptions"
            />
        </el-form-item>
        <el-form-item prop="name" label="名称">
            <el-input
                v-model="formData.name"
                placeholder="请输入名称"
                clearable
            />
        </el-form-item>
        <el-form-item prop="comment" label="注释">
            <el-input
                v-model="formData.comment"
                placeholder="请输入注释"
                clearable
            />
        </el-form-item>
        <el-form-item prop="typeEmbeddableId" label="类型对应嵌入类型">
            <GenEmbeddableTypeIdSelect
                v-model="formData.typeEmbeddableId"
                :options="typeEmbeddableIdOptions"
            />
        </el-form-item>
        <el-form-item prop="overrideColumnNames" label="覆盖列名">
            <el-input
                v-model="formData.overrideColumnNames"
                placeholder="请输入覆盖列名"
                clearable
            />
        </el-form-item>
        <el-form-item prop="extraAnnotations" label="其他注解">
            <el-input
                v-model="formData.extraAnnotations"
                placeholder="请输入其他注解"
                clearable
            />
        </el-form-item>
        <el-form-item prop="extraImports" label="其他导入">
            <el-input
                v-model="formData.extraImports"
                placeholder="请输入其他导入"
                clearable
            />
        </el-form-item>
        <el-form-item prop="extraValidations" label="其他验证器">
            <el-input
                v-model="formData.extraValidations"
                placeholder="请输入其他验证器"
                clearable
            />
        </el-form-item>
        <el-form-item prop="remark" label="备注">
            <el-input
                v-model="formData.remark"
                placeholder="请输入备注"
                clearable
            />
        </el-form-item>
        <el-form-item prop="orderKey" label="排序键">
            <el-input-number
                v-model.number="formData.orderKey"
                placeholder="请输入排序键"
                :precision="0"
                :max="2147483647"
            />
        </el-form-item>

        <slot
            v-if="withOperations"
            name="operations"
            :handleSubmit="handleSubmit"
            :handleCancel="handleCancel"
        >
            <div class="form-operations">
                <el-button type="warning" @click="handleCancel">
                    取消
                </el-button>
                <el-button
                    type="primary"
                    :loading="submitLoading"
                    @click="handleSubmit"
                >
                    提交
                </el-button>
            </div>
        </slot>
    </el-form>
</template>
