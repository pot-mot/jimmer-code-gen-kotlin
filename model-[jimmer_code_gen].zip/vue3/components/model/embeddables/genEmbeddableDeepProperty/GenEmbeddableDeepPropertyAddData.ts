import {sendMessage} from "@/utils/message"
import type {GenEmbeddableDeepPropertyInsertInput} from "@/api/__generated/model/static"

export type GenEmbeddableDeepPropertyAddData = {
    embeddableId?: number | undefined
    name: string
    comment: string
    typeEmbeddableId?: number | undefined
    extraAnnotations?: string | undefined
    extraImports?: string | undefined
    extraValidations?: string | undefined
    remark: string
}

const getUnmatchedMessageList = (data: GenEmbeddableDeepPropertyAddData): Array<string> => {
    const messageList: Array<string> = []

    if (data.embeddableId === undefined) {
        messageList.push("嵌入类型不可为空")
    }
    if (data.typeEmbeddableId === undefined) {
        messageList.push("类型对应嵌入类型不可为空")
    }

    return messageList
}

export const validateGenEmbeddableDeepPropertyAddDataForSubmit = (data: GenEmbeddableDeepPropertyAddData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertGenEmbeddableDeepPropertyAddDataAsSubmitType = (data: GenEmbeddableDeepPropertyAddData): GenEmbeddableDeepPropertyInsertInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as GenEmbeddableDeepPropertyInsertInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
