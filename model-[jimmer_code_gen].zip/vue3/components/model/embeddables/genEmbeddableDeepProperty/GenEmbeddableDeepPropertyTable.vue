<script setup lang="ts">
import type {GenEmbeddableDeepPropertyListView} from "@/api/__generated/model/static"
import {usePageSizeStore} from "@/stores/pageSizeStore"

withDefaults(defineProps<{
    rows: Array<GenEmbeddableDeepPropertyListView>,
    idColumn?: boolean | undefined,
    indexColumn?: boolean | undefined,
    multiSelect?: boolean | undefined,
    withOperations?: boolean | undefined
}>(), {
    idColumn: false,
    indexColumn: true,
    multiSelect: true,
    withOperations: true,
})

const emits = defineEmits<{
    (
        event: "selectionChange",
        selection: Array<GenEmbeddableDeepPropertyListView>
    ): void
}>()

defineSlots<{
    operations(props: {
        row: GenEmbeddableDeepPropertyListView,
        index: number
    }): any
}>()

const pageSizeStore = usePageSizeStore()

const handleSelectionChange = (
    newSelection: Array<GenEmbeddableDeepPropertyListView>
): void => {
    emits("selectionChange", newSelection)
}
</script>

<template>
    <el-table
        :data="rows"
        row-key="id"
        border
        stripe
        class="view-table"
        @selection-change="handleSelectionChange"
    >
        <el-table-column
            v-if="idColumn"
            prop="id"
            label="ID"
            :fixed="pageSizeStore.isSmall ? undefined : 'left'"
        />
        <el-table-column
            v-if="indexColumn"
            type="index"
            :fixed="pageSizeStore.isSmall ? undefined : 'left'"
        />
        <el-table-column
            v-if="multiSelect"
            type="selection"
            :width="43"
            :fixed="pageSizeStore.isSmall ? undefined : 'left'"
        />
        <el-table-column
            prop="embeddableId"
            label="嵌入类型"
            :min-width="161"
        />
        <el-table-column prop="name" label="名称" :min-width="129"/>
        <el-table-column
            prop="comment"
            label="注释"
            :min-width="129"
        />
        <el-table-column
            prop="typeEmbeddableId"
            label="类型对应嵌入类型"
            :min-width="161"
        />
        <el-table-column
            prop="extraAnnotations"
            label="其他注解"
            :min-width="129"
        />
        <el-table-column
            prop="extraImports"
            label="其他导入"
            :min-width="129"
        />
        <el-table-column
            prop="extraValidations"
            label="其他验证器"
            :min-width="129"
        />
        <el-table-column
            prop="remark"
            label="备注"
            :min-width="129"
        />
        <el-table-column
            v-if="withOperations"
            label="操作"
            :fixed="pageSizeStore.isSmall ? undefined : 'right'"
        >
            <template #default="scope">
                <slot
                    name="operations"
                    :row="scope.row as GenEmbeddableDeepPropertyListView"
                    :index="scope.$index"
                />
            </template>
        </el-table-column>
    </el-table>
</template>
