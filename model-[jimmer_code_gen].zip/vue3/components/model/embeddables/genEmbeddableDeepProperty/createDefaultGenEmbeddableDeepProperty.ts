import type {GenEmbeddableDeepPropertyAddData} from "./GenEmbeddableDeepPropertyAddData"

export const createDefaultGenEmbeddableDeepProperty = (): GenEmbeddableDeepPropertyAddData => {
    return {
        embeddableId: undefined,
        name: "",
        comment: "",
        typeEmbeddableId: undefined,
        extraAnnotations: undefined,
        extraImports: undefined,
        extraValidations: undefined,
        remark: ""
    }
}
