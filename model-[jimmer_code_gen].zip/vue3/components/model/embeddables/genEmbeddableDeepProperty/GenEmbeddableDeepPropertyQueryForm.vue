<script setup lang="ts">
import {Search} from "@element-plus/icons-vue"
import type {
    GenEmbeddableDeepPropertySpec,
    GenEmbeddableOptionView
} from "@/api/__generated/model/static"
import GenEmbeddableIdSelect from "@/components/model/embeddables/genEmbeddable/GenEmbeddableIdSelect.vue"
import type {LazyOptions} from "@/utils/lazyOptions"

const spec = defineModel<GenEmbeddableDeepPropertySpec>({
    required: true
})

defineProps<{
    embeddableIdOptions: LazyOptions<GenEmbeddableOptionView>,
    typeEmbeddableIdOptions: LazyOptions<GenEmbeddableOptionView>
}>()

const emits = defineEmits<{
    (
        event: "query",
        spec: GenEmbeddableDeepPropertySpec
    ): void
}>()
</script>

<template>
    <el-form
        :model="spec"
        label-width="auto"
        @submit.prevent
        class="query-form"
    >
        <el-row :gutter="20">
            <el-col :span="8" :xs="24">
                <el-form-item prop="embeddableId" label="嵌入类型">
                    <GenEmbeddableIdSelect
                        v-model="spec.embeddableId"
                        :options="embeddableIdOptions"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="name" label="名称">
                    <el-input
                        v-model="spec.name"
                        placeholder="请输入名称"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="comment" label="注释">
                    <el-input
                        v-model="spec.comment"
                        placeholder="请输入注释"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="typeEmbeddableId" label="类型对应嵌入类型">
                    <GenEmbeddableIdSelect
                        v-model="spec.typeEmbeddableId"
                        :options="typeEmbeddableIdOptions"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="extraAnnotations" label="其他注解">
                    <el-input
                        v-model="spec.extraAnnotations"
                        placeholder="请输入其他注解"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="extraImports" label="其他导入">
                    <el-input
                        v-model="spec.extraImports"
                        placeholder="请输入其他导入"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="extraValidations" label="其他验证器">
                    <el-input
                        v-model="spec.extraValidations"
                        placeholder="请输入其他验证器"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="remark" label="备注">
                    <el-input
                        v-model="spec.remark"
                        placeholder="请输入备注"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-button
                type="primary"
                :icon="Search"
                class="search-button"
                @click="emits('query', spec)"
            >
                查询
            </el-button>
        </el-row>
    </el-form>
</template>
