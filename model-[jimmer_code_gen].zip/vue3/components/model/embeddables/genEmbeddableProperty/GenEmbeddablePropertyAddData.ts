import {sendMessage} from "@/utils/message"
import type {GenEmbeddablePropertyInsertInput} from "@/api/__generated/model/static"

export type GenEmbeddablePropertyAddData = {
    jdbcTypeCode: number
    rawType: string
    typeIsNotNull: boolean
    dataSize?: number | undefined
    numericPrecision?: number | undefined
    columnDefaultExp?: string | undefined
    embeddableId?: number | undefined
    name: string
    comment: string
    type: string
    extraAnnotations?: string | undefined
    extraImports?: string | undefined
    extraValidations?: string | undefined
    remark: string
}

const getUnmatchedMessageList = (data: GenEmbeddablePropertyAddData): Array<string> => {
    const messageList: Array<string> = []

    if (data.embeddableId === undefined) {
        messageList.push("嵌入类型不可为空")
    }

    return messageList
}

export const validateGenEmbeddablePropertyAddDataForSubmit = (data: GenEmbeddablePropertyAddData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertGenEmbeddablePropertyAddDataAsSubmitType = (data: GenEmbeddablePropertyAddData): GenEmbeddablePropertyInsertInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as GenEmbeddablePropertyInsertInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
