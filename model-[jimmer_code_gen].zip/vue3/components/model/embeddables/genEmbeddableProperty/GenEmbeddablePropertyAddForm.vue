<script setup lang="ts">
import {ref} from "vue"
import type {FormInstance} from "element-plus"
import type {FormExpose} from "@/components/form/FormExpose"
import type {
    GenEmbeddablePropertyInsertInput,
    GenEmbeddableOptionView
} from "@/api/__generated/model/static"
import {
    validateGenEmbeddablePropertyAddDataForSubmit,
    assertGenEmbeddablePropertyAddDataAsSubmitType
} from "@/components/model/embeddables/genEmbeddableProperty/GenEmbeddablePropertyAddData"
import type {GenEmbeddablePropertyAddData} from "@/components/model/embeddables/genEmbeddableProperty/GenEmbeddablePropertyAddData"
import {createDefaultGenEmbeddableProperty} from "@/components/model/embeddables/genEmbeddableProperty/createDefaultGenEmbeddableProperty"
import {useRules} from "@/rules/model/embeddables/genEmbeddableProperty/GenEmbeddablePropertyAddFormRules"
import GenEmbeddableIdSelect from "@/components/model/embeddables/genEmbeddable/GenEmbeddableIdSelect.vue"
import type {LazyOptions} from "@/utils/lazyOptions"

const props = withDefaults(defineProps<{
    withOperations?: boolean | undefined,
    submitLoading?: boolean | undefined,
    embeddableIdOptions: LazyOptions<GenEmbeddableOptionView>
}>(), {
    withOperations: true,
    submitLoading: false,
})

const emits = defineEmits<{
    (
        event: "submit",
        formData: GenEmbeddablePropertyInsertInput
    ): void,
    (event: "cancel"): void
}>()

defineSlots<{
    operations(props: {
        handleSubmit: () => Promise<void>,
        handleCancel: () => void
    }): any
}>()

const formData = ref<GenEmbeddablePropertyAddData>(createDefaultGenEmbeddableProperty())

const formRef = ref<FormInstance>()
const rules = useRules(formData)

// 校验
const handleValidate = async (
    errorHandler: (errors: any[]) => void = (errors) => {console.error(errors)}
): Promise<boolean> => {
    const errors: any[] = []
    const formValid: boolean = await formRef.value?.validate().catch(e => {
        errors.push(e)
        return false
    }) ?? false

    const typeValidate: boolean = validateGenEmbeddablePropertyAddDataForSubmit(formData.value)

    errorHandler?.(errors)
    return formValid && typeValidate
}

// 提交
const handleSubmit = async (): Promise<void> => {
    if (props.submitLoading) return

    const validResult = await handleValidate()
    if (validResult) {
        emits("submit", assertGenEmbeddablePropertyAddDataAsSubmitType(formData.value))
    }
}

// 取消
const handleCancel = (): void => {
    emits("cancel")
}

defineExpose<FormExpose>({
    validate: handleValidate
})
</script>

<template>
    <el-form
        :model="formData"
        ref="formRef"
        :rules="rules"
        label-width="auto"
        @submit.prevent
        class="add-form"
    >
        <el-form-item prop="jdbcTypeCode" label="JdbcType 码值">
            <el-input-number
                v-model.number="formData.jdbcTypeCode"
                placeholder="请输入JdbcType 码值"
                :precision="0"
                :min="0"
                :max="2147483647"
                :value-on-clear="'min'"
            />
        </el-form-item>
        <el-form-item prop="rawType" label="字面类型">
            <el-input
                v-model="formData.rawType"
                placeholder="请输入字面类型"
                clearable
            />
        </el-form-item>
        <el-form-item prop="typeIsNotNull" label="类型是否非空">
            <el-switch v-model="formData.typeIsNotNull"/>
        </el-form-item>
        <el-form-item prop="dataSize" label="长度">
            <el-input-number
                v-model.number="formData.dataSize"
                placeholder="请输入长度"
                :precision="0"
                :max="2147483647"
                :value-on-clear="undefined"
            />
        </el-form-item>
        <el-form-item prop="numericPrecision" label="精度">
            <el-input-number
                v-model.number="formData.numericPrecision"
                placeholder="请输入精度"
                :precision="0"
                :max="2147483647"
                :value-on-clear="undefined"
            />
        </el-form-item>
        <el-form-item prop="columnDefaultExp" label="列默认表达式">
            <el-input
                v-model="formData.columnDefaultExp"
                placeholder="请输入列默认表达式"
                clearable
            />
        </el-form-item>
        <el-form-item prop="embeddableId" label="嵌入类型">
            <GenEmbeddableIdSelect
                v-model="formData.embeddableId"
                :options="embeddableIdOptions"
            />
        </el-form-item>
        <el-form-item prop="name" label="名称">
            <el-input
                v-model="formData.name"
                placeholder="请输入名称"
                clearable
            />
        </el-form-item>
        <el-form-item prop="comment" label="注释">
            <el-input
                v-model="formData.comment"
                placeholder="请输入注释"
                clearable
            />
        </el-form-item>
        <el-form-item prop="type" label="类型">
            <el-input
                v-model="formData.type"
                placeholder="请输入类型"
                clearable
            />
        </el-form-item>
        <el-form-item prop="extraAnnotations" label="其他注解">
            <el-input
                v-model="formData.extraAnnotations"
                placeholder="请输入其他注解"
                clearable
            />
        </el-form-item>
        <el-form-item prop="extraImports" label="其他导入">
            <el-input
                v-model="formData.extraImports"
                placeholder="请输入其他导入"
                clearable
            />
        </el-form-item>
        <el-form-item prop="extraValidations" label="其他验证器">
            <el-input
                v-model="formData.extraValidations"
                placeholder="请输入其他验证器"
                clearable
            />
        </el-form-item>
        <el-form-item prop="remark" label="备注">
            <el-input
                v-model="formData.remark"
                placeholder="请输入备注"
                clearable
            />
        </el-form-item>

        <slot
            v-if="withOperations"
            name="operations"
            :handleSubmit="handleSubmit"
            :handleCancel="handleCancel"
        >
            <div class="form-operations">
                <el-button type="warning" @click="handleCancel">
                    取消
                </el-button>
                <el-button
                    type="primary"
                    :loading="submitLoading"
                    @click="handleSubmit"
                >
                    提交
                </el-button>
            </div>
        </slot>
    </el-form>
</template>
