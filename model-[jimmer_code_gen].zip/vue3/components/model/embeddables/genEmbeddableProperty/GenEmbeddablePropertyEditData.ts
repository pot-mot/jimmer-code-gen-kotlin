import {sendMessage} from "@/utils/message"
import type {GenEmbeddablePropertyUpdateInput} from "@/api/__generated/model/static"

export type GenEmbeddablePropertyEditData = {
    id: number
    jdbcTypeCode: number
    rawType: string
    typeIsNotNull: boolean
    dataSize?: number | undefined
    numericPrecision?: number | undefined
    columnDefaultExp?: string | undefined
    embeddableId?: number | undefined
    name: string
    comment: string
    type: string
    extraAnnotations?: string | undefined
    extraImports?: string | undefined
    extraValidations?: string | undefined
    remark: string
}

const getUnmatchedMessageList = (data: GenEmbeddablePropertyEditData): Array<string> => {
    const messageList: Array<string> = []

    if (data.embeddableId === undefined) {
        messageList.push("嵌入类型不可为空")
    }

    return messageList
}

export const validateGenEmbeddablePropertyEditDataForSubmit = (data: GenEmbeddablePropertyEditData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertGenEmbeddablePropertyEditDataAsSubmitType = (data: GenEmbeddablePropertyEditData): GenEmbeddablePropertyUpdateInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as GenEmbeddablePropertyUpdateInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
