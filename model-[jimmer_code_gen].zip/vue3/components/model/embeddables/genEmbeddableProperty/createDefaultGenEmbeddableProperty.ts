import type {GenEmbeddablePropertyAddData} from "./GenEmbeddablePropertyAddData"

export const createDefaultGenEmbeddableProperty = (): GenEmbeddablePropertyAddData => {
    return {
        jdbcTypeCode: 0,
        rawType: "",
        typeIsNotNull: false,
        dataSize: undefined,
        numericPrecision: undefined,
        columnDefaultExp: undefined,
        embeddableId: undefined,
        name: "",
        comment: "",
        type: "",
        extraAnnotations: undefined,
        extraImports: undefined,
        extraValidations: undefined,
        remark: ""
    }
}
