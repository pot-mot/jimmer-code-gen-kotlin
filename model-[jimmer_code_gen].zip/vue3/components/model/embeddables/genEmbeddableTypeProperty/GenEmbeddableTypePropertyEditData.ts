import {sendMessage} from "@/utils/message"
import type {GenEmbeddableTypePropertyUpdateInput} from "@/api/__generated/model/static"

export type GenEmbeddableTypePropertyEditData = {
    id: number
    jdbcTypeCode: number
    rawType: string
    typeIsNotNull: boolean
    dataSize?: number | undefined
    numericPrecision?: number | undefined
    columnDefaultExp?: string | undefined
    typeEnumId?: number | undefined
    embeddablePropertyOverrideId?: number | undefined
    embeddableId?: number | undefined
    name: string
    comment: string
    type?: string | undefined
    columnName: string
    extraAnnotations?: string | undefined
    extraImports?: string | undefined
    extraValidations?: string | undefined
    remark: string
    orderKey: number
}

const getUnmatchedMessageList = (data: GenEmbeddableTypePropertyEditData): Array<string> => {
    const messageList: Array<string> = []

    if (data.embeddableId === undefined) {
        messageList.push("嵌入类型不可为空")
    }

    return messageList
}

export const validateGenEmbeddableTypePropertyEditDataForSubmit = (data: GenEmbeddableTypePropertyEditData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertGenEmbeddableTypePropertyEditDataAsSubmitType = (data: GenEmbeddableTypePropertyEditData): GenEmbeddableTypePropertyUpdateInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as GenEmbeddableTypePropertyUpdateInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
