import type {GenEmbeddableTypePropertyAddData} from "./GenEmbeddableTypePropertyAddData"

export const createDefaultGenEmbeddableTypeProperty = (): GenEmbeddableTypePropertyAddData => {
    return {
        rawType: undefined,
        typeEnumId: undefined,
        typeEmbeddableId: undefined,
        columnInfoId: undefined,
        embeddableId: undefined,
        name: "",
        comment: "",
        extraAnnotations: undefined,
        extraImports: undefined,
        extraValidations: undefined,
        remark: "",
        orderKey: 0
    }
}
