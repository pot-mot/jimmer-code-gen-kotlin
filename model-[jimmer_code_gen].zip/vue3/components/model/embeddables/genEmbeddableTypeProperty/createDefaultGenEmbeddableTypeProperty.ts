import type {GenEmbeddableTypePropertyAddData} from "./GenEmbeddableTypePropertyAddData"

export const createDefaultGenEmbeddableTypeProperty = (): GenEmbeddableTypePropertyAddData => {
    return {
        jdbcTypeCode: 0,
        rawType: "",
        typeIsNotNull: false,
        dataSize: undefined,
        numericPrecision: undefined,
        columnDefaultExp: undefined,
        typeEnumId: undefined,
        embeddableId: undefined,
        name: "",
        comment: "",
        type: undefined,
        columnName: "",
        extraAnnotations: undefined,
        extraImports: undefined,
        extraValidations: undefined,
        remark: "",
        orderKey: 0
    }
}
