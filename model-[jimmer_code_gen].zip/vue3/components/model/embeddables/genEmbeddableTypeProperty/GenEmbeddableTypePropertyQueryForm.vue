<script setup lang="ts">
import {Search} from "@element-plus/icons-vue"
import type {
    GenEmbeddableTypePropertySpec,
    GenEnumOptionView,
    GenEmbeddablePropertyOverrideOptionView,
    GenEmbeddableTypeOptionView
} from "@/api/__generated/model/static"
import GenEnumIdSelect from "@/components/model/enums/genEnum/GenEnumIdSelect.vue"
import GenEmbeddablePropertyOverrideIdSelect from "@/components/model/entities/properties/genEmbeddablePropertyOverride/GenEmbeddablePropertyOverrideIdSelect.vue"
import GenEmbeddableTypeIdSelect from "@/components/model/embeddables/genEmbeddableType/GenEmbeddableTypeIdSelect.vue"
import type {LazyOptions} from "@/utils/lazyOptions"

const spec = defineModel<GenEmbeddableTypePropertySpec>({
    required: true
})

defineProps<{
    typeEnumIdOptions: LazyOptions<GenEnumOptionView>,
    embeddablePropertyOverrideIdOptions: LazyOptions<GenEmbeddablePropertyOverrideOptionView>,
    embeddableIdOptions: LazyOptions<GenEmbeddableTypeOptionView>
}>()

const emits = defineEmits<{
    (
        event: "query",
        spec: GenEmbeddableTypePropertySpec
    ): void
}>()
</script>

<template>
    <el-form
        :model="spec"
        label-width="auto"
        @submit.prevent
        class="query-form"
    >
        <el-row :gutter="20">
            <el-col :span="8" :xs="24">
                <el-form-item prop="jdbcTypeCode" label="JdbcType 码值">
                    <el-input-number
                        v-model.number="spec.minJdbcTypeCode"
                        placeholder="最小"
                        :precision="0"
                        :min="0"
                        :max="2147483647"
                        :value-on-clear="undefined"
                        @change="emits('query', spec)"
                    />
                    <el-input-number
                        v-model.number="spec.maxJdbcTypeCode"
                        placeholder="最大"
                        :precision="0"
                        :min="0"
                        :max="2147483647"
                        :value-on-clear="undefined"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="rawType" label="字面类型">
                    <el-input
                        v-model="spec.rawType"
                        placeholder="请输入字面类型"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="typeIsNotNull" label="类型是否非空">
                    <el-select
                        v-model="spec.typeIsNotNull"
                        placeholder="请选择类型是否非空"
                        clearable
                        :value-on-clear="undefined"
                        @change="emits('query', spec)"
                    >
                        <el-option :value="true" label="是"/>
                        <el-option :value="false" label="否"/>
                    </el-select>
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="dataSize" label="长度">
                    <el-input-number
                        v-model.number="spec.minDataSize"
                        placeholder="最小"
                        :precision="0"
                        :max="2147483647"
                        :value-on-clear="undefined"
                        @change="emits('query', spec)"
                    />
                    <el-input-number
                        v-model.number="spec.maxDataSize"
                        placeholder="最大"
                        :precision="0"
                        :max="2147483647"
                        :value-on-clear="undefined"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="numericPrecision" label="精度">
                    <el-input-number
                        v-model.number="spec.minNumericPrecision"
                        placeholder="最小"
                        :precision="0"
                        :max="2147483647"
                        :value-on-clear="undefined"
                        @change="emits('query', spec)"
                    />
                    <el-input-number
                        v-model.number="spec.maxNumericPrecision"
                        placeholder="最大"
                        :precision="0"
                        :max="2147483647"
                        :value-on-clear="undefined"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="columnDefaultExp" label="列默认表达式">
                    <el-input
                        v-model="spec.columnDefaultExp"
                        placeholder="请输入列默认表达式"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="typeEnumId" label="类型对应枚举">
                    <GenEnumIdSelect
                        v-model="spec.typeEnumId"
                        :options="typeEnumIdOptions"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item
                    prop="embeddablePropertyOverrideId"
                    label="复合属性列覆盖"
                >
                    <GenEmbeddablePropertyOverrideIdSelect
                        v-model="spec.embeddablePropertyOverrideId"
                        :options="embeddablePropertyOverrideIdOptions"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="embeddableId" label="嵌入类型">
                    <GenEmbeddableTypeIdSelect
                        v-model="spec.embeddableId"
                        :options="embeddableIdOptions"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="name" label="名称">
                    <el-input
                        v-model="spec.name"
                        placeholder="请输入名称"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="comment" label="注释">
                    <el-input
                        v-model="spec.comment"
                        placeholder="请输入注释"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="type" label="类型">
                    <el-input
                        v-model="spec.type"
                        placeholder="请输入类型"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="columnName" label="列名">
                    <el-input
                        v-model="spec.columnName"
                        placeholder="请输入列名"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="extraAnnotations" label="其他注解">
                    <el-input
                        v-model="spec.extraAnnotations"
                        placeholder="请输入其他注解"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="extraImports" label="其他导入">
                    <el-input
                        v-model="spec.extraImports"
                        placeholder="请输入其他导入"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="extraValidations" label="其他验证器">
                    <el-input
                        v-model="spec.extraValidations"
                        placeholder="请输入其他验证器"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="remark" label="备注">
                    <el-input
                        v-model="spec.remark"
                        placeholder="请输入备注"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="orderKey" label="排序键">
                    <el-input-number
                        v-model.number="spec.minOrderKey"
                        placeholder="最小"
                        :precision="0"
                        :max="2147483647"
                        :value-on-clear="undefined"
                        @change="emits('query', spec)"
                    />
                    <el-input-number
                        v-model.number="spec.maxOrderKey"
                        placeholder="最大"
                        :precision="0"
                        :max="2147483647"
                        :value-on-clear="undefined"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-button
                type="primary"
                :icon="Search"
                class="search-button"
                @click="emits('query', spec)"
            >
                查询
            </el-button>
        </el-row>
    </el-form>
</template>
