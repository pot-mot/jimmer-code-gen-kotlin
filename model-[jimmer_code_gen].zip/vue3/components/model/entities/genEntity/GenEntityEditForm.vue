<script setup lang="ts">
import {ref} from "vue"
import type {FormInstance} from "element-plus"
import type {FormExpose} from "@/components/form/FormExpose"
import type {
    GenEntityUpdateInput,
    GenModelGroupOptionView,
    GenIdPropertyOptionView,
    GenLogicalDeletePropertyOptionView,
    GenVersionPropertyOptionView
} from "@/api/__generated/model/static"
import {
    validateGenEntityEditDataForSubmit,
    assertGenEntityEditDataAsSubmitType
} from "@/components/model/entities/genEntity/GenEntityEditData"
import type {GenEntityEditData} from "@/components/model/entities/genEntity/GenEntityEditData"
import {useRules} from "@/rules/model/entities/genEntity/GenEntityEditFormRules"
import GenModelGroupIdSelect from "@/components/model/genModelGroup/GenModelGroupIdSelect.vue"
import GenIdPropertyIdSelect from "@/components/model/entities/properties/genIdProperty/GenIdPropertyIdSelect.vue"
import GenLogicalDeletePropertyIdSelect from "@/components/model/entities/properties/genLogicalDeleteProperty/GenLogicalDeletePropertyIdSelect.vue"
import GenVersionPropertyIdSelect from "@/components/model/entities/properties/genVersionProperty/GenVersionPropertyIdSelect.vue"
import type {LazyOptions} from "@/utils/lazyOptions"

const formData = defineModel<GenEntityEditData>({
    required: true
})

const props = withDefaults(defineProps<{
    withOperations?: boolean | undefined,
    submitLoading?: boolean | undefined,
    groupIdOptions: LazyOptions<GenModelGroupOptionView>,
    idPropertyIdOptions: LazyOptions<GenIdPropertyOptionView>,
    logicalDeletePropertyIdOptions: LazyOptions<GenLogicalDeletePropertyOptionView>,
    versionPropertyIdOptions: LazyOptions<GenVersionPropertyOptionView>
}>(), {
    withOperations: true,
    submitLoading: false,
})

const emits = defineEmits<{
    (
        event: "submit",
        formData: GenEntityUpdateInput
    ): void,
    (event: "cancel"): void
}>()

defineSlots<{
    operations(props: {
        handleSubmit: () => Promise<void>,
        handleCancel: () => void
    }): any
}>()

const formRef = ref<FormInstance>()
const rules = useRules(formData)

// 校验
const handleValidate = async (
    errorHandler: (errors: any[]) => void = (errors) => {console.error(errors)}
): Promise<boolean> => {
    const errors: any[] = []
    const formValid: boolean = await formRef.value?.validate().catch(e => {
        errors.push(e)
        return false
    }) ?? false

    const typeValidate: boolean = validateGenEntityEditDataForSubmit(formData.value)

    errorHandler?.(errors)
    return formValid && typeValidate
}

// 提交
const handleSubmit = async (): Promise<void> => {
    if (props.submitLoading) return

    const validResult = await handleValidate()
    if (validResult) {
        emits("submit", assertGenEntityEditDataAsSubmitType(formData.value))
    }
}

// 取消
const handleCancel = (): void => {
    emits("cancel")
}

defineExpose<FormExpose>({
    validate: handleValidate
})
</script>

<template>
    <el-form
        :model="formData"
        ref="formRef"
        :rules="rules"
        label-width="auto"
        @submit.prevent
        class="edit-form"
    >
        <el-form-item prop="groupId" label="分组">
            <GenModelGroupIdSelect
                v-model="formData.groupId"
                :options="groupIdOptions"
            />
        </el-form-item>
        <el-form-item prop="interfaceName" label="接口名称">
            <el-input
                v-model="formData.interfaceName"
                placeholder="请输入接口名称"
                clearable
            />
        </el-form-item>
        <el-form-item prop="mappedSuper" label="抽象超类型">
            <el-switch v-model="formData.mappedSuper"/>
        </el-form-item>
        <el-form-item prop="tableName" label="表名称">
            <el-input
                v-model="formData.tableName"
                placeholder="请输入表名称"
                clearable
            />
        </el-form-item>
        <el-form-item prop="pluralName" label="复数名称">
            <el-input
                v-model="formData.pluralName"
                placeholder="请输入复数名称"
                clearable
            />
        </el-form-item>
        <el-form-item prop="author" label="作者">
            <el-input
                v-model="formData.author"
                placeholder="请输入作者"
                clearable
            />
        </el-form-item>
        <el-form-item prop="comment" label="注释">
            <el-input
                v-model="formData.comment"
                placeholder="请输入注释"
                clearable
            />
        </el-form-item>
        <el-form-item prop="subPackagePath" label="子包路径">
            <el-input
                v-model="formData.subPackagePath"
                placeholder="请输入子包路径"
                clearable
            />
        </el-form-item>
        <el-form-item prop="otherAnnotations" label="其他注解">
            <el-input
                v-model="formData.otherAnnotations"
                placeholder="请输入其他注解"
                clearable
            />
        </el-form-item>
        <el-form-item prop="otherImports" label="其他导入">
            <el-input
                v-model="formData.otherImports"
                placeholder="请输入其他导入"
                clearable
            />
        </el-form-item>
        <el-form-item prop="remark" label="备注">
            <el-input
                v-model="formData.remark"
                placeholder="请输入备注"
                clearable
            />
        </el-form-item>
        <el-form-item prop="idPropertyId" label="ID属性">
            <GenIdPropertyIdSelect
                v-model="formData.idPropertyId"
                :options="idPropertyIdOptions"
            />
        </el-form-item>
        <el-form-item
            prop="logicalDeletePropertyId"
            label="逻辑删除属性"
        >
            <GenLogicalDeletePropertyIdSelect
                v-model="formData.logicalDeletePropertyId"
                :options="logicalDeletePropertyIdOptions"
            />
        </el-form-item>
        <el-form-item prop="versionPropertyId" label="乐观锁属性">
            <GenVersionPropertyIdSelect
                v-model="formData.versionPropertyId"
                :options="versionPropertyIdOptions"
            />
        </el-form-item>
        <el-form-item prop="x" label="X坐标">
            <el-input-number
                v-model.number="formData.x"
                placeholder="请输入X坐标"
                :precision="0"
            />
        </el-form-item>
        <el-form-item prop="y" label="Y坐标">
            <el-input-number
                v-model.number="formData.y"
                placeholder="请输入Y坐标"
                :precision="0"
            />
        </el-form-item>

        <slot
            v-if="withOperations"
            name="operations"
            :handleSubmit="handleSubmit"
            :handleCancel="handleCancel"
        >
            <div class="form-operations">
                <el-button type="warning" @click="handleCancel">
                    取消
                </el-button>
                <el-button
                    type="primary"
                    :loading="submitLoading"
                    @click="handleSubmit"
                >
                    提交
                </el-button>
            </div>
        </slot>
    </el-form>
</template>
