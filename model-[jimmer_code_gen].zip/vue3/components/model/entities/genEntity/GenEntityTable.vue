<script setup lang="ts">
import type {GenEntityListView} from "@/api/__generated/model/static"
import {usePageSizeStore} from "@/stores/pageSizeStore"

withDefaults(defineProps<{
    rows: Array<GenEntityListView>,
    idColumn?: boolean | undefined,
    indexColumn?: boolean | undefined,
    multiSelect?: boolean | undefined,
    withOperations?: boolean | undefined
}>(), {
    idColumn: false,
    indexColumn: true,
    multiSelect: true,
    withOperations: true,
})

const emits = defineEmits<{
    (
        event: "selectionChange",
        selection: Array<GenEntityListView>
    ): void
}>()

defineSlots<{
    operations(props: {row: GenEntityListView, index: number}): any
}>()

const pageSizeStore = usePageSizeStore()

const handleSelectionChange = (newSelection: Array<GenEntityListView>): void => {
    emits("selectionChange", newSelection)
}
</script>

<template>
    <el-table
        :data="rows"
        row-key="id"
        border
        stripe
        class="view-table"
        @selection-change="handleSelectionChange"
    >
        <el-table-column
            v-if="idColumn"
            prop="id"
            label="ID"
            :fixed="pageSizeStore.isSmall ? undefined : 'left'"
        />
        <el-table-column
            v-if="indexColumn"
            type="index"
            :fixed="pageSizeStore.isSmall ? undefined : 'left'"
        />
        <el-table-column
            v-if="multiSelect"
            type="selection"
            :width="43"
            :fixed="pageSizeStore.isSmall ? undefined : 'left'"
        />
        <el-table-column
            prop="groupId"
            label="分组"
            :min-width="161"
        />
        <el-table-column
            prop="interfaceName"
            label="接口名称"
            :min-width="129"
        />
        <el-table-column
            prop="mappedSuper"
            label="抽象超类型"
            :min-width="81"
        >
            <template #default="scope">
                <el-checkbox :modelValue="scope.row.mappedSuper"/>
            </template>
        </el-table-column>
        <el-table-column
            prop="tableName"
            label="表名称"
            :min-width="129"
        />
        <el-table-column
            prop="pluralName"
            label="复数名称"
            :min-width="129"
        />
        <el-table-column
            prop="author"
            label="作者"
            :min-width="129"
        />
        <el-table-column
            prop="comment"
            label="注释"
            :min-width="129"
        />
        <el-table-column
            prop="subPackagePath"
            label="子包路径"
            :min-width="129"
        />
        <el-table-column
            prop="otherAnnotations"
            label="其他注解"
            :min-width="129"
        />
        <el-table-column
            prop="otherImports"
            label="其他导入"
            :min-width="129"
        />
        <el-table-column
            prop="remark"
            label="备注"
            :min-width="129"
        />
        <el-table-column
            prop="idPropertyId"
            label="ID属性"
            :min-width="161"
        />
        <el-table-column
            prop="logicalDeletePropertyId"
            label="逻辑删除属性"
            :min-width="161"
        />
        <el-table-column
            prop="versionPropertyId"
            label="乐观锁属性"
            :min-width="161"
        />
        <el-table-column
            prop="graphDataId"
            label="图数据"
            :min-width="161"
        />
        <el-table-column
            v-if="withOperations"
            label="操作"
            :fixed="pageSizeStore.isSmall ? undefined : 'right'"
        >
            <template #default="scope">
                <slot
                    name="operations"
                    :row="scope.row as GenEntityListView"
                    :index="scope.$index"
                />
            </template>
        </el-table-column>
    </el-table>
</template>
