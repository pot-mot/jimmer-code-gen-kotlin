<script setup lang="ts">
import {Search} from "@element-plus/icons-vue"
import type {
    GenEntitySpec,
    GenModelGroupOptionView,
    GenIdPropertyOptionView,
    GenLogicalDeletePropertyOptionView,
    GenVersionPropertyOptionView,
    GenEntityGraphDataOptionView
} from "@/api/__generated/model/static"
import GenModelGroupIdSelect from "@/components/model/genModelGroup/GenModelGroupIdSelect.vue"
import GenIdPropertyIdSelect from "@/components/model/entities/properties/genIdProperty/GenIdPropertyIdSelect.vue"
import GenLogicalDeletePropertyIdSelect from "@/components/model/entities/properties/genLogicalDeleteProperty/GenLogicalDeletePropertyIdSelect.vue"
import GenVersionPropertyIdSelect from "@/components/model/entities/properties/genVersionProperty/GenVersionPropertyIdSelect.vue"
import GenEntityGraphDataIdSelect from "@/components/model/entities/genEntityGraphData/GenEntityGraphDataIdSelect.vue"
import type {LazyOptions} from "@/utils/lazyOptions"

const spec = defineModel<GenEntitySpec>({
    required: true
})

defineProps<{
    groupIdOptions: LazyOptions<GenModelGroupOptionView>,
    idPropertyIdOptions: LazyOptions<GenIdPropertyOptionView>,
    logicalDeletePropertyIdOptions: LazyOptions<GenLogicalDeletePropertyOptionView>,
    versionPropertyIdOptions: LazyOptions<GenVersionPropertyOptionView>,
    graphDataIdOptions: LazyOptions<GenEntityGraphDataOptionView>
}>()

const emits = defineEmits<{
    (event: "query", spec: GenEntitySpec): void
}>()
</script>

<template>
    <el-form
        :model="spec"
        label-width="auto"
        @submit.prevent
        class="query-form"
    >
        <el-row :gutter="20">
            <el-col :span="8" :xs="24">
                <el-form-item prop="groupId" label="分组">
                    <GenModelGroupIdSelect
                        v-model="spec.groupId"
                        :options="groupIdOptions"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="interfaceName" label="接口名称">
                    <el-input
                        v-model="spec.interfaceName"
                        placeholder="请输入接口名称"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="mappedSuper" label="抽象超类型">
                    <el-select
                        v-model="spec.mappedSuper"
                        placeholder="请选择抽象超类型"
                        clearable
                        :value-on-clear="undefined"
                        @change="emits('query', spec)"
                    >
                        <el-option :value="true" label="是"/>
                        <el-option :value="false" label="否"/>
                    </el-select>
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="tableName" label="表名称">
                    <el-input
                        v-model="spec.tableName"
                        placeholder="请输入表名称"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="pluralName" label="复数名称">
                    <el-input
                        v-model="spec.pluralName"
                        placeholder="请输入复数名称"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="author" label="作者">
                    <el-input
                        v-model="spec.author"
                        placeholder="请输入作者"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="comment" label="注释">
                    <el-input
                        v-model="spec.comment"
                        placeholder="请输入注释"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="subPackagePath" label="子包路径">
                    <el-input
                        v-model="spec.subPackagePath"
                        placeholder="请输入子包路径"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="otherAnnotations" label="其他注解">
                    <el-input
                        v-model="spec.otherAnnotations"
                        placeholder="请输入其他注解"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="otherImports" label="其他导入">
                    <el-input
                        v-model="spec.otherImports"
                        placeholder="请输入其他导入"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="remark" label="备注">
                    <el-input
                        v-model="spec.remark"
                        placeholder="请输入备注"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="idPropertyId" label="ID属性">
                    <GenIdPropertyIdSelect
                        v-model="spec.idPropertyId"
                        :options="idPropertyIdOptions"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item
                    prop="logicalDeletePropertyId"
                    label="逻辑删除属性"
                >
                    <GenLogicalDeletePropertyIdSelect
                        v-model="spec.logicalDeletePropertyId"
                        :options="logicalDeletePropertyIdOptions"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="versionPropertyId" label="乐观锁属性">
                    <GenVersionPropertyIdSelect
                        v-model="spec.versionPropertyId"
                        :options="versionPropertyIdOptions"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="graphDataId" label="图数据">
                    <GenEntityGraphDataIdSelect
                        v-model="spec.graphDataId"
                        :options="graphDataIdOptions"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-button
                type="primary"
                :icon="Search"
                class="search-button"
                @click="emits('query', spec)"
            >
                查询
            </el-button>
        </el-row>
    </el-form>
</template>
