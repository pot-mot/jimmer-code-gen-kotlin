import {sendMessage} from "@/utils/message"
import type {GenEntityUpdateInput} from "@/api/__generated/model/static"

export type GenEntityEditData = {
    id: number
    groupId?: number | undefined
    interfaceName: string
    mappedSuper: boolean
    tableName: string
    pluralName: string
    author: string
    comment: string
    subPackagePath: string
    otherAnnotations: string
    otherImports: string
    remark: string
    idPropertyId?: number | undefined
    logicalDeletePropertyId?: number | undefined
    versionPropertyId?: number | undefined
    x: number
    y: number
}

const getUnmatchedMessageList = (data: GenEntityEditData): Array<string> => {
    const messageList: Array<string> = []

    if (data.groupId === undefined) {
        messageList.push("分组不可为空")
    }

    return messageList
}

export const validateGenEntityEditDataForSubmit = (data: GenEntityEditData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertGenEntityEditDataAsSubmitType = (data: GenEntityEditData): GenEntityUpdateInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as GenEntityUpdateInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
