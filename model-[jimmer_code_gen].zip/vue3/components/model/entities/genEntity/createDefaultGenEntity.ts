import type {GenEntityAddData} from "./GenEntityAddData"

export const createDefaultGenEntity = (): GenEntityAddData => {
    return {
        groupId: undefined,
        interfaceName: "",
        mappedSuper: false,
        tableName: "",
        pluralName: "",
        author: "",
        comment: "",
        subPackagePath: "",
        otherAnnotations: "",
        otherImports: "",
        remark: "",
        idPropertyId: undefined,
        logicalDeletePropertyId: undefined,
        versionPropertyId: undefined,
        x: 0,
        y: 0
    }
}
