import {sendMessage} from "@/utils/message"
import type {GenEntityInheritUpdateInput} from "@/api/__generated/model/static"

export type GenEntityInheritEditData = {
    id: number
    parentId?: number | undefined
    childId?: number | undefined
}

const getUnmatchedMessageList = (data: GenEntityInheritEditData): Array<string> => {
    const messageList: Array<string> = []

    if (data.parentId === undefined) {
        messageList.push("父级不可为空")
    }
    if (data.childId === undefined) {
        messageList.push("子级不可为空")
    }

    return messageList
}

export const validateGenEntityInheritEditDataForSubmit = (data: GenEntityInheritEditData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertGenEntityInheritEditDataAsSubmitType = (data: GenEntityInheritEditData): GenEntityInheritUpdateInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as GenEntityInheritUpdateInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
