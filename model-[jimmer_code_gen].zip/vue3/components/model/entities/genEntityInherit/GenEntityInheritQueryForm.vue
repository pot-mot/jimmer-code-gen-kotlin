<script setup lang="ts">
import {Search} from "@element-plus/icons-vue"
import type {
    GenEntityInheritSpec,
    GenEntityOptionView
} from "@/api/__generated/model/static"
import GenEntityIdSelect from "@/components/model/entities/genEntity/GenEntityIdSelect.vue"
import type {LazyOptions} from "@/utils/lazyOptions"

const spec = defineModel<GenEntityInheritSpec>({
    required: true
})

defineProps<{
    parentIdOptions: LazyOptions<GenEntityOptionView>,
    childIdOptions: LazyOptions<GenEntityOptionView>
}>()

const emits = defineEmits<{
    (
        event: "query",
        spec: GenEntityInheritSpec
    ): void
}>()
</script>

<template>
    <el-form
        :model="spec"
        label-width="auto"
        @submit.prevent
        class="query-form"
    >
        <el-row :gutter="20">
            <el-col :span="8" :xs="24">
                <el-form-item prop="parentId" label="父级">
                    <GenEntityIdSelect
                        v-model="spec.parentId"
                        :options="parentIdOptions"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="childId" label="子级">
                    <GenEntityIdSelect
                        v-model="spec.childId"
                        :options="childIdOptions"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-button
                type="primary"
                :icon="Search"
                class="search-button"
                @click="emits('query', spec)"
            >
                查询
            </el-button>
        </el-row>
    </el-form>
</template>
