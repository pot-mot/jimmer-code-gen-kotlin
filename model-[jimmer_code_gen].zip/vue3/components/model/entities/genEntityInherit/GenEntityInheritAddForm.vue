<script setup lang="ts">
import {ref} from "vue"
import type {FormInstance} from "element-plus"
import type {FormExpose} from "@/components/form/FormExpose"
import type {
    GenEntityInheritInsertInput,
    GenEntityOptionView
} from "@/api/__generated/model/static"
import {
    validateGenEntityInheritAddDataForSubmit,
    assertGenEntityInheritAddDataAsSubmitType
} from "@/components/model/entities/genEntityInherit/GenEntityInheritAddData"
import type {GenEntityInheritAddData} from "@/components/model/entities/genEntityInherit/GenEntityInheritAddData"
import {createDefaultGenEntityInherit} from "@/components/model/entities/genEntityInherit/createDefaultGenEntityInherit"
import {useRules} from "@/rules/model/entities/genEntityInherit/GenEntityInheritAddFormRules"
import GenEntityIdSelect from "@/components/model/entities/genEntity/GenEntityIdSelect.vue"
import type {LazyOptions} from "@/utils/lazyOptions"

const props = withDefaults(defineProps<{
    withOperations?: boolean | undefined,
    submitLoading?: boolean | undefined,
    parentIdOptions: LazyOptions<GenEntityOptionView>,
    childIdOptions: LazyOptions<GenEntityOptionView>
}>(), {
    withOperations: true,
    submitLoading: false,
})

const emits = defineEmits<{
    (
        event: "submit",
        formData: GenEntityInheritInsertInput
    ): void,
    (event: "cancel"): void
}>()

defineSlots<{
    operations(props: {
        handleSubmit: () => Promise<void>,
        handleCancel: () => void
    }): any
}>()

const formData = ref<GenEntityInheritAddData>(createDefaultGenEntityInherit())

const formRef = ref<FormInstance>()
const rules = useRules(formData)

// 校验
const handleValidate = async (
    errorHandler: (errors: any[]) => void = (errors) => {console.error(errors)}
): Promise<boolean> => {
    const errors: any[] = []
    const formValid: boolean = await formRef.value?.validate().catch(e => {
        errors.push(e)
        return false
    }) ?? false

    const typeValidate: boolean = validateGenEntityInheritAddDataForSubmit(formData.value)

    errorHandler?.(errors)
    return formValid && typeValidate
}

// 提交
const handleSubmit = async (): Promise<void> => {
    if (props.submitLoading) return

    const validResult = await handleValidate()
    if (validResult) {
        emits("submit", assertGenEntityInheritAddDataAsSubmitType(formData.value))
    }
}

// 取消
const handleCancel = (): void => {
    emits("cancel")
}

defineExpose<FormExpose>({
    validate: handleValidate
})
</script>

<template>
    <el-form
        :model="formData"
        ref="formRef"
        :rules="rules"
        label-width="auto"
        @submit.prevent
        class="add-form"
    >
        <el-form-item prop="parentId" label="父级">
            <GenEntityIdSelect
                v-model="formData.parentId"
                :options="parentIdOptions"
            />
        </el-form-item>
        <el-form-item prop="childId" label="子级">
            <GenEntityIdSelect
                v-model="formData.childId"
                :options="childIdOptions"
            />
        </el-form-item>

        <slot
            v-if="withOperations"
            name="operations"
            :handleSubmit="handleSubmit"
            :handleCancel="handleCancel"
        >
            <div class="form-operations">
                <el-button type="warning" @click="handleCancel">
                    取消
                </el-button>
                <el-button
                    type="primary"
                    :loading="submitLoading"
                    @click="handleSubmit"
                >
                    提交
                </el-button>
            </div>
        </slot>
    </el-form>
</template>
