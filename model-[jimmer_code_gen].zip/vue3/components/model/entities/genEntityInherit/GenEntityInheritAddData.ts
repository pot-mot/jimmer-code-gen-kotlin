import {sendMessage} from "@/utils/message"
import type {GenEntityInheritInsertInput} from "@/api/__generated/model/static"

export type GenEntityInheritAddData = {
    parentId?: number | undefined
    childId?: number | undefined
}

const getUnmatchedMessageList = (data: GenEntityInheritAddData): Array<string> => {
    const messageList: Array<string> = []

    if (data.parentId === undefined) {
        messageList.push("父级不可为空")
    }
    if (data.childId === undefined) {
        messageList.push("子级不可为空")
    }

    return messageList
}

export const validateGenEntityInheritAddDataForSubmit = (data: GenEntityInheritAddData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertGenEntityInheritAddDataAsSubmitType = (data: GenEntityInheritAddData): GenEntityInheritInsertInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as GenEntityInheritInsertInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
