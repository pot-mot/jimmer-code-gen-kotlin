import type {GenEntityInheritAddData} from "./GenEntityInheritAddData"

export const createDefaultGenEntityInherit = (): GenEntityInheritAddData => {
    return {
        parentId: undefined,
        childId: undefined
    }
}
