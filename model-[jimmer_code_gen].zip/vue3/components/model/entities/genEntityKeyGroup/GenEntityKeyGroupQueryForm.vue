<script setup lang="ts">
import {Search} from "@element-plus/icons-vue"
import type {
    GenEntityKeyGroupSpec,
    GenEntityIndexOptionView
} from "@/api/__generated/model/static"
import GenEntityIndexIdSelect from "@/components/model/entities/genEntityIndex/GenEntityIndexIdSelect.vue"
import type {LazyOptions} from "@/utils/lazyOptions"

const spec = defineModel<GenEntityKeyGroupSpec>({
    required: true
})

defineProps<{
    indexIdOptions: LazyOptions<GenEntityIndexOptionView>
}>()

const emits = defineEmits<{
    (
        event: "query",
        spec: GenEntityKeyGroupSpec
    ): void
}>()
</script>

<template>
    <el-form
        :model="spec"
        label-width="auto"
        @submit.prevent
        class="query-form"
    >
        <el-row :gutter="20">
            <el-col :span="8" :xs="24">
                <el-form-item prop="indexId" label="对应索引">
                    <GenEntityIndexIdSelect
                        v-model="spec.indexId"
                        :options="indexIdOptions"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="name" label="名称">
                    <el-input
                        v-model="spec.name"
                        placeholder="请输入名称"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-button
                type="primary"
                :icon="Search"
                class="search-button"
                @click="emits('query', spec)"
            >
                查询
            </el-button>
        </el-row>
    </el-form>
</template>
