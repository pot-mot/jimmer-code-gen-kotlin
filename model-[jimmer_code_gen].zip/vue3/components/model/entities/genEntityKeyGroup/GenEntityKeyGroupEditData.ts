import {sendMessage} from "@/utils/message"
import type {GenEntityKeyGroupUpdateInput} from "@/api/__generated/model/static"

export type GenEntityKeyGroupEditData = {
    id: number
    indexId?: number | undefined
    name: string
}

const getUnmatchedMessageList = (data: GenEntityKeyGroupEditData): Array<string> => {
    const messageList: Array<string> = []

    if (data.indexId === undefined) {
        messageList.push("对应索引不可为空")
    }

    return messageList
}

export const validateGenEntityKeyGroupEditDataForSubmit = (data: GenEntityKeyGroupEditData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertGenEntityKeyGroupEditDataAsSubmitType = (data: GenEntityKeyGroupEditData): GenEntityKeyGroupUpdateInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as GenEntityKeyGroupUpdateInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
