<script setup lang="ts">
import {ref} from "vue"
import type {FormInstance} from "element-plus"
import type {FormExpose} from "@/components/form/FormExpose"
import type {
    GenEntityKeyGroupInsertInput,
    GenEntityIndexOptionView
} from "@/api/__generated/model/static"
import {
    validateGenEntityKeyGroupAddDataForSubmit,
    assertGenEntityKeyGroupAddDataAsSubmitType
} from "@/components/model/entities/genEntityKeyGroup/GenEntityKeyGroupAddData"
import type {GenEntityKeyGroupAddData} from "@/components/model/entities/genEntityKeyGroup/GenEntityKeyGroupAddData"
import {createDefaultGenEntityKeyGroup} from "@/components/model/entities/genEntityKeyGroup/createDefaultGenEntityKeyGroup"
import {useRules} from "@/rules/model/entities/genEntityKeyGroup/GenEntityKeyGroupAddFormRules"
import GenEntityIndexIdSelect from "@/components/model/entities/genEntityIndex/GenEntityIndexIdSelect.vue"
import type {LazyOptions} from "@/utils/lazyOptions"

const props = withDefaults(defineProps<{
    withOperations?: boolean | undefined,
    submitLoading?: boolean | undefined,
    indexIdOptions: LazyOptions<GenEntityIndexOptionView>
}>(), {
    withOperations: true,
    submitLoading: false,
})

const emits = defineEmits<{
    (
        event: "submit",
        formData: GenEntityKeyGroupInsertInput
    ): void,
    (event: "cancel"): void
}>()

defineSlots<{
    operations(props: {
        handleSubmit: () => Promise<void>,
        handleCancel: () => void
    }): any
}>()

const formData = ref<GenEntityKeyGroupAddData>(createDefaultGenEntityKeyGroup())

const formRef = ref<FormInstance>()
const rules = useRules(formData)

// 校验
const handleValidate = async (
    errorHandler: (errors: any[]) => void = (errors) => {console.error(errors)}
): Promise<boolean> => {
    const errors: any[] = []
    const formValid: boolean = await formRef.value?.validate().catch(e => {
        errors.push(e)
        return false
    }) ?? false

    const typeValidate: boolean = validateGenEntityKeyGroupAddDataForSubmit(formData.value)

    errorHandler?.(errors)
    return formValid && typeValidate
}

// 提交
const handleSubmit = async (): Promise<void> => {
    if (props.submitLoading) return

    const validResult = await handleValidate()
    if (validResult) {
        emits("submit", assertGenEntityKeyGroupAddDataAsSubmitType(formData.value))
    }
}

// 取消
const handleCancel = (): void => {
    emits("cancel")
}

defineExpose<FormExpose>({
    validate: handleValidate
})
</script>

<template>
    <el-form
        :model="formData"
        ref="formRef"
        :rules="rules"
        label-width="auto"
        @submit.prevent
        class="add-form"
    >
        <el-form-item prop="indexId" label="对应索引">
            <GenEntityIndexIdSelect
                v-model="formData.indexId"
                :options="indexIdOptions"
            />
        </el-form-item>
        <el-form-item prop="name" label="名称">
            <el-input
                v-model="formData.name"
                placeholder="请输入名称"
                clearable
            />
        </el-form-item>

        <slot
            v-if="withOperations"
            name="operations"
            :handleSubmit="handleSubmit"
            :handleCancel="handleCancel"
        >
            <div class="form-operations">
                <el-button type="warning" @click="handleCancel">
                    取消
                </el-button>
                <el-button
                    type="primary"
                    :loading="submitLoading"
                    @click="handleSubmit"
                >
                    提交
                </el-button>
            </div>
        </slot>
    </el-form>
</template>
