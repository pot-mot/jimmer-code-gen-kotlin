import {sendMessage} from "@/utils/message"
import type {GenEntityKeyGroupInsertInput} from "@/api/__generated/model/static"

export type GenEntityKeyGroupAddData = {
    indexId?: number | undefined
    name: string
}

const getUnmatchedMessageList = (data: GenEntityKeyGroupAddData): Array<string> => {
    const messageList: Array<string> = []

    if (data.indexId === undefined) {
        messageList.push("对应索引不可为空")
    }

    return messageList
}

export const validateGenEntityKeyGroupAddDataForSubmit = (data: GenEntityKeyGroupAddData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertGenEntityKeyGroupAddDataAsSubmitType = (data: GenEntityKeyGroupAddData): GenEntityKeyGroupInsertInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as GenEntityKeyGroupInsertInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
