import type {GenEntityKeyGroupAddData} from "./GenEntityKeyGroupAddData"

export const createDefaultGenEntityKeyGroup = (): GenEntityKeyGroupAddData => {
    return {
        indexId: undefined,
        name: ""
    }
}
