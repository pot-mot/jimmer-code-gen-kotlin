<script setup lang="ts">
import {ref} from "vue"
import type {FormInstance} from "element-plus"
import type {FormExpose} from "@/components/form/FormExpose"
import type {
    GenManyToManyMappedPropertyUpdateInput,
    GenEntityOptionView,
    GenPropertyOptionView,
    GenManyToManySourcePropertyOptionView
} from "@/api/__generated/model/static"
import {
    validateGenManyToManyMappedPropertyEditDataForSubmit,
    assertGenManyToManyMappedPropertyEditDataAsSubmitType
} from "@/components/model/entities/properties/genManyToManyMappedProperty/GenManyToManyMappedPropertyEditData"
import type {GenManyToManyMappedPropertyEditData} from "@/components/model/entities/properties/genManyToManyMappedProperty/GenManyToManyMappedPropertyEditData"
import {useRules} from "@/rules/model/entities/properties/genManyToManyMappedProperty/GenManyToManyMappedPropertyEditFormRules"
import GenEntityIdSelect from "@/components/model/entities/genEntity/GenEntityIdSelect.vue"
import GenPropertyIdSelect from "@/components/model/entities/properties/genProperty/GenPropertyIdSelect.vue"
import GenManyToManySourcePropertyIdSelect from "@/components/model/entities/properties/genManyToManySourceProperty/GenManyToManySourcePropertyIdSelect.vue"
import type {LazyOptions} from "@/utils/lazyOptions"

const formData = defineModel<GenManyToManyMappedPropertyEditData>({
    required: true
})

const props = withDefaults(defineProps<{
    withOperations?: boolean | undefined,
    submitLoading?: boolean | undefined,
    typeEntityIdOptions: LazyOptions<GenEntityOptionView>,
    propertyIdOptions: LazyOptions<GenPropertyOptionView>,
    mappedByIdOptions: LazyOptions<GenManyToManySourcePropertyOptionView>
}>(), {
    withOperations: true,
    submitLoading: false,
})

const emits = defineEmits<{
    (
        event: "submit",
        formData: GenManyToManyMappedPropertyUpdateInput
    ): void,
    (event: "cancel"): void
}>()

defineSlots<{
    operations(props: {
        handleSubmit: () => Promise<void>,
        handleCancel: () => void
    }): any
}>()

const formRef = ref<FormInstance>()
const rules = useRules(formData)

// 校验
const handleValidate = async (
    errorHandler: (errors: any[]) => void = (errors) => {console.error(errors)}
): Promise<boolean> => {
    const errors: any[] = []
    const formValid: boolean = await formRef.value?.validate().catch(e => {
        errors.push(e)
        return false
    }) ?? false

    const typeValidate: boolean = validateGenManyToManyMappedPropertyEditDataForSubmit(formData.value)

    errorHandler?.(errors)
    return formValid && typeValidate
}

// 提交
const handleSubmit = async (): Promise<void> => {
    if (props.submitLoading) return

    const validResult = await handleValidate()
    if (validResult) {
        emits("submit", assertGenManyToManyMappedPropertyEditDataAsSubmitType(formData.value))
    }
}

// 取消
const handleCancel = (): void => {
    emits("cancel")
}

defineExpose<FormExpose>({
    validate: handleValidate
})
</script>

<template>
    <el-form
        :model="formData"
        ref="formRef"
        :rules="rules"
        label-width="auto"
        @submit.prevent
        class="edit-form"
    >
        <el-form-item prop="typeEntityId" label="类型对应实体">
            <GenEntityIdSelect
                v-model="formData.typeEntityId"
                :options="typeEntityIdOptions"
            />
        </el-form-item>
        <el-form-item prop="propertyId" label="属性">
            <GenPropertyIdSelect
                v-model="formData.propertyId"
                :options="propertyIdOptions"
            />
        </el-form-item>
        <el-form-item prop="mappedById" label="对应源属性">
            <GenManyToManySourcePropertyIdSelect
                v-model="formData.mappedById"
                :options="mappedByIdOptions"
            />
        </el-form-item>
        <el-form-item prop="idViewName" label="ID视图名">
            <el-input
                v-model="formData.idViewName"
                placeholder="请输入ID视图名"
                clearable
            />
        </el-form-item>

        <slot
            v-if="withOperations"
            name="operations"
            :handleSubmit="handleSubmit"
            :handleCancel="handleCancel"
        >
            <div class="form-operations">
                <el-button type="warning" @click="handleCancel">
                    取消
                </el-button>
                <el-button
                    type="primary"
                    :loading="submitLoading"
                    @click="handleSubmit"
                >
                    提交
                </el-button>
            </div>
        </slot>
    </el-form>
</template>
