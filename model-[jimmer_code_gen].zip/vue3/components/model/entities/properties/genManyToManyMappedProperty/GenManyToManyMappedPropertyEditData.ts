import {sendMessage} from "@/utils/message"
import type {GenManyToManyMappedPropertyUpdateInput} from "@/api/__generated/model/static"

export type GenManyToManyMappedPropertyEditData = {
    id: number
    typeEntityId?: number | undefined
    propertyId?: number | undefined
    mappedById?: number | undefined
    idViewName: string
}

const getUnmatchedMessageList = (data: GenManyToManyMappedPropertyEditData): Array<string> => {
    const messageList: Array<string> = []

    if (data.typeEntityId === undefined) {
        messageList.push("类型对应实体不可为空")
    }
    if (data.propertyId === undefined) {
        messageList.push("属性不可为空")
    }
    if (data.mappedById === undefined) {
        messageList.push("对应源属性不可为空")
    }

    return messageList
}

export const validateGenManyToManyMappedPropertyEditDataForSubmit = (data: GenManyToManyMappedPropertyEditData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertGenManyToManyMappedPropertyEditDataAsSubmitType = (data: GenManyToManyMappedPropertyEditData): GenManyToManyMappedPropertyUpdateInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as GenManyToManyMappedPropertyUpdateInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
