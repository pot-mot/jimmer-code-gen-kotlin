<script setup lang="ts">
import type {GenManyToManyMappedPropertyListView} from "@/api/__generated/model/static"
import {usePageSizeStore} from "@/stores/pageSizeStore"

withDefaults(defineProps<{
    rows: Array<GenManyToManyMappedPropertyListView>,
    idColumn?: boolean | undefined,
    indexColumn?: boolean | undefined,
    multiSelect?: boolean | undefined,
    withOperations?: boolean | undefined
}>(), {
    idColumn: false,
    indexColumn: true,
    multiSelect: true,
    withOperations: true,
})

const emits = defineEmits<{
    (
        event: "selectionChange",
        selection: Array<GenManyToManyMappedPropertyListView>
    ): void
}>()

defineSlots<{
    operations(props: {
        row: GenManyToManyMappedPropertyListView,
        index: number
    }): any
}>()

const pageSizeStore = usePageSizeStore()

const handleSelectionChange = (
    newSelection: Array<GenManyToManyMappedPropertyListView>
): void => {
    emits("selectionChange", newSelection)
}
</script>

<template>
    <el-table
        :data="rows"
        row-key="id"
        border
        stripe
        class="view-table"
        @selection-change="handleSelectionChange"
    >
        <el-table-column
            v-if="idColumn"
            prop="id"
            label="ID"
            :fixed="pageSizeStore.isSmall ? undefined : 'left'"
        />
        <el-table-column
            v-if="indexColumn"
            type="index"
            :fixed="pageSizeStore.isSmall ? undefined : 'left'"
        />
        <el-table-column
            v-if="multiSelect"
            type="selection"
            :width="43"
            :fixed="pageSizeStore.isSmall ? undefined : 'left'"
        />
        <el-table-column
            prop="typeEntityId"
            label="类型对应实体"
            :min-width="161"
        />
        <el-table-column
            prop="propertyId"
            label="属性"
            :min-width="161"
        />
        <el-table-column
            prop="mappedById"
            label="对应源属性"
            :min-width="161"
        />
        <el-table-column
            prop="idViewName"
            label="ID视图名"
            :min-width="129"
        />
        <el-table-column
            v-if="withOperations"
            label="操作"
            :fixed="pageSizeStore.isSmall ? undefined : 'right'"
        >
            <template #default="scope">
                <slot
                    name="operations"
                    :row="scope.row as GenManyToManyMappedPropertyListView"
                    :index="scope.$index"
                />
            </template>
        </el-table-column>
    </el-table>
</template>
