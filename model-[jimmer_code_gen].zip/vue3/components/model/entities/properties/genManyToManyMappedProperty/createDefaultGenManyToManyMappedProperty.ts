import type {GenManyToManyMappedPropertyAddData} from "./GenManyToManyMappedPropertyAddData"

export const createDefaultGenManyToManyMappedProperty = (): GenManyToManyMappedPropertyAddData => {
    return {
        typeEntityId: undefined,
        propertyId: undefined,
        mappedById: undefined,
        idViewName: ""
    }
}
