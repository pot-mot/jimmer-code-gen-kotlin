<script setup lang="ts">
import {Search} from "@element-plus/icons-vue"
import type {
    GenManyToManyMappedPropertySpec,
    GenEntityOptionView,
    GenPropertyOptionView,
    GenManyToManySourcePropertyOptionView
} from "@/api/__generated/model/static"
import GenEntityIdSelect from "@/components/model/entities/genEntity/GenEntityIdSelect.vue"
import GenPropertyIdSelect from "@/components/model/entities/properties/genProperty/GenPropertyIdSelect.vue"
import GenManyToManySourcePropertyIdSelect from "@/components/model/entities/properties/genManyToManySourceProperty/GenManyToManySourcePropertyIdSelect.vue"
import type {LazyOptions} from "@/utils/lazyOptions"

const spec = defineModel<GenManyToManyMappedPropertySpec>({
    required: true
})

defineProps<{
    typeEntityIdOptions: LazyOptions<GenEntityOptionView>,
    propertyIdOptions: LazyOptions<GenPropertyOptionView>,
    mappedByIdOptions: LazyOptions<GenManyToManySourcePropertyOptionView>
}>()

const emits = defineEmits<{
    (
        event: "query",
        spec: GenManyToManyMappedPropertySpec
    ): void
}>()
</script>

<template>
    <el-form
        :model="spec"
        label-width="auto"
        @submit.prevent
        class="query-form"
    >
        <el-row :gutter="20">
            <el-col :span="8" :xs="24">
                <el-form-item prop="typeEntityId" label="类型对应实体">
                    <GenEntityIdSelect
                        v-model="spec.typeEntityId"
                        :options="typeEntityIdOptions"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="propertyId" label="属性">
                    <GenPropertyIdSelect
                        v-model="spec.propertyId"
                        :options="propertyIdOptions"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="mappedById" label="对应源属性">
                    <GenManyToManySourcePropertyIdSelect
                        v-model="spec.mappedById"
                        :options="mappedByIdOptions"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="idViewName" label="ID视图名">
                    <el-input
                        v-model="spec.idViewName"
                        placeholder="请输入ID视图名"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-button
                type="primary"
                :icon="Search"
                class="search-button"
                @click="emits('query', spec)"
            >
                查询
            </el-button>
        </el-row>
    </el-form>
</template>
