import {sendMessage} from "@/utils/message"
import type {GenEmbeddablePropertyInsertInput} from "@/api/__generated/model/static"

export type GenEmbeddablePropertyAddData = {
    propertyId?: number | undefined
    entityId?: number | undefined
    typeEmbeddableId?: number | undefined
}

const getUnmatchedMessageList = (data: GenEmbeddablePropertyAddData): Array<string> => {
    const messageList: Array<string> = []

    if (data.propertyId === undefined) {
        messageList.push("属性不可为空")
    }
    if (data.entityId === undefined) {
        messageList.push("实体不可为空")
    }
    if (data.typeEmbeddableId === undefined) {
        messageList.push("复合类型不可为空")
    }

    return messageList
}

export const validateGenEmbeddablePropertyAddDataForSubmit = (data: GenEmbeddablePropertyAddData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertGenEmbeddablePropertyAddDataAsSubmitType = (data: GenEmbeddablePropertyAddData): GenEmbeddablePropertyInsertInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as GenEmbeddablePropertyInsertInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
