<script setup lang="ts">
import {Search} from "@element-plus/icons-vue"
import type {
    GenExtraPropertySpec,
    GenPropertyOptionView,
    GenEntityOptionView,
    GenEnumOptionView
} from "@/api/__generated/model/static"
import GenPropertyIdSelect from "@/components/model/entities/properties/genProperty/GenPropertyIdSelect.vue"
import GenEntityIdSelect from "@/components/model/entities/genEntity/GenEntityIdSelect.vue"
import GenEnumIdSelect from "@/components/model/enums/genEnum/GenEnumIdSelect.vue"
import type {LazyOptions} from "@/utils/lazyOptions"

const spec = defineModel<GenExtraPropertySpec>({
    required: true
})

defineProps<{
    propertyIdOptions: LazyOptions<GenPropertyOptionView>,
    typeEntityIdOptions: LazyOptions<GenEntityOptionView>,
    typeEnumIdOptions: LazyOptions<GenEnumOptionView>
}>()

const emits = defineEmits<{
    (
        event: "query",
        spec: GenExtraPropertySpec
    ): void
}>()
</script>

<template>
    <el-form
        :model="spec"
        label-width="auto"
        @submit.prevent
        class="query-form"
    >
        <el-row :gutter="20">
            <el-col :span="8" :xs="24">
                <el-form-item prop="propertyId" label="属性">
                    <GenPropertyIdSelect
                        v-model="spec.propertyId"
                        :options="propertyIdOptions"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="type" label="类型">
                    <el-input
                        v-model="spec.type"
                        placeholder="请输入类型"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="typeEntityId" label="类型对应实体">
                    <GenEntityIdSelect
                        v-model="spec.typeEntityId"
                        :options="typeEntityIdOptions"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="typeEnumId" label="类型对应枚举">
                    <GenEnumIdSelect
                        v-model="spec.typeEnumId"
                        :options="typeEnumIdOptions"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="body" label="属性方法体">
                    <el-input
                        v-model="spec.body"
                        placeholder="请输入属性方法体"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-button
                type="primary"
                :icon="Search"
                class="search-button"
                @click="emits('query', spec)"
            >
                查询
            </el-button>
        </el-row>
    </el-form>
</template>
