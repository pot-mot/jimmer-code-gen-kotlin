import type {GenExtraPropertyAddData} from "./GenExtraPropertyAddData"

export const createDefaultGenExtraProperty = (): GenExtraPropertyAddData => {
    return {
        typeEmbeddableId: undefined,
        typeEntityId: undefined,
        typeEnumId: undefined,
        propertyId: undefined,
        entityId: undefined,
        type: undefined,
        body: undefined
    }
}
