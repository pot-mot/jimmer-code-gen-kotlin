import type {GenExtraPropertyAddData} from "./GenExtraPropertyAddData"

export const createDefaultGenExtraProperty = (): GenExtraPropertyAddData => {
    return {
        propertyId: undefined,
        type: "",
        typeEntityId: undefined,
        typeEnumId: undefined,
        body: undefined
    }
}
