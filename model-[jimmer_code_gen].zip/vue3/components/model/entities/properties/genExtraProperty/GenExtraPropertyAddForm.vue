<script setup lang="ts">
import {ref} from "vue"
import type {FormInstance} from "element-plus"
import type {FormExpose} from "@/components/form/FormExpose"
import type {
    GenExtraPropertyInsertInput,
    GenEmbeddableOptionView,
    GenEntityOptionView,
    GenEnumOptionView,
    GenPropertyOptionView
} from "@/api/__generated/model/static"
import {
    validateGenExtraPropertyAddDataForSubmit,
    assertGenExtraPropertyAddDataAsSubmitType
} from "@/components/model/entities/properties/genExtraProperty/GenExtraPropertyAddData"
import type {GenExtraPropertyAddData} from "@/components/model/entities/properties/genExtraProperty/GenExtraPropertyAddData"
import {createDefaultGenExtraProperty} from "@/components/model/entities/properties/genExtraProperty/createDefaultGenExtraProperty"
import {useRules} from "@/rules/model/entities/properties/genExtraProperty/GenExtraPropertyAddFormRules"
import GenEmbeddableIdSelect from "@/components/model/embeddables/genEmbeddable/GenEmbeddableIdSelect.vue"
import GenEntityIdSelect from "@/components/model/entities/genEntity/GenEntityIdSelect.vue"
import GenEnumIdSelect from "@/components/model/enums/genEnum/GenEnumIdSelect.vue"
import GenPropertyIdSelect from "@/components/model/entities/properties/genProperty/GenPropertyIdSelect.vue"
import type {LazyOptions} from "@/utils/lazyOptions"

const props = withDefaults(defineProps<{
    withOperations?: boolean | undefined,
    submitLoading?: boolean | undefined,
    typeEmbeddableIdOptions: LazyOptions<GenEmbeddableOptionView>,
    typeEntityIdOptions: LazyOptions<GenEntityOptionView>,
    typeEnumIdOptions: LazyOptions<GenEnumOptionView>,
    propertyIdOptions: LazyOptions<GenPropertyOptionView>,
    entityIdOptions: LazyOptions<GenEntityOptionView>
}>(), {
    withOperations: true,
    submitLoading: false,
})

const emits = defineEmits<{
    (
        event: "submit",
        formData: GenExtraPropertyInsertInput
    ): void,
    (event: "cancel"): void
}>()

defineSlots<{
    operations(props: {
        handleSubmit: () => Promise<void>,
        handleCancel: () => void
    }): any
}>()

const formData = ref<GenExtraPropertyAddData>(createDefaultGenExtraProperty())

const formRef = ref<FormInstance>()
const rules = useRules(formData)

// 校验
const handleValidate = async (
    errorHandler: (errors: any[]) => void = (errors) => {console.error(errors)}
): Promise<boolean> => {
    const errors: any[] = []
    const formValid: boolean = await formRef.value?.validate().catch(e => {
        errors.push(e)
        return false
    }) ?? false

    const typeValidate: boolean = validateGenExtraPropertyAddDataForSubmit(formData.value)

    errorHandler?.(errors)
    return formValid && typeValidate
}

// 提交
const handleSubmit = async (): Promise<void> => {
    if (props.submitLoading) return

    const validResult = await handleValidate()
    if (validResult) {
        emits("submit", assertGenExtraPropertyAddDataAsSubmitType(formData.value))
    }
}

// 取消
const handleCancel = (): void => {
    emits("cancel")
}

defineExpose<FormExpose>({
    validate: handleValidate
})
</script>

<template>
    <el-form
        :model="formData"
        ref="formRef"
        :rules="rules"
        label-width="auto"
        @submit.prevent
        class="add-form"
    >
        <el-form-item prop="typeEmbeddableId" label="类型对应嵌入">
            <GenEmbeddableIdSelect
                v-model="formData.typeEmbeddableId"
                :options="typeEmbeddableIdOptions"
            />
        </el-form-item>
        <el-form-item prop="typeEntityId" label="类型对应实体">
            <GenEntityIdSelect
                v-model="formData.typeEntityId"
                :options="typeEntityIdOptions"
            />
        </el-form-item>
        <el-form-item prop="typeEnumId" label="类型对应枚举">
            <GenEnumIdSelect
                v-model="formData.typeEnumId"
                :options="typeEnumIdOptions"
            />
        </el-form-item>
        <el-form-item prop="propertyId" label="属性">
            <GenPropertyIdSelect
                v-model="formData.propertyId"
                :options="propertyIdOptions"
            />
        </el-form-item>
        <el-form-item prop="entityId" label="实体">
            <GenEntityIdSelect
                v-model="formData.entityId"
                :options="entityIdOptions"
            />
        </el-form-item>
        <el-form-item prop="type" label="类型">
            <el-input
                v-model="formData.type"
                placeholder="请输入类型"
                clearable
            />
        </el-form-item>
        <el-form-item prop="body" label="属性方法体">
            <el-input
                v-model="formData.body"
                placeholder="请输入属性方法体"
                clearable
            />
        </el-form-item>

        <slot
            v-if="withOperations"
            name="operations"
            :handleSubmit="handleSubmit"
            :handleCancel="handleCancel"
        >
            <div class="form-operations">
                <el-button type="warning" @click="handleCancel">
                    取消
                </el-button>
                <el-button
                    type="primary"
                    :loading="submitLoading"
                    @click="handleSubmit"
                >
                    提交
                </el-button>
            </div>
        </slot>
    </el-form>
</template>
