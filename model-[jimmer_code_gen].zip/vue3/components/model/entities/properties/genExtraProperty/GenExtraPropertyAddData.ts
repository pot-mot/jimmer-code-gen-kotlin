import {sendMessage} from "@/utils/message"
import type {GenExtraPropertyInsertInput} from "@/api/__generated/model/static"

export type GenExtraPropertyAddData = {
    propertyId?: number | undefined
    type: string
    typeEntityId?: number | undefined
    typeEnumId?: number | undefined
    body?: string | undefined
}

const getUnmatchedMessageList = (data: GenExtraPropertyAddData): Array<string> => {
    const messageList: Array<string> = []

    if (data.propertyId === undefined) {
        messageList.push("属性不可为空")
    }

    return messageList
}

export const validateGenExtraPropertyAddDataForSubmit = (data: GenExtraPropertyAddData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertGenExtraPropertyAddDataAsSubmitType = (data: GenExtraPropertyAddData): GenExtraPropertyInsertInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as GenExtraPropertyInsertInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
