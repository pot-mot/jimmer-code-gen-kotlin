<script setup lang="ts">
import {ref} from "vue"
import type {FormInstance} from "element-plus"
import type {FormExpose} from "@/components/form/FormExpose"
import type {
    GenExtraPropertyUpdateInput,
    GenPropertyOptionView,
    GenEntityOptionView,
    GenEnumOptionView
} from "@/api/__generated/model/static"
import {
    validateGenExtraPropertyEditDataForSubmit,
    assertGenExtraPropertyEditDataAsSubmitType
} from "@/components/model/entities/properties/genExtraProperty/GenExtraPropertyEditData"
import type {GenExtraPropertyEditData} from "@/components/model/entities/properties/genExtraProperty/GenExtraPropertyEditData"
import {useRules} from "@/rules/model/entities/properties/genExtraProperty/GenExtraPropertyEditFormRules"
import GenPropertyIdSelect from "@/components/model/entities/properties/genProperty/GenPropertyIdSelect.vue"
import GenEntityIdSelect from "@/components/model/entities/genEntity/GenEntityIdSelect.vue"
import GenEnumIdSelect from "@/components/model/enums/genEnum/GenEnumIdSelect.vue"
import type {LazyOptions} from "@/utils/lazyOptions"

const formData = defineModel<GenExtraPropertyEditData>({
    required: true
})

const props = withDefaults(defineProps<{
    withOperations?: boolean | undefined,
    submitLoading?: boolean | undefined,
    propertyIdOptions: LazyOptions<GenPropertyOptionView>,
    typeEntityIdOptions: LazyOptions<GenEntityOptionView>,
    typeEnumIdOptions: LazyOptions<GenEnumOptionView>
}>(), {
    withOperations: true,
    submitLoading: false,
})

const emits = defineEmits<{
    (
        event: "submit",
        formData: GenExtraPropertyUpdateInput
    ): void,
    (event: "cancel"): void
}>()

defineSlots<{
    operations(props: {
        handleSubmit: () => Promise<void>,
        handleCancel: () => void
    }): any
}>()

const formRef = ref<FormInstance>()
const rules = useRules(formData)

// 校验
const handleValidate = async (
    errorHandler: (errors: any[]) => void = (errors) => {console.error(errors)}
): Promise<boolean> => {
    const errors: any[] = []
    const formValid: boolean = await formRef.value?.validate().catch(e => {
        errors.push(e)
        return false
    }) ?? false

    const typeValidate: boolean = validateGenExtraPropertyEditDataForSubmit(formData.value)

    errorHandler?.(errors)
    return formValid && typeValidate
}

// 提交
const handleSubmit = async (): Promise<void> => {
    if (props.submitLoading) return

    const validResult = await handleValidate()
    if (validResult) {
        emits("submit", assertGenExtraPropertyEditDataAsSubmitType(formData.value))
    }
}

// 取消
const handleCancel = (): void => {
    emits("cancel")
}

defineExpose<FormExpose>({
    validate: handleValidate
})
</script>

<template>
    <el-form
        :model="formData"
        ref="formRef"
        :rules="rules"
        label-width="auto"
        @submit.prevent
        class="edit-form"
    >
        <el-form-item prop="propertyId" label="属性">
            <GenPropertyIdSelect
                v-model="formData.propertyId"
                :options="propertyIdOptions"
            />
        </el-form-item>
        <el-form-item prop="type" label="类型">
            <el-input
                v-model="formData.type"
                placeholder="请输入类型"
                clearable
            />
        </el-form-item>
        <el-form-item prop="typeEntityId" label="类型对应实体">
            <GenEntityIdSelect
                v-model="formData.typeEntityId"
                :options="typeEntityIdOptions"
            />
        </el-form-item>
        <el-form-item prop="typeEnumId" label="类型对应枚举">
            <GenEnumIdSelect
                v-model="formData.typeEnumId"
                :options="typeEnumIdOptions"
            />
        </el-form-item>
        <el-form-item prop="body" label="属性方法体">
            <el-input
                v-model="formData.body"
                placeholder="请输入属性方法体"
                clearable
            />
        </el-form-item>

        <slot
            v-if="withOperations"
            name="operations"
            :handleSubmit="handleSubmit"
            :handleCancel="handleCancel"
        >
            <div class="form-operations">
                <el-button type="warning" @click="handleCancel">
                    取消
                </el-button>
                <el-button
                    type="primary"
                    :loading="submitLoading"
                    @click="handleSubmit"
                >
                    提交
                </el-button>
            </div>
        </slot>
    </el-form>
</template>
