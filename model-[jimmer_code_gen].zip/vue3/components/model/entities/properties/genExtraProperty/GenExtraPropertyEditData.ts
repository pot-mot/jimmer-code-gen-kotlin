import {sendMessage} from "@/utils/message"
import type {GenExtraPropertyUpdateInput} from "@/api/__generated/model/static"

export type GenExtraPropertyEditData = {
    id: number
    propertyId?: number | undefined
    type: string
    typeEntityId?: number | undefined
    typeEnumId?: number | undefined
    body?: string | undefined
}

const getUnmatchedMessageList = (data: GenExtraPropertyEditData): Array<string> => {
    const messageList: Array<string> = []

    if (data.propertyId === undefined) {
        messageList.push("属性不可为空")
    }

    return messageList
}

export const validateGenExtraPropertyEditDataForSubmit = (data: GenExtraPropertyEditData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertGenExtraPropertyEditDataAsSubmitType = (data: GenExtraPropertyEditData): GenExtraPropertyUpdateInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as GenExtraPropertyUpdateInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
