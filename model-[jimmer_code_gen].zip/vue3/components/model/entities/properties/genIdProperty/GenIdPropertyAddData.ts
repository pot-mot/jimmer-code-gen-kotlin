import {sendMessage} from "@/utils/message"
import type {GenIdPropertyInsertInput} from "@/api/__generated/model/static"

export type GenIdPropertyAddData = {
    propertyId?: number | undefined
    generatedIdAnnotation?: string | undefined
}

const getUnmatchedMessageList = (data: GenIdPropertyAddData): Array<string> => {
    const messageList: Array<string> = []

    if (data.propertyId === undefined) {
        messageList.push("属性不可为空")
    }

    return messageList
}

export const validateGenIdPropertyAddDataForSubmit = (data: GenIdPropertyAddData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertGenIdPropertyAddDataAsSubmitType = (data: GenIdPropertyAddData): GenIdPropertyInsertInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as GenIdPropertyInsertInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
