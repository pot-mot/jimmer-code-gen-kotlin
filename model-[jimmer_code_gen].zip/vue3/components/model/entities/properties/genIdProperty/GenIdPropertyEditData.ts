import {sendMessage} from "@/utils/message"
import type {GenIdPropertyUpdateInput} from "@/api/__generated/model/static"

export type GenIdPropertyEditData = {
    id: number
    propertyId?: number | undefined
    generatedIdAnnotation?: string | undefined
}

const getUnmatchedMessageList = (data: GenIdPropertyEditData): Array<string> => {
    const messageList: Array<string> = []

    if (data.propertyId === undefined) {
        messageList.push("属性不可为空")
    }

    return messageList
}

export const validateGenIdPropertyEditDataForSubmit = (data: GenIdPropertyEditData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertGenIdPropertyEditDataAsSubmitType = (data: GenIdPropertyEditData): GenIdPropertyUpdateInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as GenIdPropertyUpdateInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
