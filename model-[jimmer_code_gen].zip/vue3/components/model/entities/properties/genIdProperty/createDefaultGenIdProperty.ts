import type {GenIdPropertyAddData} from "./GenIdPropertyAddData"

export const createDefaultGenIdProperty = (): GenIdPropertyAddData => {
    return {
        propertyId: undefined,
        generatedIdAnnotation: undefined
    }
}
