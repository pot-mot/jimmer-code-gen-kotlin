import type {GenIdPropertyAddData} from "./GenIdPropertyAddData"

export const createDefaultGenIdProperty = (): GenIdPropertyAddData => {
    return {
        jdbcTypeCode: 0,
        rawType: "",
        typeIsNotNull: false,
        dataSize: undefined,
        numericPrecision: undefined,
        columnDefaultExp: undefined,
        propertyId: undefined,
        columnName: "",
        type: "",
        eratedIdAnnotation: undefined
    }
}
