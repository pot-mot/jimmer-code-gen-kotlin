<script setup lang="ts">
import {ref} from "vue"
import type {FormInstance} from "element-plus"
import type {FormExpose} from "@/components/form/FormExpose"
import type {
    GenManyToManySourcePropertyInsertInput,
    GenEntityOptionView,
    GenPropertyOptionView
} from "@/api/__generated/model/static"
import {
    validateGenManyToManySourcePropertyAddDataForSubmit,
    assertGenManyToManySourcePropertyAddDataAsSubmitType
} from "@/components/model/entities/properties/genManyToManySourceProperty/GenManyToManySourcePropertyAddData"
import type {GenManyToManySourcePropertyAddData} from "@/components/model/entities/properties/genManyToManySourceProperty/GenManyToManySourcePropertyAddData"
import {createDefaultGenManyToManySourceProperty} from "@/components/model/entities/properties/genManyToManySourceProperty/createDefaultGenManyToManySourceProperty"
import {useRules} from "@/rules/model/entities/properties/genManyToManySourceProperty/GenManyToManySourcePropertyAddFormRules"
import GenEntityIdSelect from "@/components/model/entities/genEntity/GenEntityIdSelect.vue"
import GenPropertyIdSelect from "@/components/model/entities/properties/genProperty/GenPropertyIdSelect.vue"
import type {LazyOptions} from "@/utils/lazyOptions"

const props = withDefaults(defineProps<{
    withOperations?: boolean | undefined,
    submitLoading?: boolean | undefined,
    typeEntityIdOptions: LazyOptions<GenEntityOptionView>,
    propertyIdOptions: LazyOptions<GenPropertyOptionView>
}>(), {
    withOperations: true,
    submitLoading: false,
})

const emits = defineEmits<{
    (
        event: "submit",
        formData: GenManyToManySourcePropertyInsertInput
    ): void,
    (event: "cancel"): void
}>()

defineSlots<{
    operations(props: {
        handleSubmit: () => Promise<void>,
        handleCancel: () => void
    }): any
}>()

const formData = ref<GenManyToManySourcePropertyAddData>(createDefaultGenManyToManySourceProperty())

const formRef = ref<FormInstance>()
const rules = useRules(formData)

// 校验
const handleValidate = async (
    errorHandler: (errors: any[]) => void = (errors) => {console.error(errors)}
): Promise<boolean> => {
    const errors: any[] = []
    const formValid: boolean = await formRef.value?.validate().catch(e => {
        errors.push(e)
        return false
    }) ?? false

    const typeValidate: boolean = validateGenManyToManySourcePropertyAddDataForSubmit(formData.value)

    errorHandler?.(errors)
    return formValid && typeValidate
}

// 提交
const handleSubmit = async (): Promise<void> => {
    if (props.submitLoading) return

    const validResult = await handleValidate()
    if (validResult) {
        emits("submit", assertGenManyToManySourcePropertyAddDataAsSubmitType(formData.value))
    }
}

// 取消
const handleCancel = (): void => {
    emits("cancel")
}

defineExpose<FormExpose>({
    validate: handleValidate
})
</script>

<template>
    <el-form
        :model="formData"
        ref="formRef"
        :rules="rules"
        label-width="auto"
        @submit.prevent
        class="add-form"
    >
        <el-form-item prop="typeEntityId" label="类型对应实体">
            <GenEntityIdSelect
                v-model="formData.typeEntityId"
                :options="typeEntityIdOptions"
            />
        </el-form-item>
        <el-form-item prop="propertyId" label="属性">
            <GenPropertyIdSelect
                v-model="formData.propertyId"
                :options="propertyIdOptions"
            />
        </el-form-item>
        <el-form-item prop="idViewName" label="ID视图名">
            <el-input
                v-model="formData.idViewName"
                placeholder="请输入ID视图名"
                clearable
            />
        </el-form-item>

        <slot
            v-if="withOperations"
            name="operations"
            :handleSubmit="handleSubmit"
            :handleCancel="handleCancel"
        >
            <div class="form-operations">
                <el-button type="warning" @click="handleCancel">
                    取消
                </el-button>
                <el-button
                    type="primary"
                    :loading="submitLoading"
                    @click="handleSubmit"
                >
                    提交
                </el-button>
            </div>
        </slot>
    </el-form>
</template>
