import {sendMessage} from "@/utils/message"
import type {GenManyToManySourcePropertyUpdateInput} from "@/api/__generated/model/static"

export type GenManyToManySourcePropertyEditData = {
    id: number
    typeEntityId?: number | undefined
    genManyToManyMappedPropertyId?: number | undefined
    propertyId?: number | undefined
    idViewName: string
}

const getUnmatchedMessageList = (data: GenManyToManySourcePropertyEditData): Array<string> => {
    const messageList: Array<string> = []

    if (data.typeEntityId === undefined) {
        messageList.push("类型对应实体不可为空")
    }
    if (data.propertyId === undefined) {
        messageList.push("属性不可为空")
    }

    return messageList
}

export const validateGenManyToManySourcePropertyEditDataForSubmit = (data: GenManyToManySourcePropertyEditData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertGenManyToManySourcePropertyEditDataAsSubmitType = (data: GenManyToManySourcePropertyEditData): GenManyToManySourcePropertyUpdateInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as GenManyToManySourcePropertyUpdateInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
