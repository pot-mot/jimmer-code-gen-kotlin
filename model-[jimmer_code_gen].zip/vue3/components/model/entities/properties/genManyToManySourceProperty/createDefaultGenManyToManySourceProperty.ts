import type {GenManyToManySourcePropertyAddData} from "./GenManyToManySourcePropertyAddData"

export const createDefaultGenManyToManySourceProperty = (): GenManyToManySourcePropertyAddData => {
    return {
        typeEntityId: undefined,
        propertyId: undefined,
        idViewName: ""
    }
}
