import {sendMessage} from "@/utils/message"
import type {GenManyToManySourcePropertyInsertInput} from "@/api/__generated/model/static"

export type GenManyToManySourcePropertyAddData = {
    typeEntityId?: number | undefined
    propertyId?: number | undefined
    idViewName: string
}

const getUnmatchedMessageList = (data: GenManyToManySourcePropertyAddData): Array<string> => {
    const messageList: Array<string> = []

    if (data.typeEntityId === undefined) {
        messageList.push("类型对应实体不可为空")
    }
    if (data.propertyId === undefined) {
        messageList.push("属性不可为空")
    }

    return messageList
}

export const validateGenManyToManySourcePropertyAddDataForSubmit = (data: GenManyToManySourcePropertyAddData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertGenManyToManySourcePropertyAddDataAsSubmitType = (data: GenManyToManySourcePropertyAddData): GenManyToManySourcePropertyInsertInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as GenManyToManySourcePropertyInsertInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
