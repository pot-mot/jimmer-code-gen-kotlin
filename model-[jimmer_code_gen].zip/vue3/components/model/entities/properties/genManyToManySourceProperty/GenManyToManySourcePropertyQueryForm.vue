<script setup lang="ts">
import {Search} from "@element-plus/icons-vue"
import type {
    GenManyToManySourcePropertySpec,
    GenEntityOptionView,
    GenManyToManyMappedPropertyOptionView,
    GenPropertyOptionView
} from "@/api/__generated/model/static"
import GenEntityIdSelect from "@/components/model/entities/genEntity/GenEntityIdSelect.vue"
import GenManyToManyMappedPropertyIdSelect from "@/components/model/entities/properties/genManyToManyMappedProperty/GenManyToManyMappedPropertyIdSelect.vue"
import GenPropertyIdSelect from "@/components/model/entities/properties/genProperty/GenPropertyIdSelect.vue"
import type {LazyOptions} from "@/utils/lazyOptions"

const spec = defineModel<GenManyToManySourcePropertySpec>({
    required: true
})

defineProps<{
    typeEntityIdOptions: LazyOptions<GenEntityOptionView>,
    genManyToManyMappedPropertyIdOptions: LazyOptions<GenManyToManyMappedPropertyOptionView>,
    propertyIdOptions: LazyOptions<GenPropertyOptionView>
}>()

const emits = defineEmits<{
    (
        event: "query",
        spec: GenManyToManySourcePropertySpec
    ): void
}>()
</script>

<template>
    <el-form
        :model="spec"
        label-width="auto"
        @submit.prevent
        class="query-form"
    >
        <el-row :gutter="20">
            <el-col :span="8" :xs="24">
                <el-form-item prop="typeEntityId" label="类型对应实体">
                    <GenEntityIdSelect
                        v-model="spec.typeEntityId"
                        :options="typeEntityIdOptions"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item
                    prop="genManyToManyMappedPropertyId"
                    label="多对多映射属性"
                >
                    <GenManyToManyMappedPropertyIdSelect
                        v-model="spec.genManyToManyMappedPropertyId"
                        :options="genManyToManyMappedPropertyIdOptions"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="propertyId" label="属性">
                    <GenPropertyIdSelect
                        v-model="spec.propertyId"
                        :options="propertyIdOptions"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="idViewName" label="ID视图名">
                    <el-input
                        v-model="spec.idViewName"
                        placeholder="请输入ID视图名"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-button
                type="primary"
                :icon="Search"
                class="search-button"
                @click="emits('query', spec)"
            >
                查询
            </el-button>
        </el-row>
    </el-form>
</template>
