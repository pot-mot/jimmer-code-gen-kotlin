import {sendMessage} from "@/utils/message"
import type {GenManyToOneMappedPropertyInsertInput} from "@/api/__generated/model/static"

export type GenManyToOneMappedPropertyAddData = {
    typeEntityId?: number | undefined
    propertyId?: number | undefined
    mappedById?: number | undefined
    idViewName: string
}

const getUnmatchedMessageList = (data: GenManyToOneMappedPropertyAddData): Array<string> => {
    const messageList: Array<string> = []

    if (data.typeEntityId === undefined) {
        messageList.push("类型对应实体不可为空")
    }
    if (data.propertyId === undefined) {
        messageList.push("属性不可为空")
    }
    if (data.mappedById === undefined) {
        messageList.push("对应源属性不可为空")
    }

    return messageList
}

export const validateGenManyToOneMappedPropertyAddDataForSubmit = (data: GenManyToOneMappedPropertyAddData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertGenManyToOneMappedPropertyAddDataAsSubmitType = (data: GenManyToOneMappedPropertyAddData): GenManyToOneMappedPropertyInsertInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as GenManyToOneMappedPropertyInsertInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
