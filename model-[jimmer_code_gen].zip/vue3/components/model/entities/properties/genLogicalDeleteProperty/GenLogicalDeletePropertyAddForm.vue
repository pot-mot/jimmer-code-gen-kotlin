<script setup lang="ts">
import {ref} from "vue"
import type {FormInstance} from "element-plus"
import type {FormExpose} from "@/components/form/FormExpose"
import type {
    GenLogicalDeletePropertyInsertInput,
    GenEnumOptionView,
    GenPropertyOptionView
} from "@/api/__generated/model/static"
import {
    validateGenLogicalDeletePropertyAddDataForSubmit,
    assertGenLogicalDeletePropertyAddDataAsSubmitType
} from "@/components/model/entities/properties/genLogicalDeleteProperty/GenLogicalDeletePropertyAddData"
import type {GenLogicalDeletePropertyAddData} from "@/components/model/entities/properties/genLogicalDeleteProperty/GenLogicalDeletePropertyAddData"
import {createDefaultGenLogicalDeleteProperty} from "@/components/model/entities/properties/genLogicalDeleteProperty/createDefaultGenLogicalDeleteProperty"
import {useRules} from "@/rules/model/entities/properties/genLogicalDeleteProperty/GenLogicalDeletePropertyAddFormRules"
import GenEnumIdSelect from "@/components/model/enums/genEnum/GenEnumIdSelect.vue"
import GenPropertyIdSelect from "@/components/model/entities/properties/genProperty/GenPropertyIdSelect.vue"
import type {LazyOptions} from "@/utils/lazyOptions"

const props = withDefaults(defineProps<{
    withOperations?: boolean | undefined,
    submitLoading?: boolean | undefined,
    typeEnumIdOptions: LazyOptions<GenEnumOptionView>,
    propertyIdOptions: LazyOptions<GenPropertyOptionView>
}>(), {
    withOperations: true,
    submitLoading: false,
})

const emits = defineEmits<{
    (
        event: "submit",
        formData: GenLogicalDeletePropertyInsertInput
    ): void,
    (event: "cancel"): void
}>()

defineSlots<{
    operations(props: {
        handleSubmit: () => Promise<void>,
        handleCancel: () => void
    }): any
}>()

const formData = ref<GenLogicalDeletePropertyAddData>(createDefaultGenLogicalDeleteProperty())

const formRef = ref<FormInstance>()
const rules = useRules(formData)

// 校验
const handleValidate = async (
    errorHandler: (errors: any[]) => void = (errors) => {console.error(errors)}
): Promise<boolean> => {
    const errors: any[] = []
    const formValid: boolean = await formRef.value?.validate().catch(e => {
        errors.push(e)
        return false
    }) ?? false

    const typeValidate: boolean = validateGenLogicalDeletePropertyAddDataForSubmit(formData.value)

    errorHandler?.(errors)
    return formValid && typeValidate
}

// 提交
const handleSubmit = async (): Promise<void> => {
    if (props.submitLoading) return

    const validResult = await handleValidate()
    if (validResult) {
        emits("submit", assertGenLogicalDeletePropertyAddDataAsSubmitType(formData.value))
    }
}

// 取消
const handleCancel = (): void => {
    emits("cancel")
}

defineExpose<FormExpose>({
    validate: handleValidate
})
</script>

<template>
    <el-form
        :model="formData"
        ref="formRef"
        :rules="rules"
        label-width="auto"
        @submit.prevent
        class="add-form"
    >
        <el-form-item prop="jdbcTypeCode" label="JdbcType 码值">
            <el-input-number
                v-model.number="formData.jdbcTypeCode"
                placeholder="请输入JdbcType 码值"
                :precision="0"
                :min="0"
                :max="2147483647"
                :value-on-clear="'min'"
            />
        </el-form-item>
        <el-form-item prop="rawType" label="字面类型">
            <el-input
                v-model="formData.rawType"
                placeholder="请输入字面类型"
                clearable
            />
        </el-form-item>
        <el-form-item prop="typeIsNotNull" label="类型是否非空">
            <el-switch v-model="formData.typeIsNotNull"/>
        </el-form-item>
        <el-form-item prop="dataSize" label="长度">
            <el-input-number
                v-model.number="formData.dataSize"
                placeholder="请输入长度"
                :precision="0"
                :max="2147483647"
                :value-on-clear="undefined"
            />
        </el-form-item>
        <el-form-item prop="numericPrecision" label="精度">
            <el-input-number
                v-model.number="formData.numericPrecision"
                placeholder="请输入精度"
                :precision="0"
                :max="2147483647"
                :value-on-clear="undefined"
            />
        </el-form-item>
        <el-form-item prop="columnDefaultExp" label="列默认表达式">
            <el-input
                v-model="formData.columnDefaultExp"
                placeholder="请输入列默认表达式"
                clearable
            />
        </el-form-item>
        <el-form-item prop="typeEnumId" label="类型对应枚举">
            <GenEnumIdSelect
                v-model="formData.typeEnumId"
                :options="typeEnumIdOptions"
            />
        </el-form-item>
        <el-form-item prop="propertyId" label="属性">
            <GenPropertyIdSelect
                v-model="formData.propertyId"
                :options="propertyIdOptions"
            />
        </el-form-item>
        <el-form-item prop="type" label="类型">
            <el-input
                v-model="formData.type"
                placeholder="请输入类型"
                clearable
            />
        </el-form-item>
        <el-form-item
            prop="logicalDeletedAnnotation"
            label="逻辑删除注解"
        >
            <el-input
                v-model="formData.logicalDeletedAnnotation"
                placeholder="请输入逻辑删除注解"
                clearable
            />
        </el-form-item>
        <el-form-item prop="columnName" label="列名称">
            <el-input
                v-model="formData.columnName"
                placeholder="请输入列名称"
                clearable
            />
        </el-form-item>

        <slot
            v-if="withOperations"
            name="operations"
            :handleSubmit="handleSubmit"
            :handleCancel="handleCancel"
        >
            <div class="form-operations">
                <el-button type="warning" @click="handleCancel">
                    取消
                </el-button>
                <el-button
                    type="primary"
                    :loading="submitLoading"
                    @click="handleSubmit"
                >
                    提交
                </el-button>
            </div>
        </slot>
    </el-form>
</template>
