import {sendMessage} from "@/utils/message"
import type {GenLogicalDeletePropertyUpdateInput} from "@/api/__generated/model/static"

export type GenLogicalDeletePropertyEditData = {
    id: number
    jdbcTypeCode: number
    rawType: string
    typeIsNotNull: boolean
    dataSize?: number | undefined
    numericPrecision?: number | undefined
    columnDefaultExp?: string | undefined
    typeEnumId?: number | undefined
    propertyId?: number | undefined
    type?: string | undefined
    logicalDeletedAnnotation: string
    columnName: string
}

const getUnmatchedMessageList = (data: GenLogicalDeletePropertyEditData): Array<string> => {
    const messageList: Array<string> = []

    if (data.propertyId === undefined) {
        messageList.push("属性不可为空")
    }

    return messageList
}

export const validateGenLogicalDeletePropertyEditDataForSubmit = (data: GenLogicalDeletePropertyEditData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertGenLogicalDeletePropertyEditDataAsSubmitType = (data: GenLogicalDeletePropertyEditData): GenLogicalDeletePropertyUpdateInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as GenLogicalDeletePropertyUpdateInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
