import {sendMessage} from "@/utils/message"
import type {GenLogicalDeletePropertyInsertInput} from "@/api/__generated/model/static"

export type GenLogicalDeletePropertyAddData = {
    propertyId?: number | undefined
    logicalDeletedAnnotation: string
}

const getUnmatchedMessageList = (data: GenLogicalDeletePropertyAddData): Array<string> => {
    const messageList: Array<string> = []

    if (data.propertyId === undefined) {
        messageList.push("属性不可为空")
    }

    return messageList
}

export const validateGenLogicalDeletePropertyAddDataForSubmit = (data: GenLogicalDeletePropertyAddData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertGenLogicalDeletePropertyAddDataAsSubmitType = (data: GenLogicalDeletePropertyAddData): GenLogicalDeletePropertyInsertInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as GenLogicalDeletePropertyInsertInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
