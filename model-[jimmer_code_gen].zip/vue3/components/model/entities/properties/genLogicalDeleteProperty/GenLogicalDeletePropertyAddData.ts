import {sendMessage} from "@/utils/message"
import type {GenLogicalDeletePropertyInsertInput} from "@/api/__generated/model/static"

export type GenLogicalDeletePropertyAddData = {
    jdbcTypeCode: number
    rawType: string
    typeIsNotNull: boolean
    dataSize?: number | undefined
    numericPrecision?: number | undefined
    columnDefaultExp?: string | undefined
    typeEnumId?: number | undefined
    propertyId?: number | undefined
    type?: string | undefined
    logicalDeletedAnnotation: string
    columnName: string
}

const getUnmatchedMessageList = (data: GenLogicalDeletePropertyAddData): Array<string> => {
    const messageList: Array<string> = []

    if (data.propertyId === undefined) {
        messageList.push("属性不可为空")
    }

    return messageList
}

export const validateGenLogicalDeletePropertyAddDataForSubmit = (data: GenLogicalDeletePropertyAddData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertGenLogicalDeletePropertyAddDataAsSubmitType = (data: GenLogicalDeletePropertyAddData): GenLogicalDeletePropertyInsertInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as GenLogicalDeletePropertyInsertInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
