<script setup lang="ts">
import {ref} from "vue"
import type {FormInstance} from "element-plus"
import type {FormExpose} from "@/components/form/FormExpose"
import type {
    GenLogicalDeletePropertyUpdateInput,
    GenPropertyOptionView
} from "@/api/__generated/model/static"
import {
    validateGenLogicalDeletePropertyEditDataForSubmit,
    assertGenLogicalDeletePropertyEditDataAsSubmitType
} from "@/components/model/entities/properties/genLogicalDeleteProperty/GenLogicalDeletePropertyEditData"
import type {GenLogicalDeletePropertyEditData} from "@/components/model/entities/properties/genLogicalDeleteProperty/GenLogicalDeletePropertyEditData"
import {useRules} from "@/rules/model/entities/properties/genLogicalDeleteProperty/GenLogicalDeletePropertyEditFormRules"
import GenPropertyIdSelect from "@/components/model/entities/properties/genProperty/GenPropertyIdSelect.vue"
import type {LazyOptions} from "@/utils/lazyOptions"

const formData = defineModel<GenLogicalDeletePropertyEditData>({
    required: true
})

const props = withDefaults(defineProps<{
    withOperations?: boolean | undefined,
    submitLoading?: boolean | undefined,
    propertyIdOptions: LazyOptions<GenPropertyOptionView>
}>(), {
    withOperations: true,
    submitLoading: false,
})

const emits = defineEmits<{
    (
        event: "submit",
        formData: GenLogicalDeletePropertyUpdateInput
    ): void,
    (event: "cancel"): void
}>()

defineSlots<{
    operations(props: {
        handleSubmit: () => Promise<void>,
        handleCancel: () => void
    }): any
}>()

const formRef = ref<FormInstance>()
const rules = useRules(formData)

// 校验
const handleValidate = async (
    errorHandler: (errors: any[]) => void = (errors) => {console.error(errors)}
): Promise<boolean> => {
    const errors: any[] = []
    const formValid: boolean = await formRef.value?.validate().catch(e => {
        errors.push(e)
        return false
    }) ?? false

    const typeValidate: boolean = validateGenLogicalDeletePropertyEditDataForSubmit(formData.value)

    errorHandler?.(errors)
    return formValid && typeValidate
}

// 提交
const handleSubmit = async (): Promise<void> => {
    if (props.submitLoading) return

    const validResult = await handleValidate()
    if (validResult) {
        emits("submit", assertGenLogicalDeletePropertyEditDataAsSubmitType(formData.value))
    }
}

// 取消
const handleCancel = (): void => {
    emits("cancel")
}

defineExpose<FormExpose>({
    validate: handleValidate
})
</script>

<template>
    <el-form
        :model="formData"
        ref="formRef"
        :rules="rules"
        label-width="auto"
        @submit.prevent
        class="edit-form"
    >
        <el-form-item prop="propertyId" label="属性">
            <GenPropertyIdSelect
                v-model="formData.propertyId"
                :options="propertyIdOptions"
            />
        </el-form-item>
        <el-form-item
            prop="logicalDeletedAnnotation"
            label="逻辑删除注解"
        >
            <el-input
                v-model="formData.logicalDeletedAnnotation"
                placeholder="请输入逻辑删除注解"
                clearable
            />
        </el-form-item>

        <slot
            v-if="withOperations"
            name="operations"
            :handleSubmit="handleSubmit"
            :handleCancel="handleCancel"
        >
            <div class="form-operations">
                <el-button type="warning" @click="handleCancel">
                    取消
                </el-button>
                <el-button
                    type="primary"
                    :loading="submitLoading"
                    @click="handleSubmit"
                >
                    提交
                </el-button>
            </div>
        </slot>
    </el-form>
</template>
