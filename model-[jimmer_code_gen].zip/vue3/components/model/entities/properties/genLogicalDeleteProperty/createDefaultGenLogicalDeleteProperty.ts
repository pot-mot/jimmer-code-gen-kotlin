import type {GenLogicalDeletePropertyAddData} from "./GenLogicalDeletePropertyAddData"

export const createDefaultGenLogicalDeleteProperty = (): GenLogicalDeletePropertyAddData => {
    return {
        jdbcTypeCode: 0,
        rawType: "",
        typeIsNotNull: false,
        dataSize: undefined,
        numericPrecision: undefined,
        columnDefaultExp: undefined,
        typeEnumId: undefined,
        propertyId: undefined,
        type: undefined,
        logicalDeletedAnnotation: "",
        columnName: ""
    }
}
