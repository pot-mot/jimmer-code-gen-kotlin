import type {GenLogicalDeletePropertyAddData} from "./GenLogicalDeletePropertyAddData"

export const createDefaultGenLogicalDeleteProperty = (): GenLogicalDeletePropertyAddData => {
    return {
        propertyId: undefined,
        logicalDeletedAnnotation: ""
    }
}
