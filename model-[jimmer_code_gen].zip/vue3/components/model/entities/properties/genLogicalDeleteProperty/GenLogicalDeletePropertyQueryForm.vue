<script setup lang="ts">
import {Search} from "@element-plus/icons-vue"
import type {
    GenLogicalDeletePropertySpec,
    GenPropertyOptionView
} from "@/api/__generated/model/static"
import GenPropertyIdSelect from "@/components/model/entities/properties/genProperty/GenPropertyIdSelect.vue"
import type {LazyOptions} from "@/utils/lazyOptions"

const spec = defineModel<GenLogicalDeletePropertySpec>({
    required: true
})

defineProps<{
    propertyIdOptions: LazyOptions<GenPropertyOptionView>
}>()

const emits = defineEmits<{
    (
        event: "query",
        spec: GenLogicalDeletePropertySpec
    ): void
}>()
</script>

<template>
    <el-form
        :model="spec"
        label-width="auto"
        @submit.prevent
        class="query-form"
    >
        <el-row :gutter="20">
            <el-col :span="8" :xs="24">
                <el-form-item prop="propertyId" label="属性">
                    <GenPropertyIdSelect
                        v-model="spec.propertyId"
                        :options="propertyIdOptions"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item
                    prop="logicalDeletedAnnotation"
                    label="逻辑删除注解"
                >
                    <el-input
                        v-model="spec.logicalDeletedAnnotation"
                        placeholder="请输入逻辑删除注解"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-button
                type="primary"
                :icon="Search"
                class="search-button"
                @click="emits('query', spec)"
            >
                查询
            </el-button>
        </el-row>
    </el-form>
</template>
