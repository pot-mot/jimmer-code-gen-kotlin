import {sendMessage} from "@/utils/message"
import type {GenColumnPropertyInsertInput} from "@/api/__generated/model/static"

export type GenColumnPropertyAddData = {
    jdbcTypeCode: number
    rawType: string
    typeIsNotNull: boolean
    dataSize?: number | undefined
    numericPrecision?: number | undefined
    columnDefaultExp?: string | undefined
    propertyId?: number | undefined
    entityId?: number | undefined
    type: string
    columnName: string
}

const getUnmatchedMessageList = (data: GenColumnPropertyAddData): Array<string> => {
    const messageList: Array<string> = []

    if (data.propertyId === undefined) {
        messageList.push("属性不可为空")
    }
    if (data.entityId === undefined) {
        messageList.push("实体不可为空")
    }

    return messageList
}

export const validateGenColumnPropertyAddDataForSubmit = (data: GenColumnPropertyAddData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertGenColumnPropertyAddDataAsSubmitType = (data: GenColumnPropertyAddData): GenColumnPropertyInsertInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as GenColumnPropertyInsertInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
