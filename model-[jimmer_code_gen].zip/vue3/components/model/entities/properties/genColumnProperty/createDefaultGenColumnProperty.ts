import type {GenColumnPropertyAddData} from "./GenColumnPropertyAddData"

export const createDefaultGenColumnProperty = (): GenColumnPropertyAddData => {
    return {
        jdbcTypeCode: 0,
        rawType: "",
        typeIsNotNull: false,
        dataSize: undefined,
        numericPrecision: undefined,
        columnDefaultExp: undefined,
        propertyId: undefined,
        entityId: undefined,
        type: "",
        columnName: ""
    }
}
