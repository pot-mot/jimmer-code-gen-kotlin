import {sendMessage} from "@/utils/message"
import type {GenColumnPropertyUpdateInput} from "@/api/__generated/model/static"

export type GenColumnPropertyEditData = {
    id: number
    jdbcTypeCode: number
    rawType: string
    typeIsNotNull: boolean
    dataSize?: number | undefined
    numericPrecision?: number | undefined
    columnDefaultExp?: string | undefined
    propertyId?: number | undefined
    entityId?: number | undefined
    type: string
    columnName: string
}

const getUnmatchedMessageList = (data: GenColumnPropertyEditData): Array<string> => {
    const messageList: Array<string> = []

    if (data.propertyId === undefined) {
        messageList.push("属性不可为空")
    }
    if (data.entityId === undefined) {
        messageList.push("实体不可为空")
    }

    return messageList
}

export const validateGenColumnPropertyEditDataForSubmit = (data: GenColumnPropertyEditData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertGenColumnPropertyEditDataAsSubmitType = (data: GenColumnPropertyEditData): GenColumnPropertyUpdateInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as GenColumnPropertyUpdateInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
