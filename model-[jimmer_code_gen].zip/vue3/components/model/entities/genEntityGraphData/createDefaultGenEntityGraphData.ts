import type {GenEntityGraphDataAddData} from "./GenEntityGraphDataAddData"

export const createDefaultGenEntityGraphData = (): GenEntityGraphDataAddData => {
    return {
        x: 0,
        y: 0
    }
}
