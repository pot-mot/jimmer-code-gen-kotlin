import {sendMessage} from "@/utils/message"
import type {GenEntityGraphDataUpdateInput} from "@/api/__generated/model/static"

export type GenEntityGraphDataEditData = {
    id: number
    x: number
    y: number
}

const getUnmatchedMessageList = (data: GenEntityGraphDataEditData): Array<string> => {
    const messageList: Array<string> = []


    return messageList
}

export const validateGenEntityGraphDataEditDataForSubmit = (data: GenEntityGraphDataEditData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertGenEntityGraphDataEditDataAsSubmitType = (data: GenEntityGraphDataEditData): GenEntityGraphDataUpdateInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as GenEntityGraphDataUpdateInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
