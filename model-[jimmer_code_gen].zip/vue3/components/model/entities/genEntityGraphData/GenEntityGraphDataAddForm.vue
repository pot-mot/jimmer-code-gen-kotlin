<script setup lang="ts">
import {ref} from "vue"
import type {FormInstance} from "element-plus"
import type {FormExpose} from "@/components/form/FormExpose"
import type {GenEntityGraphDataInsertInput} from "@/api/__generated/model/static"
import {
    validateGenEntityGraphDataAddDataForSubmit,
    assertGenEntityGraphDataAddDataAsSubmitType
} from "@/components/model/entities/genEntityGraphData/GenEntityGraphDataAddData"
import type {GenEntityGraphDataAddData} from "@/components/model/entities/genEntityGraphData/GenEntityGraphDataAddData"
import {createDefaultGenEntityGraphData} from "@/components/model/entities/genEntityGraphData/createDefaultGenEntityGraphData"
import {useRules} from "@/rules/model/entities/genEntityGraphData/GenEntityGraphDataAddFormRules"

const props = withDefaults(defineProps<{
    withOperations?: boolean | undefined,
    submitLoading?: boolean | undefined
}>(), {
    withOperations: true,
    submitLoading: false,
})

const emits = defineEmits<{
    (
        event: "submit",
        formData: GenEntityGraphDataInsertInput
    ): void,
    (event: "cancel"): void
}>()

defineSlots<{
    operations(props: {
        handleSubmit: () => Promise<void>,
        handleCancel: () => void
    }): any
}>()

const formData = ref<GenEntityGraphDataAddData>(createDefaultGenEntityGraphData())

const formRef = ref<FormInstance>()
const rules = useRules(formData)

// 校验
const handleValidate = async (
    errorHandler: (errors: any[]) => void = (errors) => {console.error(errors)}
): Promise<boolean> => {
    const errors: any[] = []
    const formValid: boolean = await formRef.value?.validate().catch(e => {
        errors.push(e)
        return false
    }) ?? false

    const typeValidate: boolean = validateGenEntityGraphDataAddDataForSubmit(formData.value)

    errorHandler?.(errors)
    return formValid && typeValidate
}

// 提交
const handleSubmit = async (): Promise<void> => {
    if (props.submitLoading) return

    const validResult = await handleValidate()
    if (validResult) {
        emits("submit", assertGenEntityGraphDataAddDataAsSubmitType(formData.value))
    }
}

// 取消
const handleCancel = (): void => {
    emits("cancel")
}

defineExpose<FormExpose>({
    validate: handleValidate
})
</script>

<template>
    <el-form
        :model="formData"
        ref="formRef"
        :rules="rules"
        label-width="auto"
        @submit.prevent
        class="add-form"
    >
        <el-form-item prop="x" label="X坐标">
            <el-input-number
                v-model.number="formData.x"
                placeholder="请输入X坐标"
                :precision="0"
            />
        </el-form-item>
        <el-form-item prop="y" label="Y坐标">
            <el-input-number
                v-model.number="formData.y"
                placeholder="请输入Y坐标"
                :precision="0"
            />
        </el-form-item>

        <slot
            v-if="withOperations"
            name="operations"
            :handleSubmit="handleSubmit"
            :handleCancel="handleCancel"
        >
            <div class="form-operations">
                <el-button type="warning" @click="handleCancel">
                    取消
                </el-button>
                <el-button
                    type="primary"
                    :loading="submitLoading"
                    @click="handleSubmit"
                >
                    提交
                </el-button>
            </div>
        </slot>
    </el-form>
</template>
