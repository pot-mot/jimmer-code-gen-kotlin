import {sendMessage} from "@/utils/message"
import type {GenEntityGraphDataInsertInput} from "@/api/__generated/model/static"

export type GenEntityGraphDataAddData = {
    x: number
    y: number
}

const getUnmatchedMessageList = (data: GenEntityGraphDataAddData): Array<string> => {
    const messageList: Array<string> = []


    return messageList
}

export const validateGenEntityGraphDataAddDataForSubmit = (data: GenEntityGraphDataAddData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertGenEntityGraphDataAddDataAsSubmitType = (data: GenEntityGraphDataAddData): GenEntityGraphDataInsertInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as GenEntityGraphDataInsertInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
