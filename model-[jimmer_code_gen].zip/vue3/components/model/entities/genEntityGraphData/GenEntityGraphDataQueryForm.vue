<script setup lang="ts">
import {Search} from "@element-plus/icons-vue"
import type {GenEntityGraphDataSpec} from "@/api/__generated/model/static"

const spec = defineModel<GenEntityGraphDataSpec>({
    required: true
})

const emits = defineEmits<{
    (
        event: "query",
        spec: GenEntityGraphDataSpec
    ): void
}>()
</script>

<template>
    <el-form
        :model="spec"
        label-width="auto"
        @submit.prevent
        class="query-form"
    >
        <el-row :gutter="20">
            <el-col :span="8" :xs="24">
                <el-form-item prop="x" label="X坐标">
                    <el-input-number
                        v-model.number="spec.minX"
                        placeholder="最小"
                        :precision="0"
                        :value-on-clear="undefined"
                        @change="emits('query', spec)"
                    />
                    <el-input-number
                        v-model.number="spec.maxX"
                        placeholder="最大"
                        :precision="0"
                        :value-on-clear="undefined"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="y" label="Y坐标">
                    <el-input-number
                        v-model.number="spec.minY"
                        placeholder="最小"
                        :precision="0"
                        :value-on-clear="undefined"
                        @change="emits('query', spec)"
                    />
                    <el-input-number
                        v-model.number="spec.maxY"
                        placeholder="最大"
                        :precision="0"
                        :value-on-clear="undefined"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-button
                type="primary"
                :icon="Search"
                class="search-button"
                @click="emits('query', spec)"
            >
                查询
            </el-button>
        </el-row>
    </el-form>
</template>
