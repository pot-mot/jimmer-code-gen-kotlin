<script setup lang="ts">
import {ref} from "vue"
import type {FormInstance} from "element-plus"
import type {FormExpose} from "@/components/form/FormExpose"
import type {
    GenEntityIndexUpdateInput,
    GenEntityKeyGroupOptionView,
    GenEntityOptionView
} from "@/api/__generated/model/static"
import {
    validateGenEntityIndexEditDataForSubmit,
    assertGenEntityIndexEditDataAsSubmitType
} from "@/components/model/entities/genEntityIndex/GenEntityIndexEditData"
import type {GenEntityIndexEditData} from "@/components/model/entities/genEntityIndex/GenEntityIndexEditData"
import {useRules} from "@/rules/model/entities/genEntityIndex/GenEntityIndexEditFormRules"
import GenEntityKeyGroupIdSelect from "@/components/model/entities/genEntityKeyGroup/GenEntityKeyGroupIdSelect.vue"
import GenEntityIdSelect from "@/components/model/entities/genEntity/GenEntityIdSelect.vue"
import type {LazyOptions} from "@/utils/lazyOptions"

const formData = defineModel<GenEntityIndexEditData>({
    required: true
})

const props = withDefaults(defineProps<{
    withOperations?: boolean | undefined,
    submitLoading?: boolean | undefined,
    entityKeyGroupIdOptions: LazyOptions<GenEntityKeyGroupOptionView>,
    entityIdOptions: LazyOptions<GenEntityOptionView>
}>(), {
    withOperations: true,
    submitLoading: false,
})

const emits = defineEmits<{
    (
        event: "submit",
        formData: GenEntityIndexUpdateInput
    ): void,
    (event: "cancel"): void
}>()

defineSlots<{
    operations(props: {
        handleSubmit: () => Promise<void>,
        handleCancel: () => void
    }): any
}>()

const formRef = ref<FormInstance>()
const rules = useRules(formData)

// 校验
const handleValidate = async (
    errorHandler: (errors: any[]) => void = (errors) => {console.error(errors)}
): Promise<boolean> => {
    const errors: any[] = []
    const formValid: boolean = await formRef.value?.validate().catch(e => {
        errors.push(e)
        return false
    }) ?? false

    const typeValidate: boolean = validateGenEntityIndexEditDataForSubmit(formData.value)

    errorHandler?.(errors)
    return formValid && typeValidate
}

// 提交
const handleSubmit = async (): Promise<void> => {
    if (props.submitLoading) return

    const validResult = await handleValidate()
    if (validResult) {
        emits("submit", assertGenEntityIndexEditDataAsSubmitType(formData.value))
    }
}

// 取消
const handleCancel = (): void => {
    emits("cancel")
}

defineExpose<FormExpose>({
    validate: handleValidate
})
</script>

<template>
    <el-form
        :model="formData"
        ref="formRef"
        :rules="rules"
        label-width="auto"
        @submit.prevent
        class="edit-form"
    >
        <el-form-item prop="entityKeyGroupId" label="实体业务键组">
            <GenEntityKeyGroupIdSelect
                v-model="formData.entityKeyGroupId"
                :options="entityKeyGroupIdOptions"
            />
        </el-form-item>
        <el-form-item prop="entityId" label="归属表">
            <GenEntityIdSelect
                v-model="formData.entityId"
                :options="entityIdOptions"
            />
        </el-form-item>
        <el-form-item prop="name" label="名称">
            <el-input
                v-model="formData.name"
                placeholder="请输入名称"
                clearable
            />
        </el-form-item>
        <el-form-item prop="uniqueIndex" label="是否是唯一索引">
            <el-switch v-model="formData.uniqueIndex"/>
        </el-form-item>
        <el-form-item prop="remark" label="备注">
            <el-input
                v-model="formData.remark"
                placeholder="请输入备注"
                clearable
            />
        </el-form-item>

        <slot
            v-if="withOperations"
            name="operations"
            :handleSubmit="handleSubmit"
            :handleCancel="handleCancel"
        >
            <div class="form-operations">
                <el-button type="warning" @click="handleCancel">
                    取消
                </el-button>
                <el-button
                    type="primary"
                    :loading="submitLoading"
                    @click="handleSubmit"
                >
                    提交
                </el-button>
            </div>
        </slot>
    </el-form>
</template>
