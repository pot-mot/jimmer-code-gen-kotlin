import type {GenEntityIndexAddData} from "./GenEntityIndexAddData"

export const createDefaultGenEntityIndex = (): GenEntityIndexAddData => {
    return {
        entityId: undefined,
        name: "",
        uniqueIndex: false,
        remark: ""
    }
}
