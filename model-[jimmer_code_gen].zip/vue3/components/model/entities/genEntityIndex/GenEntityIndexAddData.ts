import {sendMessage} from "@/utils/message"
import type {GenEntityIndexInsertInput} from "@/api/__generated/model/static"

export type GenEntityIndexAddData = {
    entityId?: number | undefined
    name: string
    uniqueIndex: boolean
    remark: string
    orderKey: number
}

const getUnmatchedMessageList = (data: GenEntityIndexAddData): Array<string> => {
    const messageList: Array<string> = []

    if (data.entityId === undefined) {
        messageList.push("归属表不可为空")
    }

    return messageList
}

export const validateGenEntityIndexAddDataForSubmit = (data: GenEntityIndexAddData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertGenEntityIndexAddDataAsSubmitType = (data: GenEntityIndexAddData): GenEntityIndexInsertInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as GenEntityIndexInsertInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
