import {sendMessage} from "@/utils/message"
import type {GenEntityIndexUpdateInput} from "@/api/__generated/model/static"

export type GenEntityIndexEditData = {
    id: number
    genEntityKeyGroupId?: number | undefined
    entityId?: number | undefined
    name: string
    uniqueIndex: boolean
    remark: string
    orderKey: number
}

const getUnmatchedMessageList = (data: GenEntityIndexEditData): Array<string> => {
    const messageList: Array<string> = []

    if (data.entityId === undefined) {
        messageList.push("归属表不可为空")
    }

    return messageList
}

export const validateGenEntityIndexEditDataForSubmit = (data: GenEntityIndexEditData): boolean => {
    const messageList = getUnmatchedMessageList(data)
    return messageList.length === 0
}

export const assertGenEntityIndexEditDataAsSubmitType = (data: GenEntityIndexEditData): GenEntityIndexUpdateInput => {
    const messageList = getUnmatchedMessageList(data)
    if (messageList.length === 0) {
        return data as GenEntityIndexUpdateInput
    }
     else {
        messageList.forEach(message => sendMessage(message, "error"))
        throw messageList
    }
}
