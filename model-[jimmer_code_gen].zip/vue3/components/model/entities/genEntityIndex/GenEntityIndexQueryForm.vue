<script setup lang="ts">
import {Search} from "@element-plus/icons-vue"
import type {
    GenEntityIndexSpec,
    GenEntityKeyGroupOptionView,
    GenEntityOptionView
} from "@/api/__generated/model/static"
import GenEntityKeyGroupIdSelect from "@/components/model/entities/genEntityKeyGroup/GenEntityKeyGroupIdSelect.vue"
import GenEntityIdSelect from "@/components/model/entities/genEntity/GenEntityIdSelect.vue"
import type {LazyOptions} from "@/utils/lazyOptions"

const spec = defineModel<GenEntityIndexSpec>({
    required: true
})

defineProps<{
    entityKeyGroupIdOptions: LazyOptions<GenEntityKeyGroupOptionView>,
    entityIdOptions: LazyOptions<GenEntityOptionView>
}>()

const emits = defineEmits<{
    (event: "query", spec: GenEntityIndexSpec): void
}>()
</script>

<template>
    <el-form
        :model="spec"
        label-width="auto"
        @submit.prevent
        class="query-form"
    >
        <el-row :gutter="20">
            <el-col :span="8" :xs="24">
                <el-form-item prop="entityKeyGroupId" label="实体业务键组">
                    <GenEntityKeyGroupIdSelect
                        v-model="spec.entityKeyGroupId"
                        :options="entityKeyGroupIdOptions"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="entityId" label="归属表">
                    <GenEntityIdSelect
                        v-model="spec.entityId"
                        :options="entityIdOptions"
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="name" label="名称">
                    <el-input
                        v-model="spec.name"
                        placeholder="请输入名称"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="uniqueIndex" label="是否是唯一索引">
                    <el-select
                        v-model="spec.uniqueIndex"
                        placeholder="请选择是否是唯一索引"
                        clearable
                        :value-on-clear="undefined"
                        @change="emits('query', spec)"
                    >
                        <el-option :value="true" label="是"/>
                        <el-option :value="false" label="否"/>
                    </el-select>
                </el-form-item>
            </el-col>
            <el-col :span="8" :xs="24">
                <el-form-item prop="remark" label="备注">
                    <el-input
                        v-model="spec.remark"
                        placeholder="请输入备注"
                        clearable
                        @change="emits('query', spec)"
                    />
                </el-form-item>
            </el-col>
            <el-button
                type="primary"
                :icon="Search"
                class="search-button"
                @click="emits('query', spec)"
            >
                查询
            </el-button>
        </el-row>
    </el-form>
</template>
