<script setup lang="ts">
import type {DevLanguage} from "@/api/__generated/model/enums"

defineProps<{
    value: DevLanguage | undefined
}>()
</script>

<template>
    <el-text v-if="value === 'Kotlin'">
        Kotlin
    </el-text>
    <el-text v-else-if="value === 'Java'">
        Java
    </el-text>
</template>
