<script setup lang="ts">
import {DevLanguage_CONSTANTS} from "@/api/__generated/model/enums"
import type {DevLanguage} from "@/api/__generated/model/enums"
import DevLanguageView from "@/components/enums/devLanguage/DevLanguageView.vue"

const modelValue = defineModel<DevLanguage>({
    required: true
})
</script>

<template>
    <el-select
        v-model="modelValue"
        placeholder="请选择开发语言"
        filterable
    >
        <el-option
            v-for="option in DevLanguage_CONSTANTS"
            :value="option"
        >
            <DevLanguageView :value="option"/>
        </el-option>
        <template #label="{value}">
            <DevLanguageView :value="value"/>
        </template>
    </el-select>
</template>
