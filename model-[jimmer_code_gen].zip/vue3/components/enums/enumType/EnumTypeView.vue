<script setup lang="ts">
import type {EnumType} from "@/api/__generated/model/enums"

defineProps<{value: EnumType}>()
</script>

<template>
    <el-text v-if="value === 'DEFAULT'">
        默认
    </el-text>
    <el-text v-else-if="value === 'NAME'">
        名称
    </el-text>
    <el-text v-else-if="value === 'ORDINAL'">
        序号
    </el-text>
</template>
