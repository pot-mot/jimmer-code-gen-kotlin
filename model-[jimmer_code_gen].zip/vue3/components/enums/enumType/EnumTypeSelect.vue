<script setup lang="ts">
import {EnumType_CONSTANTS} from "@/api/__generated/model/enums"
import type {EnumType} from "@/api/__generated/model/enums"
import EnumTypeView from "@/components/enums/enumType/EnumTypeView.vue"

const modelValue = defineModel<EnumType>({
    required: true
})
</script>

<template>
    <el-select
        v-model="modelValue"
        placeholder="请选择枚举类型"
        filterable
    >
        <el-option
            v-for="option in EnumType_CONSTANTS"
            :value="option"
        >
            <EnumTypeView :value="option"/>
        </el-option>
        <template #label="{value}">
            <EnumTypeView :value="value"/>
        </template>
    </el-select>
</template>
