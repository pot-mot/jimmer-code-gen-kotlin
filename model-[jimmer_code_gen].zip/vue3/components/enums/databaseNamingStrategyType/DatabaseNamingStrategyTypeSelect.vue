<script setup lang="ts">
import {DatabaseNamingStrategyType_CONSTANTS} from "@/api/__generated/model/enums"
import type {DatabaseNamingStrategyType} from "@/api/__generated/model/enums"
import DatabaseNamingStrategyTypeView from "@/components/enums/databaseNamingStrategyType/DatabaseNamingStrategyTypeView.vue"

const modelValue = defineModel<DatabaseNamingStrategyType>({
    required: true
})
</script>

<template>
    <el-select
        v-model="modelValue"
        placeholder="请选择数据库命名策略"
        filterable
    >
        <el-option
            v-for="option in DatabaseNamingStrategyType_CONSTANTS"
            :value="option"
        >
            <DatabaseNamingStrategyTypeView :value="option"/>
        </el-option>
        <template #label="{value}">
            <DatabaseNamingStrategyTypeView :value="value"/>
        </template>
    </el-select>
</template>
