<script setup lang="ts">
import type {DatabaseNamingStrategyType} from "@/api/__generated/model/enums"

defineProps<{
    value: DatabaseNamingStrategyType
}>()
</script>

<template>
    <el-text v-if="value === 'RAW'">
        字面
    </el-text>
    <el-text v-else-if="value === 'LOWER_CASE'">
        全小写
    </el-text>
    <el-text v-else-if="value === 'UPPER_CASE'">
        全大写
    </el-text>
</template>
