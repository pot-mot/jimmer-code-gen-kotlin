<script setup lang="ts">
import type {TableType} from "@/api/__generated/model/enums"

defineProps<{value: TableType}>()
</script>

<template>
    <el-text v-if="value === 'TABLE'">
        TABLE
    </el-text>
    <el-text v-else-if="value === 'VIEW'">
        VIEW
    </el-text>
    <el-text v-else-if="value === 'SYSTEM_TABLE'">
        SYSTEM_TABLE
    </el-text>
    <el-text v-else-if="value === 'GLOBAL_TEMPORARY'">
        GLOBAL_TEMPORARY
    </el-text>
    <el-text v-else-if="value === 'LOCAL_TEMPORARY'">
        LOCAL_TEMPORARY
    </el-text>
    <el-text v-else-if="value === 'ALIAS'">
        ALIAS
    </el-text>
    <el-text v-else-if="value === 'UNKNOWN'">
        UNKNOWN
    </el-text>
</template>
