<script setup lang="ts">
import {TableType_CONSTANTS} from "@/api/__generated/model/enums"
import type {TableType} from "@/api/__generated/model/enums"
import TableTypeView from "@/components/enums/tableType/TableTypeView.vue"

const modelValue = defineModel<TableType | undefined>({
    required: true
})
</script>

<template>
    <el-select
        v-model="modelValue"
        placeholder="请选择表类型"
        filterable
        clearable
        :value-on-clear="undefined"
    >
        <el-option
            v-for="option in TableType_CONSTANTS"
            :value="option"
        >
            <TableTypeView :value="option"/>
        </el-option>
        <template #label="{value}">
            <TableTypeView :value="value"/>
        </template>
    </el-select>
</template>
