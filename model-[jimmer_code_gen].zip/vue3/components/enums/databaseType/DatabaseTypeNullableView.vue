<script setup lang="ts">
import type {DatabaseType} from "@/api/__generated/model/enums"

defineProps<{
    value: DatabaseType | undefined
}>()
</script>

<template>
    <el-text v-if="value === 'H2'">
        H2
    </el-text>
    <el-text v-else-if="value === 'MySQL'">
        MySQL
    </el-text>
    <el-text v-else-if="value === 'PostgreSQL'">
        PostgreSQL
    </el-text>
</template>
