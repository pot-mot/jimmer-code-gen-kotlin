<script setup lang="ts">
import {DatabaseType_CONSTANTS} from "@/api/__generated/model/enums"
import type {DatabaseType} from "@/api/__generated/model/enums"
import DatabaseTypeView from "@/components/enums/databaseType/DatabaseTypeView.vue"

const modelValue = defineModel<DatabaseType>({
    required: true
})
</script>

<template>
    <el-select
        v-model="modelValue"
        placeholder="请选择数据库类型"
        filterable
    >
        <el-option
            v-for="option in DatabaseType_CONSTANTS"
            :value="option"
        >
            <DatabaseTypeView :value="option"/>
        </el-option>
        <template #label="{value}">
            <DatabaseTypeView :value="value"/>
        </template>
    </el-select>
</template>
