<script setup lang="ts">
import type {OrderDirection} from "@/api/__generated/model/enums"

defineProps<{value: OrderDirection}>()
</script>

<template>
    <el-text v-if="value === 'ASC'">
        顺序
    </el-text>
    <el-text v-else-if="value === 'DESC'">
        逆序
    </el-text>
</template>
