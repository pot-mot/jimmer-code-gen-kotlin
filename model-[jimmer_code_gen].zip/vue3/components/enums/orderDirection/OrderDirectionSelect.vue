<script setup lang="ts">
import {OrderDirection_CONSTANTS} from "@/api/__generated/model/enums"
import type {OrderDirection} from "@/api/__generated/model/enums"
import OrderDirectionView from "@/components/enums/orderDirection/OrderDirectionView.vue"

const modelValue = defineModel<OrderDirection>({
    required: true
})
</script>

<template>
    <el-select
        v-model="modelValue"
        placeholder="请选择排序方向"
        filterable
    >
        <el-option
            v-for="option in OrderDirection_CONSTANTS"
            :value="option"
        >
            <OrderDirectionView :value="option"/>
        </el-option>
        <template #label="{value}">
            <OrderDirectionView :value="value"/>
        </template>
    </el-select>
</template>
